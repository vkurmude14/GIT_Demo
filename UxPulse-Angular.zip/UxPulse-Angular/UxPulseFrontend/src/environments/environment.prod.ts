export const environment = {
  production: true,
};
export const BASE_URL = {
  tomcat: "http://localhost:8089",
  springBoot: "http://localhost:8080",
};
export const WAR_NAME: string = "uxpulse";
