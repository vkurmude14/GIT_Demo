export interface LoginDto {
    email: string;
    password: string;
}