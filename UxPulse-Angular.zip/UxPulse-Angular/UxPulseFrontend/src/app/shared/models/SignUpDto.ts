export interface SignUpDto {
  email: string;
  password: string;
  name: string;
}
