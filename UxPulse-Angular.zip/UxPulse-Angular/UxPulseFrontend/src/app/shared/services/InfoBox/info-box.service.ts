import { Injectable } from "@angular/core";
import { UrlorScript } from "src/app/modules/scheduler/url-script/url-script.component";

export interface infoStyle {
  name: string;
  color: string;
}

@Injectable({
  providedIn: "root",
})
export class InfoBoxService {
  constructor() {}

  infoData: infoStyle[] = [];
  locations: string[] = [];
  urlOrScript: UrlorScript[] = [];
  from : string=null;
  to : string =null;
  inntervalUnit : string =null;
  interval : string =null;
  requestLabel : string =null;

  calendarClicked : boolean=false;

  geturlOrLabels(): UrlorScript[] {
    return this.urlOrScript;
  }

  pushUrlOrLabels(data: any) {
    this.urlOrScript.push(data);
  }
  getLocations() {
    return this.locations;
  }

  pushLocations(data: string) {
    this.locations.push(data);
  }

  popLocations(data: string) {
    const index: number = this.locations.indexOf(data);
    if (index !== -1) {
      this.locations.splice(index, 1);
    }
  }
  getInfoData() {
    return this.infoData;
  }

  pushInfoData(data: infoStyle) {
    this.infoData.push(data);
  }
}
