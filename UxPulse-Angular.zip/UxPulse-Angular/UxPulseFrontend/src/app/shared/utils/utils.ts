export const getDataFromHttpResponse = (response: any) => {
  return response.data;
};

export const encodeBase64 = (str) => {
  return btoa(str);
};
export const decodeBase64 = (str) => {
  return atob(str);
};

export const isUserLoggedIn = async (): Promise<boolean> => {
  return localStorage.getItem("token") != null ? true : false;
};
export const getUserInfo = async (): Promise<any> => {
  if (true === (await isUserLoggedIn())) {
    return JSON.parse(localStorage.getItem("token"));
  } else return null;
};
