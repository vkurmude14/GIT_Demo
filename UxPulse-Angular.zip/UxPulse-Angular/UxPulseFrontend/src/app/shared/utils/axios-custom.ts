import Axios from "axios";
import { API_URL } from "../../core/config/config";

export const axiosInstance = Axios.create({
  baseURL: API_URL,
  timeout: 50000,
  responseType: "json",
});
axiosInstance.defaults.headers.post["Content-Type"] = "application/json";
// Add a request interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    // Do something before request is sent
    // console.log("from req interceptor");
    return config;
  },
  (error) => {
    // Do something with request error
    return Promise.reject(error);
  }
);

// Add a response interceptor
axiosInstance.interceptors.response.use(
  (response) => {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    // console.log("from res interceptor");
    return response;
  },
  (error) => {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return Promise.reject(error);
  }
);
