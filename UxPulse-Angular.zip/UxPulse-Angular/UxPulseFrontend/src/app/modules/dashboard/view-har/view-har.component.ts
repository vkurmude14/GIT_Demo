import { Component, OnInit, ViewEncapsulation, Input } from "@angular/core";
import { DashboardService } from "../dashboardService/dashboard.service";
import { ActivatedRoute } from "@angular/router";
import * as $ from "jquery";
import * as _get from "lodash/get";

@Component({
  selector: "uxpulse-view-har",
  templateUrl: "./view-har.component.html",
  styleUrls: [
    "./view-har.component.css",
    "./css/harPreview.css",
    "./css/toolbar.css",
    "./css/toolTip.css",
    "./css/infoTip.css",
    "./css/aboutTab.css",
    "./css/domTab.css",
    "./css/domTree.css",
    "./css/dragdrop.css",
    "./css/pageStats.css",
    "./css/pageList.css",
    "./css/pageTimeline.css",
  ],
  encapsulation: ViewEncapsulation.None,
})
export class ViewHarComponent implements OnInit {
  constructor(
    private dashboardService: DashboardService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(async (params) => {
      let username = params["username"];
      let reqLabel = params["reqLabel"];
      let scheduleLabel = params["scheduleLabel"];
      let groupId = params["groupId"];
      let testId = params["testId"];
      let dashboardService = this.dashboardService;
      if (username && reqLabel && scheduleLabel && groupId && testId) {
        try {
          var path = await dashboardService.getHarData(
            username,
            reqLabel,
            scheduleLabel,
            groupId,
            testId
          );
          (function ($) {
            $("#content").bind("onViewerPreInit", function (event) {
              var viewer = _get(event, ["target", "repObject"]);
              viewer.removeTab("Home");
              viewer.removeTab("DOM");
              viewer.removeTab("About");
              viewer.removeTab("Schema");
              //viewer.removeTab("Preview");

              // Hide the tab bar
              viewer.showTabBar(false);

              var preview = viewer.getTab("Preview");
              preview.showStats(true);
              preview.showTimeline(false);
              viewer.loadHar(path);
            });
          })($);
        } catch (err) {
          console.log(err);
        }
      } else {
        alert("The link is broken");
      }
    });
  }
}
