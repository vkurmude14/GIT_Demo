//models
//-----------------------------------------------------
export interface Badge {
  title: string;
  value: number;
  info: string;
  measuringUnit: string;
}
export interface BarChartData {
  label: string;
  time: string;
  testID: string;
  groupID: string;
  StartRender: number;
  DocComplete: number;
  FullyLoaded: number;
}

export interface ParametersKeyValuePair {
  key: string;
  value: string;
}

export interface SlowElementObject {
  type: string;
  time: string;
  href: string;
  component: string;
}
export interface HeavyElementObject {
  type: string;
  size: string;
  href: string;
  component: string;
}

//constants
//-----------------------------------------------------
export const WPT_SPECIFIC_FILTERS = [
  { value: "docComplete", viewValue: "Doc complete" },
  { value: "startRender", viewValue: "Start render" },
  // { value: "visually-complete", viewValue: "Visually complete" },
  { value: "fullyLoaded", viewValue: "Fully loaded" },
  // { value: "ttfb", viewValue: "TTFB" },
  { value: "requests", viewValue: "requests" },
  { value: "bytesIn", viewValue: "Bytes in" },
];
export const UXPULSE_SPECIFIC_FILTERS = [
  { value: "label", viewValue: "Label" },
  { value: "location", viewValue: "Location" },
  { value: "browser", viewValue: "Browser" },
  { value: "network", viewValue: "Network" },
  { value: "isCustomer", viewValue: "IsCustomer" },
];

export const VIEW_SPECIFIC_FILTER = [
  { value: "firstView", viewValue: "First View" },
  { value: "repeatView", viewValue: "Repeat View" },
];
export const ISCUSTOMER_FILTER = new Set([
  { value: true, viewValue: "Yes" },
  { value: false, viewValue: "No" },
]);

export const DEFAULT_FILTER_STATE = [
  WPT_SPECIFIC_FILTERS[0],
  UXPULSE_SPECIFIC_FILTERS[0],
  VIEW_SPECIFIC_FILTER[0],
];

export const BAR_CHART_COLORS = ["#9ecae1", "#4292c6", "#08519c"];
