import {
  Component,
  OnInit,
  NgZone,
  AfterViewInit,
  Input,
  SimpleChanges,
  OnChanges,
  OnDestroy,
} from "@angular/core";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import am4themes_kelly from "@amcharts/amcharts4/themes/kelly";
import * as _ from "lodash";
import { EventEmitter, Output } from "@angular/core";
am4core.useTheme(am4themes_animated);
am4core.useTheme(am4themes_kelly);

@Component({
  selector: "uxpulse-trending-chart",
  templateUrl: "./trending-chart.component.html",
  styleUrls: ["./trending-chart.component.css"],
})
export class TrendingChartComponent
  implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  title = "uxpulsecharts";
  private chart: am4charts.XYChart;

  constructor(private zone: NgZone) {}
  @Input()
  dataArr: [];

  @Output()
  startChanged = new EventEmitter();
  @Output()
  endChanged = new EventEmitter();

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.chart != undefined) this.dataArr = changes.dataArr.currentValue;
    this.ngAfterViewInit();
  }
  ngAfterViewInit() {
    this.zone.runOutsideAngular(async () => {
      if (undefined != this.chart) this.chart.dispose();
      this.chart = am4core.create("chartdiv", am4charts.XYChart);
      // ... chart code goes here ...

      this.chart.legend = new am4charts.Legend();

      // chart.data = this.data;
      // Create axes
      let dateAxis = this.chart.xAxes.push(new am4charts.DateAxis());
      dateAxis.renderer.minGridDistance = 60;
      dateAxis.events.on("startchanged", (ev) => {
        let start = new Date(ev.target.minZoomed);
        let end = new Date(ev.target.maxZoomed);
        this.startChanged.emit(start);
        this.endChanged.emit(end);
      });
      dateAxis.events.on("endchanged", (ev) => {
        let start = new Date(ev.target.minZoomed);
        let end = new Date(ev.target.maxZoomed);
        this.startChanged.emit(start);
        this.endChanged.emit(end);
      });

      let valueAxis = this.chart.yAxes.push(new am4charts.ValueAxis());

      var createSeries = async (data, name) => {
        let series = this.chart.series.push(new am4charts.LineSeries());
        series.dataFields.valueY = "value";
        series.dataFields.dateX = "date";
        series.tooltipText = "{name}:{valueY}";
        series.data = data;
        series.name = name;
        series.tensionX = 0.99;
        series.tooltip.pointerOrientation = "vertical";
        series.strokeWidth = 3;
      };
      this.dataArr.forEach(async (val) => {
        await createSeries(_.get(val, "values"), _.get(val, "key"));
      });

      // await createSeries("value", this.dataArr);

      this.chart.cursor = new am4charts.XYCursor();
      this.chart.cursor.xAxis = dateAxis;

      this.chart.scrollbarY = new am4core.Scrollbar();
      this.chart.scrollbarX = new am4core.Scrollbar();

      this.chart = this.chart;
    });
  }

  ngOnDestroy() {
    this.zone.runOutsideAngular(() => {
      if (this.chart) {
        this.chart.dispose();
      }
    });
  }
}
