import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import * as _ from "lodash";
import {
  WPT_SPECIFIC_FILTERS,
  UXPULSE_SPECIFIC_FILTERS,
  VIEW_SPECIFIC_FILTER,
} from "../config/utils";

@Component({
  selector: "uxpulse-trending",
  templateUrl: "./trending.component.html",
  styleUrls: ["./trending.component.css"],
})
export class TrendingComponent implements OnInit {
  constructor() {}

  //filter entries
  //------------------------------

  wptFilters = [];
  @Output()
  wptFilterChosenEvent = new EventEmitter();
  uxPulseFilters = [];
  @Output()
  uxPulseFilterChosenEvent = new EventEmitter();
  viewFilters = [];
  @Output()
  viewFilterChosenEvent = new EventEmitter();
  @Input()
  labels = [];
  @Output()
  labelChosenEvent = new EventEmitter();
  @Input()
  locations = [];
  @Output()
  locationChosenEvent = new EventEmitter();
  @Input()
  browsers = [];
  @Output()
  browserChosenEvent = new EventEmitter();
  @Input()
  isCustomerList = [];
  @Output()
  isCustomerChosenEvent = new EventEmitter();
  @Input()
  networks = [];
  @Output()
  networkChosenEvent = new EventEmitter();
  @Input()
  trendingData: [];

  //chosenValue
  //------------------------------
  chosenWptFilter: any;
  chosenUxPulseFilter: any;
  chosenViewFilter: any;

  //toggle Filter
  //------------------------------
  showFilters = false;

  //trending chart date range modified
  //------------------------------
  @Output()
  trendingChartStartRangeChanged = new EventEmitter();
  @Output()
  trendingChartEndRangeChanged = new EventEmitter();

  ngOnInit(): void {
    this.wptFilters = WPT_SPECIFIC_FILTERS;
    this.uxPulseFilters = UXPULSE_SPECIFIC_FILTERS;
    this.viewFilters = VIEW_SPECIFIC_FILTER;

    this.setDefaults();
  }
  setDefaults = () => {
    this.chosenUxPulseFilter = UXPULSE_SPECIFIC_FILTERS[0];
    this.chosenViewFilter = VIEW_SPECIFIC_FILTER[0];
    this.chosenWptFilter = WPT_SPECIFIC_FILTERS[0];
  };

  //event handlers for dropdowns
  //-------------------------------------------------------------------
  handleWptFilterChange = (event: any) => {
    this.wptFilterChosenEvent.emit(_.get(event, ["value", "value"]));
  };
  handleViewFilterChange = (event: any) => {
    this.viewFilterChosenEvent.emit(_.get(event, ["value", "value"]));
  };
  handleUxPulseFilterChange = (event: any) => {
    this.uxPulseFilterChosenEvent.emit(_.get(event, ["value", "value"]));
  };

  //event Handler for Filters
  //-------------------------------------------------------------------
  handleLabelFilterChange = (event: any) => {
    this.labelChosenEvent.emit(_.get(event, "value"));
  };
  handleLocationFilterChange = (event: any) => {
    this.locationChosenEvent.emit(_.get(event, "value"));
  };
  handleBrowserFilterChange = (event: any) => {
    this.browserChosenEvent.emit(_.get(event, "value"));
  };
  handleIsCustomerFilterChange = (event: any) => {
    this.isCustomerChosenEvent.emit(_.get(event, "value"));
  };
  handleNetworkFilterChange = (event: any) => {
    this.networkChosenEvent.emit(_.get(event, "value"));
  };
  //event Handler for chosen range in trending chart
  //----------------------------------------------------------------------
  handleTrendingChartEndChanged = (event: any) => {
    this.trendingChartEndRangeChanged.emit(event);
  };
  handleTrendingChartStartChanged = (event: any) => {
    this.trendingChartStartRangeChanged.emit(event);
  };
}
