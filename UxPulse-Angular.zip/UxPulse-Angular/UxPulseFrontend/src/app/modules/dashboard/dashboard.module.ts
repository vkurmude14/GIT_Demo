import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { DashboardRoutingModule } from "./dashboard-routing.module";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { BadgeComponent } from "./badge/badge.component";
import { CustomMaterialModule } from "../../core/design/custom-material/custom-material.module";
import { TrendingComponent } from "./trending/trending.component";
import { TrendingChartComponent } from "./trending/trending-chart/trending-chart.component";
import { BarChartComponent } from "./bar-chart/bar-chart.component";
import { SiteBreakdownComponent } from "./site-breakdown/site-breakdown.component";
import { DashboardService } from "./dashboardService/dashboard.service";
import { CrossfilterService } from "./crossfilter/crossfilter.service";
import { PieChartDomainComponent } from "./pie-chart-domains/pie-chart-domains.component";
import { PieChartBreakdownsComponent } from "./pie-chart-breakdowns/pie-chart-breakdowns.component";
import { ViewHarComponent } from "./view-har/view-har.component";

@NgModule({
  declarations: [
    DashboardComponent,
    BadgeComponent,
    TrendingComponent,
    TrendingChartComponent,
    BarChartComponent,
    SiteBreakdownComponent,
    PieChartDomainComponent,
    PieChartBreakdownsComponent,
    ViewHarComponent,
  ],
  imports: [CommonModule, DashboardRoutingModule, CustomMaterialModule],
  providers: [DashboardService, CrossfilterService],
})
export class DashboardModule {}
