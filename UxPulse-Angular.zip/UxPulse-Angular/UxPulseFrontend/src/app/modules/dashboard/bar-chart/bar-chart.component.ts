import {
  Component,
  OnInit,
  NgZone,
  Output,
  EventEmitter,
  AfterViewInit,
  SimpleChanges,
  OnChanges,
} from "@angular/core";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as _ from "lodash";
import { Input } from "@angular/core";
import { BAR_CHART_COLORS } from "../config/utils";

am4core.useTheme(am4themes_animated);
/* am4core.useTheme(am4themes_kelly);  */

@Component({
  selector: "uxpulse-bar-chart",
  templateUrl: "./bar-chart.component.html",
  styleUrls: ["./bar-chart.component.css"],
})
export class BarChartComponent implements OnInit, AfterViewInit, OnChanges {
  @Input()
  dataArr = [];

  @Output()
  hitOn = new EventEmitter();
  @Output()
  hoveringOn = new EventEmitter();

  @Output()
  startChanged = new EventEmitter();
  @Output()
  endChanged = new EventEmitter();

  private chart: am4charts.XYChart;

  constructor(private zone: NgZone) {}

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (undefined != this.chart) {
      this.dataArr = _.get(changes, ["dataArr", "currentValue"]);
      this.ngAfterViewInit();
    }
  }

  async ngAfterViewInit() {
    this.zone.runOutsideAngular(() => {
      if (undefined != this.chart) this.chart.dispose();
      var chart = am4core.create("barchartdiv", am4charts.XYChart);
      // ... chart code goes here ...

      chart.data = this.dataArr;

      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "time";
      categoryAxis.renderer.minGridDistance = 250;
      categoryAxis.title.text = "Execution Date/Time";
      categoryAxis.events.on("endchanged", this.endChangedEvent);
      categoryAxis.events.on("startchanged", this.startChangedEvent);
      var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.title.text = "Seconds (M)";

      chart.dateFormatter.inputDateFormat = "dd/MM-H:m";

      // Add cursor
      chart.cursor = new am4charts.XYCursor();

      // Add legend
      chart.legend = new am4charts.Legend();

      var params = this.getParamsFromData(this.dataArr);
      this.chart = chart;
      _.pull(params, "label", "time", "testID", "groupID").forEach(
        (param, index) => {
          this.createSeries(
            param,
            param,
            am4core.color(BAR_CHART_COLORS[index]),
            this.hoveringOn
          );
        }
      );
      this.chart = chart;
    });
  }
  startChangedEvent = (ev) => {
    let axis = ev.target;
    let start = axis.getPositionLabel(axis.start);
    let end = axis.getPositionLabel(axis.end);
    this.startChanged.emit(start);
    this.endChanged.emit(end);
  };

  endChangedEvent = (ev) => {
    let axis = ev.target;
    let start = axis.getPositionLabel(axis.start);
    let end = axis.getPositionLabel(axis.end);
    this.startChanged.emit(start);
    this.endChanged.emit(end);
  };
  createSeries = async (field, name, color, hoveringOn) => {
    let series = this.chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = field;
    series.dataFields.categoryX = "time";
    series.stacked = true;
    series.name = name;
    series.tooltipText = "{name}: [bold]{valueY}[/]";
    series.columns.template.fill = color;
    series.columns.template.stroke = color;

    //trigger on-hover
    series.events.on("tooltipshownat", (event) => {
      let value = _.get(event, ["dataItem", "dataContext"]);
      hoveringOn.emit(value);
    });
    series.events.on(
      "hit",
      async (ev) => {
        this.hitOn.emit("");
      },
      this
    );

    return series;
  };
  getParamsFromData(data) {
    let a = [],
      b = [];
    data.map((e) => a.push(_.keys(e)));
    a.map((e) => {
      b = _.union(e, b);
    });
    return b;
  }

  ngOnDestroy() {
    this.zone.runOutsideAngular(() => {
      if (this.chart) {
        this.chart.dispose();
      }
    });
  }
}
