import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
  OnDestroy,
} from "@angular/core";
import * as _ from "lodash";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

@Component({
  selector: "uxpulse-pie-chart-domains",
  templateUrl: "./pie-chart-domains.component.html",
  styleUrls: ["./pie-chart-domains.component.css"],
})
export class PieChartDomainComponent implements OnInit, OnChanges, OnDestroy {
  constructor() {}

  @Input()
  domainArr = [];
  chart: any;

  ngOnChanges(changes: SimpleChanges): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    this.domainArr = _.get(changes, ["domainArr", "currentValue"]);

    this.renderDomainChart();
  }

  ngOnInit(): void {
    this.renderDomainChart();
    // Create chart instance
  }
  renderDomainChart = () => {
    if (undefined != this.chart) this.chart.dispose();
    this.chart = am4core.create("domain-pie", am4charts.PieChart);

    // Add data
    this.chart.data = this.domainArr;

    // Add and configure Series
    let pieSeries = this.chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = "bytes";
    pieSeries.dataFields.category = "domain";
    pieSeries.slices.template.stroke = am4core.color("#fff");
    pieSeries.slices.template.strokeWidth = 2;
    pieSeries.slices.template.strokeOpacity = 1;

    // This creates initial animation
    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
    pieSeries.labels.template.disabled = true;
    pieSeries.ticks.template.disabled = true;
  };
  ngOnDestroy() {
    if (this.chart) {
      this.chart.dispose();
    }
  }
}
