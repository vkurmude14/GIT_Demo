import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
  OnDestroy,
} from "@angular/core";
import * as _ from "lodash";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

@Component({
  selector: "uxpulse-pie-chart-breakdowns",
  templateUrl: "./pie-chart-breakdowns.component.html",
  styleUrls: ["./pie-chart-breakdowns.component.css"],
})
export class PieChartBreakdownsComponent
  implements OnInit, OnChanges, OnDestroy {
  constructor() {}

  @Input()
  breakdownArr = [];
  chart: any;

  ngOnChanges(changes: SimpleChanges): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    this.breakdownArr = _.get(changes, ["breakdownArr", "currentValue"]);

    this.renderBreakdownChart();
  }

  ngOnInit(): void {
    this.renderBreakdownChart();
    // Create chart instance
  }
  renderBreakdownChart = () => {
    if (undefined != this.chart) this.chart.dispose();
    this.chart = am4core.create("breakdown-pie", am4charts.PieChart);

    // Add data
    this.chart.data = this.breakdownArr;

    // Add and configure Series
    let pieSeries = this.chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = "bytes";
    pieSeries.dataFields.category = "type";
    pieSeries.slices.template.stroke = am4core.color("#fff");
    pieSeries.slices.template.strokeWidth = 2;
    pieSeries.slices.template.strokeOpacity = 1;

    // This creates initial animation
    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
    pieSeries.labels.template.disabled = true;
    pieSeries.ticks.template.disabled = true;
  };
  ngOnDestroy() {
    if (this.chart) {
      this.chart.dispose();
    }
  }
}
