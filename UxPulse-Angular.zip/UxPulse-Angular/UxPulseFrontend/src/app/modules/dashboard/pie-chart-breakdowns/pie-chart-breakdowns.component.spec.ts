import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PieChartBreakdownsComponent } from './pie-chart-breakdowns.component';

describe('PieChartBreakdownsComponent', () => {
  let component: PieChartBreakdownsComponent;
  let fixture: ComponentFixture<PieChartBreakdownsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PieChartBreakdownsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieChartBreakdownsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
