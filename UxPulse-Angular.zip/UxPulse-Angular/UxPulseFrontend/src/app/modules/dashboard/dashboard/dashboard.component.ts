import { Component, OnInit } from "@angular/core";
import { DashboardService } from "../dashboardService/dashboard.service";
import * as _ from "lodash";
import { CrossfilterService } from "../crossfilter/crossfilter.service";
import { getUserInfo } from "../../../shared/utils/utils";
import { ActivatedRoute } from "@angular/router";
import * as _get from "lodash/get";
import {
  ParametersKeyValuePair,
  SlowElementObject,
  HeavyElementObject,
} from "../config/utils";
import {
  Badge,
  WPT_SPECIFIC_FILTERS,
  UXPULSE_SPECIFIC_FILTERS,
  VIEW_SPECIFIC_FILTER,
  DEFAULT_FILTER_STATE,
} from "../config/utils";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
})
export class DashboardComponent implements OnInit {
  constructor(
    private dashboardService: DashboardService,
    private crossfilterService: CrossfilterService,
    private activatedRoute: ActivatedRoute
  ) {}
  email: string;
  //localData
  private reqLabel: string;
  private scheduleLabel: string;
  rawData: any;
  private dataToDisplay: any;
  currentState = [];
  private lastHoveredOn: {} = {};
  private lastHoverdOnData: {} = {};
  domains: [] = [];
  breakdowns: [] = [];
  barChartData = [];
  trendingData = [];

  //initially setting date for range selection
  private startDate: number = new Date().setFullYear(
    new Date().getFullYear() - 100
  );
  private endDate: number = new Date().setFullYear(
    new Date().getFullYear() + 100
  );

  //badge list
  badge: Badge[] = [];

  //filters
  private filters = {};
  private labels = new Set();
  private locations = new Set();
  private browsers = new Set();
  private isCustomerList = new Set();
  private networks = new Set();

  //site-breakdown
  private keyValuePairForParameters: ParametersKeyValuePair[] = [];
  private slowElementObjects: SlowElementObject[] = [];
  private heavyElementObjects: HeavyElementObject[] = [];

  async ngOnInit(): Promise<void> {
    this.activatedRoute.queryParams.subscribe(async (params) => {
      this.reqLabel = params["reqLabel"];
      this.scheduleLabel = params["scheduleLabel"]; // Print the parameter to the console.
      if (localStorage.getItem("scheduleLabel")) {
        this.reqLabel = localStorage.getItem("requestLabel");
        this.scheduleLabel = localStorage.getItem("scheduleLabel");
      }
      this.rawData = null;
      //trigger timeout error if the data is not received even after 10s
      setTimeout(() => {
        if (!this.rawData)
          document.getElementById("loading").innerHTML =
            "Timeout error. Waited for 10s";
      }, 15000);

      //get labels for fetching data from backend
      // this.reqLabel = localStorage.getItem("requestLabel");
      // this.scheduleLabel = localStorage.getItem("scheduleLabel");
      this.currentState = DEFAULT_FILTER_STATE;

      //remove on prod
      // this.reqLabel = localStorage.getItem("requestLabel");
      // this.scheduleLabel = localStorage.getItem("scheduleLabel");
      await this.setChartData();
    });
  }

  setChartData = async () => {
    this.email = _get(await getUserInfo(), ["email"]);
    //get raw data
    await this.dashboardService
      .getDataFromBackend(this.reqLabel, this.scheduleLabel, this.email)
      .then((e) => {
        this.rawData = e.body;
      })
      .catch((err) => {
        document.getElementById("loading").innerHTML = err;
      });

    //crossfilterSetup
    await this.crossfilterService.setRawDataToCrossfilter(this.rawData);
    await this.crossfilterService.setFilterTypes(UXPULSE_SPECIFIC_FILTERS);
    await this.crossfilterService.setMetricsA(
      VIEW_SPECIFIC_FILTER.map((view) => view.value)
    );
    await this.crossfilterService.setMetricsB(
      WPT_SPECIFIC_FILTERS.map((view) => view.value)
    );
    await this.crossfilterService.buildDimensions();
    await this.crossfilterService.buildFilters();

    this.filters = await this.crossfilterService.getFilters();
    await this.setDefaultFilters(this.filters);

    await this.crossfilterService.setSelectedValues("label", "");
    await this.crossfilterService.setSelectedValues("filterType", "label");
    await this.crossfilterService.setSelectedValues("metricsA", "firstView");
    await this.crossfilterService.setSelectedValues("metricsB", "docComplete");
    await this.crossfilterService.setSelectedValues("location", "");
    await this.crossfilterService.setSelectedValues("browser", "");
    await this.crossfilterService.setSelectedValues("network", "");
    await this.crossfilterService.setSelectedValues("isCustomer", "");

    await this.crossfilterService.getFilteredData();
    this.dataToDisplay = await this.crossfilterService.getDataToPlot();

    this.badge = this.dataToDisplay["badge"];
    this.barChartData = this.dataToDisplay["barChart"];
    this.trendingData = this.dataToDisplay["trendingChart"];
  };
  setDefaultFilters = async (filters: {}) => {
    this.labels.clear();
    filters["label"].map((entry) => {
      this.labels.add({ value: entry.label, viewValue: entry.label });
    });
    this.browsers.clear();
    filters["browser"].map((entry) => {
      this.browsers.add({ value: entry.label, viewValue: entry.label });
    });
    this.networks.clear();
    filters["network"].map((entry) => {
      this.networks.add({ value: entry.label, viewValue: entry.label });
    });
    this.isCustomerList.clear();
    filters["isCustomer"].map((entry) => {
      this.isCustomerList.add({ value: entry.label, viewValue: entry.label });
    });
    this.locations.clear();
    filters["location"].map((entry) => {
      this.locations.add({ value: entry.label, viewValue: entry.label });
    });
  };

  resetChartData = async () => {
    await this.crossfilterService.setDateRange(
      new Date().setFullYear(new Date().getFullYear() - 100),
      new Date().setFullYear(new Date().getFullYear() + 100)
    );

    this.updatePage();
  };
  updatePage = async () => {
    await this.crossfilterService.getFilteredData();
    this.dataToDisplay = await this.crossfilterService.getDataToPlot();
    this.badge = this.dataToDisplay["badge"];
    this.barChartData = this.dataToDisplay["barChart"];
    this.trendingData = this.dataToDisplay["trendingChart"];
  };
  handleLabelChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("label", event);
    await this.updatePage();
  };
  handleBrowserChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("browser", event);
    await this.updatePage();
  };
  handleLocationChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("location", event);
    await this.updatePage();
  };
  handIsCustomerChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("isCustomer", event);
    await this.updatePage();
  };
  handNetworkChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("network", event);
    await this.updatePage();
  };
  handleWptFilterChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("metricsB", event);
    await this.updatePage();
  };
  handleUxPulseFilterChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("filterType", event);
    await this.updatePage();
  };
  handleViewFilterChange = async (event: any) => {
    this.crossfilterService.setSelectedValues("metricsA", event);
    await this.updatePage();
  };
  getLastHoveredOnData = async () => {
    return _.head(
      _.filter(this.rawData, (record) => {
        return record.testID == _.get(this.lastHoveredOn, "testID");
      })
    );
  };
  setSlowElements = async (slow) => {
    this.slowElementObjects = [];

    //slow elements
    _.get(
      slow.map((slowComp) => {
        this.slowElementObjects.push({
          type: slowComp.type,
          time: slowComp.resp / 1000 + " sec",
          href: decodeURIComponent(slowComp.url),
          component:
            decodeURIComponent(slowComp.url).length > 30
              ? "..." +
                decodeURIComponent(slowComp.url).slice(
                  decodeURIComponent(slowComp.url).length - 30,
                  decodeURIComponent(slowComp.url).length
                )
              : decodeURIComponent(slowComp.url),
        });
      })
    );
  };
  setHeavyElements = async (heavy) => {
    this.heavyElementObjects = [];

    //heavy elements
    _.get(
      heavy.map((heavyComp) => {
        this.heavyElementObjects.push({
          type: heavyComp.type,
          size: heavyComp.size / 1000 + " kB",
          href: decodeURIComponent(heavyComp.url),
          component:
            decodeURIComponent(heavyComp.url).length > 30
              ? "..." +
                decodeURIComponent(heavyComp.url).slice(
                  decodeURIComponent(heavyComp.url).length - 30,
                  decodeURIComponent(heavyComp.url).length
                )
              : decodeURIComponent(heavyComp.url),
        });
      })
    );
  };
  setKeyValueParams = async () => {
    //keyValue pairs elements
    this.keyValuePairForParameters = [];
    this.keyValuePairForParameters.push({
      key: "location",
      value:
        this.lastHoverdOnData["location"] +
        ":" +
        this.lastHoverdOnData["browser"],
    });
    this.keyValuePairForParameters.push({
      key: "label",
      value: this.lastHoverdOnData["label"],
    });
    if (undefined != _.get(this.lastHoverdOnData, ["metrics", "firstView"]))
      this.keyValuePairForParameters.push({
        key: "Response firsView",
        value:
          _.get(this.lastHoverdOnData, [
            "metrics",
            "firstView",
            "startRender",
          ]) +
          "/" +
          _.get(this.lastHoverdOnData, [
            "metrics",
            "firstView",
            "docComplete",
          ]) +
          "/" +
          _.get(this.lastHoverdOnData, [
            "metrics",
            "firstView",
            "fullyLoaded",
          ]) +
          " Seconds",
      });
    else
      this.keyValuePairForParameters.push({
        key: "Response firsView",
        value: " No Data",
      });
    if (undefined != _.get(this.lastHoverdOnData, ["metrics", "repeatView"]))
      this.keyValuePairForParameters.push({
        key: "Response repeatView",
        value:
          _.get(this.lastHoverdOnData, [
            "metrics",
            "repeatView",
            "startRender",
          ]) +
          "/" +
          _.get(this.lastHoverdOnData, [
            "metrics",
            "repeatView",
            "docComplete",
          ]) +
          "/" +
          _.get(this.lastHoverdOnData, [
            "metrics",
            "repeatView",
            "fullyLoaded",
          ]) +
          " Seconds",
      });
    else
      this.keyValuePairForParameters.push({
        key: "Response repeatView",
        value: " No Data",
      });
  };
  handleHoveringOnEvent = async (event) => {
    this.lastHoveredOn = event;

    this.lastHoverdOnData = await this.getLastHoveredOnData();

    let slow = _.get(this.lastHoverdOnData, ["components", "slow"]);
    let heavy = _.get(this.lastHoverdOnData, ["components", "heavy"]);

    await this.setSlowElements(slow);
    await this.setHeavyElements(heavy);
    await this.setKeyValueParams();

    this.domains = JSON.parse(
      _.get(this.lastHoverdOnData, ["metrics", "firstView", "domains"])
    ).sort((a, b) => {
      return b.bytes - a.bytes;
    });
    this.breakdowns = JSON.parse(
      _.get(this.lastHoverdOnData, ["metrics", "firstView", "breakdown"])
    );
  };

  handleHitOnEvent = async (event) => {
    window.open(
      window.location +
        "/har?username=" +
        _.get(await getUserInfo(), "username") +
        "&reqLabel=" +
        this.reqLabel +
        "&scheduleLabel=" +
        this.scheduleLabel +
        "&groupId=" +
        _.get(this.lastHoveredOn, "groupID") +
        "&testId=" +
        _.get(this.lastHoveredOn, "testID"),
      "_blank"
    );
  };

  handleTrendingChartStartRangeChanged = async (event) => {
    this.startDate = new Date(event).getTime();
    await this.crossfilterService.setDateRange(this.startDate, this.endDate);
    this.updatePage();
  };
  handleTrendingChartEndRangeChanged = async (event) => {
    this.endDate = new Date(event).getTime();
    await this.crossfilterService.setDateRange(this.startDate, this.endDate);
    this.updatePage();
  };
  handleBarChartEndChanged = async (event) => {
    this.endDate = new Date(event).getTime();
    await this.crossfilterService.setDateRange(this.startDate, this.endDate);
    this.updatePage();
  };
  handleBarChartStartChanged = async (event) => {
    this.startDate = new Date(event).getTime();
    await this.crossfilterService.setDateRange(this.startDate, this.endDate);
    this.updatePage();
  };

  setLabelsWithDisplayData = (displayData: any) => {
    let temp = new Set();
    let labels = new Set();
    displayData.map((data) => {
      temp.add(data.label);
    });
    temp.forEach((label) => {
      labels.add({ value: label, viewValue: label });
    });
    return { labels };
  };

  setLocationsWithDisplayData = (displayData: any) => {
    let temp = new Set();
    let locations = new Set();
    displayData.map((data) => {
      temp.add(data.location);
    });
    temp.forEach((label) => {
      locations.add({ value: label, viewValue: label });
    });

    return { locations };
  };
  setBrowsersWithDisplayData = (displayData: any) => {
    let temp = new Set();
    let browsers = new Set();
    displayData.map((data) => {
      temp.add(data.browser);
    });
    temp.forEach((label) => {
      browsers.add({ value: label, viewValue: label });
    });

    return { browsers };
  };
  setNetworksWithDisplayData = (displayData: any) => {
    let temp = new Set();
    let networks = new Set();
    displayData.map((data) => {
      temp.add(data.network);
    });
    temp.forEach((label) => {
      networks.add({ value: label, viewValue: label });
    });

    return { networks };
  };
}
