import { Injectable } from "@angular/core";
import crossfilter from "crossfilter2";
import { Badge, BarChartData } from "../config/utils";
import * as _ from "lodash";
import Crossfilter = crossfilter.Crossfilter;
@Injectable()
export class CrossfilterService {
  private crossData: Crossfilter<any>;
  private groupDim: any;
  private indexDim: any;
  private filterType: any;
  private dims: any = {};
  private filters: any = {};

  private selectedFilters: any[] = [];

  metricsA: string[];
  metricsB: string[];

  private trendingChartData: any[];
  private barChartData: any[];
  private badgeData: Badge[];

  constructor() {}

  getBarChartData = async () => {
    return this.barChartData;
  };
  getTrendingChartData = async () => {
    return this.trendingChartData;
  };
  getBadgeData = async () => {
    return this.badgeData;
  };
  getDataToPlot = async () => {
    return {
      barChart: await this.getBarChartData(),
      trendingChart: await this.getTrendingChartData(),
      badge: await this.getBadgeData(),
    };
  };

  setFilterTypes = async (filterArr: any[]) => {
    this.filterType = filterArr.map((filter: any) => {
      return filter.value;
    });
  };
  setMetricsA = async (data: string[]) => {
    this.metricsA = data;
  };
  setMetricsB = async (data: string[]) => {
    this.metricsB = data;
  };

  setRawDataToCrossfilter = async (rawData: any[]) => {
    this.crossData = crossfilter(rawData);
  };
  getSize = async () => {
    return this.crossData.size();
  };

  buildDimensions = async () => {
    this.groupDim = this.crossData.dimension((record) => {
      return record["groupId"];
    });
    this.indexDim = this.crossData.dimension((record) => {
      return record["date"];
    });

    this.filterType.forEach((filter: string) => {
      this.dims[filter] = this.crossData.dimension((record) => {
        return record[filter];
      });
    });
  };

  buildFilters = async () => {
    let filters = this.filters;
    let dims = this.dims;

    this.filterType.forEach((filter: string) => {
      filters[filter] = [];
      let filteredData = dims[filter].group().all();
      filteredData.forEach((record) => {
        filters[filter].push({ label: record.key, isSelected: false });
      });
    });

    this.filters = filters;
    this.dims = dims;
  };

  getFilters = async () => {
    return this.filters;
  };

  setSelectedValues = async (key: string, value: any) => {
    this.selectedFilters[key] = value;
  };
  setDateRange = async (from, to) => {
    this.indexDim.filterRange([
      new Date(from).getTime(),
      new Date(to).getTime(),
    ]);
  };

  getFilteredData = async () => {
    let selectedFilters = this.selectedFilters;
    let dims = this.dims;
    var temp;
    //BADSTYLE
    //collect parameter
    var type = this.selectedFilters["filterType"];
    var a = this.selectedFilters["metricsA"];
    var b = this.selectedFilters["metricsB"];
    var nfilter = {};

    this.filterType.forEach((filter: string) => {
      nfilter[filter] = selectedFilters[filter];
    });
    //BSEND

    //apply percentile filter
    var tempDim = this.crossData.dimension((d) => {
      if (
        null != d["metrics"] &&
        null != d["metrics"][a] &&
        null != d["metrics"][a][b]
      )
        return d["metrics"][a][b];
    });

    var s = this.crossData.size();

    //filterData on all Dimensions

    this.filterType.forEach((d) => {
      if (d !== type) {
        dims[d].filter((e) => {
          if (nfilter[d].length === 0) return true;
          return nfilter[d].indexOf(e) >= 0;
        });
      }
    });

    //build data for main-chart

    var trendingChart = [];
    this.filters[type].forEach(async (d) => {
      let dims = this.dims;
      if (nfilter[type].length === 0 || nfilter[type].indexOf(d.label) >= 0) {
        dims[type].filter(d.label);
        temp = [];
        this.groupDim
          .group()
          .reduce(
            this.reduceAdd(a, b),
            this.reduceRemove(a, b),
            this.reduceInit
          )
          .all()
          .forEach((p, i) => {
            if (p.value.count > 0)
              temp.push({
                date: new Date(Number(p.key)),
                value: +p.value.avg,
              });
          });
        if (temp.length > 0)
          trendingChart.push({
            key: d.label,
            values: temp.sort((a, b) => {
              let aDate = new Date(a.date);
              let bDate = new Date(b.date);
              return Number(aDate) - Number(bDate);
            }),
          });
      }
      this.dims = dims;
    });

    dims[type].filter((e) => {
      if (nfilter[type].length === 0) return true;
      return nfilter[type].indexOf(e) >= 0;
    });

    //build data for bar-chart
    var barChart: BarChartData[] = [];

    // var temp1 = [];
    var oldDate = 0;

    this.indexDim.bottom(Infinity).forEach((d) => {
      var x;
      //QUICKFIX
      x = d.date === oldDate ? d.date + 1 : d.date;
      oldDate = x;
      //QFEND

      //TODO
      if (null != d.metrics[a]) {
        var st = d.metrics[a]["startRender"];
        var dc = d.metrics[a]["docComplete"] - st;
        var fl = d.metrics[a]["fullyLoaded"] - dc - st;
        barChart.push({
          label: d.label,
          testID: d.testID,
          groupID: d.groupId,
          time: new Date(d.date).toLocaleString(),
          StartRender: st,
          DocComplete: dc,
          FullyLoaded: fl,
        });
      }
    });

    //build Summary data
    var filteredSize = this.crossData.groupAll().value();
    //apply filter to aggregate only customer data
    this.dims["isCustomer"].filter("true");

    let badge: Badge[] = [];

    let reducedData = this.crossData
      .groupAll()
      .reduce(this.reduceAdd(a, b), this.reduceRemove(a, b), this.reduceInit);
    //avg response
    badge[0] = {} as Badge;
    badge[1] = {} as Badge;
    badge[2] = {} as Badge;

    badge[0].value = Math.round(_.get(reducedData.value(), "avg") * 100) / 100;
    badge[0].title = "Average Response Time";
    badge[0].measuringUnit = badge[0].value > 1 ? "seconds" : "second";

    //fastest response
    var bottom = tempDim.bottom(1)[0];
    badge[1].title = "Fastest Response Time";

    if (bottom) {
      badge[1].value = bottom.metrics[a]
        ? Math.round(bottom.metrics[a][b] * 100) / 100
        : 0;
      badge[1].info = bottom.location + ":" + bottom.browser;
    } else {
      badge[1].value = 0;
      badge[1].info = "NoData";
    }
    badge[1].measuringUnit = badge[1].value > 1 ? "seconds" : "second";
    //slowest response
    var top = tempDim.top(1)[0];
    badge[2].title = "Slowest Response Time";

    if (top) {
      badge[2].value = top.metrics[a]
        ? Math.round(top.metrics[a][b] * 100) / 100
        : 0;
      badge[2].info = top.location + ":" + top.browser;
    } else {
      badge[2].value = 0;
      badge[2].info = "NoData";
    }
    badge[2].measuringUnit = badge[2].value > 1 ? "seconds" : "second";

    //size of records
    badge[0].info = this.crossData.groupAll().value() + " Records";
    //QFEND

    //clearing all filters
    this.filterType.forEach((d) => {
      this.dims[d].filterAll();
    });
    this.groupDim.filterAll();
    tempDim.filterAll();

    //removing tempDim, increases performance?!
    tempDim.dispose();
    this.dims = dims;
    this.trendingChartData = trendingChart;
    this.barChartData = barChart;
    this.badgeData = badge;
  };
  reduceAdd = (a: any, b) => {
    return (p: any, v: any) => {
      ++p.count;
      if (
        null != v["metrics"] &&
        null != v["metrics"][a] &&
        null != v["metrics"][a][b]
      ) {
        p.sum = p.sum + v["metrics"][a][b];
      }
      p.avg = p.sum / p.count;

      return p;
    };
  };
  reduceRemove = (a: any, b: any) => {
    return (p: any, v: any) => {
      --p.count;
      if (
        null != v["metrics"] &&
        null != v["metrics"][a] &&
        null != v["metrics"][a][b]
      )
        p.sum = p.sum - v["metrics"][a][b];
      p.avg = p.sum / p.count;

      return p;
    };
  };
  reduceInit = () => {
    return { count: 0, sum: 0, avg: 0 };
  };
}
