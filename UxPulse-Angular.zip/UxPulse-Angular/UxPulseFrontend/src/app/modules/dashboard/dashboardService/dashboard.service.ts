import { Injectable } from "@angular/core";
import { axiosInstance } from "../../../shared/utils/axios-custom";
import { getDataFromHttpResponse } from "../../../shared/utils/utils";

@Injectable()
export class DashboardService {
  constructor() {}

  getDataFromBackend = async (
    reqLabel: String,
    scheduleLabel: String,
    email: string
  ) => {
    if (
      "" == reqLabel ||
      "" == scheduleLabel ||
      reqLabel == undefined ||
      scheduleLabel == undefined
    ) {
      throw new Error("Please choose both request label and schedule label");
    }

    return axiosInstance
      .get(
        "/getDashboardData?requestLabel=" +
          reqLabel +
          "&" +
          "scheduleLabel=" +
          scheduleLabel +
          "&" +
          "email=" +
          email
      )
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        // always executed
      });
  };

  getHarData = async (
    username: String,
    reqLabel: String,
    scheduleLabel: String,
    groupId: String,
    testId: String
  ) => {
    if ("" == reqLabel || "" == scheduleLabel) {
      throw new Error("Please choose both request label and schedule label");
    }
    return axiosInstance
      .get(
        "/getHarAsString?username=" +
          username +
          "&" +
          "reqlabel=" +
          reqLabel +
          "&" +
          "scheduleLabel=" +
          scheduleLabel +
          "&" +
          "groupId=" +
          groupId +
          "&" +
          "testId=" +
          testId
      )
      .then((response) => {
        return getDataFromHttpResponse(response).body;
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        // always executed
      });
  };
}
