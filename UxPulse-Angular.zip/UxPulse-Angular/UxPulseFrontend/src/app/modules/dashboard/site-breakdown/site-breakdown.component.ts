import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
} from "@angular/core";
import {
  ParametersKeyValuePair,
  SlowElementObject,
  HeavyElementObject,
} from "../config/utils";

@Component({
  selector: "uxpulse-site-breakdown",
  templateUrl: "./site-breakdown.component.html",
  styleUrls: ["./site-breakdown.component.css"],
})
export class SiteBreakdownComponent implements OnInit, OnChanges {
  constructor() {}

  //parameters input values
  @Input()
  elementDataForParameters: ParametersKeyValuePair[] = [];
  displayedColumnsForParams: string[] = ["key", "value"];
  dataSourceForParameters: any;

  //slow  elements input values
  @Input()
  elementDataForSlowElements: SlowElementObject[] = [];
  displayedColumnsForSlowElements: string[] = ["type", "time", "component"];
  dataSourceForSlowElements: any;

  //heavy elements input values
  @Input()
  elementDataForHeavyElements: HeavyElementObject[] = [];
  displayedColumnsForHeavyElements: string[] = ["type", "size", "component"];
  dataSourceForHeavyElements: any;

  @Input()
  breakdowns: [] = [];
  @Input()
  domains: [] = [];
  ngOnChanges(changes: SimpleChanges): void {
    if (this.dataSourceForHeavyElements != undefined)
      this.dataSourceForHeavyElements =
        changes.elementDataForHeavyElements.currentValue;
    if (this.dataSourceForSlowElements != undefined)
      this.dataSourceForSlowElements =
        changes.elementDataForSlowElements.currentValue;
    if (this.dataSourceForParameters != undefined)
      this.dataSourceForParameters =
        changes.elementDataForParameters.currentValue;
    if (this.domains != undefined) this.domains = changes.domains.currentValue;
    if (this.breakdowns != undefined)
      this.breakdowns = changes.breakdowns.currentValue;
  }

  ngOnInit(): void {
    this.dataSourceForParameters = this.elementDataForParameters;
    this.dataSourceForSlowElements = this.elementDataForSlowElements;
    this.dataSourceForHeavyElements = this.elementDataForHeavyElements;
  }
}
