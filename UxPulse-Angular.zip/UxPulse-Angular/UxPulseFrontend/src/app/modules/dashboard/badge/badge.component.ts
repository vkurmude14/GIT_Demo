import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "uxpulse-badge",
  templateUrl: "./badge.component.html",
  styleUrls: ["./badge.component.css"],
})
export class BadgeComponent implements OnInit {
  constructor() {}
  @Input() title: string;
  @Input() value: string;
  @Input() measuringUnit: string;
  @Input() info: string;
  @Input() color: string;

  ngOnInit(): void {}
}
