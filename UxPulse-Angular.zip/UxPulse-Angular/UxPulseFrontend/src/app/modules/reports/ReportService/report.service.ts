import { Injectable } from "@angular/core";
import { axiosInstance } from "src/app/shared/utils/axios-custom";
import { getDataFromHttpResponse } from "src/app/shared/utils/utils";
import * as _get from "lodash/get";

@Injectable({
  providedIn: "root",
})
export class ReportService {
  constructor() {}

  async getListofLabels(requestID: string, email: String): Promise<any> {
    return axiosInstance
      .get("/getLabels?requestID=" + requestID + "&email=" + email)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }
  async getRecommendationReport(url: string): Promise<any> {
    return axiosInstance
      .get("/getRecommendationReport?url=" + url)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }

  async getPriorityImpactAnalysis(): Promise<any> {
    return axiosInstance
      .get("../../../../assets/pagespeed_priority_impact.json")
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }
}
