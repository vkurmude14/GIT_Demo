import { Component, OnInit, NgZone } from "@angular/core";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import { ReportService } from "../ReportService/report.service";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as jsPDF from "jspdf";
import * as html2canvas from "html2canvas";
import { reduce } from "rxjs/operators";
import * as _set from "lodash/set";
import * as _get from "lodash/get";
import { getAuditGroup } from "../utils/utils";
import * as _pullAllBy from "lodash/pullAllBy";
import { Variable } from "@angular/compiler/src/render3/r3_ast";

export interface colorAndIcon {
  color: string;
  icon: any;
}

export interface Recommendation {
  title: string;
  observation: string;
  analysis: any[];
  recommendation: string;
  dataPresent: boolean;
}

export interface LabData {
  title: string;
  description: string;
  value: any;
  score: number;
}

@Component({
  selector: "app-recommendation-report",
  templateUrl: "./recommendation-report.component.html",
  styleUrls: ["./recommendation-report.component.css"],
})
export class RecommendationReportComponent implements OnInit {
  constructor(private zone: NgZone, private reportService: ReportService) {}

  FCPpercentileField: any;
  FCPpercentileFieldColor: colorAndIcon;
  FIDPercetileField: any;
  FIDPercetileFieldColor: colorAndIcon;
  LCPPercentileField: any;
  LCPPercentileFieldColor: colorAndIcon;
  CLSPercentileField: any;
  CLASPercentileFieldColor: colorAndIcon;

  FCPpercentileOrigin: any;
  FCPpercentileOriginColor: colorAndIcon;
  FIDPercetileOrigin: any;
  FIDPercetileOriginColor: colorAndIcon;
  LCPPercentileOrigin: any;
  LCPPercentileOriginColor: colorAndIcon;
  CLSPercentileOrigin: any;
  CLASPercentileOriginColor: colorAndIcon;

  EnableCompression: Recommendation;
  LeverageBrowserCaching: Recommendation;
  MinifyCSS: Recommendation;
  MinifyJavaScript: Recommendation;
  EliminateRenderBlockingContent: Recommendation;
  OptimizeImages: Recommendation;

  FCPLab: LabData;
  SpeedIndexLab: LabData;
  LCPLab: LabData;
  TTILab: LabData;
  TBTLab: LabData;
  CLSLab: LabData;

  seoRecommendations: [];
  accessibilityRecommendations: [];

  loading: boolean = false;
  ngOnInit() {
    if (
      localStorage.getItem("GPS") == undefined ||
      localStorage.getItem("GPS") == null
    ) {
      this.loading = true;
      this.getRecommendationReport().then(() => {
        this.loading = false;
      });
    }
    this.EnableCompression = this.getRecommendationDataEnableCompression();
    this.LeverageBrowserCaching = this.getRecommendationDataLeverageBrowserCaching();
    this.MinifyCSS = this.getRecommendationDataMinifyCSS();
    this.MinifyJavaScript = this.getRecommendationDataMinifyJavaScript();
    this.EliminateRenderBlockingContent = this.getRecommendationDataEliminateRender();
    this.OptimizeImages = this.getRecommendationDataOptimizeImages();

    let audits = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
      "audits"
    ];
    let categoryGroups = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["categoryGroups"];
    this.seoRecommendations = this.getSeoRecommendations(
      audits,
      categoryGroups
    );
    let recommendations = _get(this.seoRecommendations, ["recommendations"]);
    _set(
      this.seoRecommendations,
      "categories",
      Object.keys(recommendations).map((k) => k)
    );
    this.accessibilityRecommendations = this.getAccessibilityRecommendations(
      audits,
      categoryGroups
    );
    recommendations = _get(this.accessibilityRecommendations, [
      "recommendations",
    ]);
    _set(
      this.accessibilityRecommendations,
      "categories",
      Object.keys(recommendations).map((k) => k)
    );
    // console.log(this.seoRecommendations);
    // console.log(this.accessibilityRecommendations);

    this.FCPLab = this.getLabData("first-contentful-paint");
    this.SpeedIndexLab = this.getLabData("speed-index");
    this.LCPLab = this.getLabData("largest-contentful-paint");
    this.TTILab = this.getLabData("interactive");
    this.TBTLab = this.getLabData("total-blocking-time");
    this.CLSLab = this.getLabData("cumulative-layout-shift");

    this.FCPpercentileField = (
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .FIRST_CONTENTFUL_PAINT_MS.percentile / 1000
    ).toFixed(1);

    this.FCPpercentileFieldColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .FIRST_CONTENTFUL_PAINT_MS.category
    );

    this.FIDPercetileField = JSON.parse(
      localStorage.getItem("GPS")
    ).loadingExperience.metrics.FIRST_INPUT_DELAY_MS.percentile;

    this.FIDPercetileFieldColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .FIRST_INPUT_DELAY_MS.category
    );

    this.LCPPercentileField = (
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .LARGEST_CONTENTFUL_PAINT_MS.percentile / 1000
    ).toFixed(1);

    this.LCPPercentileFieldColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .LARGEST_CONTENTFUL_PAINT_MS.category
    );

    this.CLSPercentileField = (
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .CUMULATIVE_LAYOUT_SHIFT_SCORE.percentile / 100
    ).toFixed(2);

    this.CLASPercentileFieldColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).loadingExperience.metrics
        .CUMULATIVE_LAYOUT_SHIFT_SCORE.category
    );

    this.FCPpercentileOrigin = (
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .FIRST_CONTENTFUL_PAINT_MS.percentile / 1000
    ).toFixed(1);

    this.FCPpercentileOriginColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .FIRST_CONTENTFUL_PAINT_MS.category
    );

    this.FIDPercetileOrigin = JSON.parse(
      localStorage.getItem("GPS")
    ).originLoadingExperience.metrics.FIRST_INPUT_DELAY_MS.percentile;

    this.FIDPercetileOriginColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .FIRST_INPUT_DELAY_MS.category
    );

    this.LCPPercentileOrigin = (
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .LARGEST_CONTENTFUL_PAINT_MS.percentile / 1000
    ).toFixed(1);

    this.LCPPercentileOriginColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .LARGEST_CONTENTFUL_PAINT_MS.category
    );

    this.CLSPercentileOrigin = (
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .CUMULATIVE_LAYOUT_SHIFT_SCORE.percentile / 100
    ).toFixed(2);

    this.CLASPercentileOriginColor = this.colorCoding(
      JSON.parse(localStorage.getItem("GPS")).originLoadingExperience.metrics
        .CUMULATIVE_LAYOUT_SHIFT_SCORE.category
    );

    this.zone.runOutsideAngular(() => {
      var doc = {
        pageSize: "A4",
        pageOrientation: "portrait",
        pageMargins: [30, 30, 30, 30],
        content: [],
      };

      FCPFieldChart();
      FIDFieldChart();
      LCPFieldChart();
      CLSFieldChart();
      FCPOriginChart();
      FIDOriginChart();
      LCPOriginChart();
      CLSOriginChart();
      scoreChart();
      seoScoreChart(_get(this.seoRecommendations, ["score"]));
      accessibilityScoreChart(
        _get(this.accessibilityRecommendations, ["score"])
      );
      try {
        savePDF(this.seoRecommendations, this.accessibilityRecommendations);
      } catch (err) {
        // console.log(err);
      }
      var chart: am4charts.GaugeChart;
      var chart1: am4charts.PieChart;
      var chart2: am4charts.PieChart;
      var chart3: am4charts.PieChart;
      var chart4: am4charts.PieChart;
      var chart5: am4charts.PieChart;
      var chart6: am4charts.PieChart;
      var chart7: am4charts.PieChart;
      var chart8: am4charts.PieChart;
      var chart9: am4charts.GaugeChart;

      var chart10: am4charts.GaugeChart;

      function scoreChart() {
        am4core.useTheme(am4themes_animated);
        chart = am4core.create("scoreDiv", am4charts.GaugeChart);
        chart.hiddenState.properties.opacity = 0; // this makes initial fade in effect

        chart.innerRadius = -10;

        let axis = chart.xAxes.push(
          new am4charts.ValueAxis<am4charts.AxisRendererCircular>()
        );
        axis.min = 0;
        axis.max = 100;
        axis.strictMinMax = true;
        axis.renderer.grid.template.stroke = new am4core.InterfaceColorSet().getFor(
          "background"
        );
        axis.renderer.grid.template.strokeOpacity = 0.3;

        let colorSet = new am4core.ColorSet();

        let range0 = axis.axisRanges.create();
        range0.value = 0;
        range0.endValue = 49;
        range0.axisFill.fillOpacity = 1;
        range0.axisFill.fill = am4core.color("#ff4e42");
        range0.axisFill.zIndex = -1;

        let range1 = axis.axisRanges.create();
        range1.value = 50;
        range1.endValue = 89;
        range1.axisFill.fillOpacity = 1;
        range1.axisFill.fill = am4core.color("#ffa400");
        range1.axisFill.zIndex = -1;

        let range2 = axis.axisRanges.create();
        range2.value = 90;
        range2.endValue = 100;
        range2.axisFill.fillOpacity = 1;
        range2.axisFill.fill = am4core.color("#0cce6b");
        range2.axisFill.zIndex = -1;

        let hand = chart.hands.push(new am4charts.ClockHand());
        hand.showValue(
          JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
            "categories"
          ]["performance"]["score"] * 100
        );

        hand.tooltipText = (
          JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
            "categories"
          ]["performance"]["score"] * 100
        ).toString();
      }

      function seoScoreChart(seoScore) {
        am4core.useTheme(am4themes_animated);
        chart9 = am4core.create("seoScoreDiv", am4charts.GaugeChart);
        chart9.hiddenState.properties.opacity = 0; // this makes initial fade in effect

        chart9.innerRadius = -10;

        let axis = chart9.xAxes.push(
          new am4charts.ValueAxis<am4charts.AxisRendererCircular>()
        );
        axis.min = 0;
        axis.max = 100;
        axis.strictMinMax = true;
        axis.renderer.grid.template.stroke = new am4core.InterfaceColorSet().getFor(
          "background"
        );
        axis.renderer.grid.template.strokeOpacity = 0.3;

        let colorSet = new am4core.ColorSet();

        let range0 = axis.axisRanges.create();
        range0.value = 0;
        range0.endValue = 49;
        range0.axisFill.fillOpacity = 1;
        range0.axisFill.fill = am4core.color("#ff4e42");
        range0.axisFill.zIndex = -1;

        let range1 = axis.axisRanges.create();
        range1.value = 50;
        range1.endValue = 89;
        range1.axisFill.fillOpacity = 1;
        range1.axisFill.fill = am4core.color("#ffa400");
        range1.axisFill.zIndex = -1;

        let range2 = axis.axisRanges.create();
        range2.value = 90;
        range2.endValue = 100;
        range2.axisFill.fillOpacity = 1;
        range2.axisFill.fill = am4core.color("#0cce6b");
        range2.axisFill.zIndex = -1;

        let hand = chart9.hands.push(new am4charts.ClockHand());
        hand.showValue(seoScore * 100);

        hand.tooltipText = (seoScore * 100).toString();
      }
      function accessibilityScoreChart(seoScore) {
        am4core.useTheme(am4themes_animated);
        chart10 = am4core.create("accessibilityScoreDiv", am4charts.GaugeChart);
        chart10.hiddenState.properties.opacity = 0; // this makes initial fade in effect

        chart10.innerRadius = -10;

        let axis = chart10.xAxes.push(
          new am4charts.ValueAxis<am4charts.AxisRendererCircular>()
        );
        axis.min = 0;
        axis.max = 100;
        axis.strictMinMax = true;
        axis.renderer.grid.template.stroke = new am4core.InterfaceColorSet().getFor(
          "background"
        );
        axis.renderer.grid.template.strokeOpacity = 0.3;

        let colorSet = new am4core.ColorSet();

        let range0 = axis.axisRanges.create();
        range0.value = 0;
        range0.endValue = 49;
        range0.axisFill.fillOpacity = 1;
        range0.axisFill.fill = am4core.color("#ff4e42");
        range0.axisFill.zIndex = -1;

        let range1 = axis.axisRanges.create();
        range1.value = 50;
        range1.endValue = 89;
        range1.axisFill.fillOpacity = 1;
        range1.axisFill.fill = am4core.color("#ffa400");
        range1.axisFill.zIndex = -1;

        let range2 = axis.axisRanges.create();
        range2.value = 90;
        range2.endValue = 100;
        range2.axisFill.fillOpacity = 1;
        range2.axisFill.fill = am4core.color("#0cce6b");
        range2.axisFill.zIndex = -1;

        let hand = chart10.hands.push(new am4charts.ClockHand());
        hand.showValue(seoScore * 100);

        hand.tooltipText = (seoScore * 100).toString();
      }
      function savePDF(seoRecommendations, accessibilityRecommendations) {
        Promise.all([
          chart.exporting.pdfmake,
          chart.exporting.getImage("png"),
          chart1.exporting.getImage("png"),
          chart2.exporting.getImage("png"),
          chart3.exporting.getImage("png"),
          chart4.exporting.getImage("png"),
          chart5.exporting.getImage("png"),
          chart6.exporting.getImage("png"),
          chart7.exporting.getImage("png"),
          chart8.exporting.getImage("png"),
          chart9.exporting.getImage("png"),
          chart10.exporting.getImage("png"),
        ]).then(async function (res) {
          // pdfmake is ready
          // ...
          var pdfMake = res[0];
          // pdfmake is ready
          // Create document templat

          doc.content.push({
            text: "UxPulse Recommendation Report",
            fontSize: 20,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "#2B3B83",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            text: "for " + localStorage.getItem("url"),
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "#2B3B83",
            decoration: "underline",
            decorationColor: "black",
          });

          doc.content.push({
            image: res[1],
            width: 530,
          });
          doc.content.push({
            text: "Field Data",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "blue",
            decoration: "underline",
            link:
              "https://web.dev/user-centric-performance-metrics/#in-the-field",
            decorationColor: "black",
          });
          doc.content.push({
            text: "First Contentful Paint (FCP)",
            fontSize: 12,
            link: "https://web.dev/fcp/",
            bold: true,
            margin: [0, 20, 0, 15],
            color: "blue",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            text:
              "measures the time from when the page starts loading to when any part of the page's content is rendered on the screen.",
            fontSize: 10,
            bold: true,
            margin: [0, 20, 0, 15],
          });
          doc.content.push({
            image: res[2],
            width: 500,
            height: 70,
          });
          doc.content.push({
            text: "First Input Delay (FID)",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "blue",
            link: "https://web.dev/fid/",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            text:
              "measures the time from when a user first interacts with your site (i.e. when they click a link, tap a button, or use a custom, JavaScript-powered control) to the time when the browser is actually able to respond to that interaction. ",
            fontSize: 10,
            bold: true,
            margin: [0, 20, 0, 15],
          });
          doc.content.push({
            image: res[3],
            width: 500,
            height: 70,
          });
          doc.content.push({
            text: "Largest Contentful Paint (LCP)",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "blue",
            link: "https://web.dev/lcp/",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            text:
              "measures the time from when the page starts loading to when the largest text block or image element is rendered on the screen.",
            fontSize: 10,
            bold: true,
            margin: [0, 20, 0, 15],
          });
          doc.content.push({
            image: res[4],
            width: 500,
            height: 70,
          });
          doc.content.push({
            text: "Cumulative Layout Shift (CLS)",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            link: "https://web.dev/cls/",
            color: "blue",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            text:
              "measures the cumulative score of all unexpected layout shifts that occur between when the page starts loading and when its lifecycle state changes to hidden.",
            fontSize: 10,
            bold: true,
            margin: [0, 20, 0, 15],
          });
          doc.content.push({
            image: res[5],
            width: 500,
            height: 70,
          });
          // doc.content.push({
          //   text: "Origin Data",
          //   fontSize: 12,
          //   bold: true,
          //   margin: [0, 20, 0, 15],
          //   color: "blue",
          //   decoration: "underline",
          //   decorationColor: "black",
          // });
          // doc.content.push({
          //   text: "First Contentful Paint (FCP)",
          //   fontSize: 12,
          //   bold: true,
          //   margin: [0, 20, 0, 15],
          //   color: "#2B3B83",
          //   decoration: "underline",
          //   decorationColor: "black",
          // });
          // doc.content.push({
          //   image: res[6],
          //   width: 500,
          //   height: 70,
          // });
          // doc.content.push({
          //   text: "First Input Delay (FID)",
          //   fontSize: 12,
          //   bold: true,
          //   margin: [0, 20, 0, 15],
          //   color: "#2B3B83",
          //   decoration: "underline",
          //   decorationColor: "black",
          // });
          // doc.content.push({
          //   image: res[7],
          //   width: 500,
          //   height: 70,
          // });
          // doc.content.push({
          //   text: "Largest Contentful Paint (LCP)",
          //   fontSize: 12,
          //   bold: true,
          //   margin: [0, 20, 0, 15],
          //   color: "#2B3B83",
          //   decoration: "underline",
          //   decorationColor: "black",
          // });
          // doc.content.push({
          //   image: res[8],
          //   width: 500,
          //   height: 70,
          // });
          // doc.content.push({
          //   text: "Cumulative Layout Shift (CLS)",
          //   fontSize: 12,
          //   bold: true,
          //   margin: [0, 20, 0, 15],
          //   color: "#2B3B83",
          //   decoration: "underline",
          //   decorationColor: "black",
          // });
          // doc.content.push({
          //   image: res[9],
          //   width: 500,
          //   height: 70,
          // });
          doc.content.push({
            text: "Lab Data",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
            color: "blue",
            link:
              "https://web.dev/user-centric-performance-metrics/#in-the-lab",
            decoration: "underline",
            decorationColor: "black",
          });
          doc.content.push({
            columns: [
              {
                text: "First Contentful Paint",
                fontSize: 12,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["first-contentful-paint"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "First Contentful Paint marks the time at which the first text or image is painted. [Learn more](https://web.dev/first-contentful-paint).",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          doc.content.push({
            columns: [
              {
                text: "Speed Index ",
                fontSize: 12,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["speed-index"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "Speed Index shows how quickly the contents of a page are visibly populated. [Learn more](https://web.dev/speed-index).",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          doc.content.push({
            columns: [
              {
                text: "Largest Contentful Paint",
                fontSize: 12,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["largest-contentful-paint"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "Largest Contentful Paint marks the time at which the largest text or image is painted. [Learn More](https://web.dev/lighthouse-largest-contentful-paint)",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          doc.content.push({
            columns: [
              {
                text: "Time to Interactive ",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["interactive"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "Time to interactive is the amount of time it takes for the page to become fully interactive. [Learn more](https://web.dev/interactive).",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          doc.content.push({
            columns: [
              {
                text: "Total Blocking Time",
                fontSize: 12,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["total-blocking-time"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "Sum of all time periods between FCP and Time to Interactive, when task length exceeded 50ms, expressed in milliseconds. [Learn more](https://web.dev/lighthouse-total-blocking-time).",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          doc.content.push({
            columns: [
              {
                text: " Cumulative Layout Shift ",
                fontSize: 12,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text: JSON.parse(localStorage.getItem("GPS"))[
                  "lighthouseResult"
                ]["audits"]["cumulative-layout-shift"]["displayValue"],
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
              {
                text:
                  "Cumulative Layout Shift measures the movement of visible elements within the viewport. [Learn more](https://web.dev/cls).",
                fontSize: 10,
                bold: true,
                margin: [0, 20, 0, 15],
              },
            ],
            columnGap: 30,
          });
          let count = 0;
          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["uses-text-compression"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text: ++count + ". Enable Compression",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : High | Impact : Low | effort : Low",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });

            doc.content.push({
              text:
                "All modern browsers support and automatically negotiate gzip compression for all HTTP requests. Enabling gzip compression can reduce the size of the transferred response by up to 90%, which can significantly reduce the amount of time to download the resource, reduce data usage for the client, and improve the time to first render of your pages.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["uses-text-compression"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["uses-long-cache-ttl"]["details"]["items"][
                        index
                      ].url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["uses-long-cache-ttl"]["details"]["items"][
                      index
                    ].url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text:
                "Enable and test gzip compression support on your web server for above domains.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }

          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["uses-long-cache-ttl"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text: ++count + ". Leverage Browser Caching",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : High | Impact : High | effort : Low",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text:
                "Fetching resources over the network is both slow and expensive: the download may require multiple roundtrips between the client and server, which delays processing and may block rendering of page content, and also incurs data costs for the visitor. All server responses should specify a caching policy to help the client determine if and when it can reuse a previously fetched response.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["uses-long-cache-ttl"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["uses-long-cache-ttl"]["details"]["items"][
                        index
                      ].url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["uses-long-cache-ttl"]["details"]["items"][
                      index
                    ].url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text:
                "Each resource should specify an explicit caching policy. Cache-Control defines how, and for how long the individual response can be cached by the browser. ETag provides a revalidation token that is automatically sent by the browser to check if the resource has changed since the last time it was requested.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }

          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["unminified-css"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text: ++count + ". Minify CSS",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : Medium | Impact : Medium | effort : Medium",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text:
                "Minification refers to the process of removing unnecessary or redundant data without affecting how the resource is processed by the browser - e.g. code comments and formatting, removing unused code, using shorter variable and function names, and so on.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["unminified-css"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["unminified-css"]["details"]["items"][index]
                        .url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["unminified-css"]["details"]["items"][index]
                      .url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "You should minify your CSS resources. ",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }

          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["unminified-javascript"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text: ++count + ". Minify JavaScript",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : High | Impact : Medium | effort : Medium",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text:
                "Minification refers to the process of removing unnecessary or redundant data without affecting how the resource is processed by the browser - e.g. code comments and formatting, removing unused code, using shorter variable and function names, and so on.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["unminified-javascript"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["unminified-javascript"]["details"]["items"][
                        index
                      ].url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["unminified-javascript"]["details"]["items"][
                      index
                    ].url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text:
                "You should minify your JavaScript resources. For minifying JavaScript, try the Closure Compiler, JSMin or the YUI Compressor. ",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }

          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["render-blocking-resources"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text:
                ++count +
                ". Eliminate render-blocking JavaScript and CSS in above-the-fold content",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : High | Impact : High | effort : Low",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text:
                "Before the browser can render a page it has to build the DOM tree by parsing the HTML markup. During this process, whenever the parser encounters a script it has to stop and execute it before it can continue parsing the HTML. In the case of an external script the parser is also forced to wait for the resource to download, which may incur one or more network roundtrips and delay the time to first render of the page.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["render-blocking-resources"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["render-blocking-resources"]["details"][
                        "items"
                      ][index].url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["render-blocking-resources"]["details"][
                      "items"
                    ][index].url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text:
                "You should avoid and minimize the use of blocking JavaScript, especially external scripts that must be fetched before they can be executed. Scripts that are necessary to render page content can be inlined to avoid extra network requests. Scripts that are not critical to initial render should be made asynchronous or deferred until after the first render.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }

          if (
            JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
              "audits"
            ]["uses-webp-images"]["details"]["items"].length != 0
          ) {
            doc.content.push({
              text: ++count + ". Optimize Images",
              fontSize: 12,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text: "priority : Low | Impact : Medium | effort : High",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text:
                "Images often account for most of the downloaded bytes on a page. As a result, optimizing images can often yield some of the largest byte savings and performance improvements: the fewer bytes the browser has to download, the less competition there is for the client's bandwidth and the faster the browser can download and render content on the screen.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
            doc.content.push({
              text: count + ".1 Analysis",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            for (
              let index = 0;
              index <
              JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
                "audits"
              ]["uses-webp-images"]["details"]["items"].length;
              index++
            ) {
              doc.content.push({
                columns: [
                  {
                    text:
                      "-> " +
                      JSON.parse(localStorage.getItem("GPS"))[
                        "lighthouseResult"
                      ]["audits"]["uses-webp-images"]["details"]["items"][index]
                        .url,
                    link: JSON.parse(localStorage.getItem("GPS"))[
                      "lighthouseResult"
                    ]["audits"]["uses-webp-images"]["details"]["items"][index]
                      .url,
                    fontSize: 10,
                    bold: true,
                    margin: [0, 0, 0, 0],
                  },
                ],
              });
            }
            doc.content.push({
              text: count + ".2 Recommendation",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
              color: "#2B3B83",
              decoration: "underline",
              decorationColor: "black",
            });
            doc.content.push({
              text:
                "Finding the optimal format and optimization strategy for your image assets requires careful analysis across many dimensions: type of data being encoded, image format capabilities, quality settings, resolution. In addition, you need to consider whether some images are best served in a vector format, or the desired effects can be achieved via CSS.",
              fontSize: 10,
              bold: true,
              margin: [0, 20, 0, 15],
            });
          }
          doc.content.push({
            text: "SEO scoring",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
          });

          doc.content.push({
            image: res[10],
            width: 530,
          });
          doc.content.push({
            text: "Accessibility scoring",
            fontSize: 12,
            bold: true,
            margin: [0, 20, 0, 15],
          });

          doc.content.push({
            image: res[11],
            width: 530,
          });

          pdfMake.createPdf(doc).download("report.pdf");
        });
      }

      function FCPFieldChart() {
        chart1 = am4core.create("chartdiv1", am4charts.PieChart);
        chart1.innerRadius = am4core.percent(40);
        // chart1.legend = new am4charts.Legend();
        // chart1.legend.position = "bottom";
        // chart1.legend.labels.template.truncate = false;
        // Add data
        chart1.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a \n good (< 1 s) First Contentful Paint (FCP).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a (1 s ~ 3 s)\n First Contentful Paint (FCP) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 3 s)\n First Contentful Paint (FCP).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart1.series.push(new am4charts.PieSeries());
        // pieSeries.labels.template.disabled = true;
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        // pieSeries.ticks.template.disabled = true;
        //pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function FIDFieldChart() {
        chart2 = am4core.create("chartdiv2", am4charts.PieChart);
        chart2.innerRadius = am4core.percent(40);

        // Add data
        chart2.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_INPUT_DELAY_MS.distributions[0]
              .proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[0].proportion *
                100
              ).toFixed(0) +
              "% of loads for this page have a good (< 100 ms)\n First Input Delay (FID).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_INPUT_DELAY_MS.distributions[1]
              .proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[1].proportion *
                100
              ).toFixed(0) +
              "% of loads for this page have a (100 ms ~ 300 ms)\n First Input Delay (FID) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.FIRST_INPUT_DELAY_MS.distributions[2]
              .proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[2].proportion *
                100
              ).toFixed(0) +
              "%  of loads for this page have a poor (> 300 ms)\n First Input Delay (FID).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart2.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        //pieSeries.labels.template.text = "proportion";
        // pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
        // chart2.legend = new am4charts.Legend();
      }

      function LCPFieldChart() {
        chart3 = am4core.create("chartdiv3", am4charts.PieChart);
        chart3.innerRadius = am4core.percent(40);

        // Add data
        chart3.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a good (< 2.5 s)\n Largest Contentful Paint (LCP).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "%  of loads for this page have a (2.5 s ~ 4 s)\n Largest Contentful Paint (LCP) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 4 s)\n Largest Contentful Paint (LCP).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart3.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        // pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function CLSFieldChart() {
        chart4 = am4core.create("chartdiv4", am4charts.PieChart);
        chart4.innerRadius = am4core.percent(40);

        // Add data
        chart4.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a good (< 0.1)\n Cumulative Layout Shift (CLS).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a (0.1 ~ 0.25)\n Cumulative Layout Shift (CLS) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .loadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).loadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 0.25)\n Cumulative Layout Shift (CLS).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart4.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        // pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function FCPOriginChart() {
        chart5 = am4core.create("chartdiv5", am4charts.PieChart);
        chart5.innerRadius = am4core.percent(40);

        // Add data
        chart5.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a good (< 1 s)\n First Contentful Paint (FCP).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a (1 s ~ 3 s)\n First Contentful Paint (FCP) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_CONTENTFUL_PAINT_MS.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 3 s)\n First Contentful Paint (FCP).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart5.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        //pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function FIDOriginChart() {
        chart6 = am4core.create("chartdiv6", am4charts.PieChart);
        chart6.innerRadius = am4core.percent(40);

        // Add data
        chart6.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_INPUT_DELAY_MS
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[0].proportion *
                100
              ).toFixed(0) +
              "% of loads for this page have a good (< 100 ms)\n First Input Delay (FID).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_INPUT_DELAY_MS
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[1].proportion *
                100
              ).toFixed(0) +
              "% of loads for this page have a (100 ms ~ 300 ms)\n First Input Delay (FID) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.FIRST_INPUT_DELAY_MS
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.FIRST_INPUT_DELAY_MS.distributions[2].proportion *
                100
              ).toFixed(0) +
              "%  of loads for this page have a poor (> 300 ms)\n First Input Delay (FID).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart6.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        //pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function LCPOriginChart() {
        chart7 = am4core.create("chartdiv7", am4charts.PieChart);
        chart7.innerRadius = am4core.percent(40);

        // Add data
        chart7.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a good (< 2.5 s)\n Largest Contentful Paint (LCP).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "%  of loads for this page have a (2.5 s ~ 4 s)\n Largest Contentful Paint (LCP) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.LARGEST_CONTENTFUL_PAINT_MS.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 4 s)\n Largest Contentful Paint (LCP).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart7.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        //  pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }

      function CLSOriginChart() {
        chart8 = am4core.create("chartdiv8", am4charts.PieChart);
        chart8.innerRadius = am4core.percent(40);

        // Add data
        chart8.data = [
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[0].proportion,
            color: am4core.color("#0cce6b"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[0]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a good (< 0.1)\n Cumulative Layout Shift (CLS).",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[1].proportion,
            color: am4core.color("#ffa400"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[1]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a (0.1 ~ 0.25)\n Cumulative Layout Shift (CLS) that needs improvement.",
          },
          {
            proportion: JSON.parse(localStorage.getItem("GPS"))
              .originLoadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE
              .distributions[2].proportion,
            color: am4core.color("#ff4e42"),
            tooltip:
              (
                JSON.parse(localStorage.getItem("GPS")).originLoadingExperience
                  .metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE.distributions[2]
                  .proportion * 100
              ).toFixed(0) +
              "% of loads for this page have a poor (> 0.25)\n Cumulative Layout Shift (CLS).",
          },
        ];

        // Add and configure Series
        let pieSeries = chart8.series.push(new am4charts.PieSeries());
        pieSeries.slices.template.propertyFields.fill = "color";
        pieSeries.dataFields.category = "tooltip";
        //pieSeries.labels.template.disabled = true;
        pieSeries.dataFields.value = "proportion";
      }
    });
  }

  colorCoding(category: string): colorAndIcon {
    let obj: colorAndIcon = {} as any;
    if (category == "AVERAGE") {
      obj.color = "#ffa400";
      obj.icon = "&#9632;";
    } else if (category == "SLOW") {
      obj.color = "#ff4e42";
      obj.icon = "&#9650;";
    } else {
      obj.color = "#0cce6b";
      obj.icon = "&#9679;";
    }
    return obj;
  }
  async getRecommendationReport() {
    let data = await this.reportService.getRecommendationReport(
      localStorage.getItem("url")
    );
    alert("Please Reload page once manually to display the data");

    localStorage.setItem("GPS", JSON.stringify(data.body));
    return true;
  }

  wait_promise(ms) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(ms);
      }, ms);
    });
  }

  getLabData(auditType: string) {
    let obj: LabData = {} as any;

    obj.title = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
      "audits"
    ][auditType]["title"];
    obj.description = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"][auditType]["description"];
    obj.value = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
      "audits"
    ][auditType]["displayValue"];
    obj.score = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"][
      "audits"
    ][auditType]["score"];

    return obj;
  }

  getColorCodingAccToScore(score: number): colorAndIcon {
    let obj: colorAndIcon = {} as any;
    if (score > 0 && score < 0.5) {
      obj.color = "#ff4e42";
      obj.icon = "&#9650;";
    } else if (score >= 0.5 && score < 0.9) {
      obj.color = "#ffa400";
      obj.icon = "&#9632;";
    } else if (score >= 0.9 && score <= 1) {
      obj.color = "#0cce6b";
      obj.icon = "&#9679;";
    }
    return obj;
  }

  getRecommendationDataEnableCompression(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["uses-text-compression"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "All modern browsers support and automatically negotiate gzip compression for all HTTP requests. Enabling gzip compression can reduce the size of the transferred response by up to 90%, which can significantly reduce the amount of time to download the resource, reduce data usage for the client, and improve the time to first render of your pages.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["uses-text-compression"]["details"]["items"];
      rec.title = "Enable Compression";
      rec.recommendation =
        "Enable and test gzip compression support on your web server for above domains.";
    }
    return rec;
  }

  getRecommendationDataLeverageBrowserCaching(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["uses-long-cache-ttl"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "Fetching resources over the network is both slow and expensive: the download may require multiple roundtrips between the client and server, which delays processing and may block rendering of page content, and also incurs data costs for the visitor. All server responses should specify a caching policy to help the client determine if and when it can reuse a previously fetched response.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["uses-long-cache-ttl"]["details"]["items"];
      rec.title = "Leverage browser caching";
      rec.recommendation =
        "Each resource should specify an explicit caching policy. Cache-Control defines how, and for how long the individual response can be cached by the browser. ETag provides a revalidation token that is automatically sent by the browser to check if the resource has changed since the last time it was requested.";
    }
    return rec;
  }

  getRecommendationDataMinifyCSS(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["unminified-css"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "Minification refers to the process of removing unnecessary or redundant data without affecting how the resource is processed by the browser - e.g. code comments and formatting, removing unused code, using shorter variable and function names, and so on.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["unminified-css"]["details"]["items"];
      rec.title = "Minify CSS";
      rec.recommendation = "You should minify your CSS resources. ";
    }
    return rec;
  }
  getRecommendationDataMinifyJavaScript(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["unminified-javascript"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "Minification refers to the process of removing unnecessary or redundant data without affecting how the resource is processed by the browser - e.g. code comments and formatting, removing unused code, using shorter variable and function names, and so on.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["unminified-javascript"]["details"]["items"];
      rec.title = "Minify JavaScript";
      rec.recommendation =
        "You should minify your JavaScript resources. For minifying JavaScript, try the Closure Compiler, JSMin or the YUI Compressor. ";
    }
    return rec;
  }

  getRecommendationDataEliminateRender(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["render-blocking-resources"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "Before the browser can render a page it has to build the DOM tree by parsing the HTML markup. During this process, whenever the parser encounters a script it has to stop and execute it before it can continue parsing the HTML. In the case of an external script the parser is also forced to wait for the resource to download, which may incur one or more network roundtrips and delay the time to first render of the page.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["render-blocking-resources"]["details"]["items"];
      rec.title =
        "Eliminate render-blocking JavaScript and CSS in above-the-fold content";
      rec.recommendation =
        "You should avoid and minimize the use of blocking JavaScript, especially external scripts that must be fetched before they can be executed. Scripts that are necessary to render page content can be inlined to avoid extra network requests. Scripts that are not critical to initial render should be made asynchronous or deferred until after the first render.";
    }
    return rec;
  }

  getRecommendationDataOptimizeImages(): Recommendation {
    let rec: Recommendation = {} as any;

    let sizeOfItems = JSON.parse(localStorage.getItem("GPS"))[
      "lighthouseResult"
    ]["audits"]["uses-webp-images"]["details"]["items"].length;
    if (sizeOfItems == 0) {
      rec.dataPresent = false;
    } else {
      rec.dataPresent = true;
      rec.observation =
        "Images often account for most of the downloaded bytes on a page. As a result, optimizing images can often yield some of the largest byte savings and performance improvements: the fewer bytes the browser has to download, the less competition there is for the client's bandwidth and the faster the browser can download and render content on the screen.";
      rec.analysis = JSON.parse(localStorage.getItem("GPS"))[
        "lighthouseResult"
      ]["audits"]["uses-webp-images"]["details"]["items"];
      rec.title = "Optimize Images";
      rec.recommendation =
        "Finding the optimal format and optimization strategy for your image assets requires careful analysis across many dimensions: type of data being encoded, image format capabilities, quality settings, resolution. In addition, you need to consider whether some images are best served in a vector format, or the desired effects can be achieved via CSS.";
    }
    return rec;
  }

  getSeoRecommendations = (audits, categoryGroups): any => {
    let tempData = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"];
    let seoCategoryAuditRefs = tempData["categories"]["seo"]["auditRefs"];
    let seoData = tempData["categories"]["seo"];

    let seoRecommendations = {};
    let groupedAuditRefs: {};

    _set(seoRecommendations, ["title"], _get(seoData, ["title"]));
    _set(seoRecommendations, ["description"], _get(seoData, ["description"]));
    _set(seoRecommendations, ["score"], _get(seoData, ["score"]));

    groupedAuditRefs = this.groupAuditRefs(
      seoCategoryAuditRefs,
      categoryGroups,
      _get(seoData, ["manualDescription"])
    );

    //mapping auditscores to audits

    seoCategoryAuditRefs.forEach((audit) => {
      let groupedAudit = groupedAuditRefs[getAuditGroup(audit)].audits;
      groupedAudit.forEach((auditInGroup) => {
        audit.id == auditInGroup.id
          ? (auditInGroup.data = audits[audit.id])
          : null;
      });
    });
    _set(seoRecommendations, ["recommendations"], groupedAuditRefs);
    return seoRecommendations;
  };

  groupAuditRefs = (categoryAuditRefs, categoryGroups, manualDesc): {} => {
    let groupedAuditRefs = {};
    categoryAuditRefs.forEach((element) => {
      //grouping
      if (groupedAuditRefs[element.group] == undefined)
        //if group not given then consider as manual
        _set(
          groupedAuditRefs,
          getAuditGroup(element),
          {
            data:
              element.group != undefined
                ? categoryGroups[element.group]
                : { title: "Manual", description: manualDesc },
            audits: [],
          } //create array for each category
        );
      _set(element, "data", {});

      groupedAuditRefs[getAuditGroup(element)].audits.push(element);
    });
    return groupedAuditRefs;
  };

  getAccessibilityRecommendations = (audits, categoryGroups): any => {
    let tempData = JSON.parse(localStorage.getItem("GPS"))["lighthouseResult"];
    let accessibilityCategoryAuditRefs =
      tempData["categories"]["accessibility"]["auditRefs"];
    let accessibilityData = tempData["categories"]["accessibility"];

    let accessibilityRecommendations = {};
    let groupedAuditRefs: {};

    _set(
      accessibilityRecommendations,
      ["title"],
      _get(accessibilityData, ["title"])
    );
    _set(
      accessibilityRecommendations,
      ["description"],
      _get(accessibilityData, ["description"])
    );
    _set(
      accessibilityRecommendations,
      ["score"],
      _get(accessibilityData, ["score"])
    );

    groupedAuditRefs = this.groupAuditRefs(
      accessibilityCategoryAuditRefs,
      categoryGroups,
      _get(accessibilityData, ["manualDescription"])
    );

    accessibilityCategoryAuditRefs.forEach((audit) => {
      let groupedAudit = groupedAuditRefs[getAuditGroup(audit)].audits;
      groupedAudit.forEach((auditInGroup) => {
        audit.id == auditInGroup.id
          ? (auditInGroup.data = audits[audit.id])
          : null;
      });
    });
    _set(accessibilityRecommendations, ["recommendations"], groupedAuditRefs);
    return accessibilityRecommendations;
  };
}
