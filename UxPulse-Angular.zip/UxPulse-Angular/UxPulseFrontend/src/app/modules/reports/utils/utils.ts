export const getAuditGroup = (element) => {
  return element.group == undefined ? "manual" : element.group;
};
