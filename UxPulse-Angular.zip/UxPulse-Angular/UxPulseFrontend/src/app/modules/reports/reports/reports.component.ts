import { Component, OnInit } from "@angular/core";
import { ReportService } from "../ReportService/report.service";
import { UrlorScript } from "../../scheduler/url-script/url-script.component";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { API_URL } from "../../../core/config/config";
import { getUserInfo } from "../../../shared/utils/utils";
import * as _get from "lodash/get";

@Component({
  selector: "app-reports",
  templateUrl: "./reports.component.html",
  styleUrls: ["./reports.component.css"],
})
export class ReportsComponent implements OnInit {
  constructor(
    private reportService: ReportService,
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}
  email: string;
  reqLabel: string;
  scheduleLabel: string;

  async ngOnInit(): Promise<void> {
    this.activatedRoute.queryParams.subscribe(async (params) => {
      this.reqLabel = params["reqLabel"];
      this.scheduleLabel = params["scheduleLabel"]; // Print the parameter to the console.
      this.recommendationsForm = this.fb.group({
        url: ["", [Validators.required]],
      });
      this.endUserForm = this.fb.group({
        url: ["", [Validators.required]],
      });
      this.email = _get(await getUserInfo(), ["email"]);

      if (localStorage.getItem("scheduleLabel")) {
        this.reqLabel = localStorage.getItem("requestLabel");
        this.scheduleLabel = localStorage.getItem("scheduleLabel");
      }
      this.getListOfLabels(this.reqLabel);
      this.recommendationPath = window.location.origin + "/recommendation";
    });
  }

  recommendationsForm: FormGroup;
  endUserForm: FormGroup;
  labels: UrlorScript[] = [];
  public recommendationPath;

  async getListOfLabels(requestID: string) {
    let list = await this.reportService.getListofLabels(requestID, this.email);
    // this.labels = list.body;
    for (let index = 0; index < list.body.length; index++) {
      const element = list.body[index];
      if (element.isScript != true) {
        this.labels.push(element);
      }
    }
  }

  async onViewRecommendationsReport() {
    localStorage.setItem("url", this.recommendationsForm.get("url").value);
    localStorage.removeItem("GPS");
    // this.reportService.getRecommendationReport(
    //   this.recommendationsForm.get("url").value
    // );
    this.router.navigate(["/recommendation"]);
  }
  async onViewEndUserReport() {
    alert(
      "We are working on this part. Please contact  dev team for further assistance!!"
    );
  }

  onDownloadEndUserReport = async () => {
    let requestLabel = localStorage.getItem("requestLabel");
    let scheduleLabel = localStorage.getItem("scheduleLabel");
    const { username, email } = await getUserInfo();
    window.open(
      API_URL +
        "/getEndUserReport?scheduleLabel=" +
        scheduleLabel +
        "&requestLabel=" +
        requestLabel +
        "&email=" +
        email +
        "&username=" +
        username,
      "_blank"
    );
  };

  onDownloadRecommendationsReport = async () => {};
}
