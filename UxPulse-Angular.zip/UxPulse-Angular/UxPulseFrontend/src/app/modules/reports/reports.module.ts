import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ReportsRoutingModule } from "./reports-routing.module";
import { ReportsComponent } from "./reports/reports.component";
import { CustomMaterialModule } from "src/app/core/design/custom-material/custom-material.module";
import { RecommendationReportComponent } from './recommendation-report/recommendation-report.component';

@NgModule({
  declarations: [ReportsComponent, RecommendationReportComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    CustomMaterialModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class ReportsModule {}
