import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { ReschedulerRoutingModule } from "./rescheduler-routing.module";
import { ReschedulerComponent } from "./rescheduler/rescheduler.component";
import { CustomMaterialModule } from "src/app/core/design/custom-material/custom-material.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CalendarComponent } from "../scheduler/calendar/calendar.component";
import { SchedulerModule } from "../scheduler/scheduler.module";

@NgModule({
  declarations: [ReschedulerComponent],
  imports: [
    CommonModule,
    ReschedulerRoutingModule,
    CustomMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    SchedulerModule,
  ],
})
export class ReschedulerModule {}
