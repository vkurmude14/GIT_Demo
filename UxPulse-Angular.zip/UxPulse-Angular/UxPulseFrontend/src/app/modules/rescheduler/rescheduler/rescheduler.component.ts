import { Component, OnInit } from "@angular/core";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { startWith, map } from "rxjs/operators";
import { HomeService } from "../../home/homeService/home.service";
import { SchedulerService } from "../../scheduler/SchedulerService/scheduler.service";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";
import * as moment from "moment";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-rescheduler",
  templateUrl: "./rescheduler.component.html",
  styleUrls: ["./rescheduler.component.css"],
})
export class ReschedulerComponent implements OnInit {
  requestID = new FormControl();
  scheduleName = new FormControl();
  options: string[] = [];
  filteredOptions: Observable<string[]>;

  constructor(
    private homeService: HomeService,
    private schedulerService: SchedulerService,
    private infoBoxService: InfoBoxService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.getListOfRequests();
  }

  async getListOfRequests() {
    let data = await this.homeService.getListOfRequestsFromAPI(
      JSON.parse(localStorage.getItem("token")).email
    );
    this.options = data.body;
    this.filteredOptions = this.requestID.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let xyz = this._filter(value);
        // if (xyz.length == 0) {
        //   localStorage.setItem("requestLabel", "No Results Found");
        // } else {
        //   localStorage.setItem("requestLabel", value);
        // }
        return xyz;
      })
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter((option) =>
      option.toLowerCase().includes(filterValue)
    );
  }

  async onSubmit() {
    let isScheduleNameUsed = await this.schedulerService.isScheduleNameUsed(
      this.requestID.value,
      this.scheduleName.value
    );

    let data = await this.schedulerService.getListofLocationAndUrlFromRequestID(
      this.requestID.value
    );
    if (isScheduleNameUsed.body != true && data.success == true) {
      await this.schedulerService.schedule(
        {
          locations: data.body.locations,
          urlsLabel: data.body.urlsLabel,
          from: moment(this.infoBoxService.from).format("MM/DD/YYYY"),
          to: moment(this.infoBoxService.to).format("MM/DD/YYYY"),
          intervalUnit: this.infoBoxService.inntervalUnit,
          interval: this.infoBoxService.interval,
          requestLabel: this.requestID.value,
          scheduleName: this.scheduleName.value,
        },
        JSON.parse(localStorage.getItem("token")).username
      );
      this.toastr.success("ReScheduled Successfuly");
    } else {
      this.toastr.error("Schedule Name is Already Used");
    }
  }
}
