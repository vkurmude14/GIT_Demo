import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReschedulerComponent } from './rescheduler.component';

describe('ReschedulerComponent', () => {
  let component: ReschedulerComponent;
  let fixture: ComponentFixture<ReschedulerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReschedulerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReschedulerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
