import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";
import { ElementSchemaRegistry } from "@angular/compiler";
import { ToastrService } from "ngx-toastr";

export interface UrlorScript {
  label: string;
  urlOrScript: string;
  isCustomer: boolean;
  isScript: boolean;
}

@Component({
  selector: "uxpulse-url-script",
  templateUrl: "./url-script.component.html",
  styleUrls: ["./url-script.component.css"],
})
export class UrlScriptComponent implements OnInit {
  form: FormGroup;
  urlOrScript: UrlorScript[];

  constructor(
    private fb: FormBuilder,
    private infoBoxService: InfoBoxService,
    private toastr: ToastrService
  ) {}

  isDisabled: boolean = true;
  ngOnInit(): void {
    this.urlOrScript = [];
    this.form = this.fb.group({
      isCustomer: false,
      label: ["", Validators.required],
      url: [
        { value: "", disabled: !this.isDisabled },
        [
          Validators.required,
          Validators.pattern(
            "^(http://www.|https://www.|http://|https://)?[a-z0-9]+([-.]{1}[a-z0-9]+)*.[a-z]{2,5}(:[0-9]{1,5})?(/.*)?$"
          ),
        ],
      ],
      isScript: ["url", Validators.required],
      script: [{ value: "", disabled: this.isDisabled }, Validators.required],
    });
  }

  labelAdded() {
    if (this.form.valid) {
      const isLabelValid = this.isLabelValid();
      if (isLabelValid) {
        if (this.form.get("isScript").value == "url") {
          this.infoBoxService.pushUrlOrLabels({
            label: this.form.get("label").value,
            urlOrScript: this.form.get("url").value,
            isCustomer: this.form.get("isCustomer").value,
            isScript: false,
          });
          this.toastr.success("Label Added Successfully");
          this.infoBoxService.pushInfoData({
            name:
              "Label Added : " +
              this.form.get("label").value +
              "-" +
              this.form.get("url").value,
            color: "green",
          });
        } else if (this.form.get("isScript").value == "script") {
          this.infoBoxService.pushUrlOrLabels({
            label: this.form.get("label").value,
            urlOrScript: this.form.get("script").value,
            isCustomer: this.form.get("isCustomer").value,
            isScript: true,
          });
          this.toastr.success("Label Added Successfully");
          this.infoBoxService.pushInfoData({
            name:
              "Label Added : " +
              this.form.get("label").value +
              "-" +
              this.form.get("script").value,
            color: "green",
          });
        }
      } else if (!isLabelValid) {
        this.toastr.error("Label Name Already Used");
      }
    }
  }

  isLabelValid(): boolean {
    let isLabelValid: boolean = true;
    this.urlOrScript = this.infoBoxService.geturlOrLabels();
    for (let index = 0; index < this.urlOrScript.length; index++) {
      const element = this.urlOrScript[index];
      if (element.label == this.form.get("label").value) {
        isLabelValid = false;
      }
    }
    return isLabelValid;
  }

  clickUrl() {
    this.form.controls["script"].disable();
    this.form.controls["url"].enable();
    this.form.get("isScript").setValue("url");
  }

  clickScript() {
    this.form.controls["url"].disable();
    this.form.controls["script"].enable();
    this.form.get("isScript").setValue("script");
  }
}
