import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrlScriptComponent } from './url-script.component';

describe('UrlScriptComponent', () => {
  let component: UrlScriptComponent;
  let fixture: ComponentFixture<UrlScriptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UrlScriptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrlScriptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
