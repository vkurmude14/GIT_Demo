import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { InfoBoxService, infoStyle } from "src/app/shared/services/InfoBox/info-box.service";

@Component({
  selector: "uxpulse-scheduler",
  templateUrl: "./scheduler.component.html",
  styleUrls: ["./scheduler.component.css"],
})
export class SchedulerComponent implements OnInit {
  @ViewChild("scrollMe") private myScrollContainer: ElementRef;

  infoBoxData: infoStyle[] = [];

  constructor(private infoBoxService: InfoBoxService) {
    this.infoBoxData = infoBoxService.getInfoData();
  }

  ngOnInit(): void {
    this.scrollToBottom();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) {}
  }
}
