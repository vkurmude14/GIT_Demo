import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { SchedulerRoutingModule } from "./scheduler-routing.module";
import { LocationComponent } from "./location/location.component";
import { CustomMaterialModule } from "src/app/core/design/custom-material/custom-material.module";
import { SchedulerComponent } from "./scheduler/scheduler.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { UrlScriptComponent } from "./url-script/url-script.component";
import { CalendarComponent } from "./calendar/calendar.component";
import { ScheduleComponent } from "./schedule/schedule.component";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";

@NgModule({
  declarations: [
    LocationComponent,
    SchedulerComponent,
    UrlScriptComponent,
    CalendarComponent,
    ScheduleComponent,
  ],
  imports: [
    CommonModule,
    SchedulerRoutingModule,
    CustomMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMultiSelectModule,
  ],
  exports: [CalendarComponent],
})
export class SchedulerModule {
  static forRoot() {
    return {
      ngModule: SchedulerModule,
      providers: [{ provide: InfoBoxService }],
    };
  }
}
