import { Component, OnInit, ViewChild } from "@angular/core";
import { LocationService } from "./locationService/location.service";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "uxpulse-location",
  templateUrl: "./location.component.html",
  styleUrls: ["./location.component.css"],
})
export class LocationComponent implements OnInit {
  selectedItems = [];
  settings = {};
  itemList = [];

  constructor(
    private locationService: LocationService,
    private infoBoxService: InfoBoxService,
    private toastr: ToastrService
  ) {
    this.itemList = locationService.getItemList();
  }

  ngOnInit(): void {
    this.selectedItems = [];

    this.settings = {
      singleSelection: false,
      selectGroup: false,
      text: "Select Location",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      searchPlaceholderText: "Search Location",
      enableSearchFilter: true,
      badgeShowLimit: 1000,
      searchBy: ["itemName", "group"],
      groupBy: "group",
      enableCheckAll: false,
      enableFilterSelectAll: false,
    };
  }

  onItemSelect(item: any) {
    this.toastr.success(item.itemName + " Added Succesfully");
    this.infoBoxService.pushInfoData({
      name: "Location Added :" + item.itemName,
      color: "green",
    });
    this.infoBoxService.pushLocations(item.name);
  }
  onSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.infoBoxService.pushInfoData({
        name: "Location Added :" + element.itemName,
        color: "green",
      });
    }
  }

  OnItemDeSelect(item: any) {
    this.toastr.error(item.itemName + " Removed Succesfully");
    this.infoBoxService.pushInfoData({
      name: "Location Removed :" + item.itemName,
      color: "red",
    });
    this.infoBoxService.popLocations(item.name);
  }

  onDeSelectAll(items: any) {
    for (let index = 0; index < items.length; index++) {
      const element = items[index];
      this.infoBoxService.pushInfoData({
        name: "Location Removed :" + element.itemName,
        color: "red",
      });
    }
  }
}
