import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { API_URL } from "src/app/core/config/config";

@Injectable({
  providedIn: "root",
})
export class LocationService {
  constructor(private http: HttpClient) {}

  itemList: any;

  public getItemList() {
    return this.itemList;
  }

  load() {
    return new Promise((resolve, reject) => {
      this.http.get<any>(API_URL + "/getLocations").subscribe((response) => {
        this.itemList = response.body;
        resolve(true);
      });
    });
  }
}
