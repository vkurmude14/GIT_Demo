import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import {
  SchedulerService,
  SchedulerDto,
} from "../SchedulerService/scheduler.service";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";
import * as moment from "moment";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "uxpulse-schedule",
  templateUrl: "./schedule.component.html",
  styleUrls: ["./schedule.component.css"],
})
export class ScheduleComponent implements OnInit {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private schedulerService: SchedulerService,
    private infoBoxService: InfoBoxService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      label: [, [Validators.required, Validators.maxLength(8)]],
      scheduleName: [, [Validators.required, Validators.maxLength(8)]],
    });
  }

  schedule: SchedulerDto;
  async onSubmit() {
    if (this.infoBoxService.getLocations().length == 0) {
      this.toastr.error("Please Add atleast one location");
      this.infoBoxService.pushInfoData({
        name: "Please Add atleast one location",
        color: "red",
      });
    } else if (this.infoBoxService.geturlOrLabels().length == 0) {
      this.toastr.error("Please Add atleast one Url Or Script");
      this.infoBoxService.pushInfoData({
        name: "Please Add atleast one Url Or Script",
        color: "red",
      });
    } else if (this.infoBoxService.calendarClicked == false) {
      this.infoBoxService.pushInfoData({
        name: "Please Set Date,Intervals in Calendar",
        color: "red",
      });
    } else {
      if (this.form.valid) {
        let data = await this.schedulerService.isRequestIdUsed(
          this.form.get("label").value
        );
        if (data.body == true) {
          this.toastr.error("Request Label already in Use");
        } else {
          let data = await this.scheduler();
          data.success === true
            ? this.toastr.success(data.body) &&
              this.infoBoxService.pushInfoData({
                name: data.body,
                color: "green",
              })
            : this.toastr.error(data.body) &&
              this.infoBoxService.pushInfoData({
                name: data.message,
                color: "red",
              });
        }
      }
    }
  }

  scheduler() {
    return this.schedulerService.schedule(
      {
        locations: this.infoBoxService.getLocations(),
        urlsLabel: this.infoBoxService.geturlOrLabels(),
        from: moment(this.infoBoxService.from).format("MM/DD/YYYY"),
        to: moment(this.infoBoxService.to).format("MM/DD/YYYY"),
        intervalUnit: this.infoBoxService.inntervalUnit,
        interval: this.infoBoxService.interval,
        requestLabel: this.form.get("label").value,
        scheduleName: this.form.get("scheduleName").value,
      },
      JSON.parse(localStorage.getItem("token")).username
    );
  }
}
