import { Injectable } from "@angular/core";
import { axiosInstance } from "src/app/shared/utils/axios-custom";
import { getDataFromHttpResponse } from "src/app/shared/utils/utils";
import { UrlorScript } from "../url-script/url-script.component";

export interface SchedulerDto {
  locations: string[];
  urlsLabel: UrlorScript[];
  from: string;
  to: string;
  intervalUnit: string;
  interval: string;
  requestLabel: string;
  scheduleName: string;
}

@Injectable({
  providedIn: "root",
})
export class SchedulerService {
  constructor() {}

  async schedule(schedule: SchedulerDto, username: string): Promise<any> {
    return axiosInstance
      .post("/schedule?username=" + username, schedule)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        // always executed
      });
  }

  async isRequestIdUsed(requestID: string): Promise<any> {
    return axiosInstance
      .get("/checkRequestID?requestID=" + requestID)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }

  async isScheduleNameUsed(
    requestID: string,
    scheduleName: string
  ): Promise<any> {
    return axiosInstance
      .get(
        "/checkScheduleName?requestID=" +
          requestID +
          "&scheduleName=" +
          scheduleName
      )
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }
  async getListofLocationAndUrlFromRequestID(requestID: string): Promise<any> {
    return axiosInstance
      .get("/getListofLocationAndUrlFromRequestID?requestID=" + requestID)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed;
      });
  }
}
