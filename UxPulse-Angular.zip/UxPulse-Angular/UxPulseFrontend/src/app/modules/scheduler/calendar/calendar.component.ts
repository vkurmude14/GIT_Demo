import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { InfoBoxService } from "src/app/shared/services/InfoBox/info-box.service";
import * as moment from "moment";

interface Interval {
  interval: string;
  value: string;
}

@Component({
  selector: "uxpulse-calendar",
  templateUrl: "./calendar.component.html",
  styleUrls: ["./calendar.component.css"],
})
export class CalendarComponent implements OnInit {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private infoBoxService: InfoBoxService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      From: [new Date(), Validators.required],
      To: [new Date(), Validators.required],
      intervalValue: [8, Validators.required],
      intervalUnit: ["HOURLY", Validators.required],
    });
    this.infoBoxService.calendarClicked = false;
    this.form.controls["To"].setValue(this.getTomorrow());
  }
  getTomorrow() {
    let d = new Date();
    d.setDate(d.getDate() + 1);
    return d;
  }
  intervals: Interval[] = [
    { interval: "Hours", value: "HOURLY" },
    { interval: "Minutes", value: "MINUTE" },
    { interval: "Days", value: "DAILY" },
    { interval: "Week", value: "WEEKLY" },
  ];

  FromMinDate = new Date();
  ToMinDate: Date;

  addEventFrom(type: string, event: MatDatepickerInputEvent<Date>) {
    this.ToMinDate = this.form.get("From").value;
  }

  onSubmit() {
    if (this.form.valid) {
      this.infoBoxService.from = this.form.get("From").value;
      this.infoBoxService.to = this.form.get("To").value;
      this.infoBoxService.inntervalUnit = this.form.get("intervalUnit").value;
      this.infoBoxService.interval = this.form.get("intervalValue").value;
      this.infoBoxService.pushInfoData({
        name:
          "From : " + moment(this.form.get("From").value).format("MM/DD/YYYY"),
        color: "green",
      });
      this.infoBoxService.pushInfoData({
        name: "To : " + moment(this.form.get("To").value).format("MM/DD/YYYY"),
        color: "green",
      });
      this.infoBoxService.pushInfoData({
        name: "Interval : " + this.form.get("intervalValue").value,
        color: "green",
      });
      this.infoBoxService.pushInfoData({
        name: "IntervalUnit : " + this.form.get("intervalUnit").value,
        color: "green",
      });
      this.infoBoxService.calendarClicked = true;
    }
  }
}
