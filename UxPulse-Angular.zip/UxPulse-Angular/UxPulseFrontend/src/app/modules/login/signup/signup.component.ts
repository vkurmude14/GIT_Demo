import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { SignupService } from "../signupService/signup.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";

@Component({
  selector: "uxpulse-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.css"],
})
export class SignupComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private signupService: SignupService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  form: FormGroup;

  ngOnInit(): void {
    this.form = this.fb.group({
      username: ["", [Validators.required, Validators.maxLength(8)]],
      email: [
        "",
        [
          Validators.required,
          Validators.email,
          Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
        ],
      ],
      password: ["", [Validators.required, Validators.minLength(8)]],
    });
  }

  async onSubmit() {
    if (this.form.valid) {
      let isUserNameAvailable = await this.signupService.isUserNameAvailable(
        this.form.get("username").value
      );
      if (isUserNameAvailable.body == true) {
        let res = await this.signupService.signup(this.form.value);
        res.success === true
          ? this.toastr.success(res.message) && this.router.navigate(["/login"])
          : this.toastr.error(res.message);
      } else {
        this.toastr.error("User Name Already Used");
      }
    }
  }
}
