import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { Router } from "@angular/router";
import { LoginDto } from "src/app/shared/models/LoginDto";
import {
  encodeBase64,
  getDataFromHttpResponse,
} from "../../../shared/utils/utils";
import { axiosInstance } from "../../../shared/utils/axios-custom";

@Injectable({
  providedIn: "root",
})
export class LoginService {
  constructor(private router: Router) {}

  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(
    this.hasToken()
  );

  isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  async login(user: LoginDto) {
    if (user.email !== "" && user.password !== "") {
      return axiosInstance
        .post("/login", {
          ...user,
          password: encodeBase64(user.password),
        })
        .then((response) => {
          let data = getDataFromHttpResponse(response);
          if (data.success == true) {
            localStorage.setItem(
              "token",
              JSON.stringify({
                username: data.body.username,
                email: data.body.email,
              })
            );
            this.loggedIn.next(true);
          } else {
            this.loggedIn.next(false);
          }
          return data;
        })
        .catch((error) => {
          alert(error.message);
        })
        .finally(() => {
          // always executed
        });
    }
  }

  logout() {
    localStorage.removeItem("token");
    this.loggedIn.next(false);
    this.router.navigate(["/login"]);
    window.location.reload();
  }

  private hasToken(): boolean {
    return !!localStorage.getItem("token");
  }
}
