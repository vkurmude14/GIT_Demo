import { Injectable } from "@angular/core";
import { axiosInstance } from "../../../shared/utils/axios-custom";
import { SignUpDto } from "../../../shared/models/SignUpDto";
import {
  getDataFromHttpResponse,
  encodeBase64,
} from "../../../shared/utils/utils";

@Injectable()
export class SignupService {
  constructor() {}

  async signup(user: SignUpDto): Promise<any> {
    return axiosInstance
      .post("/signup", { ...user, password: encodeBase64(user.password) })
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        // always executed
      });
  }

  async isUserNameAvailable(username: string): Promise<any> {
    return axiosInstance
      .get("/isUserNameAvailable?username=" + username)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed
      });
  }
}
