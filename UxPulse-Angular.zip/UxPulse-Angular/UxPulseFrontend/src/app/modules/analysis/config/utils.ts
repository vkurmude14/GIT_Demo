export const CHECKPOINTS_MAP_TO_TEXT = {
  score_OnPageRedirects: "Page level Redirects",
  score_keep_alive: "Keep Alive",
  score_gzip: "Gzip Compression",
  score_compress: "Image Compression",
  score_progressive_jpeg: "Progressive Images",
  score_minify: "Minification",
  score_cdn: "Use of CDN",
  score_renderBlockingJs: "Render Blocking JavaScript",
  score_cssDelivery: "Css Content Delivery links",
  score_BrowserResponseTime: "Browser Response Time",
  score_cache: "Browser Caching Policy",
};

export const CHECKPOINTS_MULTTIPLY = {
  score_compress: 0.07,
  score_progressive_jpeg: 0.03,
};

export const CHECKPOINTS_DIVIDE = {
  score_OnPageRedirects: 10,
  score_keep_alive: 10,
  score_gzip: 10,
  score_minify: 10,
  score_cache: 10,
  score_cdn: 10,
  score_renderBlockingJs: 10,
  score_cssDelivery: 10,
  score_BrowserResponseTime: 10,
};
