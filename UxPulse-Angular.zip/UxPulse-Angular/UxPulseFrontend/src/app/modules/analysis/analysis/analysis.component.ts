import { Component, OnInit } from "@angular/core";
import { AnalysisService } from "../analysisService/analysis.service";
import {
  CHECKPOINTS_MAP_TO_TEXT,
  CHECKPOINTS_MULTTIPLY,
  CHECKPOINTS_DIVIDE,
} from "../config/utils";
import * as _pullAllBy from "lodash/pullAllBy";
import { ActivatedRoute } from "@angular/router";
import * as _get from "lodash/get";
import { getUserInfo } from "../../../shared/utils/utils";

@Component({
  selector: "uxpulse-analysis",
  templateUrl: "./analysis.component.html",
  styleUrls: ["./analysis.component.css"],
})
export class AnalysisComponent implements OnInit {
  constructor(
    private analysisService: AnalysisService,
    private activatedRoute: ActivatedRoute
  ) {}
  email: string;
  dataArr: any = [];
  labels: string[] = ["ALL"];
  allData: {};
  ELEMENT_DATA: any[] = [];
  chosenLabel = "ALL";
  loading: boolean = true;
  reqLabel: string;
  scheduleLabel: String;

  async ngOnInit(): Promise<void> {
    this.activatedRoute.queryParams.subscribe(async (params) => {
      this.reqLabel = params["reqLabel"];
      this.scheduleLabel = params["scheduleLabel"]; // Print the parameter to the console.

      if (localStorage.getItem("scheduleLabel")) {
        this.reqLabel = localStorage.getItem("requestLabel");
        this.scheduleLabel = localStorage.getItem("scheduleLabel");
      }

      this.email = _get(await getUserInfo(), ["email"]);
      //get initially all data
      this.allData = await this.analysisService.getDataFromBackend(
        this.reqLabel,
        this.scheduleLabel,
        null,
        this.email
      );
      this.loading = false;
      this.labels.push(...this.allData["labels"]);
      this.pushDataToDataArr(this.allData);
    });
  }
  pushDataToDataArr = (toPush) => {
    this.ELEMENT_DATA = [];
    Object.keys(toPush).forEach((key) => {
      key != "labels" &&
        this.ELEMENT_DATA.push({
          checkpoint: CHECKPOINTS_MAP_TO_TEXT[key],
          score: CHECKPOINTS_MULTTIPLY[key]
            ? toPush[key] == "NA"
              ? toPush[key]
              : toPush[key] * CHECKPOINTS_MULTTIPLY[key]
            : CHECKPOINTS_DIVIDE[key]
            ? toPush[key] == "NA"
              ? toPush[key]
              : toPush[key] / CHECKPOINTS_DIVIDE[key]
            : "NA",
        });
    });

    this.dataArr.push({
      label: this.chosenLabel,
      schedule: this.scheduleLabel,
      dataSource: this.ELEMENT_DATA,
      colName: Object.keys(this.ELEMENT_DATA[0]),
    });
  };
  handleLabelFilterChange = async (event: any) => {
    this.loading = true;
    this.chosenLabel = event.value;
    let reqLabel = localStorage.getItem("requestLabel");
    let scheduleLabel = localStorage.getItem("scheduleLabel");

    let temp = await this.analysisService.getDataFromBackend(
      reqLabel,
      scheduleLabel,
      this.chosenLabel == "ALL" ? null : this.chosenLabel,
      this.email
    );

    this.loading = false;
    this.ELEMENT_DATA = [];
    let toRemove = this.labels.map((val) => {
      if (val != "ALL")
        return {
          label: val,
        };
    });
    if (this.dataArr.length == 2) _pullAllBy(this.dataArr, toRemove, "label");
    this.chosenLabel == "ALL"
      ? _pullAllBy(this.dataArr, toRemove, "label")
      : this.pushDataToDataArr(temp);
  };
}
