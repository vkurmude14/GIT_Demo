import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { AnalysisRoutingModule } from "./analysis-routing.module";
import { AnalysisComponent } from "./analysis/analysis.component";
import { CustomMaterialModule } from "../../core/design/custom-material/custom-material.module";
import { AnalysisService } from "./analysisService/analysis.service";

@NgModule({
  declarations: [AnalysisComponent],
  imports: [CommonModule, AnalysisRoutingModule, CustomMaterialModule],
  providers: [AnalysisService],
})
export class AnalysisModule {}
