import { Injectable } from "@angular/core";
import { axiosInstance } from "../../../shared/utils/axios-custom";
import { getDataFromHttpResponse } from "../../../shared/utils/utils";

@Injectable()
export class AnalysisService {
  constructor() {}

  getDataFromBackend = async (
    reqLabel: String,
    scheduleLabel: String,
    label: string,
    email: string
  ) => {
    if ("" == reqLabel || "" == scheduleLabel) {
      throw new Error("Please choose both request label and schedule label");
    }
    let path = "/getAnalysisData?requestLabel=" + reqLabel + "&email=" + email;
    if (scheduleLabel) path = path + "&" + "scheduleLabel=" + scheduleLabel;
    if (label) path = path + "&" + "label=" + label;
    return axiosInstance
      .get(path)
      .then((response) => {
        return getDataFromHttpResponse(response).body;
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        // always executed
      });
  };
}
