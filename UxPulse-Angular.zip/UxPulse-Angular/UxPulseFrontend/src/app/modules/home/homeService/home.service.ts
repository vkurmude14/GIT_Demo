import { Injectable } from "@angular/core";
import { axiosInstance } from "src/app/shared/utils/axios-custom";
import { getDataFromHttpResponse } from "src/app/shared/utils/utils";
import { HttpClient } from "@angular/common/http";
import { DeleteRunDataDto } from "../home/home.component";

@Injectable({
  providedIn: "root",
})
export class HomeService {
  constructor(private http: HttpClient) {}

  async getListOfRequestsFromAPI(email: string) {
    return axiosInstance
      .get("/getRequests?email=" + email)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed
      });
  }

  async getListOfSchedulesFromAPI(email: string, requestID: string) {
    return axiosInstance
      .get("/getSchedules?email=" + email + "&requestID=" + requestID)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed
      });
  }

  async getListOfrunDataFromAPI(
    email: string,
    requestID: string,
    scheduleName: string
  ) {
    return axiosInstance
      .get(
        "/getRunData?email=" +
          email +
          "&requestID=" +
          requestID +
          "&scheduleName=" +
          scheduleName
      )
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed
      });
  }

  async deleteRunDataFromAPI(deleteRunData: DeleteRunDataDto) {
    return axiosInstance
      .post("deleteRunData", deleteRunData)
      .then((response) => {
        return getDataFromHttpResponse(response);
      })
      .catch((error) => {
        return error;
      })
      .finally(() => {
        //always executed
      });
  }
}
