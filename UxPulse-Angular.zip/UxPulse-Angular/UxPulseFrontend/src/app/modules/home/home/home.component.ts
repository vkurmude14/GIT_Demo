import { Component, OnInit, Pipe, PipeTransform } from "@angular/core";
import { HomeService } from "../homeService/home.service";
import { FormBuilder, FormGroup, FormControl, FormArray } from "@angular/forms";
import { SelectionModel } from "@angular/cdk/collections";
import { ToastrService } from "ngx-toastr";
import { ActivatedRoute } from "@angular/router";

@Pipe({ name: "groupBy" })
export class GroupByPipe implements PipeTransform {
  transform(value: Array<any>, field: string): Array<any> {
    const groupedObj = value.reduce((prev, cur) => {
      if (!prev[cur[field]]) {
        prev[cur[field]] = [cur];
      } else {
        prev[cur[field]].push(cur);
      }
      return prev;
    }, {});
    return Object.keys(groupedObj).map((key) => ({
      key,
      value: groupedObj[key],
    }));
  }
}

export interface Status {
  tag: string;
  message: string;
}

export interface RunData {
  testID: string;
  label: string;
  network: string;
  location: string;
  errors: string[];
  status: Status;
  groupID: string;
}

export interface DeleteRunDataDto {
  testIDs: string[];
  email: string;
  requestID: string;
  scheduleName: string;
}

@Component({
  selector: "uxpulse-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  form: FormGroup;

  selection = new SelectionModel<RunData>(true, []);

  isAllSelected(item: any) {
    let mySelected = 0;
    for (let index = 0; index < this.selection.selected.length; index++) {
      const element = this.selection.selected[index];
      for (let index = 0; index < item.value.length; index++) {
        const element1 = item.value[index];
        if (element.testID == element1.testID) {
          mySelected = mySelected + 1;
        }
      }
    }

    const numSelected = mySelected;
    const numRows = item.value.length;
    return numSelected === numRows;
  }

  selectItemvalue(item: any) {
    for (let index = 0; index < item.value.length; index++) {
      const element = item.value[index];
      this.selection.select(element);
    }
  }

  deSelectItemValue(item: any) {
    for (let index = 0; index < item.value.length; index++) {
      const element = item.value[index];
      this.selection.deselect(element);
    }
  }

  masterToggle(item: any) {
    this.isAllSelected(item)
      ? this.deSelectItemValue(item)
      : this.selectItemvalue(item);
  }

  constructor(
    private homeService: HomeService,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.reqLabel = params["reqLabel"];
      this.scheduleLabel = params["scheduleLabel"]; // Print the parameter to the console.
      // this.ngOnInit();

      if (localStorage.getItem("scheduleLabel")) {
        this.reqLabel = localStorage.getItem("requestLabel");
        this.scheduleLabel = localStorage.getItem("scheduleLabel");
      }
      this.getListOfRuns();
    });
  }
  reqLabel: string;
  scheduleLabel: string;
  runData: any;

  async getListOfRuns() {
    let data = await this.homeService.getListOfrunDataFromAPI(
      JSON.parse(localStorage.getItem("token")).email,
      this.reqLabel,
      this.scheduleLabel
    );
    this.runData = data.body;
  }

  async onDelete() {
    if (!this.selection.isEmpty()) {
      let testIDs: string[] = [];
      for (let index = 0; index < this.selection.selected.length; index++) {
        const element = this.selection.selected[index];
        testIDs.push(element.testID);
      }
      let deleteRunData: DeleteRunDataDto = {
        testIDs: testIDs,
        email: JSON.parse(localStorage.getItem("token")).email,
        requestID: localStorage.getItem("requestLabel"),
        scheduleName: localStorage.getItem("scheduleLabel"),
      };
      let data = await this.homeService.deleteRunDataFromAPI(deleteRunData);
      this.runData = data.body;
      this.toastr.success(data.message);
      this.selection.clear();
    } else {
      this.toastr.error("Please Select atleast one Request");
    }
  }

  colorcoding(tag: string) {
    let color;
    if (tag == "CREATED" || tag == "WAITING") {
      color = "	#00FFFF";
    } else if (tag == "FAILED" || tag == "CANCELLED") {
      color = "#FF0000";
    } else if (tag == "COMPLETE") {
      color = "#5cb85c";
    } else if (
      tag == "RUNNING" ||
      tag == "FETCHINGDATA" ||
      tag == "FETCHINGHAR" ||
      tag == "PROCESSING"
    ) {
      color = "#FFFF00";
    } else if (tag == "EXECUTED" || tag == "FETCHINGRAW") {
      color = "#00FF00";
    }
    return color;
  }
}
