import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { RecommendationReportComponent } from "./modules/reports/recommendation-report/recommendation-report.component";

const routes: Routes = [
  {
    path: "scheduler",
    loadChildren: () =>
      import("./modules/scheduler/scheduler.module").then(
        (m) => m.SchedulerModule
      ),
  },
  {
    path: "rescheduler",
    loadChildren: () =>
      import("./modules/rescheduler/rescheduler.module").then(
        (m) => m.ReschedulerModule
      ),
  },
  {
    path: "analysis",
    loadChildren: () =>
      import("./modules/analysis/analysis.module").then(
        (m) => m.AnalysisModule
      ),
  },
  {
    path: "dashboard",
    loadChildren: () =>
      import("./modules/dashboard/dashboard.module").then(
        (m) => m.DashboardModule
      ),
  },
  {
    path: "home",
    loadChildren: () =>
      import("./modules/home/home.module").then((m) => m.HomeModule),
  },
  {
    path: "reports",
    loadChildren: () =>
      import("./modules/reports/reports.module").then((m) => m.ReportsModule),
  },
  {
    path: "login",
    loadChildren: () =>
      import("./modules/login/login.module").then((m) => m.LoginModule),
  },
  {
    path: "recommendation",
    component: RecommendationReportComponent,
  },
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "**",
    redirectTo: "login",
    pathMatch: "full",
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { useHash: true, enableTracing: false }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
