import { Component } from "@angular/core";
import { BreakpointObserver } from "@angular/cdk/layout";
import { LoginService } from "./modules/login/loginService/login.service";
import { Observable } from "rxjs";
import { LocationService } from "./modules/scheduler/location/locationService/location.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
})
export class AppComponent {
  title = "UxPulseFrontend";

  constructor(private loginService: LoginService) {
    this.isLoggedIn$ = loginService.isLoggedIn();
  }

  isLoggedIn$: Observable<boolean>;

  ngOnInit() {
    console.log("AppComponent: OnInit()");
    //this.isLoggedIn$ = this.loginService.isLoggedIn();
  }
}
