import { Component } from "@angular/core";
import { BreakpointObserver, Breakpoints } from "@angular/cdk/layout";
import { Observable } from "rxjs";
import { map, shareReplay, startWith } from "rxjs/operators";
import { LoginService } from "src/app/modules/login/loginService/login.service";
import { FormControl } from "@angular/forms";
import { HomeService } from "src/app/modules/home/homeService/home.service";
import { Router, ActivatedRoute } from "@angular/router";
@Component({
  selector: "uxpulse-layout",
  templateUrl: "./uxpulse-layout.component.html",
  styleUrls: ["./uxpulse-layout.component.css"],
})
export class UxpulseLayoutComponent {
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );

  requestLabelOptions: string[] = [];
  scheduleLabelOptions: string[] = [];
  requestLabelfilteredOptions: Observable<string[]>;
  scheduleLabelfilteredOptions: Observable<string[]>;
  requestLabel = new FormControl();
  scheduleLabel = new FormControl();

  constructor(
    private breakpointObserver: BreakpointObserver,
    private loginService: LoginService,
    private homeService: HomeService,
    private route: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  isLoggedIn$: Observable<boolean>;

  ngOnInit() {
    this.getListOfRequests();

    this.isLoggedIn$ = this.loginService.isLoggedIn();
  }

  async getListOfRequests() {
    let data = await this.homeService.getListOfRequestsFromAPI(
      JSON.parse(localStorage.getItem("token")).email
    );
    this.requestLabelOptions = data.body;
    this.requestLabelfilteredOptions = this.requestLabel.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let xyz = this._filterRequestLabel(value);
        if (xyz.length == 0) {
          localStorage.setItem("requestLabel", "No Results Found");
        } else {
          localStorage.setItem("requestLabel", value);
          localStorage.setItem("scheduleLabel", "");
          this.scheduleLabel.setValue("");
          this.getListOfSchedules();
        }
        return xyz;
      })
    );
  }
  async getListOfSchedules() {
    let data = await this.homeService.getListOfSchedulesFromAPI(
      JSON.parse(localStorage.getItem("token")).email,
      localStorage.getItem("requestLabel")
    );
    this.scheduleLabelOptions = data.body;
    this.scheduleLabelfilteredOptions = this.scheduleLabel.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let xyz = this._filterScheduleLabel(value);
        if (xyz.length == 0) {
          localStorage.setItem("scheduleLabel", "No Schedule Found");
        } else {
          localStorage.setItem("scheduleLabel", value);
          if (localStorage.getItem("scheduleLabel") != "") {
            this.route.navigate([location.href.split("?")[0].split("#")[1]], {
              queryParams: {
                reqLabel: localStorage.getItem("requestLabel"),
                scheduleLabel: localStorage.getItem("scheduleLabel"),
              },
            });
          }
        }
        return xyz;
      })
    );
  }

  onLogout() {
    this.loginService.logout();
  }

  private _filterRequestLabel(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.requestLabelOptions.filter((option) =>
      option.toLowerCase().includes(filterValue)
    );
  }

  private _filterScheduleLabel(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.scheduleLabelOptions.filter((option) =>
      option.toLowerCase().includes(filterValue)
    );
  }
}
