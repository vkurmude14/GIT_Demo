import {
  BASE_URL,
  WAR_NAME,
  environment,
} from "../../../environments/environment";

export const API_URL: string = environment.production
  ? BASE_URL.tomcat + "/" + WAR_NAME
  : BASE_URL.springBoot + "/api/v1";
