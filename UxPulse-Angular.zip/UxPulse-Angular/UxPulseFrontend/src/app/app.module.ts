import { BrowserModule } from "@angular/platform-browser";
import {
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA,
  APP_INITIALIZER,
} from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { FooterComponent } from "./core/components/footer/footer.component";
import { CustomMaterialModule } from "./core/design/custom-material/custom-material.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { UxpulseLayoutComponent } from "./core/components/uxpulse-layout/uxpulse-layout.component";
import { LayoutModule } from "@angular/cdk/layout";
import { SchedulerModule } from "./modules/scheduler/scheduler.module";
import { HomeModule } from "./modules/home/home.module";
import { LoginModule } from "./modules/login/login.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { LocationService } from "./modules/scheduler/location/locationService/location.service";
import { ToastrModule } from "ngx-toastr";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { ReschedulerModule } from "./modules/rescheduler/rescheduler.module";

export function locationProviderFactory(provider: LocationService) {
  return () => provider.load();
}

@NgModule({
  declarations: [AppComponent, FooterComponent, UxpulseLayoutComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CustomMaterialModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      preventDuplicates: true,
      positionClass: "toast-top-right",
      timeOut: 3000,
    }),
    LayoutModule,
    HomeModule,
    LoginModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularMultiSelectModule,
    ReschedulerModule,
  ],
  providers: [
    LocationService,
    {
      provide: APP_INITIALIZER,
      useFactory: locationProviderFactory,
      deps: [LocationService],
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
