For using crossfilter in our applications, since the existing crossfilter library has issue with compatibilty, we have to modify one line of library's index.d.ts file.

follow below steps for that:

1, do "npm i" for installing all dependencies.
2, once dependencies are installed, goto node_modules -> crossfilter2 -> index.d.ts.
3, open the file in editor.
4, find the line "export = crossfilter" and modify it to "export default crossfilter"
