package core;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
// import java.util.concurrent.Callable;
import java.util.HashSet;
import java.util.Iterator;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import config.GlobalVariables;
import dao.Dao;
import dao.DaoFactory;
import dto.RunData;
import dto.StatusDto;
import dto.Tasks;
import exception.DownloadException;
import exception.HARDownloadException;
import exception.ProcessException;
import exception.RawDownloadException;
import exception.SendException;
import exception.StatusDownloadException;
import harprocessor.ProcessHAR;

/*
 *	PwatchRun is a Entity
 *
 */
/**
 * @author M1027351
 * @param <E>
 */

// public class PwatchRun implements Callable <Run>,Runnable{
public class PwatchRun implements Runnable {

  RunData run;
  Dao dao;
  StatusDto statusTemp;
  Request request;
  private String testID;
  String scheduleID;

  public String getTestID() {
    return testID;
  }

  public RunData getRun() {
    return run;
  }

  public void setRun(RunData run) {
    this.run = run;
  }

  public void setTestID(String testID) {
    this.testID = testID;
  }

  public String getStatus() {
    return status;
  }

  public String getServer() {
    return server;
  }

  public void setServer(String server) {
    this.server = server;
  }

  private String server;
  String status;

  public PwatchRun() {
    super();
  }

  public PwatchRun(Tasks task, String groupID, String id, String scheduleID)
      throws MalformedURLException, UnsupportedEncodingException, UnknownHostException {
    run = new RunData(task);
    run.setGroupID(groupID);
    run.setRequestID(id);
    run.setScheduleID(scheduleID);
    // System.out.println("Task Id fro get ask" + taskId);
    // task = dao.getTask(taskId);
    run.setUrlOrScript(task.getUrlOrScript());
    String location;
    server = task.getServer();
    location = task.getLocation();

    if (task.getIsScript()) {
      request =
          new ScriptRequest(
              task.getUrlOrScript(), location, task.getNetwork(), task.getLabel(), task.getBlock());

    } else {
      request =
          new URLRequest(
              task.getUrlOrScript(), location, task.getNetwork(), task.getLabel(), task.getBlock());
    }
  }

  public void run() {
    // public Run call() throws UnknownHostException {
    try {

      try {
        dao = DaoFactory.getDao();
      } catch (UnknownHostException e) {
        throw new InterruptedException();
      }

      // run.setStatus(RunData.RunStatus.CREATED);
      // ====
      statusTemp = new StatusDto("", "");
      statusTemp.setTag(StatusDto.RunStatus.CREATED.toString());
      run.setStatus(statusTemp);
      // ====
      run.setStart(String.valueOf(System.currentTimeMillis()));
      testID = sendWptRequest(request);

      Thread.currentThread().setName(testID);

      // TODO This goes to the Logger
      System.out.println("#Test Started#" + (new Date()) + "#" + testID + '#' + server);

      run.setTestID(testID);
      // run.setGroupID("");

      dao.addRun(run);

      // run.setStatus(RunData.RunStatus.WAITING);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.WAITING.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);

      //      Object memoryData = collectMemoryMetrics(run.getUrlOrScript());
      //      run.setMemoryData(memoryData);
      //      dao.updateMemoryMetric(run);

      waitForComplete();

      JSONObject data = downloadWptResult(testID);

      // run.setStatus(RunData.RunStatus.FETCHINGDATA);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FETCHINGDATA.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);

      run.setData(data);
      dao.updateRunData(run);

      // run.setStatus(RunData.RunStatus.FETCHINGRAW);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FETCHINGRAW.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);

      String raw = downloadWptRaw(testID);
      run.setRaw(raw);
      dao.updateRunRaw(run);

      // run.setStatus(RunData.RunStatus.FETCHINGHAR);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FETCHINGHAR.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);

      String har = downloadWptHAR(testID);
      run.setHar(har);
      dao.updateRunHar(run);

      // run.setStatus(RunData.RunStatus.PROCESSING);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.PROCESSING.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);
      System.out.println("***processing done***");
      String reco = ProcessHAR.analyseHAR(run.getGroupID(), run.getTestID());

      run.setRecommondations(reco);
      dao.updateRecommondations(run);

      // run.setStatus(RunData.RunStatus.COMPLETE);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.COMPLETE.toString());
      run.setStatus(statusTemp);
      // ========================
      dao.updateRunStatus(run);
      // TODO This goes to the Logger
      System.out.println("#Test Completed#" + (new Date()) + "#" + testID);

    } catch (InterruptedException e) {
      // cancelWptRequest(testID);
      run.addError("TimeOut:" + e.getMessage());
      // run.setStatus(RunData.RunStatus.FAILED);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FAILED.toString());
      run.setStatus(statusTemp);
      // ========================
      // TODO This goes to the Logger
      System.out.println("#Test Failed#CAN#" + (new Date()) + "#" + testID);

    } catch (HARDownloadException e) {
      // run.setStatus(RunData.RunStatus.FAILED);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FAILED.toString());
      run.setStatus(statusTemp);
      // ========================
      run.addError("Har:" + e.getMessage());
      // TODO This goes to the Logger
      System.out.println("#Test Failed#HAR#" + (new Date()) + "#" + testID);

    } catch (DownloadException e) {
      // run.setStatus(RunData.RunStatus.FAILED);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FAILED.toString());
      run.setStatus(statusTemp);
      // ========================
      run.addError("Data:" + e.getMessage());
      System.out.println("#Test Failed#DAT#" + (new Date()) + "#" + testID);

    } /* catch (SendException e) {
      	testID = "FAILED" + System.nanoTime();
      	run.setTestID(testID);
      	run.setStatus(Run.RunStatus.FAILED);
      	run.addError("Send:" + e.getMessage());
      	dao.addRun(run);
      	System.out.println("#Test Failed#SEN#" + (new Date()) + "#" + testID);
      }*/ catch (ProcessException e) {
      //  run.setStatus(RunData.RunStatus.FAILED);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FAILED.toString());
      run.setStatus(statusTemp);
      // ========================
      run.addError("Process:" + e.getMessage());
      System.out.println("#Test Failed#PRO#" + (new Date()) + "#" + testID);
    } /*catch (StatusDownloadException e) {

      }*/ catch (RawDownloadException e) {
      // run.setStatus(RunData.RunStatus.FAILED);
      // ================
      statusTemp.setTag(StatusDto.RunStatus.FAILED.toString());
      run.setStatus(statusTemp);
      // ========================
      run.addError("Raw:" + e.getMessage());
      System.out.println("#Test Failed#RAW#" + (new Date()) + "#" + testID);
    } catch (StatusDownloadException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (SendException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      dao.addError(run);
      dao.updateRunStatus(run);
    }
  }

  private int waitForComplete() throws InterruptedException, StatusDownloadException {
    int statusCode = 0;
    while (200 != statusCode) {
      try {
        statusCode = downloadWptStatus(testID).getInt("statusCode");
        String statusText = downloadWptStatus(testID).getString("statusText");
        // System.out.println(statusCode);
        if (100 == statusCode) {
          // System.out.println("Running");
          // run.setStatus(RunData.RunStatus.RUNNING);
          // ================
          statusTemp.setTag(StatusDto.RunStatus.RUNNING.toString());
          run.setStatus(statusTemp);
          // ========================

        }
        if (400 == statusCode) {
          // run.setStatus(RunData.RunStatus.CANCELLED);
          // ================
          statusTemp.setTag(StatusDto.RunStatus.CANCELLED.toString());
          run.setStatus(statusTemp);
          // ========================
        }
        if (200 == statusCode) {
          // System.out.println("Executed");
          // run.setStatus(RunData.RunStatus.EXECUTED);
          // ================
          statusTemp.setTag(StatusDto.RunStatus.EXECUTED.toString());
          run.setStatus(statusTemp);
          // ========================
        }
        // run.setStatusTest(statusText);
        // ================
        statusTemp.setMessage(statusText);
        run.setStatus(statusTemp);
        // ========================
        dao.updateRunStatus(run);

      } catch (StatusDownloadException e) {
        e.printStackTrace();

      } catch (JSONException e) {
        e.printStackTrace();
        throw new StatusDownloadException(e.getMessage());
      }
      Thread.sleep(GlobalVariables.pingInterval * 1000);
    }
    return statusCode;
  }

  //  public Object collectMemoryMetrics(String url) {
  //    System.setProperty(
  //        "webdriver.chrome.driver", GlobalVariables.chromeDriverPath + "chromedriver.exe");
  //    WebDriver driver = new ChromeDriver();
  //    driver.get(url);
  //    driver.manage().window().maximize();
  //    Object data = writePerfMetricasJSON(driver);
  //    driver.quit();
  //    return data;
  //  }

  //  public static Object writePerfMetricasJSON(WebDriver driver) {
  //    JavascriptExecutor js1 = ((JavascriptExecutor) driver);
  //
  //    Date startTime = new Date();
  //    // String url="https://www.academy.com/";
  //    //		driver.get(url);
  //
  //    new WebDriverWait(driver, 45)
  //        .until(
  //            webDriver ->
  //                ((JavascriptExecutor) webDriver)
  //                    .executeScript("return document.readyState")
  //                    .equals("complete"));
  //
  //    // String scriptToExecute1 = "var performance = window.performance ||
  // window.performance.memory
  //    // || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var
  //    // network = performance.getEntries() || {}; return network;";
  //    String scriptToExecute1 = "return window.performance.memory";
  //    System.out.println("net data is below : ");
  //    Object netData1 = ((JavascriptExecutor) driver).executeScript(scriptToExecute1);
  //
  //    System.out.println(netData1);
  //    // System.out.println(((JavascriptExecutor)driver).executeScript(scriptToExecute1));
  //
  //    return netData1;
  //
  //    // Date currenttime = new Date();
  //
  //  }

  private String sendWptRequest(Request request) throws SendException {

    try {
      String url = server + "/runtest.php";

      String urlParameters =
          "location="
              + request.location
              + '.'
              + request.connectvity
              + "&k="
              + config.GlobalVariables.apiKey1
              + "&private=1"
              + "&video=1"
              + "&f=json"
              + "&noimages=0"
              + "&noheaders=0"
              + "&label="
              + "&lighthouse=1"
              + request.label
              + "&priority=1&ignoreSSL=1&block="
              + request.block;
      System.out.println("url=" + urlParameters);
      // if(auth){
      // urlParameters += "&login="+user+"&password"+password;
      // }

      if (ScriptRequest.class == request.getClass()) {
        urlParameters = urlParameters.concat("&script=" + request.getData());

      } else {
        urlParameters = urlParameters.concat("&url=" + request.getData());
      }
      System.out.println(url + "?" + urlParameters);
      System.err.println(url + "?" + urlParameters);
      System.out.println(url + "?" + urlParameters);
      JSONObject wptResponse = new JSONObject((sendHttpRequest(url, urlParameters, "GET")));
      return wptResponse.getJSONObject("data").getString("testId");

    } catch (JSONException e) {
      // KEY EXAUSTED
      e.printStackTrace();
      throw new SendException("KEY EXAUSTED#check api key#" + e.getMessage());
    } catch (IOException e) {
      e.printStackTrace();
      throw new SendException("NETWORK ERROR" + e.getMessage());
    }
  }

  private JSONObject downloadWptStatus(String testID) throws StatusDownloadException {
    try {

      String url = server + "/testStatus.php";
      String urlParameters = "test=" + testID + "&f=json";

      JSONObject wptStatus = new JSONObject(sendHttpRequest(url, urlParameters, "GET"));

      return wptStatus;

    } catch (JSONException e) {
      e.printStackTrace();
      throw new StatusDownloadException(e.getMessage());
    } catch (IOException e) {
      e.printStackTrace();
      throw new StatusDownloadException("NETWORK ERROR" + e.getMessage());
    }
  }

  private JSONObject downloadWptResult(String testID) throws DownloadException {
    try {

      String url = server + "/jsonResult.php";
      String urlParameters = "test=" + testID;

      JSONObject wptResult = new JSONObject(sendHttpRequest(url, urlParameters, "GET"));

      wptResult = wptResult.getJSONObject("data");
      System.out.println("****Updated****");
      try {
        JSONObject firstView = wptResult.getJSONObject("median").getJSONObject("firstView");
        firstView = removeDotsInJSONKey(firstView);
        firstView = formatData(firstView);
        wptResult.put("firstView", firstView);
        System.out.println("****got itt finally******");

      } catch (JSONException e) {
        e.printStackTrace();
        run.addError(e.getMessage());
      }
      try {
        JSONObject repeatView = wptResult.getJSONObject("median").getJSONObject("repeatView");
        repeatView = removeDotsInJSONKey(repeatView);
        repeatView = formatData(repeatView);
        wptResult.put("repeatView", repeatView);
      } catch (JSONException e) {
        e.printStackTrace();
        run.addError(e.getMessage());
      }

      wptResult.remove("runs");
      wptResult.remove("average");
      wptResult.remove("standardDeviation");
      wptResult.remove("median");

      return wptResult;

    } catch (JSONException e) {
      e.printStackTrace();
      throw new DownloadException(e.getMessage());
    } catch (IOException e) {
      e.printStackTrace();
      throw new DownloadException("NETWORK DOWN" + e.getMessage());
    }
  }

  private String downloadWptHAR(String testId) throws HARDownloadException {
    // http://www.webpagetest.org/cancelTest.php?test=<testId>&k=<API key>
    try {

      String url = server + "/export.php";
      String urlParameters = "test=" + testId;

      String wptResult = (sendHttpRequest(url, urlParameters, "GET"));

      // System.out.println(url+"?"+urlParameters);
      // System.out.println(wptResult);
      return wptResult;

    } catch (IOException e) {
      e.printStackTrace();
      throw new HARDownloadException(e.getMessage());
    }
  }

  private String downloadWptRaw(String testId) throws RawDownloadException {
    // http://www.webpagetest.org/cancelTest.php?test=<testId>&k=<API key>
    try {

      String url = server + "/csv.php";
      String urlParameters = "test=" + testId;

      String wptResult = (sendHttpRequest(url, urlParameters, "GET"));

      // System.out.println(url+"?"+urlParameters);
      // System.out.println(wptResult);
      return wptResult;

    } catch (IOException e) {
      e.printStackTrace();
      throw new RawDownloadException(e.getMessage());
    }
  }

  /*
   * private String cancelWptRequest(String testId) { //
   * http://www.webpagetest.org/cancelTest.php?test=<testId>&k=<API key>
   *
   *
   * String url = server + "/cancelTest.php"; String urlParameters = "test=" +
   * testId;
   *
   * String wptResult = null; try { wptResult = (sendHttpRequest(url,
   * urlParameters, "GET")); } catch (IOException e) { e.printStackTrace(); }
   *
   * // System.out.println(wptResult); return wptResult;
   *
   *
   * }
   */

  public String sendHttpRequest(String url1, String parameters, String type) throws IOException {

    StringBuffer response = null;

    URL url = null;

    if (type == "GET") {
      url = new URL(url1 + "?" + parameters);
    }

    HttpURLConnection con = (HttpURLConnection) url.openConnection();

    con.setRequestMethod(type);
    HttpURLConnection.setFollowRedirects(true);
    con.setInstanceFollowRedirects(true);
    if (type == "POST") {
      con.setDoOutput(true);
      DataOutputStream wr = new DataOutputStream(con.getOutputStream());
      wr.writeBytes(parameters);
      wr.flush();
      wr.close();
    }
    boolean redirect = false;
    int status = con.getResponseCode();
    if (status != HttpURLConnection.HTTP_OK) {
      if (status == HttpURLConnection.HTTP_MOVED_TEMP
          || status == HttpURLConnection.HTTP_MOVED_PERM
          || status == HttpURLConnection.HTTP_SEE_OTHER) redirect = true;
    }
    if (redirect) {
      SSLContext sc;
      try {
        sc = SSLContext.getInstance("TLS");
        sc.init(
            null,
            new TrustManager[] {new TrustAllX509TrustManager()},
            new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier(
            new HostnameVerifier() {
              public boolean verify(String string, SSLSession ssls) {
                return true;
              }
            });
      } catch (KeyManagementException e) {
        e.printStackTrace(); // wont happen
      } catch (NoSuchAlgorithmException e) {
        e.printStackTrace(); // wont happen
      }
      String newUrl = con.getHeaderField("Location");
      // open the new connnection again
      con = (HttpURLConnection) new URL(newUrl).openConnection();
      System.out.println("Redirect to URL : " + newUrl);
    }
    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
    String inputLine;
    response = new StringBuffer();

    while ((inputLine = in.readLine()) != null) {
      response.append(inputLine);
      response.append(System.lineSeparator());
    }
    //		System.out.println(response.toString());
    in.close();
    return response.toString().replaceAll("[\u0000-\u001f]", "");
  }

  private JSONObject formatData(JSONObject data) throws JSONException {
    data.remove("requests");
    data.remove("pages");
    data.remove("thumbnails");
    data.remove("images");
    data.remove("rawData");
    data.remove("videoFrames");
    data.remove("userTimes");
    data.remove("userTime");

    // use to remove keys with 'dot' mongodb throws exception
    Iterator<?> keys = data.keys();

    HashSet<String> se = new HashSet<String>();

    while (keys.hasNext()) {
      String key = keys.next().toString();
      if (key.contains(".")) {
        se.add(key.toString());
      }
    }

    Iterator<String> i = se.iterator();

    while (i.hasNext()) {
      String key = i.next();
      Object o = data.get(key);
      String newKey = key.replaceAll(".", "_");
      data.remove(key);
      data.put(newKey, o);
    }

    try {
      JSONObject domains = data.getJSONObject("domains");
      JSONArray domainsArray = new JSONArray();

      for (String s : JSONObject.getNames(domains)) {
        JSONObject temp = domains.getJSONObject(s);
        temp.put("domain", s);
        domainsArray.put(temp);
      }
      data.put("domains", domainsArray);
    } catch (JSONException e) {
      // TODO Nothing to do
    }
    try {

      JSONObject breakdown = data.getJSONObject("breakdown");
      JSONArray breakdownArray = new JSONArray();

      for (String s : JSONObject.getNames(breakdown)) {
        JSONObject temp = breakdown.getJSONObject(s);
        temp.remove("color");
        temp.put("type", s);
        breakdownArray.put(temp);
      }
      data.put("breakdown", breakdownArray);
    } catch (JSONException e) {
      // TODO Nothing to do
    }

    return data;
  }

  /////////////////////////////////
  public static JSONArray removeDotsInJSONArrayKey(JSONArray JsonArray) throws JSONException {

    JSONArray dup = new JSONArray();
    for (int i = 0; i < JsonArray.length(); i++) {
      Object value = JsonArray.get(i);
      if (value instanceof JSONArray) {
        JSONArray modifiedvalue = removeDotsInJSONArrayKey(JsonArray.getJSONArray(i));
        dup.put(i, modifiedvalue);
      } else if (value instanceof JSONObject) {
        JSONObject modifiedvalue = removeDotsInJSONKey(JsonArray.getJSONObject(i));
        dup.put(i, modifiedvalue);
      }
    }

    return dup;
  }

  public static JSONObject removeDotsInJSONKey(JSONObject WptResult) throws JSONException {

    // jObject =
    JSONObject wptResultDup = new JSONObject();
    // wptResultDup.put("", 1);
    Iterator<?> keys = WptResult.keys();

    Iterator<?> keysdup = keys;

    while (keysdup.hasNext()) {

      String key = (String) keys.next();
      Object currentEntry1 = WptResult.get(key);
      if (currentEntry1 instanceof JSONArray) {

        String key1 = key;
        System.out.println("Before  : " + key1);
        key1 = key1.replace(".", "_");
        System.out.println("After  : " + key1);
        JSONArray value = WptResult.getJSONArray(key);
        // WptResult.remove(key);

        value = removeDotsInJSONArrayKey(value);
        wptResultDup.put(key1, value);

      } else if (currentEntry1 instanceof JSONObject) {
        String key1 = key;
        System.out.println("Before  : " + key1);
        key1 = key1.replace(".", "_");
        System.out.println("After  : " + key1);
        JSONObject value = WptResult.getJSONObject(key);
        // WptResult.remove(key);

        value = removeDotsInJSONKey(value);
        wptResultDup.put(key1, value);
      } else {
        String key2 = key;
        System.out.println("Before individual  :" + key2);
        key2 = key2.replace(".", "_");
        System.out.println("After Individual   :" + key2);
        //	key2.replace(".js", "_js");
        Object currentEntry = WptResult.get(key);
        String classNameOfThing = currentEntry.getClass().getName();
        System.out.println(key2 + " is a " + classNameOfThing);
        if (currentEntry instanceof Integer) {
          int value = WptResult.getInt(key);

          wptResultDup.put(key2, value);
        } else if (currentEntry instanceof String) {
          String value = WptResult.getString(key);
          wptResultDup.put(key2, value);
        } else if (currentEntry instanceof Array) {
          JSONArray value = WptResult.getJSONArray(key);
          wptResultDup.put(key2, value);
        } else if (currentEntry instanceof Boolean) {
          Boolean Value = WptResult.getBoolean(key);
          wptResultDup.put(key2, Value);
        } else if (currentEntry instanceof Double) {
          Double Value = WptResult.getDouble(key);
          wptResultDup.put(key2, Value);
        }

        // WptResult.remove(key);
      }
    }
    System.out.println("WptResultDup" + wptResultDup);
    return wptResultDup;
  }
  /////////////////////////////////

  private abstract class Request {
    String location;
    String connectvity;
    String label;
    String block;

    public abstract String getData();
  }

  private class URLRequest extends Request {

    public URLRequest(
        String urlOrScript, String location, String network, String label, String block)
        throws MalformedURLException {
      this.url = new URL(urlOrScript);
      this.location = location;
      this.connectvity = network;
      this.label = label;
      this.block = block;
    }

    URL url;

    @Override
    public String getData() {
      return url.toString();
    }
  }

  private class ScriptRequest extends Request {
    String script;

    public ScriptRequest(
        String urlOrScript, String location, String network, String label, String block)
        throws UnsupportedEncodingException {
      this.script = URLEncoder.encode(urlOrScript, "UTF-8");
      this.location = location;
      this.connectvity = network;
      this.label = label;
      this.block = block;
    }

    public String getData() {
      return script;
    }
  }
  /*
   * private class Result { private String testID; private JSONObject data; }
   *
   * private class Status { String status; }
   */
}
