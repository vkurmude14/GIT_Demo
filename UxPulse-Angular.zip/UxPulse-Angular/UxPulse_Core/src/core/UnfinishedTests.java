package core;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import dao.DaoFactory;
import dao.DaoImpl;

public class UnfinishedTests {

  public Map<String, List<String>> find(String requestID) {
    Map<String, List<String>> groupTestMap = new HashMap<>();
    try {
      DaoImpl dao = (DaoImpl) DaoFactory.getDao();
      DBCollection col = ((DaoImpl) dao).getCollection("runData");
      DBObject o = new BasicDBObject("groupID", true);
      DBObject q = new BasicDBObject("requestID", requestID);
      q.put("status", "FETCHINGDATA");
      DBCursor cursor = col.find(q, o);
      while (cursor.hasNext()) {
        DBObject dbObject = cursor.next();
        String groupID = (String) dbObject.get("groupID");
        String testID = (String) dbObject.get("_id");
        List<String> testList = groupTestMap.get(groupID);
        if (testList == null) {
          testList = new ArrayList<String>();
        }
        testList.add(testID);
        groupTestMap.put(groupID, testList);
      }
    } catch (UnknownHostException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return groupTestMap;
  }
}
