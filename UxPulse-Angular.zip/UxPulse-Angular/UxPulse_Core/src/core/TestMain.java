package core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONException;
import org.json.JSONObject;

import config.GlobalVariables;
import dto.RunData;

public class TestMain {

	public static void main(String[] args) throws IOException {
		readConfig();
		String requestID = "Unilever_5Dec";
		Map<String, List<String>> groupTestMap = new UnfinishedTests().find(requestID);
		
		int threadsCount = 0;
		List<Thread> tlist = new ArrayList<>();
		for (Entry<String, List<String>> entry : groupTestMap.entrySet()) {
			String groupID = entry.getKey();
			for (String testID : entry.getValue()) {
				PwatchRun prun = new PwatchRun();
				prun.setServer("http://api.webpagetest.org");
				RunData run = new RunData();
				run.setRequestID("requestID");
				run.setGroupID(groupID);
				run.setTestID(testID);
				prun.setRun(run);
				prun.setTestID(testID);
				Thread t = new Thread(prun);
				tlist.add(t);
			}

		}

		for (Thread t : tlist) {
			t.start();
			threadsCount++;
			if (threadsCount % 4 == 0) {
				try {
					System.out.println(threadsCount + " threads running, sleeping for 10 seconds");
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static void readConfig() {
		String config = "config.json";
		String groupID = String.valueOf(System.currentTimeMillis());
		String suffix = "";
		try {
			String configJSON = new String(Files.readAllBytes(Paths.get(config)));
			GlobalVariables.loadProperties(new JSONObject(configJSON));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File file1 = new File(GlobalVariables.logpath);
		System.out.println("logging at " + file1.getPath());
		System.out.println(GlobalVariables.dbhost + ":" + GlobalVariables.dbport + " " + GlobalVariables.dbname);
		if (!file1.exists()) {
			file1.mkdirs();
		}

		try {
			String file = GlobalVariables.logpath + "\\" + groupID + "_errors" + suffix + ".txt";
			System.setErr(new PrintStream(file));
		} catch (FileNotFoundException e1) {
			System.out.print("Failed to set Error Stream. check logpath in config");
			e1.printStackTrace();
		}
		try {
			String file = GlobalVariables.logpath + "\\" + groupID + "_logs" + suffix + ".txt";
			System.setOut(new PrintStream(file));
		} catch (FileNotFoundException e1) {
			System.out.print("Failed to set Output Stream. check logpath in config ");
			e1.printStackTrace();
		}
		System.out.println("***Startedddd***" + (new Date()));
		if (GlobalVariables.useProxy) {
			System.getProperties().put("http.proxyHost", GlobalVariables.proxyHost);
			System.getProperties().put("http.proxyPort", GlobalVariables.proxyPort);
			System.getProperties().put("https.proxyHost", GlobalVariables.proxyHost);
			System.getProperties().put("https.proxyPort", GlobalVariables.proxyPort);
			System.getProperties().put("http.nonProxyHosts", GlobalVariables.nonProxyHosts);
		}

	}

}
