package config;

import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import core.PwatchRun;

public class GlobalVariables {

  public static String dbhost = "localhost";
  public static int dbport = 27017;
  public static String dbname = "uxpulseDev";
  public static String dbuser = "";
  public static String dbpass = "";

  public static int timeout = 60 * 60; // seconds
  public static int pingInterval = 30; // seconds

  public static String apiKey1 = "";
  public static String logpath = "";
  public static String harpath = "";
  public static String chromeDriverPath = "";
  public static Boolean useProxy = false;
  public static String proxyHost = "localhost";
  public static String proxyPort = "8085";
  public static String nonProxyHosts = "localhost";

  public static void loadProperties(JSONObject config)
      throws JSONException, NumberFormatException, IOException {
    if (config.has("dbhost")) dbhost = config.getString("dbhost");

    if (config.has("dbport")) dbport = Integer.parseInt(config.getString("dbport"));

    if (config.has("dbname")) dbname = config.getString("dbname");

    if (config.has("dbuser")) dbuser = config.getString("dbuser");

    if (config.has("dbpass")) dbpass = config.getString("dbpass");

    if (config.has("timeout")) timeout = Integer.parseInt(config.getString("timeout"));

    if (config.has("pingInterval"))
      pingInterval = Integer.parseInt(config.getString("pingInterval"));

    if (config.has("logpath")) logpath = config.getString("logpath");

    if (config.has("harpath")) harpath = config.getString("harpath");

    if (config.has("useProxy")) useProxy = Boolean.parseBoolean(config.getString("useProxy"));

    if (config.has("proxyHost")) proxyHost = config.getString("proxyHost");

    if (config.has("nonProxyHosts")) proxyPort = config.getString("proxyPort");

    if (config.has("nonProxyHosts")) nonProxyHosts = config.getString("nonProxyHosts");

    if (config.has("chromeDriverPath")) chromeDriverPath = config.getString("chromeDriverPath");
  }

  public static String KeyManagement(JSONObject config, int tasklength)
      throws IOException, NumberFormatException, JSONException {
    System.setProperty("http.proxyHost", "172.22.218.218");
    System.setProperty("http.proxyPort", "8085");
    PwatchRun prun = new PwatchRun();

    int usage;
    String url = "http://api.webpagetest.org/usage.php";
    String key = "";
    int limit;
    String type = "GET";
    String apiKys = config.getString("apiKey");
    JSONObject apKys = new JSONObject(apiKys);
    @SuppressWarnings("unchecked")
    Iterator<String> keys = apKys.keys();
    while (keys.hasNext()) {
      key = (String) keys.next();
      limit = Integer.parseInt(apKys.getString(key));

      String reString = prun.sendHttpRequest(url, "k=" + key, type);
      Pattern pattern = Pattern.compile("<td>(.*?)<\\/td><td>(.*?)<\\/td><td>(.*?)<\\/td>");
      Matcher matcher = pattern.matcher(reString);
      if (matcher.find()) {
        usage = Integer.parseInt(matcher.group(2));

        if (limit - usage > tasklength * 2) {
          break;
        }
      }
    }
    System.out.println("***API_Key ==> " + key);

    if (config.has("apiKey")) apiKey1 = key;
    if (apiKey1 != null) return key;
    return "failed";
  }
}
