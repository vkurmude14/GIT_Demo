package dto;

import java.io.Serializable;

import com.mongodb.BasicDBObject;

public class StatusDto extends BasicDBObject {

  /** */
  private static final long serialVersionUID = 1L;

  private String tag;
  private String message;

  public StatusDto(String tag, String message) {
    super.put("tag", tag);
    super.put("message", message);
  }

  public String getTag() {
    return super.getString("tag");
  }

  public void setTag(String tag) {
    super.put("tag", tag);
  }

  public String getMessage() {
    return super.getString("message");
  }

  public void setMessage(String message) {
    super.put("message", message);
  }

  public static enum RunStatus implements Serializable {
    CREATED,
    FAILED,
    COMPLETE,
    RUNNING,
    CANCELLED,
    EXECUTED,
    WAITING,
    FETCHINGDATA,
    FETCHINGHAR,
    PROCESSING,
    FETCHINGRAW;
  }
}
