package dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Group implements Serializable{
	
	/**
	 * 
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static enum GroupStatus{
		INITALIZING,RUNNING,COMPLETE,PARTIAL,FAILED
	}		
	private String id;	
	private GroupStatus status;
	private Map<String,RunData> runs;
	
	public Group(String id) {
		super();
		this.id = id;
		runs = new HashMap<String, RunData>();
	}
	
	public Map<String, RunData> getRuns() {
		return runs;
	}
	public void setRuns(Map<String, RunData> runs) {
		this.runs = runs;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public GroupStatus getStatus() {
		return status;
	}
	public void setStatus(GroupStatus status) {
		this.status = status;
	}
	public RunData getRun(String runId) {
		return runs.get(runId);
	}
	public void addRun(RunData run) {
		this.runs.put(run.getTestID(), run);
	}
}	
	