package dto;

import java.util.List;

public class Request {

	String requestID;
	List<Tasks> runs;
	public String getRequestID() {
		return requestID;
	}
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
	public List<Tasks> getRuns() {
		return runs;
	}
	public void setRuns(List<Tasks> runs) {
		this.runs = runs;
	}	
}
