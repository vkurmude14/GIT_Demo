package dto;

import org.bson.types.ObjectId;

public class Tasks {

  /** */
  private ObjectId _id;

  private String location;
  private String network;
  private String server;
  private Boolean isScript;
  private Boolean isCustomer;
  private String urlOrScript;
  private String label;
  private String block;

  public ObjectId get_id() {
    return _id;
  }

  public void set_id(ObjectId _id) {
    this._id = _id;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getNetwork() {
    return network;
  }

  public void setNetwork(String network) {
    this.network = network;
  }

  public String getServer() {
    return server;
  }

  public void setServer(String server) {
    this.server = server;
  }

  public Boolean getIsScript() {
    return isScript;
  }

  public void setIsScript(Boolean isScript) {
    this.isScript = isScript;
  }

  public String getUrlOrScript() {
    return urlOrScript;
  }

  public void setUrlOrScript(String urlOrScript) {
    this.urlOrScript = urlOrScript;
  }

  public Tasks(
      String location,
      String network,
      String server,
      String label,
      Boolean isScript,
      String urlOrScript,
      Boolean isCustomer2,
      String block) {
    this.location = location;
    this.network = network;
    this.server = server;
    this.isScript = isScript;
    this.isCustomer = isCustomer2;
    this.urlOrScript = urlOrScript;
    this.label = label;
    this.block = block;
  }

  public Tasks() {}

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public Boolean getIsCustomer() {
    return isCustomer;
  }

  public void setIsCustomer(Boolean isCustomer) {
    this.isCustomer = isCustomer;
  }

  public String getBlock() {
    return block;
  }

  public void setBlock(String block) {
    this.block = block;
  }

  @Override
  public String toString() {
    return "RequestRun [location="
        + location
        + ", network="
        + network
        + ", server="
        + server
        + ", isScript="
        + isScript
        + ", isCustomer="
        + isCustomer
        + ", urlOrScript="
        + urlOrScript
        + ", label="
        + label
        + ", block="
        + block
        + ", getLocation()="
        + getLocation()
        + ", getNetwork()="
        + getNetwork()
        + ", getServer()="
        + getServer()
        + ", getIsScript()="
        + getIsScript()
        + ", getUrlOrScript()="
        + getUrlOrScript()
        + ", getLabel()="
        + getLabel()
        + ", getIsCustomer()="
        + getIsCustomer()
        + ", getBlock()="
        + getBlock()
        + ", getClass()="
        + getClass()
        + ", hashCode()="
        + hashCode()
        + ", toString()="
        + super.toString()
        + "]";
  }
}
