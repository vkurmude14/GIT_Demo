package dto;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class RunData {
  /** */
  public RunData(Tasks task) {
    this.taskId = task.get_id().toHexString();
  }

  public RunData() {}

  //  public static enum RunStatus {
  //    CREATED,
  //    FAILED,
  //    COMPLETE,
  //    RUNNING,
  //    CANCELLED,
  //    EXECUTED,
  //    WAITING,
  //    FETCHINGDATA,
  //    FETCHINGHAR,
  //    PROCESSING,
  //    FETCHINGRAW;
  //  }

  String _id;
  String requestUserID;
  String scheduleID;
  StatusDto status;
  // RunStatus status; // need to change
  // Task request; // assign task id instead of task need to change
  String taskId;
  // String statusText; // need to change
  String groupID;

  String start;
  String end;

  JSONObject data;

  String raw;
  String har;
  String recommondations;
  Object memoryData;
  String urlOrScript;

  public String getTaskId() {
    return taskId;
  }

  public void setTaskId(String taskId) {
    this.taskId = taskId;
  }

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public StatusDto getStatus() {
    return status;
  }

  public void setStatus(StatusDto status1) {
    this.status = status1;
  }

  public String getUrlOrScript() {
    return urlOrScript;
  }

  public void setUrlOrScript(String urlOrScript) {
    this.urlOrScript = urlOrScript;
  }

  public Object getMemoryData() {
    return memoryData;
  }

  public void setMemoryData(Object memoryData) {
    this.memoryData = memoryData;
  }

  public String getRequestID() {
    return requestUserID;
  }

  public void setRequestID(String requestID) {
    this.requestUserID = requestID;
  }

  //  public String getStatusText() {
  //    return statusText;
  //  }

  //  public void setStatusText(String statusText) {
  //    this.statusText = statusText;
  //  }

  public String getRaw() {
    return raw;
  }

  public void setRaw(String raw) {
    this.raw = raw;
  }

  public String getGroupID() {
    return groupID;
  }

  public void setGroupID(String groupID) {
    this.groupID = groupID;
  }

  public String getRecommondations() {
    return recommondations;
  }

  public void setRecommondations(String recommondations) {
    this.recommondations = recommondations;
  }

  List<String> errors = new ArrayList<String>();

  public String getStart() {
    return start;
  }

  public void setStart(String start) {
    this.start = start;
  }

  public String getEnd() {
    return end;
  }

  public void setEnd(String end) {
    this.end = end;
  }

  //  public String getStatusTest() {
  //    return statusText;
  //  }

  //  public void setStatusTest(String statusText) {
  //    this.statusText = statusText;
  //  }

  public void setErrors(List<String> errors) {
    this.errors = errors;
  }

  public String[] getErrors() {
    return errors.toArray(new String[errors.size()]);
  }

  public void addError(String error) {
    this.errors.add(error);
  }

  public String getTestID() {
    return _id;
  }

  public void setTestID(String testID) {
    this._id = testID;
  }

  //  public String getStatus() {
  //    return status.toString();
  //  }
  //
  //  public void setStatus(RunStatus status) {
  //    this.status = status;
  //  }

  //  public Task getRequest() {
  //    return request;
  //  }
  //
  //  public void setRequest(Task request) {
  //    this.request = request;
  //  }

  public JSONObject getData() {
    return data;
  }

  public void setData(JSONObject data) {
    this.data = data;
  }

  public String getHar() {
    return har;
  }

  public void setHar(String har) {
    this.har = har;
  }

  public String getScheduleID() {
    return scheduleID;
  }

  public void setScheduleID(String scheduleID) {
    this.scheduleID = scheduleID;
  }
}
