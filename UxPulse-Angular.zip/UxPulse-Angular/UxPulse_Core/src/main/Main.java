package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
// import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
// import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
// import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import config.GlobalVariables;
// import config.GlobalVariables;
import core.PwatchRun;
import dao.Dao;
import dao.DaoFactory;
import dto.Request;
import dto.Tasks;
// import dto.Run;

public class Main {

  public static void main(String[] args)
      throws ExecutionException, InterruptedException, UnknownHostException {
    String path = "work.json";
    String config = "config.json";
    String groupID = String.valueOf(System.currentTimeMillis());
    int tasksLength = 0;
    JSONObject ConfigJson = null;
    int offset = 0;
    String suffix = "";

    if (args.length >= 1) {
      if (args[0].contains("-h")) {
        System.out.printf("Help File");
        System.out.printf("Usage:");
        System.out.println("\tjava -jar pwatchcore.jar work.json config.json ");
        System.out.println("Recovery Mode");
        System.out.println("\tjava -jar pwatchcore.jar -r log.txt config.json ");
        System.exit(1);
      }
      if (args[0].contains("-r")) {
        // Recovery Mode //
        // get LogFile
        offset = 1;
      }
    }

    if (args.length >= 1) {
      path = args[offset + 0];
    }
    if (args.length >= 2) {
      config = args[offset + 1];
    }

    try {
      String configJSON = new String(Files.readAllBytes(Paths.get(config)));
      ConfigJson = new JSONObject(configJSON);
      GlobalVariables.loadProperties(new JSONObject(configJSON));
    } catch (JSONException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    File file1 = new File(GlobalVariables.logpath);
    System.out.println("logging at " + file1.getPath());
    System.out.println(
        GlobalVariables.dbhost + ":" + GlobalVariables.dbport + " " + GlobalVariables.dbname);
    if (!file1.exists()) {
      file1.mkdirs();
    }

    try {
      String file = GlobalVariables.logpath + "\\" + groupID + "_errors" + suffix + ".txt";
      System.setErr(new PrintStream(file));
    } catch (FileNotFoundException e1) {
      System.out.print("Failed to set Error Stream. check logpath in config");
      e1.printStackTrace();
    }
    try {
      String file = GlobalVariables.logpath + "\\" + groupID + "_logs" + suffix + ".txt";
      System.setOut(new PrintStream(file));
    } catch (FileNotFoundException e1) {
      System.out.print("Failed to set Output Stream. check logpath in config ");
      e1.printStackTrace();
    }
    System.out.println("***Started***" + (new Date()));

    Request req = new Request();

    if (GlobalVariables.useProxy) {
      System.getProperties().put("http.proxyHost", GlobalVariables.proxyHost);
      System.getProperties().put("http.proxyPort", GlobalVariables.proxyPort);
      System.getProperties().put("https.proxyHost", GlobalVariables.proxyHost);
      System.getProperties().put("https.proxyPort", GlobalVariables.proxyPort);
      System.getProperties().put("http.nonProxyHosts", GlobalVariables.nonProxyHosts);
    }
    List<Tasks> runs = new ArrayList<Tasks>();
    String id = null;
    JSONObject work;
    String json;
    String scheduleName = null;
    String scheduleID = null;
    try {

      json = new String(Files.readAllBytes(Paths.get(path)));

      work = new JSONObject(json);
      id = work.getString("requestID");
      scheduleName = work.getString("scheduleName");
      JSONArray tasks = work.getJSONArray("tasks");
      tasksLength = tasks.length();
      GlobalVariables.KeyManagement(ConfigJson, tasksLength);

      for (int i = 0; i < tasks.length(); i++) {
        JSONObject task;
        task = tasks.getJSONObject(i);
        // String network = task.getString("network");

        // TODO resolve this network thing
        String location = task.getString("location");
        String urlOrScript = task.getString("urlOrScript");
        String server = task.getString("server");
        String label = task.getString("label");
        String network = task.getString("network");
        String block = task.getString("block");
        Boolean isScript = task.getBoolean("isScript");
        Boolean isCustomer = task.getBoolean("isCustomer");

        Tasks r =
            new Tasks(location, network, server, label, isScript, urlOrScript, isCustomer, block);

        //	System.out.println(network);
        //	System.out.println(location);
        //	System.out.println(urlOrScript);
        //	System.out.println(server);
        //	System.out.println(isScript);

        runs.add(r);
        //		System.out.println();
      }

    } catch (IOException | JSONException e) {
      e.printStackTrace();
    }

    req.setRequestID(id);
    req.setRuns(runs);

    // TODO Migrate following CODE to Singleton
    List<PwatchRun> pwatchRunList;
    String RequestID;

    List<Tasks> failed;

    pwatchRunList = new ArrayList<PwatchRun>();
    failed = new ArrayList<Tasks>();
    RequestID = req.getRequestID();

    //	dao.createGroup(req.getRequestID(), groupID);

    System.out.println(RequestID);
    System.out.println(groupID);

    List<Tasks> tasks = req.getRuns();
    Iterator<Tasks> r = tasks.iterator();

    while (r.hasNext()) {
      Tasks run = r.next();

      try {
        Dao dao = DaoFactory.getDao();
        Tasks taskNew = dao.isTaskDuplicate(run);
        if (taskNew.get_id() == null) {
          String taskId = dao.addTask(run);
          System.out.println("task id from add task" + taskId);
        }
        try {
          System.out.println("ScheduleName   ::::::::" + scheduleName);
          scheduleID = dao.getScheduleID(scheduleName);
          System.out.println("Schedule ID :: " + scheduleID);
          // run.setScheduleID(dao.getScheduleID(scheduleName));
          // dao.addRun(run);
        } catch (UnknownHostException e) { // TODO Auto-generated catch block
          e.printStackTrace();
        }

        pwatchRunList.add(new PwatchRun(run, groupID, id, scheduleID));
        Thread.sleep(1000);
      } catch (MalformedURLException e) {
        e.printStackTrace();
        failed.add(run);
      } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
        failed.add(run);
      }
    }
    //	Set<Future<Run>> futureList = new HashSet<Future<Run>>();
    ExecutorService t = Executors.newCachedThreadPool();

    for (int i = 0; i < pwatchRunList.size(); i++) {
      // futureList.add(t.submit(pwatchRunList.get(i)));
      t.execute(pwatchRunList.get(i));
    }
    t.shutdown();
    t.awaitTermination(GlobalVariables.timeout, TimeUnit.SECONDS);
    if (!t.isTerminated()) {
      System.out.println("***Timed OUT***" + (new Date()));
      t.shutdownNow();
    }
    t.awaitTermination(4, TimeUnit.SECONDS);
    System.out.println("***Exiting***" + (new Date()));
  }
}
