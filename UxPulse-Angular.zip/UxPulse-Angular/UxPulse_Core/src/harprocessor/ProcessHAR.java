package harprocessor;

import java.io.*;
import java.util.*;

import org.json.JSONException;
import org.json.JSONObject;

import config.GlobalVariables;
import exception.ProcessException;



public class ProcessHAR {

	public static String analyseHAR(String groupID, String runID) throws ProcessException
	{
		  List<String> command = new ArrayList<String>();
		  //yslow -i all -f json -r ydefault -d "D:\\b2b.tmag.biz_Home.har"
		  	String path = GlobalVariables.harpath+"//"+groupID+"//"+runID;
		  	
		    command.add("cmd");
		    command.add("/C");
		    command.add("yslow");
		    command.add("-i");
		    command.add("all");
		    command.add(path+".har");
		    command.add(">");
		    command.add(path+".json");
		    
		    ProcessBuilder builder = new ProcessBuilder(command);
		    //Map<String, String> environ = builder.environment();
		    String rec = "{}"; 
		    try{
		    	final Process process = builder.start();
		    	InputStream is = process.getInputStream();
		    	InputStreamReader isr = new InputStreamReader(is);
		    	BufferedReader br = new BufferedReader(isr);
		    	String line;
		    	while ((line = br.readLine()) != null) {
		    		System.out.println(line);
		    	}
		    	rec = updateReccomonadation(groupID,runID); 
		    }
		    catch(IOException e){ 
		    	e.printStackTrace();
		    	throw new ProcessException("Command");
		    }
		    catch (JSONException e) {
		    	e.printStackTrace();
		    	throw new ProcessException("JSON");
			}
		    return rec;
		    //System.out.println("Program terminated!");
	}
	
	public static String updateReccomonadation(String groupID, String runID) throws IOException, JSONException{
		String recomondations;
		String path = GlobalVariables.harpath+"//"+groupID+"//"+runID+".json";
		BufferedReader br = new BufferedReader(new FileReader(path));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line.trim());
	           // sb.append(System.lineSeparator());
	            line = br.readLine();
	        }
	        recomondations= sb.toString();
	    } finally {
	        br.close();
	    }
	    JSONObject reco = new JSONObject(recomondations);
	    return reco.toString();
	}
}
