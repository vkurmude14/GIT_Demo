package dao;

import java.net.UnknownHostException;

public class DaoFactory {
	static Dao dao = null;;
	public static Dao getDao() throws UnknownHostException{
		if(dao==null){
			dao = new DaoImpl();
		}
		return dao;
	}
}

