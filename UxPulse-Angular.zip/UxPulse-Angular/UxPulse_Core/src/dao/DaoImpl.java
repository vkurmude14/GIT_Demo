package dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import config.GlobalVariables;
import dto.RunData;
import dto.Tasks;

public class DaoImpl implements Dao {

  DBCollection col;

  public DaoImpl() throws UnknownHostException {
    super();
    col = getCollection("runData");
  }

  @Override
  public void addRun(RunData r) {
    JSONObject j = new JSONObject(r);
    DBObject o = new BasicDBObject((BasicDBObject) JSON.parse(j.toString()));
    o.put("_id", r.getTestID());
    col.insert(o);
  }

  @Override
  public void updateRunStatus(RunData r) {

    DBObject o = new BasicDBObject();
    o.put("status", r.getStatus());
    // o.put("statusText",r.getStatusTest());
    o = new BasicDBObject("$set", o);
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
  }

  @Override
  public void updateRecommondations(RunData r) {
    DBObject o =
        new BasicDBObject(
            "$set", new BasicDBObject("recommondations", JSON.parse(r.getRecommondations())));
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
  }

  @Override
  public void updateRunData(RunData r) {

    // System.out.println("StatusRun"+r.getStatus());
    DBObject o =
        new BasicDBObject("$set", new BasicDBObject("data", JSON.parse(r.getData().toString())));
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
    //	System.out.println("DataUpdated "+r.getTestID());
  }

  @Override
  public void updateRunHar(RunData r) {

    //	DBObject o = new BasicDBObject("$set",new
    // BasicDBObject("groups."+groupID+".runs."+r.getTestID()+".har",JSON.parse(r.getHar().toString())));
    //	col.update(q, o);

    // if file doesnt exists, then create it
    try {

      File file = new File(GlobalVariables.harpath + "//" + r.getGroupID());
      // Add extension .har to filename
      if (!file.exists()) {
        file.mkdirs();
      }

      file =
          new File(GlobalVariables.harpath + "//" + r.getGroupID() + "//" + r.getTestID() + ".har");
      if (!file.exists()) {
        file.createNewFile();
      }
      FileWriter fw = new FileWriter(file.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(r.getHar());
      bw.close();

    } catch (IOException e) {
      System.out.println("Failed to write file " + r.getTestID());
      e.printStackTrace();
    }
  }

  public DBCollection getCollection(String col) throws UnknownHostException {
    MongoClient mongo = new MongoClient(GlobalVariables.dbhost, GlobalVariables.dbport);
    return mongo.getDB(GlobalVariables.dbname).getCollection(col);
  }

  @Override
  public void addError(RunData r) {

    DBObject o = new BasicDBObject("$set", new BasicDBObject("errors", r.getErrors()));
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
    // System.out.println("ErrorsUpdated "+r.getTestID());
  }

  @Override
  public void updateRunRaw(RunData r) {
    // System.out.println("StatusRun"+r.getStatus());
    DBObject o = new BasicDBObject("$set", new BasicDBObject("raw", r.getRaw()));
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
    //	System.out.println("DataUpdated "+r.getTestID());

  }

  @Override
  public void updateMemoryMetric(RunData r) {
    DBObject o = new BasicDBObject("$set", new BasicDBObject("memory", r.getMemoryData()));
    DBObject q = new BasicDBObject("_id", r.getTestID());
    col.update(q, o);
  }

  @Override
  public String addTask(Tasks task) throws UnknownHostException {
    DBCollection col = getCollection("tasks");
    task.set_id(new ObjectId());
    JSONObject j = new JSONObject(task);
    DBObject o = new BasicDBObject((BasicDBObject) JSON.parse(j.toString()));
    o.put("_id", task.get_id());
    col.insert(o);
    return task.get_id().toHexString();
  }

  @Override
  public Tasks getTask(String taskId) throws UnknownHostException {
    DBCollection col = getCollection("tasks");
    Tasks task = new Tasks();
    BasicDBObject whereQuery = new BasicDBObject();
    whereQuery.put("_id", taskId);
    DBCursor cursor = col.find(whereQuery);
    while (cursor.hasNext()) {
      DBObject obj = cursor.next();
      task.set_id((ObjectId) obj.get("_id"));
      task.setLocation(obj.get("location").toString());
      task.setUrlOrScript(obj.get("urlOrScript").toString());
      task.setLabel(obj.get("label").toString());
      task.setServer(obj.get("server").toString());
      task.setNetwork(obj.get("network").toString());
      task.setBlock(obj.get("block").toString());
      task.setIsCustomer((Boolean) obj.get("isCustomer"));
      task.setIsScript((Boolean) obj.get("isScript"));
    }
    System.out.println("Task Details " + task.get_id());
    System.out.println("Task Details " + task.toString());
    return task;
  }

  @Override
  public Tasks isTaskDuplicate(Tasks task) throws UnknownHostException {
    DBCollection col = getCollection("tasks");
    BasicDBObject andQuery = new BasicDBObject();
    List<BasicDBObject> objDB = new ArrayList<BasicDBObject>();
    objDB.add(new BasicDBObject("location", task.getLocation()));
    objDB.add(new BasicDBObject("label", task.getLabel()));
    objDB.add(new BasicDBObject("urlOrScript", task.getUrlOrScript()));
    andQuery.put("$and", objDB);

    DBCursor cursor = col.find(andQuery);
    while (cursor.hasNext()) {
      DBObject obj = cursor.next();
      task.set_id((ObjectId) obj.get("_id"));
      task.setLocation(obj.get("location").toString());
      task.setUrlOrScript(obj.get("urlOrScript").toString());
      task.setLabel(obj.get("label").toString());
      task.setServer(obj.get("server").toString());
      task.setNetwork(obj.get("network").toString());
      task.setBlock(obj.get("block").toString());
      task.setIsCustomer((Boolean) obj.get("isCustomer"));
      task.setIsScript((Boolean) obj.get("isScript"));
    }

    return task;
  }

  @Override
  public String getScheduleID(String scheduleName) throws UnknownHostException {
    DBCollection col = getCollection("schedule");
    BasicDBObject whereQuery = new BasicDBObject();
    whereQuery.put("scheduleName", scheduleName);
    DBCursor cursor = col.find(whereQuery);
    System.out.println("schName ::::::::::::" + scheduleName);
    String scheduleID = null;
    while (cursor.hasNext()) {
      DBObject obj = cursor.next();
      scheduleID = obj.get("_id").toString();
    }
    System.out.println("schID ::::::::::::" + scheduleID);
    return scheduleID;
  }
}
