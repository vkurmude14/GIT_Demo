package dao;

import java.net.UnknownHostException;

import dto.RunData;
import dto.Tasks;

public interface Dao {

  public void addRun(RunData r);

  public void addError(RunData r);

  public void updateRunStatus(RunData r);

  public void updateRunData(RunData r);

  public void updateRunHar(RunData r);

  public void updateRunRaw(RunData r);

  void updateRecommondations(RunData r);

  public void updateMemoryMetric(RunData r);

  public String addTask(Tasks task) throws UnknownHostException;

  public Tasks getTask(String taskId) throws UnknownHostException;

  public Tasks isTaskDuplicate(Tasks task) throws UnknownHostException;

  public String getScheduleID(String scheduleName) throws UnknownHostException;
}
