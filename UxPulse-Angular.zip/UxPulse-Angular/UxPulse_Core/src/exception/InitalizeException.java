package exception;

public class InitalizeException extends PwatchException {

	public InitalizeException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
