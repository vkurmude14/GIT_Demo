package exception;

public class RawDownloadException extends PwatchException {

	public RawDownloadException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
