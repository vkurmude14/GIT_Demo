package exception;

public class PwatchException extends Exception {

	public PwatchException(String message) {
	
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
