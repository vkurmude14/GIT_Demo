package exception;

public class SendException extends PwatchException {

	public SendException(String message) {
		super(message);
		
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
