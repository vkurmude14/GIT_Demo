package exception;

public class HARDownloadException extends PwatchException {

	public HARDownloadException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
