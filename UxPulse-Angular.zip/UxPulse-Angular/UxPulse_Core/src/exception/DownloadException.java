package exception;

public class DownloadException extends PwatchException {

	public DownloadException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
