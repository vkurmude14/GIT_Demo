package exception;

public class ProcessException extends PwatchException {

	public ProcessException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
