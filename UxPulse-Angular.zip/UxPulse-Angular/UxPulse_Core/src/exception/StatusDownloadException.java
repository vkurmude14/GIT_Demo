package exception;

public class StatusDownloadException extends PwatchException {

	public StatusDownloadException(String message) {
		super(message);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
