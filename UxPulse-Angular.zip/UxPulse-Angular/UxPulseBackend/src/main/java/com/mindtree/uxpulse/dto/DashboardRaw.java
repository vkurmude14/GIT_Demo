package com.mindtree.uxpulse.dto;

import com.mindtree.uxpulse.entity.Tasks;

import lombok.Data;

/** @author M1049117 */
@Data
public class DashboardRaw {
  private String _id;
  private String requestID;
  private String testID;
  private Object data;
  private Object memory;
  private String groupID;
  private Object recommondations;
  private String urlOrScript;
  private String taskId;
  private Tasks taskData;
}
