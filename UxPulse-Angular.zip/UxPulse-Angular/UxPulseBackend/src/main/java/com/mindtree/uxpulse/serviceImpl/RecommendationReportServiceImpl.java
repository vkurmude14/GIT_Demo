package com.mindtree.uxpulse.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.UrlLabelDto;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.exception.ConnectivityException;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.service.RecommendationReportService;
import com.mindtree.uxpulse.util.GlobalVariables;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/** @author M1049117 */
@Service
public class RecommendationReportServiceImpl implements RecommendationReportService {

  @Autowired private RunDataRepo runDataRepository;
  @Autowired private CouchDbConnector dbConnector;

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.RecommendationReportService#getRecommendationsFromGooglePageSpeed(java.lang.String)
   */
  @Override
  public JsonNode getRecommendationsFromGooglePageSpeed(String url)
      throws ConnectivityException, JsonMappingException, JsonProcessingException {
    JsonNode jsonNode = null;
    try {
      String GPSAPI =
          GlobalVariables.GPS_URL
              + url
              + GlobalVariables.GPS_CATEGORIES
              + GlobalVariables.GPS_STRATEGY;
      Client restClient = Client.create();
      WebResource webResource = restClient.resource(GPSAPI);
      ClientResponse resp = webResource.accept("application/json").get(ClientResponse.class);
      if (resp.getStatus() != 200) {
        throw new ConnectivityException("Please Check your Internet Connection");
      }
      String output = resp.getEntity(String.class);
      ObjectMapper objectMapper = new ObjectMapper();
      jsonNode = objectMapper.readTree(output);

    } catch (Exception e) {
      e.printStackTrace();
    }

    return jsonNode;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.RecommendationReportService#getListOfLabels(java.lang.String)
   */
  @Override
  public List<UrlLabelDto> getListOfLabels(String requestID) {
    List<RunData> runDatas = runDataRepository.findByRequestID(requestID);
    HashSet<UrlLabelDto> urls = new HashSet<>();
    HashSet<String> listOfTaskID = new HashSet<>();
    for (RunData runData : runDatas) {
      listOfTaskID.add(runData.getTaskId());
    }

    List<Tasks> tasks = new ArrayList<>();
    for (String t : listOfTaskID) {
      Tasks task = dbConnector.find(Tasks.class, t);
      tasks.add(task);
    }
    for (Tasks task : tasks) {
      UrlLabelDto obj = new UrlLabelDto();
      obj.setIsCustomer(task.getIsCustomer());
      obj.setLabel(task.getLabel());
      obj.setIsScript(task.getIsScript());
      obj.setUrlOrScript(task.getUrlOrScript());
      urls.add(obj);
    }
    return new ArrayList<UrlLabelDto>(urls);
  }
}
