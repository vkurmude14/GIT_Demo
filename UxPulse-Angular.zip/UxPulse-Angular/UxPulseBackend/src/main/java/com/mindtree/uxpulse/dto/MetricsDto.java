package com.mindtree.uxpulse.dto;

import lombok.Data;

/** @author M1049117 */
@Data
public class MetricsDto {
  private FirstViewDto firstView;
  private RepeatViewDto repeatView;
}
