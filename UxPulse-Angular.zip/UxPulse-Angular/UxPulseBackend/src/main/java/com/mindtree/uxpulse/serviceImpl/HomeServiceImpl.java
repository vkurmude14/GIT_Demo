package com.mindtree.uxpulse.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.DeleteRunDataDto;
import com.mindtree.uxpulse.dto.HomePageGroupDataDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoRunDataFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.UserNotFoundException;
import com.mindtree.uxpulse.repo.RequestUserRepo;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.repo.ScheduleRepo;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.HomeService;

/** @author M1049117 */
@Service
public class HomeServiceImpl implements HomeService {

  @Autowired private UsersRepo usersRepository;

  @Autowired private RequestUserRepo requestUserRepository;

  @Autowired private ScheduleRepo scheduleRepository;

  @Autowired private RunDataRepo runDataRepository;

  private ObjectMapper objectMapper = new ObjectMapper();

  @Autowired CouchDbConnector dbConnector;

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.HomeService#getListOfRequests(java.lang.String)
   */
  @Override
  public List<String> getListOfRequests(String email)
      throws UserNotFoundException, NoRequestsFoundException {
    List<Users> users = usersRepository.findByEmail(email);
    if (users.size() == 0) {
      throw new UserNotFoundException("No User Found for this Email ID");
    }
    String userID = users.get(0).get_id();
    List<RequestUser> requestUser = requestUserRepository.findByUserId(userID);
    if (requestUser.size() == 0) {
      throw new NoRequestsFoundException("No Requests Found for this User");
    }
    List<String> requests = new ArrayList<String>();
    for (RequestUser str : requestUser) {
      requests.add(str.getRequestID());
    }
    return requests;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.HomeService#getListOfSchedules(java.lang.String, java.lang.String)
   */
  @Override
  public List<String> getListOfSchedules(String email, String requestID)
      throws UserNotFoundException, NoRequestsFoundException, NoSchedulesFoundException {
    List<Users> users = usersRepository.findByEmail(email);
    if (users.size() == 0) {
      throw new UserNotFoundException("No User Found for this Email ID");
    }
    String userID = users.get(0).get_id();
    List<RequestUser> requestUser = requestUserRepository.findByUserId(userID);
    if (requestUser.size() == 0) {
      throw new NoRequestsFoundException("No Requests Found for this User");
    }
    String requestUserId = null;
    for (RequestUser req : requestUser) {
      if (req.getRequestID().equals(requestID)) {
        requestUserId = req.get_id();
      }
    }
    List<String> schedules = new ArrayList<>();
    if (requestUserId == null) {
      throw new NoSchedulesFoundException("No Schedules Found for this User");
    } else {
      for (Schedule sch : scheduleRepository.findByRequestUserId(requestUserId)) {
        schedules.add(sch.getScheduleName());
      }
    }
    return schedules;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.HomeService#getListOfRequestsByUser(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<HomePageGroupDataDto> getListOfRequestsByUser(
      String email, String requestID, String scheduleName)
      throws UserNotFoundException, NoRequestsFoundException, NoSchedulesFoundException,
          NoRunDataFoundException {
    List<Users> users = usersRepository.findByEmail(email);
    if (users.size() == 0) {
      throw new UserNotFoundException("No User Found for this Email ID");
    }
    System.out.println(" user size" + users.size());

    String userID = users.get(0).get_id();
    List<RequestUser> requestUser = requestUserRepository.findByUserId(userID);
    if (requestUser.size() == 0) {
      throw new NoRequestsFoundException("No Requests Found for this User");
    }
    System.out.println("Request user size" + requestUser.size());
    String requestUserId = null;
    for (RequestUser req : requestUser) {
      if (req.getRequestID().equals(requestID)) {
        requestUserId = req.get_id();
      }
    }
    List<Schedule> schedules = new ArrayList<>();
    if (requestUserId == null) {
      throw new NoSchedulesFoundException("No Schedules Found for this User");
    }

    schedules = scheduleRepository.findByRequestUserId(requestUserId);
    String scheduleID = null;
    System.out.println("schedule  size" + schedules.size());
    for (Schedule sch : schedules) {
      if (sch.getScheduleName().equals(scheduleName)) {
        scheduleID = sch.get_id();
      }
    }
    List<RunData> runDatas = runDataRepository.findByRequestIdAndScheduleId(requestID, scheduleID);
    System.out.println("rundata  size" + runDatas.size());

    if (runDatas.size() == 0) {
      throw new NoRunDataFoundException("No Runs Found for the given Schedule");
    }
    List<HomePageGroupDataDto> listOfRuns = new ArrayList<>();
    for (RunData run : runDatas) {
      HomePageGroupDataDto obj = new HomePageGroupDataDto();
      obj.setTestID(run.get_id());
      obj.setStatus(run.getStatus());
      obj.setErrors(run.getErrors());
      String taskId = run.getTaskId();
      Tasks task = dbConnector.find(Tasks.class, taskId);

      obj.setLabel(task.getLabel());
      obj.setLocation(task.getLocation());
      obj.setNetwork(task.getNetwork());
      obj.setGroupID(run.getGroupID());

      listOfRuns.add(obj);
    }

    return listOfRuns;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.HomeService#deleteRunData(com.mindtree.uxpulse.dto.DeleteRunDataDto)
   */
  @Override
  public List<HomePageGroupDataDto> deleteRunData(DeleteRunDataDto deleteRunData)
      throws UserNotFoundException, NoSchedulesFoundException, NoRunDataFoundException,
          NoRequestsFoundException {
    List<String> itrId = deleteRunData.getTestIDs();
    List<RunData> runDatas = new ArrayList<>();
    for (String itr : itrId) {
      RunData temp = dbConnector.find(RunData.class, itr);
      runDatas.add(temp);
    }
    //    System.out.println(runDatas);
    runDataRepository.deleteByRunDataList(runDatas);
    return getListOfRequestsByUser(
        deleteRunData.getEmail(), deleteRunData.getRequestID(), deleteRunData.getScheduleName());
  }
}
