package com.mindtree.uxpulse.dto;

import java.util.Set;

import lombok.Data;

/**
 * analysis dto containing only necessary fields
 *
 * @author M1049117
 */
@Data
public class AnalysisData {

  private Object score_OnPageRedirects;
  private Object score_keep_alive;
  private Object score_gzip;
  private Object score_compress;
  private Object score_progressive_jpeg;
  private Object score_minify;
  private Object score_cdn;
  private Object score_renderBlockingJs;
  private Object score_cssDelivery;
  private Object score_BrowserResponseTime;
  private Set<String> labels;
}
