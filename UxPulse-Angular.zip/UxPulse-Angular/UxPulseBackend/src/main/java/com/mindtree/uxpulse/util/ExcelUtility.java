package com.mindtree.uxpulse.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.ResourceUtils;

import com.mindtree.uxpulse.dto.AverageForLabelDto;
import com.mindtree.uxpulse.dto.EndUserReportDto;
import com.mindtree.uxpulse.dto.EndUserReportSummaryDto;
import com.mindtree.uxpulse.dto.ParameterWiseEndUserReportDto;

public class ExcelUtility {

  @SuppressWarnings({"unchecked", "unused", "rawtypes"})
  public ByteArrayInputStream manipulateWorkBookWithActualData(
      String reqLabel, String scheduleLabel, EndUserReportDto data, HttpServletResponse response)
      throws IOException, InvalidFormatException {

    XSSFSheet activeSheet;

    int rowIndex;
    int columnIndex;

    File file = ResourceUtils.getFile("classpath:" + GlobalVariables.END_USER_REPORT_TEMPLATE_PATH);
    //   Create Workbook instance holding reference to .xlsx file
    File newFile = new File(reqLabel + "_" + scheduleLabel + "_" + "EndUserReport.xlsx");
    FileUtils.copyFile(file, newFile);
    XSSFWorkbook workbook = new XSSFWorkbook(newFile);

    // test profile start----------------------------------------------
    activeSheet = workbook.getSheet("Test Profile");
    // Set start DateTime
    rowIndex = 3;
    columnIndex = 5;
    activeSheet
        .getRow(rowIndex)
        .getCell(columnIndex)
        .setCellValue(new Date(data.getStart()).toString());

    // set end DateTime
    rowIndex = 4;
    activeSheet
        .getRow(rowIndex)
        .getCell(columnIndex)
        .setCellValue(new Date(data.getEnd()).toString());

    // put labels and urls
    rowIndex = 7;
    for (Map.Entry el : data.getLabelsAndUrls().entrySet()) {
      columnIndex = 4;
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      columnIndex = 8;
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getValue());
      rowIndex++;
    }

    // put locations
    rowIndex = 17;
    columnIndex = 4;
    for (String el : data.getLocations()) {
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue(el);
    }
    // put browsers
    rowIndex = 24;
    for (String el : data.getBrowsers()) {
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue(el);
    }
    // put networks
    rowIndex = 31;
    for (String el : data.getNetworks()) {
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue(el);
    }
    // test profile end----------------------------------------------

    // summary start----------------------------------------------
    activeSheet = workbook.getSheet("Summary");

    rowIndex = 8;

    EndUserReportSummaryDto endUserSummary = data.getSummaryDto();
    Map<String, Integer> recordCount = endUserSummary.getRecordCount();
    Map<String, AverageForLabelDto> cached = endUserSummary.getCached();
    Map<String, AverageForLabelDto> nonCached = endUserSummary.getNonCached();
    AverageForLabelDto avgForLabel;

    // for non cached users
    for (Map.Entry el : nonCached.entrySet()) {
      columnIndex = 1;
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      avgForLabel = (AverageForLabelDto) el.getValue();
      columnIndex = 2;
      //      System.out.println(
      //          rowIndex
      //              + " : "
      //              + columnIndex
      //              + " : "
      //              + avgForLabel.getTimeToFirstByte()
      //              + " : "
      //              + " : "
      //              + (String) el.getKey()
      //              + " : "
      //              + +recordCount.get((String) el.getKey()));
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getTimeToFirstByte() / recordCount.get((String) el.getKey()));
      columnIndex = 3;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getFirstResponseTimeInSec() / recordCount.get((String) el.getKey()));
      columnIndex = 4;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getVisuallyComplete() / recordCount.get((String) el.getKey()));
      columnIndex = 5;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getPerceivedResponseTimeInSec() / recordCount.get((String) el.getKey()));

      columnIndex = 6;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getActualResponseTimeInSec() / recordCount.get((String) el.getKey()));
      columnIndex = 7;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getPageSizeInKb() / recordCount.get((String) el.getKey()));
      columnIndex = 8;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getRequests() / recordCount.get((String) el.getKey()));

      rowIndex++;
    }
    rowIndex = 8;
    // for cached users
    for (Map.Entry el : cached.entrySet()) {
      columnIndex = 10;
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      avgForLabel = (AverageForLabelDto) el.getValue();
      columnIndex = 11;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getTimeToFirstByte() / recordCount.get((String) el.getKey()));
      columnIndex = 12;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getFirstResponseTimeInSec() / recordCount.get((String) el.getKey()));
      columnIndex = 13;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getVisuallyComplete() / recordCount.get((String) el.getKey()));
      columnIndex = 14;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getPerceivedResponseTimeInSec() / recordCount.get((String) el.getKey()));
      columnIndex = 15;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(
              avgForLabel.getActualResponseTimeInSec() / recordCount.get((String) el.getKey()));
      columnIndex = 16;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getPageSizeInKb() / recordCount.get((String) el.getKey()));
      columnIndex = 17;
      activeSheet
          .getRow(rowIndex)
          .getCell(columnIndex)
          .setCellValue(avgForLabel.getRequests() / recordCount.get((String) el.getKey()));

      rowIndex++;
    }

    // summary end----------------------------------------------
    // locationwise start----------------------------------------------
    activeSheet = workbook.getSheet("LocationWisePerformance");

    ParameterWiseEndUserReportDto locationWise = data.getLocationWisePerformance();
    recordCount = locationWise.getRecordCount();
    Map<String, Map<String, Double>> paramCached = locationWise.getCached();
    Map<String, Map<String, Double>> paramNonCached = locationWise.getNonCached();

    rowIndex = 42;
    columnIndex = 2;
    // set all locations
    for (Map.Entry el : recordCount.entrySet()) {

      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      activeSheet.getRow(rowIndex).getCell(columnIndex + 9).setCellValue((String) el.getKey());

      columnIndex++;
    }

    rowIndex = 43;
    int headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramNonCached.entrySet()) {

      columnIndex = 1;
      // set reqname
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      Map<String, Double> temp = (Map) el.getValue();
      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {
        System.out.println(
            rowIndex
                + " : "
                + columnIndex
                + " : "
                + headingRow
                + " : "
                + activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue()
                + " : "
                + temp.get(activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue())
                + " : "
                + recordCount.get(
                    activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue()));
        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue())
                    / recordCount.get(
                        activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue()));
        columnIndex++;
      }
      rowIndex++;
    }

    rowIndex = 43;
    headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramCached.entrySet()) {

      columnIndex = 10;
      // set reqname
      System.out.println(
          rowIndex
              + " : "
              + columnIndex
              + " : "
              + headingRow
              + " : "
              + el.getKey()
              + " : "
              + activeSheet.getRow(rowIndex).getCell(columnIndex));
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      Map<String, Double> temp = (Map) el.getValue();

      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {
        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue())
                    / recordCount.get(
                        activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue()));
        columnIndex++;
      }
      rowIndex++;
    }

    // locationwise end----------------------------------------------

    // browserwise start----------------------------------------------
    activeSheet = workbook.getSheet("BrowserWisePerformance");

    ParameterWiseEndUserReportDto browserWise = data.getBrowserWisePerformance();
    recordCount = browserWise.getRecordCount();
    paramCached = browserWise.getCached();
    paramNonCached = browserWise.getNonCached();

    rowIndex = 42;
    // set all browsers
    columnIndex = 2;
    for (Map.Entry el : recordCount.entrySet()) {

      String temp = ((String) el.getKey());
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue(temp);
      activeSheet.getRow(rowIndex).getCell(columnIndex + 9).setCellValue(temp);
      columnIndex++;
    }

    rowIndex = 43;
    headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramNonCached.entrySet()) {

      columnIndex = 1;
      // set reqname
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      Map<String, Double> temp = (Map) el.getValue();
      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {
        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(
                        activeSheet
                            .getRow(headingRow)
                            .getCell(columnIndex)
                            .getStringCellValue()
                            .replaceAll("_", " "))
                    / recordCount.get(
                        activeSheet
                            .getRow(headingRow)
                            .getCell(columnIndex)
                            .getStringCellValue()
                            .replaceAll("_", " ")));
        columnIndex++;
      }
      rowIndex++;
    }

    rowIndex = 43;
    headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramCached.entrySet()) {

      columnIndex = 10;
      // set reqname
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      Map<String, Double> temp = (Map) el.getValue();

      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {
        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(
                        activeSheet
                            .getRow(headingRow)
                            .getCell(columnIndex)
                            .getStringCellValue()
                            .replaceAll("_", " "))
                    / recordCount.get(
                        activeSheet
                            .getRow(headingRow)
                            .getCell(columnIndex)
                            .getStringCellValue()
                            .replaceAll("_", " ")));
        columnIndex++;
      }
      rowIndex++;
    }

    // browserwise end----------------------------------------------

    // networkwise start----------------------------------------------

    activeSheet = workbook.getSheet("NetworkWisePerformance");

    ParameterWiseEndUserReportDto networkWise = data.getNetworkWisePerformance();
    recordCount = networkWise.getRecordCount();
    paramCached = networkWise.getCached();
    paramNonCached = networkWise.getNonCached();

    rowIndex = 42;
    columnIndex = 2;
    // set all networks
    for (Map.Entry el : recordCount.entrySet()) {

      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      activeSheet.getRow(rowIndex).getCell(columnIndex + 9).setCellValue((String) el.getKey());
      columnIndex++;
    }

    rowIndex = 43;
    headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramNonCached.entrySet()) {

      columnIndex = 1;

      // set reqname
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());

      Map<String, Double> temp = (Map) el.getValue();
      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {
        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(activeSheet.getRow(headingRow).getCell(columnIndex).toString())
                    / recordCount.get(
                        activeSheet.getRow(headingRow).getCell(columnIndex).toString()));
        columnIndex++;
      }
      rowIndex++;
    }

    rowIndex = 43;
    headingRow = 42;
    // for non cached users
    for (Map.Entry el : paramCached.entrySet()) {
      columnIndex = 10;

      // set reqname
      System.out.println(
          rowIndex
              + " : "
              + columnIndex
              + " : "
              + el.getKey()
              + " : "
              + activeSheet.getRow(rowIndex).getCell(columnIndex));
      activeSheet.getRow(rowIndex).getCell(columnIndex).setCellValue((String) el.getKey());
      Map<String, Double> temp = (Map) el.getValue();

      columnIndex++;
      for (Map.Entry entry : temp.entrySet()) {

        activeSheet
            .getRow(rowIndex)
            .getCell(columnIndex)
            .setCellValue(
                temp.get(activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue())
                    / recordCount.get(
                        activeSheet.getRow(headingRow).getCell(columnIndex).getStringCellValue()));
        columnIndex++;
      }
      rowIndex++;
    }

    // networkwise end----------------------------------------------

    // Write the workbook in file system
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    workbook.write(out);
    response.addHeader("Content-Disposition", "attachment; filename=" + newFile.getName());
    workbook.close();
    return new ByteArrayInputStream(out.toByteArray());
  }
}
