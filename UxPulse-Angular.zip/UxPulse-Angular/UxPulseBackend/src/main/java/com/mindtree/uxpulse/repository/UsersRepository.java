package com.mindtree.uxpulse.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.mindtree.uxpulse.entity.Users;

/** @author M1049117 */
public interface UsersRepository extends MongoRepository<Users, String> {

  /**
   * @param email
   * @return list of users
   */
  @Query("{ 'email' : ?0 }")
  public List<Users> findUserByEmail(String email);

  /**
   * @param username
   * @return list of users
   */
  @Query("{ 'username' : ?0 }")
  public List<Users> findUserByUsername(String username);
}
