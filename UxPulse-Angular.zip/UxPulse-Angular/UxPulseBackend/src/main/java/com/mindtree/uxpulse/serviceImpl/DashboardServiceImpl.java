package com.mindtree.uxpulse.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.mindtree.uxpulse.dto.ComponentsDto;
import com.mindtree.uxpulse.dto.DashboardData;
import com.mindtree.uxpulse.dto.DashboardRaw;
import com.mindtree.uxpulse.dto.FirstViewDto;
import com.mindtree.uxpulse.dto.MetricsDto;
import com.mindtree.uxpulse.dto.RepeatViewDto;
import com.mindtree.uxpulse.dto.StatusDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.repo.RequestUserRepo;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.repo.ScheduleRepo;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.DashboardService;
import com.mindtree.uxpulse.util.GlobalVariables;
import com.mindtree.uxpulse.util.ReadPropertiesFile;

/** @author M1049117 */
@Service
public class DashboardServiceImpl implements DashboardService {

  @Autowired private RunDataRepo runDataRepo;
  @Autowired private CouchDbConnector dbConnector;
  @Autowired private UsersRepo usersRepo;
  @Autowired private RequestUserRepo reqUserRepo;
  @Autowired private ScheduleRepo scheduleRepo;

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.DashboardService#getRunDataForDashboard(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<DashboardData> getRunDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoSuchFieldException,
          SecurityException, IllegalArgumentException, IllegalAccessException,
          JsonProcessingException, NoTaskFoundException {

    // get raw data from db
    List<DashboardRaw> rawData = getRawDataForDashboard(scheduleLabel, requestLabel, email);

    // mapping object to json
    ObjectMapper objectMapper = new ObjectMapper();
    List<DashboardData> dashboardData = new ArrayList<DashboardData>();

    int i = 0;
    int j = 0;
    String[] location = {};
    Object jsonProvider;
    MetricsDto metricsDto;
    FirstViewDto firstView;
    RepeatViewDto repeatView;
    ComponentsDto componentsDto;
    List<Object> components;
    DashboardData tempObj;
    TreeMap<Long, Object> component;

    // for the raw records obtained
    for (DashboardRaw record : rawData) {

      jsonProvider = new Object();
      jsonProvider = objectMapper.readTree(objectMapper.writeValueAsString(record.getData()));
      tempObj = new DashboardData();
      metricsDto = new MetricsDto();

      // get firstView
      if (((JsonNode) jsonProvider).has("firstView")) {
        firstView = new FirstViewDto();
        firstView.setFullyLoaded(
            ((JsonNode) jsonProvider).get("firstView").get("fullyLoaded").asLong() / 1000);
        firstView.setStartRender(
            ((JsonNode) jsonProvider).get("firstView").get("render").asLong() / 1000);
        firstView.setDocComplete(
            ((JsonNode) jsonProvider).get("firstView").get("docTime").asLong() / 1000);
        if (null != ((JsonNode) jsonProvider).get("firstView").get("requestsDoc")) {

          firstView.setRequests(
              ((JsonNode) jsonProvider).get("firstView").get("requestsDoc").asLong());
        }
        if (null != ((JsonNode) jsonProvider).get("firstView").get("bytesIn"))
          firstView.setBytesIn(
              ((JsonNode) jsonProvider).get("firstView").get("bytesIn").asLong() / 1024);
        firstView.setRtt(((JsonNode) jsonProvider).get("firstView").get("server_rtt").asText());
        firstView.setTtfb(((JsonNode) jsonProvider).get("firstView").get("TTFB").asText());
        if (null != ((JsonNode) jsonProvider).get("firstView").get("domains"))
          firstView.setDomains(
              ((JsonNode) jsonProvider).get("firstView").get("domains").toString());
        if (null != ((JsonNode) jsonProvider).get("firstView").get("breakdown"))
          firstView.setBreakdown(
              ((JsonNode) jsonProvider).get("firstView").get("breakdown").toString());
        metricsDto.setFirstView(firstView);
      }

      // get repeatView
      if (((JsonNode) jsonProvider).has("repeatView")) {
        repeatView = new RepeatViewDto();
        repeatView.setFullyLoaded(
            ((JsonNode) jsonProvider).get("repeatView").get("fullyLoaded").asLong() / 1000);
        repeatView.setStartRender(
            ((JsonNode) jsonProvider).get("repeatView").get("render").asLong() / 1000);
        repeatView.setDocComplete(
            ((JsonNode) jsonProvider).get("repeatView").get("docTime").asLong() / 1000);
        if (null != ((JsonNode) jsonProvider).get("repeatView").get("requestsDoc")) {

          repeatView.setRequests(
              ((JsonNode) jsonProvider).get("repeatView").get("requestsDoc").asLong());
        }
        if (null != ((JsonNode) jsonProvider).get("repeatView").get("bytesIn"))
          repeatView.setBytesIn(
              ((JsonNode) jsonProvider).get("repeatView").get("bytesIn").asLong() / 1024);
        repeatView.setRtt(((JsonNode) jsonProvider).get("repeatView").get("server_rtt").asText());
        repeatView.setTtfb(((JsonNode) jsonProvider).get("repeatView").get("TTFB").asText());

        metricsDto.setRepeatView(repeatView);
      }

      // setting all values to the temporary obj and added to dashboardData list
      tempObj.setIndex(++i);
      tempObj.setGroupId(record.getGroupID());
      location = ((JsonNode) jsonProvider).get("location").asText().split(":");
      tempObj.setLocation(location[0]); // set location
      tempObj.setBrowser(location[1]); // set browser
      tempObj.setNetwork(((JsonNode) jsonProvider).get("connectivity").asText()); // setConnectivity
      tempObj.setDate(
          ((JsonNode) jsonProvider).get("completed").asLong() * 1000); // set completed time
      tempObj.setLatency(((JsonNode) jsonProvider).get("latency").asText()); //  set latency
      tempObj.setLabel(record.getTaskData().getLabel()); // set request label
      tempObj.setUrlOrScript(record.getUrlOrScript()); // set urlOrScript
      tempObj.setTestID(record.getTestID()); // set test ID
      tempObj.setMetrics(metricsDto); // set Metrics Dto
      tempObj.setIsCustomer(record.getTaskData().getIsCustomer()); // set Is customer

      // set Components
      jsonProvider =
          objectMapper.readTree(objectMapper.writeValueAsString(record.getRecommondations()));
      if (null != ((JsonNode) jsonProvider).get("comps")) {
        j = 0;
        componentsDto = new ComponentsDto();
        // provides sorted map based on key value (here it is long)
        component = new TreeMap<Long, Object>();

        // getting all the components into  a hashmap of <size, object>
        while (null != ((JsonNode) jsonProvider).get("comps").get(j)) {
          component.put(
              ((JsonNode) jsonProvider).get("comps").get(j).get("size").asLong(),
              ((JsonNode) jsonProvider).get("comps").get(j));
          ++j;
        }
        // get last 5 elements
        components = Lists.newArrayList(Iterables.limit(component.descendingMap().values(), 5));
        componentsDto.setHeavy(components);
        // get first 5 elements
        components = Lists.newArrayList(Iterables.limit(component.values(), 5));
        componentsDto.setSlow(components);
        tempObj.setComponents(componentsDto);
      }

      dashboardData.add(tempObj);
    }
    return dashboardData;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.DashboardService#getRawDataForDashboard(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<DashboardRaw> getRawDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException {

    Users userData = usersRepo.findByEmail(email).get(0);

    List<RequestUser> requestData =
        reqUserRepo.findByRequestIdAndUserId(requestLabel, userData.get_id());

    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");

    List<RunData> runDataTemp = new ArrayList<>();

    if (null != scheduleLabel) {
      List<Schedule> scheduleData = scheduleRepo.findByRequestUserId(requestData.get(0).get_id());
      if (scheduleData.size() == 0) {
        throw new NoSchedulesFoundException("No Schedules Found for this User");
      }

      runDataTemp =
          runDataRepo.findByRequestIdScheduleIdStatusTag(
              requestLabel, scheduleData.get(0).get_id(), StatusDto.RunStatus.COMPLETE.toString());

    } else {
      runDataTemp =
          runDataRepo.findByRequestIdStatusTag(
              requestLabel, StatusDto.RunStatus.COMPLETE.toString());
    }
    List<DashboardRaw> dashboardRawList = new ArrayList<>();

    runDataTemp.forEach(
        rD -> {
          DashboardRaw rawTemp = new DashboardRaw();
          rawTemp.set_id(rD.get_id());
          rawTemp.setData(rD.getData());
          rawTemp.setRequestID(rD.getRequestID());
          rawTemp.setTaskId(rD.getTaskId());
          rawTemp.setRecommondations(rD.getRecommondations());
          rawTemp.setGroupID(rD.getGroupID());
          rawTemp.setMemory(rD.getMemory());
          rawTemp.setTestID(rD.getTestID());
          rawTemp.setUrlOrScript(rD.getUrlOrScript());
          dashboardRawList.add(rawTemp);
        });

    dashboardRawList.forEach(
        record -> {
          Tasks taskData = dbConnector.find(Tasks.class, record.getTaskId());
          if (requestData.size() == 0)
            try {
              throw new NoTaskFoundException("No Tasks Found for this Taskid");
            } catch (NoTaskFoundException e) { // TODO Auto-generated catch block
              e.printStackTrace();
            }
          record.setTaskData(taskData);
        });

    return dashboardRawList;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.DashboardService#getHarData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public String getHarData(
      String username, String reqlabel, String scheduleLabel, String groupId, String testId)
      throws IOException { // TODO Auto-generated method stub
    Properties prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.APP_PROPERTIES);
    File file =
        ResourceUtils.getFile(
            prop.getProperty("app.harpath")
                + "\\"
                + username
                + "\\"
                + reqlabel
                + "\\"
                + scheduleLabel
                + "\\"
                + groupId
                + "\\"
                + testId
                + ".har");

    return new String(Files.readAllBytes(file.toPath()));
  }
}
