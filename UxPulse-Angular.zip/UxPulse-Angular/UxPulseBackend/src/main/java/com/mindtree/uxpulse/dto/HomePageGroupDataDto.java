package com.mindtree.uxpulse.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class HomePageGroupDataDto {

  private String testID;
  private String label;
  private String network;
  private String location;
  private String[] errors;
  private StatusDto status;
  private String groupID;
}
