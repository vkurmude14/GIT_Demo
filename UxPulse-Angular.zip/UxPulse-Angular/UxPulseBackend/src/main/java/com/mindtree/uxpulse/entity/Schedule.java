package com.mindtree.uxpulse.entity;

import org.codehaus.jackson.annotate.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/** @author M1049117 */
@Data
@NoArgsConstructor
public class Schedule {

  @JsonProperty("_id")
  private String _id;

  @NonNull private String scheduleName;
  @NonNull private String requestUserId;

  @JsonProperty("_rev")
  private String revision;
}
