package com.mindtree.uxpulse.service;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.mindtree.uxpulse.dto.LoginDto;
import com.mindtree.uxpulse.dto.LoginResponseDto;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.InvalidCredentialsException;
import com.mindtree.uxpulse.exception.UserAlreadyPresentException;
import com.mindtree.uxpulse.exception.UserNotFoundException;

@Service
public interface UserService {

  /**
   * @param user
   * @return string
   * @throws UserAlreadyPresentException
   * @throws IOException
   */
  public String createUser(Users user) throws UserAlreadyPresentException, IOException;

  /**
   * @param username
   * @return boolean
   */
  public boolean isUserNameAvailable(String username);

  /**
   * @param login
   * @return loginresponse
   * @throws UserNotFoundException
   * @throws InvalidCredentialsException
   */
  public LoginResponseDto login(LoginDto login)
      throws UserNotFoundException, InvalidCredentialsException;
}
