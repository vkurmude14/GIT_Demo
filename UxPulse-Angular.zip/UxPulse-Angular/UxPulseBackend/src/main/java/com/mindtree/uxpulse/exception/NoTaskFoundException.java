package com.mindtree.uxpulse.exception;

/** @author M1049117 */
public class NoTaskFoundException extends ServiceException {

  /** */
  private static final long serialVersionUID = 1L;

  public NoTaskFoundException() {
    super();
  }

  public NoTaskFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

  public NoTaskFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public NoTaskFoundException(String message) {
    super(message);
  }

  public NoTaskFoundException(Throwable cause) {
    super(cause);
  }
}
