package com.mindtree.uxpulse.util;

import java.util.Base64;

import org.springframework.stereotype.Service;

@Service
public class PasswordEncoderDecoder {

  public String decodePassword(String encodedPassword) throws IllegalArgumentException {
    byte[] decodedBytes = Base64.getDecoder().decode(encodedPassword);
    String decodedPassword = new String(decodedBytes);
    return decodedPassword;
  }

  public String encodePassword(String decodedPassword) throws IllegalArgumentException {
    String encodedPassword = Base64.getEncoder().encodeToString(decodedPassword.getBytes());
    return encodedPassword;
  }
}
