package com.mindtree.uxpulse.dto;

import com.mongodb.lang.NonNull;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@RequiredArgsConstructor
public class ConfigDto {

  @NonNull private String dbhost;
  @NonNull private String dbport;
  @NonNull private String dbname;
  @NonNull private String dbuser;
  @NonNull private String dbpass;
  @NonNull private String timeout;
  @NonNull private String pingInterval;
  @NonNull private String apiKey;
  @NonNull private String useProxy;
  @NonNull private String proxyHost;
  @NonNull private String proxyPort;
  @NonNull private String nonProxyHosts;
  @NonNull private String logpath;
  @NonNull private String harpath;
  @NonNull private String chromeDriverPath;
}
