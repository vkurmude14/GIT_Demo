package com.mindtree.uxpulse.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.service.AnalysisService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/** @author M1049117 */
@CrossOrigin("*")
@RestController
public class AnalysisController {

  @Autowired private AnalysisService analysisService;

  /**
   * get the analysis data
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param label
   * @param email
   * @return ResponseEntity
   * @throws NoSchedulesFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws NoRequestsFoundException
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws JsonProcessingException
   * @throws NoTaskFoundException
   */
  @GetMapping(
      value = "getAnalysisData",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getAnalysisData(
      @RequestParam(required = false) String scheduleLabel,
      @RequestParam String requestLabel,
      @RequestParam(required = false) String label,
      @RequestParam String email)
      throws NoSchedulesFoundException, NoSuchFieldException, SecurityException,
          NoRequestsFoundException, IllegalArgumentException, IllegalAccessException,
          JsonProcessingException, NoTaskFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "getAnalysisData",
            HttpStatus.OK.toString(),
            200,
            analysisService.getDataForAnalysis(scheduleLabel, requestLabel, label, email),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
