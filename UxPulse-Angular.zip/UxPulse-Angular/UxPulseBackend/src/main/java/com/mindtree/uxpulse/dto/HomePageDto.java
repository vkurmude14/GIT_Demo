package com.mindtree.uxpulse.dto;

import java.util.List;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@RequiredArgsConstructor
public class HomePageDto {

  private String groupID;
  private List<HomePageGroupDataDto> groupData;
}
