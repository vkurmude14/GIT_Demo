package com.mindtree.uxpulse.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mindtree.uxpulse.entity.Tasks;

/** @author M1049117 */
public interface TaskRepository extends MongoRepository<Tasks, String> {}
