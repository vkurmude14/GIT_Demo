package com.mindtree.uxpulse.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

/** @author M1049117 */
@Data
public class EndUserReportSummaryDto {

  Map<String, Integer> recordCount;
  Map<String, AverageForLabelDto> cached;
  Map<String, AverageForLabelDto> nonCached;

  public EndUserReportSummaryDto() {
    this.recordCount = new HashMap<>();
    this.cached = new HashMap<String, AverageForLabelDto>();
    this.nonCached = new HashMap<String, AverageForLabelDto>();
  }
}
