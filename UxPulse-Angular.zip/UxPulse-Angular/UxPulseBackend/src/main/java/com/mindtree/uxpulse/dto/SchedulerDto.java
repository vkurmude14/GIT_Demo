package com.mindtree.uxpulse.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@RequiredArgsConstructor
@NoArgsConstructor
public class SchedulerDto {

  @NonNull private List<String> locations;
  @NonNull private List<UrlLabelDto> urlsLabel;
  @NonNull private String from;
  @NonNull private String to;
  @NonNull private String intervalUnit;
  @NonNull private String interval;
  @NonNull private String requestLabel;
  @NonNull private String scheduleName;
}
