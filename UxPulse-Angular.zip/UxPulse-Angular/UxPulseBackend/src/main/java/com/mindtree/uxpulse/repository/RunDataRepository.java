package com.mindtree.uxpulse.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.mindtree.uxpulse.entity.RunData;

/** @author M1049117 */
public interface RunDataRepository
    extends MongoRepository<RunData, String>, RunDataCustomRepository {

  /**
   * @param requestID
   * @param scheduleID
   * @return list of rundata
   */
  @Query("{ $and:[ { 'requestID' :?0 },{ 'scheduleID' :?1 } ]}")
  public List<RunData> findRunDataByRequestIdAndScheduleID(String requestID, String scheduleID);

  /**
   * @param requestID
   * @return list of rundata
   */
  @Query("{ 'requestID' : ?0 }")
  public List<RunData> findRunDataByRequestID(String requestID);
}
