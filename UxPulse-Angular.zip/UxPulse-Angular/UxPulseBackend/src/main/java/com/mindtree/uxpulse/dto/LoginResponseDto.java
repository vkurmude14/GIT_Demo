package com.mindtree.uxpulse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/** @author M1049117 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginResponseDto {
  private boolean isCrendentialsRight;
  @NonNull private String username;
  @NonNull private String email;
  @NonNull private String message;
}
