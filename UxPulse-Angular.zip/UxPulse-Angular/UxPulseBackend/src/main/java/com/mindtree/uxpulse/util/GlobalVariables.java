package com.mindtree.uxpulse.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GlobalVariables {

  public static final String WPT_SERVER = "http://api.webpagetest.org";
  public static String proxyHost = "172.22.218.218";
  public static String proxyPort = "8085";

  public static final String APP_PROPERTIES = "app.properties";
  public static final String APPLICATION_PROPERTIES = "application.properties";
  public static final String LOG_PROPERTIES = "log.properties";
  public static final String DB_CONFIG_PROPERTIES = "db.properties";
  public static final String GPS_URL =
      "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=";

  public static final String GPS_CATEGORIES =
      "&category=performance" + "&category=SEO" + "&category=accessibility";

  public static final String GPS_STRATEGY = "&strategy=desktop";

  public static final List<String> LIGHTHOUSE_TAGS =
      new ArrayList<>(
          Arrays.asList(
              "OnPageRedirects",
              "keep-alive",
              "gzip",
              "compress",
              "progressive_jpeg",
              "minify",
              "cache",
              "cdn",
              "renderBlockingJs",
              "cssDelivery",
              "BrowserResponseTime"));
  public static final String END_USER_REPORT_TEMPLATE_PATH = "templates/EndUserExperience.xlsx";
}
