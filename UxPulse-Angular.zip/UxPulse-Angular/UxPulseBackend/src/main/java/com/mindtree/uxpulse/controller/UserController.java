package com.mindtree.uxpulse.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.uxpulse.dto.LoginDto;
import com.mindtree.uxpulse.dto.LoginResponseDto;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.InvalidCredentialsException;
import com.mindtree.uxpulse.exception.UserAlreadyPresentException;
import com.mindtree.uxpulse.exception.UserNotFoundException;
import com.mindtree.uxpulse.service.UserService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/**
 * user controller
 *
 * @author M1049117
 */
@CrossOrigin("*")
@RestController
public class UserController {

  @Autowired private UserService userService;

  /**
   * create user
   *
   * @param user
   * @return ResponseEntity
   * @throws UserAlreadyPresentException
   * @throws IOException
   */
  @PostMapping(
      value = "signup",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> createUser(@RequestBody Users user)
      throws UserAlreadyPresentException, IOException {
    String str = userService.createUser(user);
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(str, HttpStatus.CREATED.toString(), 201, null, true, false);

    return ResponseEntity.status(HttpStatus.CREATED).body(apiSuccessResponse);
  }

  /**
   * login controller
   *
   * @param login
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws InvalidCredentialsException
   */
  @PostMapping(
      value = "login",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> login(@RequestBody LoginDto login)
      throws UserNotFoundException, InvalidCredentialsException {
    LoginResponseDto response = userService.login(login);
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            response.getMessage(),
            HttpStatus.OK.toString(),
            200,
            response,
            response.isCrendentialsRight(),
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * @param username
   * @return ResponseEntity
   */
  @GetMapping(
      value = "isUserNameAvailable",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> isUserNameAvailable(
      @RequestParam("username") String username) {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "isUserNameAvailable",
            HttpStatus.OK.toString(),
            200,
            userService.isUserNameAvailable(username),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
