package com.mindtree.uxpulse.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class Users {

  @JsonProperty("_id")
  private String _id;

  @NonNull private String username;
  @NonNull private String email;
  @NonNull private String password;
  private long time;
  private List<String> keys;

  @JsonProperty("_rev")
  private String revision;
}
