package com.mindtree.uxpulse.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.mindtree.uxpulse.entity.Schedule;

/** @author M1049117 */
public interface ScheduleRepository extends MongoRepository<Schedule, String> {

  /**
   * @param requestUserId
   * @return list of schedules
   */
  @Query("{ 'requestUserId' : ?0 }")
  public List<Schedule> findScheduleByRequestUserID(String requestUserId);
}
