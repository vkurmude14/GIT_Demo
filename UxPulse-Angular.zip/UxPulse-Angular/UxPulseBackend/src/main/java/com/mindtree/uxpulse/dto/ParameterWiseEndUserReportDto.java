package com.mindtree.uxpulse.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

/** @author M1049117 */
@Data
public class ParameterWiseEndUserReportDto {
  Map<String, Integer> recordCount;
  Map<String, Map<String, Double>> cached;
  Map<String, Map<String, Double>> nonCached;

  public ParameterWiseEndUserReportDto() {
    this.recordCount = new HashMap<>();
    this.cached = new HashMap<String, Map<String, Double>>();
    this.nonCached = new HashMap<String, Map<String, Double>>();
  }
}
