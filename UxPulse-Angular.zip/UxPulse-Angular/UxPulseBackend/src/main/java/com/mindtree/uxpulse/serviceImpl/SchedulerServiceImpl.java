package com.mindtree.uxpulse.serviceImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.ConfigDto;
import com.mindtree.uxpulse.dto.SchedulerDto;
import com.mindtree.uxpulse.dto.UrlLabelDto;
import com.mindtree.uxpulse.dto.WorkDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.TaskSchedulerException;
import com.mindtree.uxpulse.repo.RequestUserRepo;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.repo.ScheduleRepo;
import com.mindtree.uxpulse.repo.TaskRepo;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.SchedulerService;
import com.mindtree.uxpulse.util.GlobalVariables;
import com.mindtree.uxpulse.util.ReadPropertiesFile;

/** @author M1049117 */
@Service
public class SchedulerServiceImpl implements SchedulerService {

  @Autowired CouchDbConnector dbConnector;

  @Autowired private RequestUserRepo requestUserRepository;
  @Autowired private UsersRepo userRepository;
  @Autowired private ScheduleRepo scheduleRepository;
  @Autowired private RunDataRepo runDataRepository;
  @Autowired private TaskRepo taskRepository;

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#scheduleTest(com.mindtree.uxpulse.dto.SchedulerDto, java.lang.String)
   */
  @Override
  public String scheduleTest(SchedulerDto scheduler, String username)
      throws IOException, ParseException, TaskSchedulerException {

    List<Tasks> tasks = new ArrayList<>();
    for (String location : scheduler.getLocations()) {
      for (UrlLabelDto urls : scheduler.getUrlsLabel()) {
        Tasks task = new Tasks();
        task.setLocation(location);
        task.setServer(GlobalVariables.WPT_SERVER);
        task.setUrlOrScript(urls.getUrlOrScript());
        task.setLabel(urls.getLabel());
        task.setIsScript(urls.getIsScript());
        task.setIsCustomer(urls.getIsCustomer());
        task.setBlock("");
        task.setNetwork("Cable");
        tasks.add(task);
      }
    }
    String workPath = writeWorkJsonFile(scheduler, username, tasks);
    String configPath = writeConfigJson(scheduler, username);
    String command = createSchedulerTask(scheduler, workPath, configPath, username);
    Process process = Runtime.getRuntime().exec(command);
    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    String line = null;
    StringBuilder output = new StringBuilder();
    while ((line = reader.readLine()) != null) {
      output.append(line);
    }
    reader.close();
    if (output.toString().equals("")) {
      throw new TaskSchedulerException(
          "ERROR: Value for '/TR' option cannot be more than 261 character(s)");
    }

    List<RequestUser> requestUsers =
        requestUserRepository.findByRequestID(scheduler.getRequestLabel());
    if (requestUsers.size() == 0) {
      RequestUser requestUser = new RequestUser();
      requestUser.setRequestID(scheduler.getRequestLabel());
      requestUser.setTaskSchedulerName(username + "-" + scheduler.getRequestLabel());
      List<Users> users = userRepository.findByUsername(username);
      requestUser.setUserId(users.get(0).get_id());
      dbConnector.create(requestUser);
      Schedule schedule = new Schedule();
      schedule.setRequestUserId(requestUser.get_id());
      schedule.setScheduleName(scheduler.getScheduleName());
      dbConnector.create(schedule);
    } else {

      Schedule schedule = new Schedule();
      schedule.setRequestUserId(requestUsers.get(0).get_id());
      schedule.setScheduleName(scheduler.getScheduleName());
      dbConnector.create(schedule);
    }

    return output.toString();
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#writeWorkJsonFile(com.mindtree.uxpulse.dto.SchedulerDto, java.lang.String, java.util.List)
   */
  @Override
  public String writeWorkJsonFile(SchedulerDto scheduler, String username, List<Tasks> tasks)
      throws IOException {
    Properties prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.APP_PROPERTIES);
    String filePath =
        prop.getProperty("app.userpath")
            + username
            + File.separator
            + scheduler.getRequestLabel()
            + File.separator
            + scheduler.getScheduleName();
    File file = new File(filePath);
    boolean bool = file.mkdirs();
    if (bool) {

      System.out.println("Directory created successfully");

    } else {
      System.out.println("Sorry couldnt create specified directory");
    }
    try (FileWriter fstream = new FileWriter(filePath + File.separator + "work.json", true)) {
      WorkDto work = new WorkDto();
      work.setLabel(scheduler.getRequestLabel());
      work.setTasks(tasks);
      work.setRequestID(scheduler.getRequestLabel());
      work.setTaskName(username + "-" + scheduler.getRequestLabel());
      work.setScheduleName(scheduler.getScheduleName());
      ObjectMapper mapper = new ObjectMapper();
      fstream.write(mapper.writeValueAsString(work));
      fstream.close();
      return filePath + File.separator + "work.json";
    }
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#writeConfigJson(com.mindtree.uxpulse.dto.SchedulerDto, java.lang.String)
   */
  @Override
  public String writeConfigJson(SchedulerDto scheduler, String username) throws IOException {
    Properties prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.APP_PROPERTIES);
    String filePath =
        prop.getProperty("app.userpath")
            + username
            + File.separator
            + scheduler.getRequestLabel()
            + File.separator
            + scheduler.getScheduleName();
    String logPath =
        prop.getProperty("app.logpath")
            + username
            + File.separator
            + scheduler.getRequestLabel()
            + File.separator
            + scheduler.getScheduleName();
    String harPath =
        prop.getProperty("app.harpath")
            + username
            + File.separator
            + scheduler.getRequestLabel()
            + File.separator
            + scheduler.getScheduleName();
    String chromeDriverPath = prop.getProperty("app.uxpulse_jar_path");
    ConfigDto config = new ConfigDto();

    prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.DB_CONFIG_PROPERTIES);
    config.setDbhost(prop.getProperty("db.host"));
    config.setDbport(prop.getProperty("db.port"));
    config.setDbname(prop.getProperty("db.database"));
    config.setDbuser(prop.getProperty("db.username"));
    config.setDbpass(prop.getProperty("db.password"));
    config.setTimeout("47000");
    config.setPingInterval("400");
    prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.APP_PROPERTIES);
    config.setApiKey(prop.getProperty("app.keys"));
    config.setUseProxy(
        prop.getProperty("app.useProxy")); // true, if mindtree network. false, if other network
    config.setProxyHost(prop.getProperty("app.proxyHost"));
    config.setProxyPort(prop.getProperty("app.proxyPort"));
    config.setNonProxyHosts(prop.getProperty("app.nonProxyHosts"));
    config.setLogpath(logPath);
    config.setHarpath(harPath);
    config.setChromeDriverPath(chromeDriverPath);
    ObjectMapper mapper = new ObjectMapper();
    try (FileWriter fstream = new FileWriter(filePath + File.separator + "config.json", true)) {
      fstream.write(mapper.writeValueAsString(config));
    }
    return filePath + File.separator + "config.json";
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#createSchedulerTask(com.mindtree.uxpulse.dto.SchedulerDto, java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public String createSchedulerTask(
      SchedulerDto scheduler, String workPath, String configPath, String username)
      throws ParseException, IOException {
    Properties prop =
        ReadPropertiesFile.readPropertiesFile(
            getClass().getClassLoader().getResource(".").getPath()
                + GlobalVariables.APP_PROPERTIES);
    String intervalCommand = "";
    String command = "";
    String taskrun =
        "java -jar "
            + prop.getProperty("app.uxpulse_jar_path")
            + "UxPulse.jar "
            + workPath
            + " "
            + configPath;

    switch (scheduler.getIntervalUnit()) {
      case "DAILY":
        intervalCommand = " /SC DAILY /MO " + scheduler.getInterval();
        break;

      case "HOURLY":
        intervalCommand =
            " /SC DAILY /MO 1 /DU 24:00 /RI " + (Integer.parseInt(scheduler.getInterval()) * 60);
        break;

      case "MINUTE":
        intervalCommand = " /SC DAILY /MO 1 /DU 24:00 /RI " + scheduler.getInterval();
        break;

      case "WEEKLY":
        intervalCommand = " /SC WEEKLY /MO " + scheduler.getInterval();
        break;
    }

    command =
        "schtasks /Create"
            + " /RU "
            + prop.getProperty("user.username")
            + " /RP "
            + prop.getProperty("user.password")
            + " /TN "
            + username
            + "-"
            + scheduler.getRequestLabel()
            + " /TR \""
            + taskrun
            + "\" /SD "
            + new SimpleDateFormat("MM/dd/yyyy").format(new Date(scheduler.getFrom()))
            + " /ST "
            + new SimpleDateFormat("HH:mm")
                .format(new Date(Calendar.getInstance().getTimeInMillis() + (60000)))
            + " /ED "
            + new SimpleDateFormat("MM/dd/yyyy").format(new Date(scheduler.getTo()))
            + " /F"
            + intervalCommand
            + "";

    System.out.println(command);
    return command;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#isRequestIdUsed(java.lang.String)
   */
  @Override
  public boolean isRequestIdUsed(String requestID) {
    boolean isRequestIdUsed = false;
    List<RequestUser> requestUsers = requestUserRepository.findByRequestID(requestID);
    if (requestUsers.size() != 0) {
      isRequestIdUsed = true;
    }
    return isRequestIdUsed;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#isScheduleNameUsed(java.lang.String, java.lang.String)
   */
  @Override
  public boolean isScheduleNameUsed(String requestID, String scheduleName) {
    boolean isScheduleNameUsed = false;
    List<RequestUser> requestUsers = requestUserRepository.findByRequestID(requestID);
    if (requestUsers.size() != 0) {
      for (RequestUser user : requestUsers) {
        String requestUserId = user.get_id();
        List<Schedule> schedules = scheduleRepository.findByRequestUserId(requestUserId);
        if (schedules.size() != 0) {
          for (Schedule sch : schedules) {
            if (sch.getScheduleName().equals(scheduleName)) {
              isScheduleNameUsed = true;
            }
          }
        }
      }
    }
    return isScheduleNameUsed;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.SchedulerService#getListofLocationAndUrlFromRequestID(java.lang.String)
   */
  @Override
  public SchedulerDto getListofLocationAndUrlFromRequestID(String requestID) {
    List<RunData> runDatas = runDataRepository.findByRequestID(requestID);
    HashSet<String> locations = new HashSet<>();
    HashSet<UrlLabelDto> urls = new HashSet<>();
    HashSet<String> listOfTaskID = new HashSet<>();
    for (RunData runData : runDatas) {
      listOfTaskID.add(runData.getTaskId());
    }
    List<Tasks> tasks = (List<Tasks>) taskRepository.findByTaskIdList(listOfTaskID);
    for (Tasks task : tasks) {
      locations.add(task.getLocation());
      UrlLabelDto obj = new UrlLabelDto();
      obj.setIsCustomer(task.getIsCustomer());
      obj.setLabel(task.getLabel());
      obj.setIsScript(task.getIsScript());
      obj.setUrlOrScript(task.getUrlOrScript());
      urls.add(obj);
    }
    SchedulerDto sch = new SchedulerDto();
    sch.setLocations(new ArrayList<String>(locations));
    sch.setUrlsLabel(new ArrayList<UrlLabelDto>(urls));
    sch.setFrom("");
    sch.setInterval("");
    sch.setIntervalUnit("");
    sch.setRequestLabel(requestID);
    sch.setScheduleName("");
    sch.setTo("");
    return sch;
  }
}
