package com.mindtree.uxpulse.dto;

public class EndUserReportData {}
