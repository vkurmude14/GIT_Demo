package com.mindtree.uxpulse.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.mindtree.uxpulse.entity.RequestUser;

/** @author M1049117 */
public interface RequestUserRepository extends MongoRepository<RequestUser, String> {

  /**
   * @param requestID
   * @return list of requestusers
   */
  @Query("{ 'requestID' : ?0 }")
  public List<RequestUser> findRequestUserByRequestID(String requestID);

  /**
   * @param userID
   * @return list of requestusers
   */
  @Query("{ 'userId' : ?0 }")
  public List<RequestUser> findRequestUserByUserID(String userID);
}
