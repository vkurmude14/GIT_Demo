package com.mindtree.uxpulse.controller;

import java.io.IOException;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.uxpulse.dto.SchedulerDto;
import com.mindtree.uxpulse.exception.TaskSchedulerException;
import com.mindtree.uxpulse.service.SchedulerService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/**
 * scheduler controller
 *
 * @author M1049117
 */
@CrossOrigin("*")
@RestController
public class SchedulerController {

  @Autowired private SchedulerService schedulerService;

  /**
   * Schedule test
   *
   * @param username
   * @param scheduler
   * @return ResponseEntity
   * @throws IOException
   * @throws ParseException
   * @throws TaskSchedulerException
   */
  @PostMapping(
      value = "schedule",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> scheduleTests(
      @RequestParam("username") String username, @RequestBody SchedulerDto scheduler)
      throws IOException, ParseException, TaskSchedulerException {

    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Scheduler",
            HttpStatus.OK.toString(),
            200,
            schedulerService.scheduleTest(scheduler, username),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * @param requestID
   * @return ResponseEntity
   */
  @GetMapping(
      value = "checkRequestID",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> isRequestIdUsed(
      @RequestParam("requestID") String requestID) {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "checkRequestID",
            HttpStatus.OK.toString(),
            200,
            schedulerService.isRequestIdUsed(requestID),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * @param requestID
   * @param scheduleName
   * @return ResponseEntity
   */
  @GetMapping(
      value = "checkScheduleName",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> isScheduleNameUsed(
      @RequestParam("requestID") String requestID,
      @RequestParam("scheduleName") String scheduleName) {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "isScheduleNameUsed",
            HttpStatus.OK.toString(),
            200,
            schedulerService.isScheduleNameUsed(requestID, scheduleName),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * @param requestID
   * @return ResponseEntity
   */
  @GetMapping(
      value = "getListofLocationAndUrlFromRequestID",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse>
      getListofLocationAndUrlFromRequestID(@RequestParam("requestID") String requestID) {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "isScheduleNameUsed",
            HttpStatus.OK.toString(),
            200,
            schedulerService.getListofLocationAndUrlFromRequestID(requestID),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
