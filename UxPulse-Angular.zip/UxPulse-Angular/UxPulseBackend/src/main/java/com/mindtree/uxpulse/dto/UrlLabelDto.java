package com.mindtree.uxpulse.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@RequiredArgsConstructor
@NoArgsConstructor
public class UrlLabelDto {
  @NonNull private String label;
  @NonNull private String urlOrScript;
  @NonNull private Boolean isScript;
  @NonNull private Boolean isCustomer;
}
