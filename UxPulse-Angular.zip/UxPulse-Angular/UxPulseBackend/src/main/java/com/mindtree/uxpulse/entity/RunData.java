package com.mindtree.uxpulse.entity;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.mindtree.uxpulse.dto.StatusDto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/** @author M1049117 */
@Data
@NoArgsConstructor
public class RunData {

  @JsonProperty("_id")
  private String _id;

  @NonNull private String requestID;
  @NonNull private String requestUserID;
  @NonNull private String scheduleID;
  @NonNull private StatusDto status;
  @NonNull private String taskId;
  @NonNull private String groupID;

  private String start;
  private String end;

  private Object data;
  private String testID;

  private String raw;
  private String har;
  private String recommondations;
  private Object memory;
  private String urlOrScript;
  List<String> errors = new ArrayList<String>();

  @JsonProperty("_rev")
  private String revision;

  public String[] getErrors() {
    return errors.toArray(new String[errors.size()]);
  }

  public void addError(String error) {
    this.errors.add(error);
  }
}
