package com.mindtree.uxpulse.serviceImpl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.AverageForLabelDto;
import com.mindtree.uxpulse.dto.EndUserReportDto;
import com.mindtree.uxpulse.dto.EndUserReportRaw;
import com.mindtree.uxpulse.dto.EndUserReportSummaryDto;
import com.mindtree.uxpulse.dto.ParameterWiseEndUserReportDto;
import com.mindtree.uxpulse.dto.StatusDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.repo.RequestUserRepo;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.repo.ScheduleRepo;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.EndUserReportService;
import com.mindtree.uxpulse.util.ExcelUtility;

/** @author M1049117 */
@Service
public class EndUserReportServiceImpl implements EndUserReportService {
  @Autowired private RunDataRepo runDataRepo;
  @Autowired private CouchDbConnector dbConnector;
  @Autowired private UsersRepo usersRepo;
  @Autowired private RequestUserRepo reqUserRepo;
  @Autowired private ScheduleRepo scheduleRepo;
  private ObjectMapper objectMapper = new ObjectMapper();

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.EndUserReportService#getRawDataForEndUserReport(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<EndUserReportRaw> getRawDataForEndUserReport(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException {

    Users userData = usersRepo.findByEmail(email).get(0);
    List<RequestUser> requestData =
        reqUserRepo.findByRequestIdAndUserId(requestLabel, userData.get_id());
    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");

    List<RunData> runDataTemp = new ArrayList<>();

    if (null != scheduleLabel) {
      List<Schedule> scheduleData = scheduleRepo.findByRequestUserId(requestData.get(0).get_id());
      if (scheduleData.size() == 0) {
        throw new NoSchedulesFoundException("No Schedules Found for this User");
      }
      runDataTemp =
          runDataRepo.findByRequestIdScheduleIdStatusTag(
              requestLabel, scheduleData.get(0).get_id(), StatusDto.RunStatus.COMPLETE.toString());
    } else {
      runDataTemp =
          runDataRepo.findByRequestIdStatusTag(
              requestLabel, StatusDto.RunStatus.COMPLETE.toString());
    }
    List<EndUserReportRaw> endUserReportRawList = new ArrayList<>();

    runDataTemp.forEach(
        rD -> {
          EndUserReportRaw rawTemp = new EndUserReportRaw();
          rawTemp.set_id(rD.get_id());

          rawTemp.setData(rD.getData());

          rawTemp.setRequestID(rD.getRequestID());
          rawTemp.setTaskId(rD.getTaskId());
          rawTemp.setGroupID(Long.parseLong(rD.getGroupID()));
          endUserReportRawList.add(rawTemp);
        });

    endUserReportRawList.forEach(
        record -> {
          Tasks taskData = dbConnector.find(Tasks.class, record.getTaskId());
          if (requestData.size() == 0)
            try {
              throw new NoTaskFoundException("No Tasks Found for this Taskid");
            } catch (NoTaskFoundException e) { // TODO Auto-generated catch block
              e.printStackTrace();
            }
          record.setTaskData(taskData);
        });

    return endUserReportRawList;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.EndUserReportService#getEndUserReportData(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public EndUserReportDto getEndUserReportData(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException,
          JsonMappingException, JsonProcessingException {

    // get raw data
    List<EndUserReportRaw> rawData = getRawDataForEndUserReport(scheduleLabel, requestLabel, email);
    // Initializing objects - start ------------------------------------------------

    // summary sheet average  for label
    AverageForLabelDto averageForLabelDto;
    // for Summary sheet
    EndUserReportSummaryDto summaryDto;
    // for locationwise sheet
    ParameterWiseEndUserReportDto locationWiseDto;
    // for browserwise sheet
    ParameterWiseEndUserReportDto browserWiseDto;
    // for networkwise sheet
    ParameterWiseEndUserReportDto networkWiseDto;
    double perceivedResponseTimeCached = 0D;
    double perceivedResponseTimeNonCached = 0D;

    // mainDto
    EndUserReportDto endUserReportDto = new EndUserReportDto();
    // initiate object mapper

    Map<String, Double> temp;
    Object jsonProvider = new Object();
    AverageForLabelDto totalForAvgDto;
    Long min = Long.MAX_VALUE;
    Long max = Long.MIN_VALUE;

    // Initializing objects - end ---------------------------------------------------

    // for each record in rawdata
    for (EndUserReportRaw record : rawData) {

      // TestProfile start------------------------------------------------

      // push location
      endUserReportDto.getLocations().add(record.getTaskData().getLocation().split(":")[0]);
      // push network
      endUserReportDto.getNetworks().add(record.getTaskData().getNetwork());
      // push browsers
      endUserReportDto.getBrowsers().add(record.getTaskData().getLocation().split(":")[1]);
      // push labels and urls
      endUserReportDto
          .getLabelsAndUrls()
          .put(record.getTaskData().getLabel(), record.getTaskData().getUrlOrScript());

      // TestProfile end--------------------------------------------------

      // Summary Data start ------------------------------------------------

      summaryDto = endUserReportDto.getSummaryDto();

      // preparing json provider for processing the data
      jsonProvider = objectMapper.readTree(objectMapper.writeValueAsString(record.getData()));

      averageForLabelDto =
          getAverageForLabelInViewType(jsonProvider, new AverageForLabelDto(), "firstView");
      perceivedResponseTimeNonCached = averageForLabelDto.getPerceivedResponseTimeInSec();
      totalForAvgDto = summaryDto.getNonCached().get(record.getTaskData().getLabel());
      if (null == totalForAvgDto)
        summaryDto.getNonCached().put(record.getTaskData().getLabel(), averageForLabelDto);
      else {
        totalForAvgDto = addParametersOfAvgForLabelDto(totalForAvgDto, averageForLabelDto);
        summaryDto.getNonCached().put(record.getTaskData().getLabel(), totalForAvgDto);
      }

      averageForLabelDto =
          getAverageForLabelInViewType(jsonProvider, averageForLabelDto, "repeatView");
      perceivedResponseTimeCached = averageForLabelDto.getPerceivedResponseTimeInSec();

      totalForAvgDto = summaryDto.getCached().get(record.getTaskData().getLabel());
      if (null == totalForAvgDto)
        summaryDto.getCached().put(record.getTaskData().getLabel(), averageForLabelDto);
      else {
        totalForAvgDto = addParametersOfAvgForLabelDto(totalForAvgDto, averageForLabelDto);
        summaryDto.getCached().put(record.getTaskData().getLabel(), totalForAvgDto);
      }

      // counting records
      if (null
          != endUserReportDto.getSummaryDto().getRecordCount().get(record.getTaskData().getLabel()))
        endUserReportDto
            .getSummaryDto()
            .getRecordCount()
            .put(
                record.getTaskData().getLabel(),
                endUserReportDto
                        .getSummaryDto()
                        .getRecordCount()
                        .get(record.getTaskData().getLabel())
                    + 1);
      else
        endUserReportDto.getSummaryDto().getRecordCount().put(record.getTaskData().getLabel(), 1);

      endUserReportDto.setSummaryDto(summaryDto);

      // Summary Data end --------------------------------------------------

      // locationWise data start ------------------------------------------------
      // non cached
      locationWiseDto = endUserReportDto.getLocationWisePerformance();
      temp = locationWiseDto.getNonCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getLocation().split(":")[0]))
          temp.put(
              record.getTaskData().getLocation().split(":")[0], perceivedResponseTimeNonCached);
        else
          temp.put(
              record.getTaskData().getLocation().split(":")[0],
              temp.get(record.getTaskData().getLocation().split(":")[0])
                  + perceivedResponseTimeNonCached);
      else {
        temp = new HashMap<String, Double>();
        temp.put(record.getTaskData().getLocation().split(":")[0], perceivedResponseTimeNonCached);
      }
      locationWiseDto.getNonCached().put(record.getTaskData().getLabel(), temp);

      // cached
      locationWiseDto = endUserReportDto.getLocationWisePerformance();
      temp = locationWiseDto.getCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getLocation().split(":")[0]))
          temp.put(record.getTaskData().getLocation().split(":")[0], perceivedResponseTimeCached);
        else
          temp.put(
              record.getTaskData().getLocation().split(":")[0],
              temp.get(record.getTaskData().getLocation().split(":")[0])
                  + perceivedResponseTimeCached);
      else {
        temp = new HashMap<String, Double>();
        temp.put(record.getTaskData().getLocation().split(":")[0], perceivedResponseTimeNonCached);
      }
      locationWiseDto.getCached().put(record.getTaskData().getLabel(), temp);

      // counting records
      if (null
          != endUserReportDto
              .getSummaryDto()
              .getRecordCount()
              .get(record.getTaskData().getLocation().split(":")[0]))
        endUserReportDto
            .getLocationWisePerformance()
            .getRecordCount()
            .put(
                record.getTaskData().getLocation().split(":")[0],
                endUserReportDto
                        .getSummaryDto()
                        .getRecordCount()
                        .get(record.getTaskData().getLocation().split(":")[0])
                    + 1);
      else
        endUserReportDto
            .getLocationWisePerformance()
            .getRecordCount()
            .put(record.getTaskData().getLocation().split(":")[0], 1);

      endUserReportDto.setLocationWisePerformance(locationWiseDto);

      // locationWise data end --------------------------------------------------

      // browserWise data start ------------------------------------------------
      // non cached
      browserWiseDto = endUserReportDto.getBrowserWisePerformance();
      temp = browserWiseDto.getNonCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getLocation().split(":")[1]))
          temp.put(
              record.getTaskData().getLocation().split(":")[1], perceivedResponseTimeNonCached);
        else
          temp.put(
              record.getTaskData().getLocation().split(":")[1],
              temp.get(record.getTaskData().getLocation().split(":")[1])
                  + perceivedResponseTimeNonCached);
      else {
        temp = new HashMap<String, Double>();
        temp.put(record.getTaskData().getLocation().split(":")[1], perceivedResponseTimeNonCached);
      }
      browserWiseDto.getNonCached().put(record.getTaskData().getLabel(), temp);

      // cached
      browserWiseDto = endUserReportDto.getBrowserWisePerformance();
      temp = browserWiseDto.getCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getLocation().split(":")[1]))
          temp.put(record.getTaskData().getLocation().split(":")[1], perceivedResponseTimeCached);
        else
          temp.put(
              record.getTaskData().getLocation().split(":")[1],
              temp.get(record.getTaskData().getLocation().split(":")[1])
                  + perceivedResponseTimeCached);
      else {
        temp = new HashMap<String, Double>();
        temp.put(record.getTaskData().getLocation().split(":")[1], perceivedResponseTimeNonCached);
      }
      browserWiseDto.getCached().put(record.getTaskData().getLabel(), temp);

      // counting records
      if (null
          != endUserReportDto
              .getSummaryDto()
              .getRecordCount()
              .get(record.getTaskData().getLocation().split(":")[1]))
        endUserReportDto
            .getBrowserWisePerformance()
            .getRecordCount()
            .put(
                record.getTaskData().getLocation().split(":")[1],
                endUserReportDto
                        .getSummaryDto()
                        .getRecordCount()
                        .get(record.getTaskData().getLocation().split(":")[1])
                    + 1);
      else
        endUserReportDto
            .getBrowserWisePerformance()
            .getRecordCount()
            .put(record.getTaskData().getLocation().split(":")[1], 1);

      endUserReportDto.setBrowserWisePerformance(browserWiseDto);
      // browserWise data end --------------------------------------------------

      // networkWise data start ------------------------------------------------
      // non cached
      networkWiseDto = endUserReportDto.getNetworkWisePerformance();
      temp = networkWiseDto.getNonCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getNetwork()))
          temp.put(record.getTaskData().getNetwork(), perceivedResponseTimeNonCached);
        else
          temp.put(
              record.getTaskData().getNetwork(),
              temp.get(record.getTaskData().getNetwork()) + perceivedResponseTimeNonCached);
      else {
        temp = new HashMap<>();
        temp.put(record.getTaskData().getNetwork(), perceivedResponseTimeNonCached);
      }
      networkWiseDto.getNonCached().put(record.getTaskData().getLabel(), temp);

      // cached
      networkWiseDto = endUserReportDto.getNetworkWisePerformance();
      temp = networkWiseDto.getCached().get(record.getTaskData().getLabel());
      if (null != temp)
        if (null == temp.get(record.getTaskData().getNetwork()))
          temp.put(record.getTaskData().getNetwork(), perceivedResponseTimeCached);
        else
          temp.put(
              record.getTaskData().getNetwork(),
              temp.get(record.getTaskData().getNetwork()) + perceivedResponseTimeCached);
      else {
        temp = new HashMap<>();
        temp.put(record.getTaskData().getNetwork(), perceivedResponseTimeNonCached);
      }
      networkWiseDto.getCached().put(record.getTaskData().getLabel(), temp);

      // counting records
      if (null
          != endUserReportDto
              .getSummaryDto()
              .getRecordCount()
              .get(record.getTaskData().getNetwork()))
        endUserReportDto
            .getNetworkWisePerformance()
            .getRecordCount()
            .put(
                record.getTaskData().getNetwork(),
                endUserReportDto
                        .getSummaryDto()
                        .getRecordCount()
                        .get(record.getTaskData().getNetwork())
                    + 1);
      else
        endUserReportDto
            .getNetworkWisePerformance()
            .getRecordCount()
            .put(record.getTaskData().getNetwork(), 1);

      endUserReportDto.setNetworkWisePerformance(networkWiseDto);
      // networkWise data end --------------------------------------------------

      // start and end timestamp start --------------------------------------------------
      if (record.getGroupID() > max) max = record.getGroupID();
      if (record.getGroupID() < min) min = record.getGroupID();

      endUserReportDto.setStart(min);
      endUserReportDto.setEnd(max);

      // start and end timestamp end --------------------------------------------------

    }

    return endUserReportDto;
  }

  /**
   * @param totalForAvgDto
   * @param givenAvgDto
   * @return
   */
  private AverageForLabelDto addParametersOfAvgForLabelDto(
      AverageForLabelDto totalForAvgDto, AverageForLabelDto givenAvgDto) {
    totalForAvgDto.setActualResponseTimeInSec(
        totalForAvgDto.getActualResponseTimeInSec() + givenAvgDto.getActualResponseTimeInSec());
    totalForAvgDto.setFirstResponseTimeInSec(
        totalForAvgDto.getFirstResponseTimeInSec() + givenAvgDto.getFirstResponseTimeInSec());
    totalForAvgDto.setFirstResponseTimeInSec(
        totalForAvgDto.getFirstResponseTimeInSec() + givenAvgDto.getFirstResponseTimeInSec());
    totalForAvgDto.setPageSizeInKb(
        totalForAvgDto.getPageSizeInKb() + givenAvgDto.getPageSizeInKb());
    totalForAvgDto.setPerceivedResponseTimeInSec(
        totalForAvgDto.getPerceivedResponseTimeInSec()
            + givenAvgDto.getPerceivedResponseTimeInSec());
    totalForAvgDto.setRequests(totalForAvgDto.getRequests() + givenAvgDto.getRequests());
    totalForAvgDto.setTimeToFirstByte(
        totalForAvgDto.getTimeToFirstByte() + givenAvgDto.getTimeToFirstByte());
    totalForAvgDto.setVisuallyComplete(
        totalForAvgDto.getVisuallyComplete() + givenAvgDto.getVisuallyComplete());
    return totalForAvgDto;
  }

  private AverageForLabelDto getAverageForLabelInViewType(
      Object jsonProvider, AverageForLabelDto averageForLabelDto, String viewType) {
    if (((JsonNode) jsonProvider).has(viewType)) {
      averageForLabelDto = new AverageForLabelDto();
      averageForLabelDto.setTimeToFirstByte(
          ((JsonNode) jsonProvider).get(viewType).get("TTFB").asLong() / 1000);

      averageForLabelDto.setActualResponseTimeInSec(
          ((JsonNode) jsonProvider).get(viewType).get("fullyLoaded").asLong() / 1000);
      averageForLabelDto.setFirstResponseTimeInSec(
          ((JsonNode) jsonProvider).get(viewType).get("render").asLong() / 1000);
      averageForLabelDto.setVisuallyComplete(
          ((JsonNode) jsonProvider).get(viewType).get("visualComplete").asLong() / 1000);

      averageForLabelDto.setPerceivedResponseTimeInSec(
          ((JsonNode) jsonProvider).get(viewType).get("docTime").asLong() / 1000);
      if (null != ((JsonNode) jsonProvider).get(viewType).get("requestsDoc")) {

        averageForLabelDto.setRequests(
            ((JsonNode) jsonProvider).get(viewType).get("requestsDoc").asLong());
      }
      if (null != ((JsonNode) jsonProvider).get(viewType).get("bytesIn"))
        averageForLabelDto.setPageSizeInKb(
            ((JsonNode) jsonProvider).get(viewType).get("bytesIn").asLong() / 1024);
    }
    return averageForLabelDto;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.EndUserReportService#getEndUserReport(java.lang.String, java.lang.String, javax.servlet.http.HttpServletResponse, java.lang.String)
   */
  @Override
  public ByteArrayInputStream getEndUserReport(
      String scheduleLabel, String requestLabel, HttpServletResponse response, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException, IOException,
          InvalidFormatException {

    ExcelUtility excelUtility = new ExcelUtility();
    EndUserReportDto data = getEndUserReportData(scheduleLabel, requestLabel, email);
    return excelUtility.manipulateWorkBookWithActualData(
        requestLabel, scheduleLabel, data, response);
  }
}
