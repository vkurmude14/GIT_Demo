package com.mindtree.uxpulse.dto;

import lombok.Data;

/** @author M1049117 */
@Data
public class DashboardData {
  private int index;
  private String groupId;
  private String location;
  private String browser;
  private String network;
  private long date;
  private String latency;
  private String label;
  private String urlOrScript;
  private String testID;
  private MetricsDto metrics;
  private Boolean isCustomer;
  private ComponentsDto components;
}
