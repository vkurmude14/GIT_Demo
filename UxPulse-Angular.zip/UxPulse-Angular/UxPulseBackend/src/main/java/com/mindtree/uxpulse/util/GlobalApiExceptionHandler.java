package com.mindtree.uxpulse.util;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.uxpulse.exception.InvalidCredentialsException;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoRunDataFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.TaskSchedulerException;
import com.mindtree.uxpulse.exception.UserAlreadyPresentException;
import com.mindtree.uxpulse.exception.UserNotFoundException;

@RestControllerAdvice
public class GlobalApiExceptionHandler {

  @ExceptionHandler(value = UserAlreadyPresentException.class)
  @ResponseStatus(value = HttpStatus.CONFLICT)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      UserAlreadyPresentException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("USER ALREADY PRESENT", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.CONFLICT.toString());
    error.setHttpStatusCode(409);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {IOException.class})
  @ResponseStatus(value = HttpStatus.BAD_REQUEST)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(IOException e) {
    CustomApiErrorResponse error = new CustomApiErrorResponse("BAD REQUEST", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.BAD_REQUEST.toString());
    error.setHttpStatusCode(400);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {NullPointerException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      NullPointerException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {UserNotFoundException.class})
  @ResponseStatus(value = HttpStatus.NOT_FOUND)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      UserNotFoundException e) {
    CustomApiErrorResponse error = new CustomApiErrorResponse("NOT FOUND", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.NOT_FOUND.toString());
    error.setHttpStatusCode(404);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {InvalidCredentialsException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      InvalidCredentialsException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {TaskSchedulerException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      TaskSchedulerException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {NoRequestsFoundException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      NoRequestsFoundException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {NoSchedulesFoundException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      NoSchedulesFoundException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }

  @ExceptionHandler(value = {NoRunDataFoundException.class})
  @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
  public ResponseEntity<CustomApiErrorResponse> handleGenericNotFoundException(
      NoRunDataFoundException e) {
    CustomApiErrorResponse error =
        new CustomApiErrorResponse("INTERNAL SERVER ERROR", e.getMessage());
    error.setCause(e.getCause());
    error.setError(true);
    error.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
    error.setHttpStatusCode(500);
    error.setMessage(e.getMessage());
    error.setSuccess(false);
    return ResponseEntity.status(HttpStatus.OK).body(error);
  }
}
