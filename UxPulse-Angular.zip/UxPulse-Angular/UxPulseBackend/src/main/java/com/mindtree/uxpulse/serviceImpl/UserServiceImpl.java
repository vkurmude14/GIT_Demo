package com.mindtree.uxpulse.serviceImpl;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.uxpulse.dto.LoginDto;
import com.mindtree.uxpulse.dto.LoginResponseDto;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.InvalidCredentialsException;
import com.mindtree.uxpulse.exception.UserAlreadyPresentException;
import com.mindtree.uxpulse.exception.UserNotFoundException;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.UserService;
import com.mindtree.uxpulse.util.PasswordEncoderDecoder;

/** @author M1049117 */
@Service
public class UserServiceImpl implements UserService {

  @Autowired private UsersRepo userRepository;
  @Autowired CouchDbConnector dbConnector;

  @Autowired private PasswordEncoderDecoder passwordDecoder;

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.UserService#createUser(com.mindtree.uxpulse.entity.Users)
   */
  @Override
  public String createUser(Users user) throws UserAlreadyPresentException, IOException {
    String str = null;
    if (user.getUsername().equals("")
        || user.getUsername() == null
        || user.getEmail().equals("")
        || user.getEmail() == null
        || user.getPassword().equals("")
        || user.getPassword() == null) {
      throw new NullPointerException("Please Enter UserName,Email and Password");
    } else {
      List<Users> users = userRepository.findByEmail(user.getEmail().trim());
      if (users.size() == 0) {
        Users newUser = new Users(user.getUsername(), user.getEmail().trim(), user.getPassword());
        newUser.setTime((new Date()).getTime());
        newUser.setKeys(user.getKeys());
        dbConnector.create(newUser);
        str = "User is registered Successfully";
      } else {
        throw new UserAlreadyPresentException("User is already present in with given EmailID");
      }
    }
    return str;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.UserService#isUserNameAvailable(java.lang.String)
   */
  @Override
  public boolean isUserNameAvailable(String username) {
    boolean isUserNameAvailable = true;
    List<Users> users = userRepository.findByUsername(username);
    if (users.size() != 0) {
      isUserNameAvailable = false;
    }
    return isUserNameAvailable;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.UserService#login(com.mindtree.uxpulse.dto.LoginDto)
   */
  @Override
  public LoginResponseDto login(LoginDto login)
      throws UserNotFoundException, InvalidCredentialsException {
    if (login.getEmail().equals("")
        || login.getEmail() == null
        || login.getPassword().equals("")
        || login.getPassword() == null) {
      throw new NullPointerException("Please Enter Email and Password");
    }
    List<Users> user = userRepository.findByEmail(login.getEmail().trim());
    LoginResponseDto response;

    if (user.size() != 0) {
      if (user.get(0).getEmail().equals(login.getEmail().trim())
          && passwordDecoder
              .decodePassword(user.get(0).getPassword())
              .equals(passwordDecoder.decodePassword(login.getPassword()))) {

        response =
            new LoginResponseDto(
                true,
                user.get(0).getUsername(),
                user.get(0).getEmail(),
                "User Succesfully Logged In");
      } else {
        response = new LoginResponseDto(false, "", "", "User Credentials Not valid");
        throw new InvalidCredentialsException(response.getMessage());
      }
    } else {
      throw new UserNotFoundException("User is not registered with UxPulse");
    }
    return response;
  }
}
