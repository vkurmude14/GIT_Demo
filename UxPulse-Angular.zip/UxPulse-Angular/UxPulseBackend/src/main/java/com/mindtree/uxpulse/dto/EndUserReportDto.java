package com.mindtree.uxpulse.dto;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import lombok.Data;

/** @author M1049117 */
@Data
public class EndUserReportDto {

  // test Profile sheet
  private Map<String, String> labelsAndUrls;
  private Set<String> locations;
  private Set<String> browsers;
  private Set<String> networks;
  private Long start;
  private Long end;

  public EndUserReportDto() {

    this.labelsAndUrls = new HashMap<String, String>();
    this.locations = new HashSet<>();
    this.browsers = new HashSet<>();
    this.networks = new HashSet<>();
    this.summaryDto = new EndUserReportSummaryDto();
    this.locationWisePerformance = new ParameterWiseEndUserReportDto();
    this.browserWisePerformance = new ParameterWiseEndUserReportDto();
    this.networkWisePerformance = new ParameterWiseEndUserReportDto();
  }

  // summary sheet
  private EndUserReportSummaryDto summaryDto;

  // LocationWise Perf
  private ParameterWiseEndUserReportDto locationWisePerformance;

  // BrowserWise Perf
  private ParameterWiseEndUserReportDto browserWisePerformance;

  // NetworkWisePerformance
  private ParameterWiseEndUserReportDto networkWisePerformance;
}
