package com.mindtree.uxpulse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mindtree.uxpulse.dto.AnalysisData;
import com.mindtree.uxpulse.dto.AnalysisRaw;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;

@Service
public interface AnalysisService {
  /**
   * get the raw data for analysis page
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param label
   * @param email
   * @return list of analysis raw
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoTaskFoundException
   */
  public List<AnalysisRaw> getRawDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException;

  /**
   * get data for analysis
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param label
   * @param email
   * @return analysis data
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundExceptionS
   * @throws NoTaskFoundException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   */
  public AnalysisData getDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException,
          JsonMappingException, JsonProcessingException;
}
