package com.mindtree.uxpulse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mindtree.uxpulse.dto.UrlLabelDto;
import com.mindtree.uxpulse.exception.ConnectivityException;

@Service
public interface RecommendationReportService {

  /**
   * @param url
   * @return recommendations json
   * @throws ConnectivityException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   */
  public JsonNode getRecommendationsFromGooglePageSpeed(String url)
      throws ConnectivityException, JsonMappingException, JsonProcessingException;

  /**
   * @param requestLabel
   * @return list urllabel
   */
  public List<UrlLabelDto> getListOfLabels(String requestLabel);
}
