package com.mindtree.uxpulse.dto;

import com.mindtree.uxpulse.entity.Tasks;

import lombok.Data;

/** @author M1049117 */
@Data
public class EndUserReportRaw {
  private String _id;
  private String requestID;
  private Object data;
  private String taskId;
  private Tasks taskData;
  private Long groupID;
}
