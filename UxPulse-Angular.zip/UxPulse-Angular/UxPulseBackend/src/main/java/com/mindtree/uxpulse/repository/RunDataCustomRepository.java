package com.mindtree.uxpulse.repository;

import java.util.List;

import com.mindtree.uxpulse.dto.AnalysisRaw;
import com.mindtree.uxpulse.dto.DashboardRaw;
import com.mindtree.uxpulse.dto.EndUserReportRaw;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;

/** @author M1049117 */
public interface RunDataCustomRepository {

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return list of dashboard raw
   * @throws NoRequestsFoundException
   * @throws NoSchedulesFoundException
   * @throws NoTaskFoundException
   */
  public List<DashboardRaw> getRawDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException;

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param label
   * @param email
   * @return list of analysis raw
   * @throws NoRequestsFoundException
   * @throws NoSchedulesFoundException
   * @throws NoTaskFoundException
   */
  public List<AnalysisRaw> getRawDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException;

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return list of enduserreport raw
   * @throws NoRequestsFoundException
   * @throws NoSchedulesFoundException
   * @throws NoTaskFoundException
   */
  List<EndUserReportRaw> getRawDataForEndUserReport(
      String scheduleLabel, String requestLabel, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException;
}
