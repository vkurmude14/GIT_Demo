package com.mindtree.uxpulse.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/** @author M1049117 */
@Data
@NoArgsConstructor
public class StatusDto {

  private RunStatus tag;
  private String message;

  /** @author M1049117 */
  public static enum RunStatus {
    CREATED,
    FAILED,
    COMPLETE,
    RUNNING,
    CANCELLED,
    EXECUTED,
    WAITING,
    FETCHINGDATA,
    FETCHINGHAR,
    PROCESSING,
    FETCHINGRAW;
  }
}
