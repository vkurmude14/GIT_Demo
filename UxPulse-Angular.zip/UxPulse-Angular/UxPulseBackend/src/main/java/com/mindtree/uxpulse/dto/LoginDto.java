package com.mindtree.uxpulse.dto;

import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/** @author M1049117 */
@Data
@RequiredArgsConstructor
public class LoginDto {
  @NonNull private String email;
  @NonNull private String password;
}
