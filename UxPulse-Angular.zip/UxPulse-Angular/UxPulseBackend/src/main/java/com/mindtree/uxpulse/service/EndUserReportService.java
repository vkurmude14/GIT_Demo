package com.mindtree.uxpulse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mindtree.uxpulse.dto.EndUserReportRaw;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;

@Service
public interface EndUserReportService {

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return list of enduserreportraw
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoTaskFoundException
   */
  public List<EndUserReportRaw> getRawDataForEndUserReport(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException;

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return Object
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoTaskFoundException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   */
  public Object getEndUserReportData(String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException,
          JsonMappingException, JsonProcessingException;

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param response
   * @param email
   * @return ByteArrayInputStream
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoTaskFoundException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   * @throws IOException
   * @throws InvalidFormatException
   */
  public ByteArrayInputStream getEndUserReport(
      String scheduleLabel, String requestLabel, HttpServletResponse response, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException,
          JsonMappingException, JsonProcessingException, IOException, InvalidFormatException;
}
