package com.mindtree.uxpulse.dto;

import lombok.Data;

/** @author M1049117 */
@Data
public class AverageForLabelDto {
  // TTFB
  private double timeToFirstByte;
  // render
  private double firstResponseTimeInSec;
  // docTime
  private double perceivedResponseTimeInSec;
  // FullyLoaded
  private double actualResponseTimeInSec;
  // bytesIn
  private double pageSizeInKb;
  // requestsDoc
  private double requests;
  // visualComplete
  private double visuallyComplete;

  public AverageForLabelDto() {
    this.timeToFirstByte = 0D;
    this.firstResponseTimeInSec = 0D;
    this.perceivedResponseTimeInSec = 0D;
    this.actualResponseTimeInSec = 0D;
    this.pageSizeInKb = 0D;
    this.requests = 0D;
    this.visuallyComplete = 0D;
  }
}
