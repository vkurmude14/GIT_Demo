package com.mindtree.uxpulse.dto;

import lombok.Data;

/** @author M1049117 */
@Data
public class FirstViewDto {
  private Long fullyLoaded;
  private Long startRender;
  private Long docComplete;
  private Long requests;
  private Long bytesIn;
  private String rtt;
  private String ttfb;
  private String domains;
  private String breakdown;
}
