package com.mindtree.uxpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** @author M1049117 */
@SpringBootApplication
public class UxPulseApplication extends ServletInitializer {

  /** @param args */
  public static void main(String[] args) {
    System.setProperty("java.net.useSystemProxies", "true");
    System.getProperties().put("http.proxyHost", "172.22.218.218");
    System.getProperties().put("http.proxyPort", "8085");
    System.getProperties().put("https.proxyHost", "172.22.218.218");
    System.getProperties().put("https.proxyPort", "8085");

    SpringApplication.run(UxPulseApplication.class, args);
  }
}
