package com.mindtree.uxpulse.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.LocationListDto;
import com.mindtree.uxpulse.exception.ConnectivityException;
import com.mindtree.uxpulse.service.LocationService;
import com.mindtree.uxpulse.util.GlobalVariables;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/** @author M1049117 */
@Service
public class LocationServiceImpl implements LocationService {

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.LocationService#parseLocations()
   */
  @Override
  public List<LocationListDto> parseLocations()
      throws JsonMappingException, JsonProcessingException, ConnectivityException,
          NullPointerException {
    ClientResponse resp = null;
    try {
      System.setProperty("java.net.useSystemProxies", "true");
      Client restClient = Client.create();
      WebResource webResource =
          restClient.resource(GlobalVariables.WPT_SERVER + "/getLocations.php?f=json");
      resp = webResource.accept("application/json").get(ClientResponse.class);
    } catch (Exception e) {
      try {
        System.setProperty("http.proxyHost", GlobalVariables.proxyHost);
        System.setProperty("http.proxyPort", GlobalVariables.proxyPort);
        Client restClient = Client.create();
        WebResource webResource =
            restClient.resource(GlobalVariables.WPT_SERVER + "/getLocations.php?f=json");
        resp = webResource.accept("application/json").get(ClientResponse.class);
      } catch (Exception ex) {

        ex.printStackTrace();
      }
    }
    if (resp.getStatus() != 200) {
      throw new ConnectivityException("Please Check your Internet Connection");
    }
    String output = resp.getEntity(String.class);
    ObjectMapper objectMapper = new ObjectMapper();
    JsonNode jsonNode = objectMapper.readTree(output);

    Map<String, Map<String, Map<String, Integer>>> map =
        objectMapper.readValue(jsonNode.get("data").toString(), Map.class);
    List<LocationListDto> hasMap = new ArrayList<>();
    int i = 1;
    for (Entry<String, Map<String, Map<String, Integer>>> map1 : map.entrySet()) {

      Map<String, Map<String, Integer>> map2 = map1.getValue();

      String[] browsers = (map2.get("Browsers") + "").split(",");
      for (String browser : browsers) {
        LocationListDto obj = new LocationListDto();
        obj.setId(i);
        obj.setLabel(map2.get("labelShort") + " " + browser);
        obj.setItemName(obj.getLabel());
        obj.setLocation(map2.get("location") + "");
        obj.setBrowser(browser);
        obj.setServer(GlobalVariables.WPT_SERVER);
        obj.setName(map1.getKey() + ":" + browser);
        Map<String, Integer> set = null;
        for (Entry<String, Map<String, Integer>> mp2 : map1.getValue().entrySet()) {
          if (mp2.getKey().equals("PendingTests")) {
            set = mp2.getValue();
          }
        }
        if (set != null) {
          obj.setTotal(set.get("Total"));
          obj.setTesting(set.get("Testing"));
          obj.setIdle(set.get("Idle"));
          obj.setGroup(map2.get("group") + "");
          hasMap.add(obj);
          i++;
        }
      }
    }
    return hasMap;
  }
}
