package com.mindtree.uxpulse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.uxpulse.dto.DeleteRunDataDto;
import com.mindtree.uxpulse.dto.HomePageGroupDataDto;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoRunDataFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.UserNotFoundException;

@Service
public interface HomeService {

  /**
   * @param email
   * @return list of requests
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   */
  public List<String> getListOfRequests(String email)
      throws UserNotFoundException, NoRequestsFoundException;

  /**
   * @param email
   * @param requestID
   * @return list of schedules
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   * @throws NoSchedulesFoundException
   */
  public List<String> getListOfSchedules(String email, String requestID)
      throws UserNotFoundException, NoRequestsFoundException, NoSchedulesFoundException;

  /**
   * @param email
   * @param requestID
   * @param scheduleName
   * @return list of homepage group
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   * @throws NoSchedulesFoundException
   * @throws NoRunDataFoundException
   */
  public List<HomePageGroupDataDto> getListOfRequestsByUser(
      String email, String requestID, String scheduleName)
      throws UserNotFoundException, NoRequestsFoundException, NoSchedulesFoundException,
          NoRunDataFoundException;

  /**
   * @param deleteRunData
   * @return list of homepage group
   * @throws UserNotFoundException
   * @throws NoSchedulesFoundException
   * @throws NoRunDataFoundException
   * @throws NoRequestsFoundException
   */
  public List<HomePageGroupDataDto> deleteRunData(DeleteRunDataDto deleteRunData)
      throws UserNotFoundException, NoSchedulesFoundException, NoRunDataFoundException,
          NoRequestsFoundException;
}
