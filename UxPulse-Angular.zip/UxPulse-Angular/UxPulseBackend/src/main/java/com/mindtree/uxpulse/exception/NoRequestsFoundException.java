package com.mindtree.uxpulse.exception;

/** @author M1049117 */
public class NoRequestsFoundException extends Exception {

  /** */
  private static final long serialVersionUID = 1L;

  public NoRequestsFoundException() {}

  public NoRequestsFoundException(String message) {
    super(message);
  }

  public NoRequestsFoundException(Throwable cause) {
    super(cause);
  }

  public NoRequestsFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public NoRequestsFoundException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
