package com.mindtree.uxpulse.service;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mindtree.uxpulse.dto.LocationListDto;
import com.mindtree.uxpulse.exception.ConnectivityException;

@Service
public interface LocationService {

  /**
   * @return list of locations
   * @throws JsonMappingException
   * @throws JsonProcessingException
   * @throws ConnectivityException
   * @throws NullPointerException
   * @throws NoSuchAlgorithmException
   * @throws KeyManagementException
   */
  public List<LocationListDto> parseLocations()
      throws JsonMappingException, JsonProcessingException, ConnectivityException,
          NullPointerException, NoSuchAlgorithmException, KeyManagementException;
}
