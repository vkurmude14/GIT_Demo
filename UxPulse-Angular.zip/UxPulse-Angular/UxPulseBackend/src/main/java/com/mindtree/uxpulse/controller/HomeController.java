package com.mindtree.uxpulse.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.uxpulse.dto.DeleteRunDataDto;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoRunDataFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.UserNotFoundException;
import com.mindtree.uxpulse.service.HomeService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/**
 * All homepage controllers are placed here
 *
 * @author M1049117
 */
@CrossOrigin("*")
@RestController
public class HomeController {

  @Autowired private HomeService homeService;

  /**
   * get all the requests for given email
   *
   * @param email
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   */
  @GetMapping(
      value = "getRequests",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getRequests(
      @RequestParam("email") String email) throws UserNotFoundException, NoRequestsFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Requests",
            HttpStatus.OK.toString(),
            200,
            homeService.getListOfRequests(email),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * get all the schedules for given requestid and email
   *
   * @param email
   * @param requestID
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   */
  @GetMapping(
      value = "getSchedules",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getSchedules(
      @RequestParam("email") String email, @RequestParam("requestID") String requestID)
      throws UserNotFoundException, NoSchedulesFoundException, NoRequestsFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Schedules",
            HttpStatus.OK.toString(),
            200,
            homeService.getListOfSchedules(email, requestID),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * get the run data for given reqId and scheduleId
   *
   * @param email
   * @param requestID
   * @param scheduleName
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoRunDataFoundException
   */
  @GetMapping(
      value = "getRunData",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getRunData(
      @RequestParam("email") String email,
      @RequestParam("requestID") String requestID,
      @RequestParam("scheduleName") String scheduleName)
      throws UserNotFoundException, NoSchedulesFoundException, NoRequestsFoundException,
          NoRunDataFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "RunData",
            HttpStatus.OK.toString(),
            200,
            homeService.getListOfRequestsByUser(email, requestID, scheduleName),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * delete run data
   *
   * @param deleteRunData
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoRunDataFoundException
   */
  @PostMapping(
      value = "deleteRunData",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> deleteRunData(
      @RequestBody DeleteRunDataDto deleteRunData)
      throws UserNotFoundException, NoSchedulesFoundException, NoRequestsFoundException,
          NoRunDataFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Requests Deleted Successfully",
            HttpStatus.OK.toString(),
            200,
            homeService.deleteRunData(deleteRunData),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
