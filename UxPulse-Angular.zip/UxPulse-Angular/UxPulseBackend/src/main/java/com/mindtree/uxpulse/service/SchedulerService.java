package com.mindtree.uxpulse.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.uxpulse.dto.SchedulerDto;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.exception.TaskSchedulerException;

@Service
public interface SchedulerService {

  /**
   * @param scheduler
   * @param email
   * @return string
   * @throws IOException
   * @throws ParseException
   * @throws TaskSchedulerException
   */
  public String scheduleTest(SchedulerDto scheduler, String email)
      throws IOException, ParseException, TaskSchedulerException;

  /**
   * @param scheduler
   * @param email
   * @param tasks
   * @return string
   * @throws IOException
   */
  public String writeWorkJsonFile(SchedulerDto scheduler, String email, List<Tasks> tasks)
      throws IOException;

  /**
   * @param scheduler
   * @param email
   * @return string
   * @throws IOException
   */
  public String writeConfigJson(SchedulerDto scheduler, String email) throws IOException;

  /**
   * @param scheduler
   * @param workPath
   * @param configPath
   * @param email
   * @return
   * @throws ParseException
   * @throws IOException
   */
  public String createSchedulerTask(
      SchedulerDto scheduler, String workPath, String configPath, String email)
      throws ParseException, IOException;

  /**
   * @param requestID
   * @return boolean
   */
  public boolean isRequestIdUsed(String requestID);

  /**
   * @param requestID
   * @param scheduleName
   * @return boolean
   */
  public boolean isScheduleNameUsed(String requestID, String scheduleName);

  /**
   * @param requestID
   * @return scheduler dto
   */
  public SchedulerDto getListofLocationAndUrlFromRequestID(String requestID);
}
