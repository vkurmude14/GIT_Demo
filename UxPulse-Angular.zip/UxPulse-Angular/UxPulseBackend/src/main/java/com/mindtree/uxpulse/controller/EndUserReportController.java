package com.mindtree.uxpulse.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.service.EndUserReportService;

@CrossOrigin("*")
@RestController
public class EndUserReportController {

  @Autowired private EndUserReportService endUserReportService;

  /**
   * get the end user report
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param username
   * @param email
   * @param response
   * @return ResponseEntity
   * @throws NoSchedulesFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws NoRequestsFoundException
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws NoTaskFoundException
   * @throws IOException
   * @throws InvalidFormatException
   */
  @GetMapping(value = "getEndUserReport")
  public @ResponseBody ResponseEntity<InputStreamResource> getEndUserReport(
      @RequestParam String scheduleLabel,
      @RequestParam String requestLabel,
      @RequestParam String username,
      @RequestParam String email,
      HttpServletResponse response)
      throws NoSchedulesFoundException, NoSuchFieldException, SecurityException,
          NoRequestsFoundException, IllegalArgumentException, IllegalAccessException,
          NoTaskFoundException, IOException, InvalidFormatException {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
    try {
      ByteArrayInputStream in =
          endUserReportService.getEndUserReport(scheduleLabel, requestLabel, response, email);
      return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}
