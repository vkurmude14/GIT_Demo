package com.mindtree.uxpulse.serviceImpl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.uxpulse.dto.AnalysisData;
import com.mindtree.uxpulse.dto.AnalysisRaw;
import com.mindtree.uxpulse.dto.StatusDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.repo.RequestUserRepo;
import com.mindtree.uxpulse.repo.RunDataRepo;
import com.mindtree.uxpulse.repo.ScheduleRepo;
import com.mindtree.uxpulse.repo.UsersRepo;
import com.mindtree.uxpulse.service.AnalysisService;
import com.mindtree.uxpulse.util.GlobalVariables;

/** @author M1049117 */
@Service
public class AnalysisServiceImpl implements AnalysisService {

  @Autowired private RunDataRepo runDataRepo;
  @Autowired private CouchDbConnector dbConnector;
  @Autowired private UsersRepo usersRepo;
  @Autowired private RequestUserRepo reqUserRepo;
  @Autowired private ScheduleRepo scheduleRepo;
  private ObjectMapper objectMapper = new ObjectMapper();

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.AnalysisService#getRawDataForAnalysis(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<AnalysisRaw> getRawDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException {

    Users userData = usersRepo.findByEmail(email).get(0);

    List<RequestUser> requestData =
        reqUserRepo.findByRequestIdAndUserId(requestLabel, userData.get_id());

    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");

    List<RunData> runDataTemp = new ArrayList<>();

    if (null != scheduleLabel) {
      List<Schedule> scheduleData = scheduleRepo.findByRequestUserId(requestData.get(0).get_id());
      if (scheduleData.size() == 0) {
        throw new NoSchedulesFoundException("No Schedules Found for this User");
      }

      runDataTemp =
          runDataRepo.findByRequestIdScheduleIdStatusTag(
              requestLabel, scheduleData.get(0).get_id(), StatusDto.RunStatus.COMPLETE.toString());

    } else {
      runDataTemp =
          runDataRepo.findByRequestIdStatusTag(
              requestLabel, StatusDto.RunStatus.COMPLETE.toString());
    }

    List<AnalysisRaw> analysisRawList = new ArrayList<>();
    List<AnalysisRaw> toRemove = new ArrayList<>();

    runDataTemp.forEach(
        rD -> {
          AnalysisRaw rawTemp = new AnalysisRaw();
          rawTemp.set_id(rD.get_id());

          rawTemp.setData(rD.getData());

          rawTemp.setRequestID(rD.getRequestID());
          rawTemp.setTaskId(rD.getTaskId());
          rawTemp.setTestID(rD.getTestID());
          analysisRawList.add(rawTemp);
        });

    analysisRawList.forEach(
        record -> {
          Tasks taskData = dbConnector.find(Tasks.class, record.getTaskId());
          if (requestData.size() == 0)
            try {
              throw new NoTaskFoundException("No Tasks Found for this Taskid");
            } catch (NoTaskFoundException e) { // TODO Auto-generated catch block
              e.printStackTrace();
            }
          record.setTaskData(taskData);
          if (null != label) {
            if (!label.equals(taskData.getLabel())) toRemove.add(record);
          }
        });
    // filtering out if label parameter is passed
    List<AnalysisRaw> filteredLabel = new ArrayList<>(analysisRawList);
    if (null != label) filteredLabel.removeAll(toRemove);

    return filteredLabel;
  }
  /**
   * Sets a field value on a given object
   *
   * @param targetObject the object to set the field value on
   * @param fieldName exact name of the field
   * @param fieldValue value to set on the field
   * @return true if the value was successfully set, false otherwise
   */
  public static boolean setField(Object targetObject, String fieldName, Object fieldValue) {
    Field field;
    try {
      field = targetObject.getClass().getDeclaredField(fieldName);
    } catch (NoSuchFieldException e) {
      field = null;
    }
    Class superClass = targetObject.getClass().getSuperclass();
    while (field == null && superClass != null) {
      try {
        field = superClass.getDeclaredField(fieldName);
      } catch (NoSuchFieldException e) {
        superClass = superClass.getSuperclass();
      }
    }
    if (field == null) {
      return false;
    }
    field.setAccessible(true);
    try {
      field.set(targetObject, fieldValue);
      return true;
    } catch (IllegalAccessException e) {
      return false;
    }
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.service.AnalysisService#getDataForAnalysis(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */

  @Override
  public AnalysisData getDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException,
          JsonMappingException, JsonProcessingException {

    // get Raw data from db
    List<AnalysisRaw> rawData = getRawDataForAnalysis(scheduleLabel, requestLabel, label, email);

    Set<String> labels = new HashSet<>();

    // mapping to json

    double TTFB = 0;
    double Render = 0;
    double visual = 0;
    double docTime = 0;
    double Fully = 0;
    double count = 0;
    double tagScore = 0;
    double temp = 0;
    Object jsonProvider;
    AnalysisData analysisDto = new AnalysisData();

    Object tempJsonProvider;

    for (String tag : GlobalVariables.LIGHTHOUSE_TAGS) {
      TTFB = 0;
      Render = 0;
      visual = 0;
      docTime = 0;
      Fully = 0;
      count = 0;
      tagScore = 0;

      for (AnalysisRaw record : rawData) {

        labels.add(record.getTaskData().getLabel());

        jsonProvider = new Object();

        jsonProvider =
            objectMapper
                .readTree(objectMapper.writeValueAsString(record.getData()))
                .get("lighthouse");

        switch (tag) {
          case "minify":
            // if lighthouse is set and location contains :Chrome
            if (!((JsonNode) jsonProvider).isNull()
                && record.getTaskData().getLocation().contains(":Chrome")) {
              if (((JsonNode) jsonProvider).has("audits")) {

                if (((JsonNode) jsonProvider).get("audits").has("unminified-javascript")
                    && ((JsonNode) jsonProvider).get("audits").has("unminified-css")) {
                  if (((JsonNode) jsonProvider)
                          .get("audits")
                          .get("unminified-javascript")
                          .has("score")
                      && ((JsonNode) jsonProvider)
                          .get("audits")
                          .get("unminified-css")
                          .has("score")) {
                    temp =
                        ((JsonNode) jsonProvider)
                                .get("audits")
                                .get("unminified-javascript")
                                .get("score")
                                .asDouble()
                            + ((JsonNode) jsonProvider)
                                .get("audits")
                                .get("unminified-javascript")
                                .get("score")
                                .asDouble();
                    temp = temp * 50;
                    tagScore = tagScore + temp;
                    count++;
                  }
                }
              }
            }
            break;

          case "renderBlockingJs":
            // if lighthouse is set and location contains :Chrome
            if (!((JsonNode) jsonProvider).isNull()
                && record.getTaskData().getLocation().contains(":Chrome")) {
              if (((JsonNode) jsonProvider).has("audits")) {
                if (((JsonNode) jsonProvider).get("audits").has("render-blocking-resources")) {
                  if (((JsonNode) jsonProvider)
                      .get("audits")
                      .get("render-blocking-resources")
                      .has("score")) {

                    tagScore =
                        tagScore
                            + ((JsonNode) jsonProvider)
                                    .get("audits")
                                    .get("render-blocking-resources")
                                    .get("score")
                                    .asDouble()
                                * 100;
                    count++;
                  }
                }
              }
            }
            break;

          case "cssDelivery":
            // if lighthouse is set and location contains :Chrome
            if (!((JsonNode) jsonProvider).isNull()
                && record.getTaskData().getLocation().contains(":Chrome")) {

              if (((JsonNode) jsonProvider).has("audits")) {
                if (((JsonNode) jsonProvider).get("audits").has("unused-css-rules")) {
                  if (((JsonNode) jsonProvider)
                      .get("audits")
                      .get("unused-css-rules")
                      .has("score")) {

                    tagScore =
                        tagScore
                            + ((JsonNode) jsonProvider)
                                    .get("audits")
                                    .get("unused-css-rules")
                                    .get("score")
                                    .asDouble()
                                * 100;
                    count++;
                  }
                }
              }
            }
            break;

          case "BrowserResponseTime":
            tempJsonProvider =
                objectMapper.readTree(objectMapper.writeValueAsString(record.getData()));
            // if data is set and location contains :Chrome
            if (!((JsonNode) tempJsonProvider).isNull()
                && record.getTaskData().getLocation().contains(":Chrome")) {

              if (((JsonNode) tempJsonProvider).has("firstView")) {
                tempJsonProvider = ((JsonNode) tempJsonProvider).get("firstView");
                TTFB = TTFB + (((JsonNode) tempJsonProvider).get("TTFB").asDouble() / 1000);
                Render = Render + (((JsonNode) tempJsonProvider).get("render").asDouble() / 1000);
                visual =
                    visual
                        + (((JsonNode) tempJsonProvider).get("visualComplete").asDouble() / 1000);
                docTime =
                    docTime + (((JsonNode) tempJsonProvider).get("docTime").asDouble() / 1000);
                Fully =
                    Fully + (((JsonNode) tempJsonProvider).get("fullyLoaded").asDouble() / 1000);

                if (!(0 == TTFB)
                    && !(0 == Render)
                    && !(0 == visual)
                    && !(0 == docTime)
                    && !(0 == Fully)) {
                  TTFB = TTFB / 2;
                  Render = Render / 2;
                  visual = visual / 2;
                  docTime = docTime / 2;
                  Fully = Fully / 2;
                }
                if (0.5 >= TTFB) {
                  tagScore = tagScore + 20;
                }
                if (2 >= Render) {
                  tagScore = tagScore + 20;
                }
                if (3 >= visual) {
                  tagScore = tagScore + 20;
                }
                if (5 >= docTime) {
                  tagScore = tagScore + 20;
                }
                if (7 >= Fully) {
                  tagScore = tagScore + 20;
                }
                count++;
              }
            }
            break;

          case "OnPageRedirects":
            // if lighthouse is set and location contains :Chrome
            if (!((JsonNode) jsonProvider).isNull()
                && record.getTaskData().getLocation().contains(":Chrome")) {
              if (((JsonNode) jsonProvider).has("audits")) {
                if (((JsonNode) jsonProvider).get("audits").has("redirects")) {
                  if (((JsonNode) jsonProvider).get("audits").get("redirects").has("score")) {

                    tagScore =
                        tagScore
                            + ((JsonNode) jsonProvider)
                                    .get("audits")
                                    .get("redirects")
                                    .get("score")
                                    .asDouble()
                                * 100;
                    count++;
                  }
                }
              }
            }
            break;

          default:
            // if firstview in data is set and location contains :Chrome

            if (!((JsonNode)
                        objectMapper.readTree(objectMapper.writeValueAsString(record.getData())))
                    .has("firstView")
                && record.getTaskData().getLocation().contains(":Chrome")) {
              tempJsonProvider =
                  (JsonNode)
                      objectMapper
                          .readTree(objectMapper.writeValueAsString(record.getData()))
                          .get("firstView");
              if (((JsonNode) tempJsonProvider).has("score_" + tag)) {
                if (((JsonNode) tempJsonProvider).get("score_" + tag).asDouble() >= 0) {
                  tagScore =
                      tagScore + ((JsonNode) tempJsonProvider).get("score_" + tag).asDouble();
                  count++;
                }
              }
            }
            break;
        }
      }
      tag = tag.equals("keep-alive") ? "keep_alive" : tag;

      if (0 == count) setField(analysisDto, "score_" + tag, "NA");
      else if (0 == tagScore && 0 != count) setField(analysisDto, "score_" + tag, 0D);
      else if (0 != tagScore && 0 != count) {
        tagScore = tagScore / count;
        setField(analysisDto, "score_" + tag, Math.round(tagScore));
      }
    }
    analysisDto.setLabels(labels);
    return analysisDto;
  }
}
