package com.mindtree.uxpulse.controller;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mindtree.uxpulse.exception.ConnectivityException;
import com.mindtree.uxpulse.service.LocationService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/**
 * Location list controller
 *
 * @author M1049117
 */
@CrossOrigin("*")
@RestController
public class LocationController {

  @Autowired private LocationService locationService;

  /**
   * get the locations available for execution
   *
   * @return ResponseEntity
   * @throws JsonMappingException
   * @throws JsonProcessingException
   * @throws ConnectivityException
   * @throws KeyManagementException
   * @throws NullPointerException
   * @throws NoSuchAlgorithmException
   */
  @GetMapping(
      value = "getLocations",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getLocations()
      throws JsonMappingException, JsonProcessingException, ConnectivityException,
          KeyManagementException, NullPointerException, NoSuchAlgorithmException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Locations",
            HttpStatus.OK.toString(),
            200,
            locationService.parseLocations(),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
