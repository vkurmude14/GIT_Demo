package com.mindtree.uxpulse.repository.repositoryImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.mindtree.uxpulse.dto.AnalysisRaw;
import com.mindtree.uxpulse.dto.DashboardRaw;
import com.mindtree.uxpulse.dto.EndUserReportRaw;
import com.mindtree.uxpulse.dto.StatusDto;
import com.mindtree.uxpulse.entity.RequestUser;
import com.mindtree.uxpulse.entity.RunData;
import com.mindtree.uxpulse.entity.Schedule;
import com.mindtree.uxpulse.entity.Tasks;
import com.mindtree.uxpulse.entity.Users;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.repository.RunDataCustomRepository;

public class RunDataCustomRepositoryImpl implements RunDataCustomRepository {
  private final MongoTemplate mongoTemplate;

  @Autowired
  public RunDataCustomRepositoryImpl(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.repository.RunDataCustomRepository#getRawDataForEndUserReport(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<EndUserReportRaw> getRawDataForEndUserReport(
      String scheduleLabel, String requestLabel, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException {
    Users userData =
        mongoTemplate.findOne(Query.query(Criteria.where("email").is(email)), Users.class);
    List<RequestUser> requestData =
        mongoTemplate.find(
            Query.query(
                Criteria.where("requestID")
                    .is(requestLabel)
                    .andOperator(Criteria.where("userId").is(userData.get_id()))),
            RequestUser.class);
    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");

    List<Schedule> scheduleData =
        mongoTemplate.find(
            Query.query(Criteria.where("requestUserId").is(requestData.get(0).get_id())),
            Schedule.class);
    if (scheduleData.size() == 0) {
      throw new NoSchedulesFoundException("No Schedules Found for this User");
    }
    List<AggregationOperation> list = new ArrayList<AggregationOperation>();
    list.add(
        Aggregation.match(
            Criteria.where("requestID")
                .is(requestLabel)
                .andOperator(
                    Criteria.where("scheduleID").is(scheduleData.get(0).get_id()),
                    Criteria.where("status.tag").is(StatusDto.RunStatus.COMPLETE))));
    list.add(Aggregation.project("requestID", "data", "taskId", "groupID"));

    TypedAggregation<RunData> agg = Aggregation.newAggregation(RunData.class, list);
    List<EndUserReportRaw> endUserReportRawList =
        mongoTemplate.aggregate(agg, RunData.class, EndUserReportRaw.class).getMappedResults();

    for (EndUserReportRaw record : endUserReportRawList) {
      List<Tasks> taskData =
          mongoTemplate.find(
              Query.query(Criteria.where("_id").is(record.getTaskId())), Tasks.class);
      if (requestData.size() == 0) throw new NoTaskFoundException("No Tasks Found for this Taskid");
      record.setTaskData(taskData.get(0));
    }
    return endUserReportRawList;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.repository.RunDataCustomRepository#getRawDataForAnalysis(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */
  public List<AnalysisRaw> getRawDataForAnalysis(
      String scheduleLabel, String requestLabel, String label, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException {
    List<AnalysisRaw> toRemove = new ArrayList<>();
    Users userData =
        mongoTemplate.findOne(Query.query(Criteria.where("email").is(email)), Users.class);

    List<RequestUser> requestData =
        mongoTemplate.find(
            Query.query(
                Criteria.where("requestID")
                    .is(requestLabel)
                    .andOperator(Criteria.where("userId").is(userData.get_id()))),
            RequestUser.class);

    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");
    List<AggregationOperation> list = new ArrayList<AggregationOperation>();

    if (null != scheduleLabel) {
      List<Schedule> scheduleData =
          mongoTemplate.find(
              Query.query(Criteria.where("requestUserId").is(requestData.get(0).get_id())),
              Schedule.class);
      if (scheduleData.size() == 0) {
        throw new NoSchedulesFoundException("No Schedules Found for this User");
      }
      list.add(
          Aggregation.match(
              Criteria.where("requestID")
                  .is(requestLabel)
                  .andOperator(
                      Criteria.where("scheduleID").is(scheduleData.get(0).get_id()),
                      Criteria.where("status.tag").is(StatusDto.RunStatus.COMPLETE))));
    } else {
      list.add(
          Aggregation.match(
              Criteria.where("requestID")
                  .is(requestLabel)
                  .andOperator(Criteria.where("status.tag").is(StatusDto.RunStatus.COMPLETE))));
    }

    list.add(Aggregation.project("requestID", "testID", "data", "taskId"));

    TypedAggregation<RunData> agg = Aggregation.newAggregation(RunData.class, list);
    List<AnalysisRaw> analysisRawList =
        mongoTemplate.aggregate(agg, RunData.class, AnalysisRaw.class).getMappedResults();
    // addding task data
    for (AnalysisRaw record : analysisRawList) {
      List<Tasks> taskData =
          mongoTemplate.find(
              Query.query(Criteria.where("_id").is(record.getTaskId())), Tasks.class);
      if (requestData.size() == 0) throw new NoTaskFoundException("No Tasks Found for this Taskid");
      record.setTaskData(taskData.get(0));
      if (null != label) {
        if (!label.equals(taskData.get(0).getLabel())) toRemove.add(record);
      }
    }

    // filtering out if label parameter is passed
    List<AnalysisRaw> filteredLabel = new ArrayList<>(analysisRawList);
    if (null != label) filteredLabel.removeAll(toRemove);
    return filteredLabel;
  }

  /* (non-Javadoc)
   * @see com.mindtree.uxpulse.repository.RunDataCustomRepository#getRawDataForDashboard(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<DashboardRaw> getRawDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoRequestsFoundException, NoSchedulesFoundException, NoTaskFoundException {
    Users userData =
        mongoTemplate.findOne(Query.query(Criteria.where("email").is(email)), Users.class);
    List<RequestUser> requestData =
        mongoTemplate.find(
            Query.query(
                Criteria.where("requestID")
                    .is(requestLabel)
                    .andOperator(Criteria.where("userId").is(userData.get_id()))),
            RequestUser.class);
    if (requestData.size() == 0)
      throw new NoRequestsFoundException("No Requests Found for this User");

    List<Schedule> scheduleData =
        mongoTemplate.find(
            Query.query(Criteria.where("requestUserId").is(requestData.get(0).get_id())),
            Schedule.class);
    if (scheduleData.size() == 0) {
      throw new NoSchedulesFoundException("No Schedules Found for this User");
    }
    List<AggregationOperation> list = new ArrayList<AggregationOperation>();
    list.add(
        Aggregation.match(
            Criteria.where("requestID")
                .is(requestLabel)
                .andOperator(
                    Criteria.where("scheduleID").is(scheduleData.get(0).get_id()),
                    Criteria.where("status.tag").is(StatusDto.RunStatus.COMPLETE))));
    list.add(
        Aggregation.project(
            "requestID",
            "testID",
            "groupID",
            "data",
            "urlOrScript",
            "memory",
            "taskId",
            "recommondations"));

    TypedAggregation<RunData> agg = Aggregation.newAggregation(RunData.class, list);
    List<DashboardRaw> dashboardRawList =
        mongoTemplate.aggregate(agg, RunData.class, DashboardRaw.class).getMappedResults();

    for (DashboardRaw record : dashboardRawList) {
      List<Tasks> taskData =
          mongoTemplate.find(
              Query.query(Criteria.where("_id").is(record.getTaskId())), Tasks.class);
      if (requestData.size() == 0) throw new NoTaskFoundException("No Tasks Found for this Taskid");
      record.setTaskData(taskData.get(0));
    }
    return dashboardRawList;
  }
}
