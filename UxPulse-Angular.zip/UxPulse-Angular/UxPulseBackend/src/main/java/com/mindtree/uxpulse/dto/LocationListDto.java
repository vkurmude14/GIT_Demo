package com.mindtree.uxpulse.dto;

import lombok.Data;

/** @author M1049117 */
@Data
public class LocationListDto {

  private int id;

  private String itemName;

  private String label;

  private String location;

  private String browser;

  private String server;

  private String name;

  private int Total;

  private int Testing;

  private int Idle;

  private String group;
}
