package com.mindtree.uxpulse.dto;

import com.mindtree.uxpulse.entity.Tasks;

import lombok.Data;

/** @author M1049117 */
@Data
public class AnalysisRaw {
  private String _id;
  private String requestID;
  private String testID;
  private Object data;
  private String taskId;
  private Tasks taskData;
}
