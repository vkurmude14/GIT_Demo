package com.mindtree.uxpulse.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mindtree.uxpulse.dto.DashboardData;
import com.mindtree.uxpulse.dto.DashboardRaw;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;

@Service
public interface DashboardService {
  /**
   * get the raw data for dashboard
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return list of dashboard raw
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoTaskFoundException
   */
  public List<DashboardRaw> getRawDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoTaskFoundException;

  /**
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return ist of dashboard data
   * @throws NoSchedulesFoundException
   * @throws NoRequestsFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws JsonProcessingException
   * @throws NoTaskFoundException
   */
  public List<DashboardData> getRunDataForDashboard(
      String scheduleLabel, String requestLabel, String email)
      throws NoSchedulesFoundException, NoRequestsFoundException, NoSuchFieldException,
          SecurityException, IllegalArgumentException, IllegalAccessException,
          JsonProcessingException, NoTaskFoundException;

  /**
   * @param username
   * @param reqlabel
   * @param scheduleLabel
   * @param groupId
   * @param testId
   * @return har as string
   * @throws IOException
   */
  public String getHarData(
      String username, String reqlabel, String scheduleLabel, String groupId, String testId)
      throws IOException;
}
