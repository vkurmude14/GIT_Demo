package com.mindtree.uxpulse.dto;

import java.util.List;

import com.mindtree.uxpulse.entity.Tasks;
import com.mongodb.lang.NonNull;

import lombok.Data;

/** @author M1049117 */
@Data
public class WorkDto {

  @NonNull private String label;
  @NonNull private List<Tasks> tasks;
  @NonNull private String requestID;
  @NonNull private String taskName;
  @NonNull private String scheduleName;
}
