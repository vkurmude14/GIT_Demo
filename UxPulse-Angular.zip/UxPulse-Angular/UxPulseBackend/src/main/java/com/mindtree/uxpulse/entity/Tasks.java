package com.mindtree.uxpulse.entity;

import org.codehaus.jackson.annotate.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/** @author M1049117 */
@Data
@NoArgsConstructor
public class Tasks {

  @JsonProperty("_id")
  private String _id;

  @NonNull private String location;
  @NonNull private String network;
  @NonNull private String server;
  @NonNull private Boolean isScript;
  @NonNull private Boolean isCustomer;
  @NonNull private String urlOrScript;
  @NonNull private String label;
  @NonNull private String block;

  @JsonProperty("_rev")
  private String revision;
}
