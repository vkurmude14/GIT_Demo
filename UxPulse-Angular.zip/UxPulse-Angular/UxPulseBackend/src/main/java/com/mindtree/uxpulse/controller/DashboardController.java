package com.mindtree.uxpulse.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.NoSchedulesFoundException;
import com.mindtree.uxpulse.exception.NoTaskFoundException;
import com.mindtree.uxpulse.service.DashboardService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/** @author M1049117 */
@CrossOrigin("*")
@RestController
public class DashboardController {
  @Autowired private DashboardService dashboardService;

  /**
   * get dasboard data
   *
   * @param scheduleLabel
   * @param requestLabel
   * @param email
   * @return ResponseEntity
   * @throws NoSchedulesFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws NoRequestsFoundException
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws JsonProcessingException
   * @throws NoTaskFoundException
   */
  @GetMapping(
      value = "getDashboardData",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getDashboardData(
      @RequestParam String scheduleLabel,
      @RequestParam String requestLabel,
      @RequestParam String email)
      throws NoSchedulesFoundException, NoSuchFieldException, SecurityException,
          NoRequestsFoundException, IllegalArgumentException, IllegalAccessException,
          JsonProcessingException, NoTaskFoundException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "getDashboardData",
            HttpStatus.OK.toString(),
            200,
            dashboardService.getRunDataForDashboard(scheduleLabel, requestLabel, email),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * get the har file as string
   *
   * @param username
   * @param reqlabel
   * @param scheduleLabel
   * @param groupId
   * @param testId
   * @return ResponseEntity
   * @throws IOException
   */
  @GetMapping("/getHarAsString")
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getHarData(
      @RequestParam String username,
      @RequestParam String reqlabel,
      @RequestParam String scheduleLabel,
      @RequestParam String groupId,
      @RequestParam String testId)
      throws IOException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "getHarAsString",
            HttpStatus.OK.toString(),
            200,
            dashboardService.getHarData(username, reqlabel, scheduleLabel, groupId, testId),
            true,
            false);
    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
