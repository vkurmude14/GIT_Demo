package com.mindtree.uxpulse.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mindtree.uxpulse.exception.ConnectivityException;
import com.mindtree.uxpulse.exception.NoRequestsFoundException;
import com.mindtree.uxpulse.exception.UserNotFoundException;
import com.mindtree.uxpulse.service.RecommendationReportService;
import com.mindtree.uxpulse.util.CustomApiSuccessResponse;

/** @author M1049117 */
@CrossOrigin("*")
@RestController
public class RecommendationReportController {

  @Autowired RecommendationReportService recommendationService;

  /**
   * get the recommendation report
   *
   * @param url
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   * @throws ConnectivityException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   */
  @GetMapping(
      value = "getRecommendationReport",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getRecommendationReport(
      @RequestParam("url") String url)
      throws UserNotFoundException, NoRequestsFoundException, ConnectivityException,
          JsonMappingException, JsonProcessingException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "RecommendationReport",
            HttpStatus.OK.toString(),
            200,
            recommendationService.getRecommendationsFromGooglePageSpeed(url),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }

  /**
   * get labels for recommendation report download
   *
   * @param requestID
   * @return ResponseEntity
   * @throws UserNotFoundException
   * @throws NoRequestsFoundException
   * @throws ConnectivityException
   * @throws JsonMappingException
   * @throws JsonProcessingException
   */
  @GetMapping(
      value = "getLabels",
      produces = {"application/json"})
  public @ResponseBody ResponseEntity<CustomApiSuccessResponse> getListOfLabels(
      @RequestParam("requestID") String requestID)
      throws UserNotFoundException, NoRequestsFoundException, ConnectivityException,
          JsonMappingException, JsonProcessingException {
    CustomApiSuccessResponse apiSuccessResponse =
        new CustomApiSuccessResponse(
            "Labels",
            HttpStatus.OK.toString(),
            200,
            recommendationService.getListOfLabels(requestID),
            true,
            false);

    return ResponseEntity.status(HttpStatus.OK).body(apiSuccessResponse);
  }
}
