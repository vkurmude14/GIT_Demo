package com.mindtree.uxpulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UxPulseApplicationTests {

	@Test
	void contextLoads() {
	}

}
