<?php
include 'mongoUtil.php';
require('PwatchServer\\config.php');
if(isset($_POST["user"])&&isset($_POST["pass"])){
	$user=$_POST["user"];
	$pass=$_POST["pass"];
	$url=$_POST["url"];
	$sleep = rand(100000,999999);
	usleep($sleep);
	
	$valid = false;
	$hashpass = [];
	try{
       // $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'users');
		$q = array("_id"=>$user);
		$f = array("key"=>1,"_id"=>0);
		
		$hashpass = $collection->findOne($q,$f);
		
		if(isset($hashpass["key"] )){
				$valid = true;
				$hashpass = $hashpass["key"];
		}
		
	}
    catch(MongoClientException $e){
        error_log($e);
		echo $e;
        echo '{"error":"Failure in Database Connection"}';
		die();
    }
    catch(Exception $e){
        error_log($e);
		echo $e;
		echo '{"error":"Failure in Database Connection"}';
		die();
    }
	
	
	
	if($valid){
		
		if($hashpass===crypt($pass,$hashpass)){
			session_start();
			$_SESSION['user']=$user;
			header('Location:'.$url);
			 
		}
		else			
			header('Location:index.php?&error=invalidPass');	
	}
	else
		header('Location:index.php?&error=invalidUser');
}
else	
	header('Location:index.php?&error=noDataSent');
?>
