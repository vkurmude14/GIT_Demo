<?php
require("servers.php");
header('Content-Type: application/json');
$locations = array();
$opts = array(
        'http'=>array(
			'method'=>"GET",
			'proxy' => 'tcp://172.22.218.218:8085',
			'request_fulluri' => true,
            )
	);
$context = stream_context_create($opts);

foreach($servers as $key=>$value){
	try{
		if($value["proxy"]){	
			$json = file_get_contents($value["url"]."/getLocations.php?f=json", false, $context);
		if(Empty($json)){
			$json = file_get_contents($value["url"]."/getLocations.php?f=json");
		}
		}
		else{
			$json = file_get_contents($value["url"]."/getLocations.php?f=json");	
		}
	}catch(Exception $e){
		//error.log($se)
	}
	
	$objs = json_decode($json);
	$objs = $objs->data;
	
	foreach($objs as $key=>$obj){
		$browsers = explode(",",$obj->Browsers);
		foreach($browsers as $browser){
			$location["label"] = $obj->labelShort.' '.$browser ;
			$location["location"] = $obj->location;
			$location["browser"] = $browser;
			$location["server"] = $value["url"];
		//	$location["proxy"] = $value["proxy"];
			$location["name"] = $key.':'.$browser;
			$location['Total'] = $obj->PendingTests->Total;
			$location['Testing'] = $obj->PendingTests->Testing;
			$location['Idle'] = $obj->PendingTests->Idle;
			$location['group'] = $obj->group;
			if (empty($locations[$obj->group]))
			    $locations[$obj->group]= array();
			array_push($locations[$obj->group],$location);
		}
	}
}

$myfile = fopen("locations.json", "w") or die("Unable to open file!");
fwrite($myfile,json_encode($locations));
fclose($myfile);

echo "done";