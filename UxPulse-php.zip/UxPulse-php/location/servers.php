<?php 
$servers = array(
	
	array("url"=>"http://api.webpagetest.org","proxy"=>true),
	//array("url"=>"http://10.60.224.22:8997","proxy"=>false),
	//array("url"=>"http://a2md19234","proxy"=>false)
);
?>