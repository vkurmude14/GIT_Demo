<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

 if(isset($_POST['selectedtests'])){
$_SESSION['selectedtests'] = $_POST['selectedtests'];
 }
 if(isset($_POST['selectedrequests'])){
$_SESSION['selectedrequests'] = $_POST['selectedrequests'];
 }
 if(isset($_POST['selectedgroups'])){
	 $_SESSION['selectedgroups'] = $_POST['selectedgroups'];
 }
$message='';
//if(isset($_SESSION['message']))$message = $_SESSION['message'];
if(isset($_GET['url']))$url = $_GET['url'];
		else $url="index.php";
	if(isset($_GET['request']))$request = $_GET['request'];
		else $request="";
		if(isset($_GET['schedule']))$schedule = $_GET['schedule'];
		else $schedule="";
		$location="";
		if(!isset($_POST['delete'])){
	        $jsList=["PwatchServer/getRequestDetails.php?request=".$request."&schedule=".$schedule,"index.js"];
		}
		else if(isset($_POST['delete'])){
	            $jsList=["PwatchServer/manageTests.php?request=".$request."&schedule=".$schedule."&manageType=delete","PwatchServer/getRequestDetails.php?request=".$request."&schedule=".$schedule,"index.js"];
				$message="Succesfully Deleted";
				//$jsList=[];
			}
	$cssList=["index.css"];
	$name="Home";
 
if(!isset($_SESSION['user'])){
	
		include("templates/login.inc.php");
		die();
	}
	else{
		
		$user=$_SESSION['user'];
		include "templates/header.inc.php";
		if(isset($_POST['recovery'])){
	    if(!empty($_POST['selectedtests'])){
	try {
		$message ="Triggering Recovery Failed";
		$args=array();
		$args=$_POST['selectedtests'];
		$jarpath = getcwd()."\\PwatchServer\\"."KelloggsRecovery.jar";
		$script = "java -jar ".$jarpath;
		$arg1=" ".getcwd()."\\PwatchServer\\users\\".$user."\\".$request."\\config.json";
		foreach($args as $arg) {
		$arg1=$arg1." ".$arg;
		}		
		$script =$script.$arg1;
		pclose(popen("start /B ". $script, "r"));
		$message ="Recovery Scheduled Successfully";
		} catch (Exception $e) {
			$message =$e;
		}
		
		}
			}
			unset($_POST);
?>
<span class="label-success"><?php echo $message?></span>

                <!-- Main content -->
                <section class="content">
				
                    <!-- Main row -->
                    <div class="row">
						<section class="col-lg-12">
						<form method="post" action="">
							<div  class="box" style="position: relative;">
                                <div class="box-header" >
								
                                    <i class="fa fa-upload"></i>									
                                    <h3 class="box-title">Details</h3> 
									
         					
                                </div>
								
								<!-- /.box-header -->
								<button style="position:fixed; top:.6in; right:60;"  type="submit" value="recovery" name="recovery" class="btn" title="Recovery" onclick="return confirm('Recovering Tests Might Change the Results and Report')"><i class="fa fa-retweet"></i></button>
								<button style="position:fixed; top:.6in; right:12;"  type="submit" value ="delete" name="delete" class="btn" title="Delete Failed Executions" onclick="return confirm('Delete Permanantly! Are you sure?')"><i class="fa fa-trash"></i></button>
							
								<div id="details" class="box-body">
								
								</div>
							

</div>
        
							</form>
                        </section><!-- right col -->
                    </div><!-- /.row (main row) -->

                </section>
								
<!-- /.content -->
 <?php
	require("templates/footer.inc.php");
	}
?>
	