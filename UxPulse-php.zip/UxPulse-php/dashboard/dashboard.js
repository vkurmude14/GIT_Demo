﻿//var domain = [ { "requests" : 2 , "bytes" : 1284 , "domain" : "idsync.rlcdn.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 329 , "domain" : "l.sharethis.com" , "connections" : 1} , { "requests" : 32 , "bytes" : 2915642 , "domain" : "www.mindtree.com" , "connections" : 6} , { "requests" : 1 , "bytes" : 3621 , "domain" : "www.googleadservices.com" , "connections" : 1} , { "requests" : 12 , "bytes" : 170245 , "domain" : "www.google.com" , "cdn_provider" : "Google" , "connections" : 3} , { "requests" : 1 , "bytes" : 3164 , "domain" : "rum-static.pingdom.net" , "cdn_provider" : "Cloudflare" , "connections" : 1} , { "requests" : 1 , "bytes" : 843 , "domain" : "think.cio.mindtree.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 635 , "domain" : "www.bizographics.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 2445 , "domain" : "cdn.pardot.com" , "cdn_provider" : "NetDNA" , "connections" : 1} , { "requests" : 1 , "bytes" : 254 , "domain" : "stats.g.doubleclick.net" , "connections" : 1} , { "requests" : 1 , "bytes" : 295 , "domain" : "stpix.media6degrees.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 6194 , "domain" : "maxcdn.bootstrapcdn.com" , "cdn_provider" : "NetDNA" , "connections" : 1} , { "requests" : 1 , "bytes" : 22583 , "domain" : "js.bizographics.com" , "cdn_provider" : "Amazon CloudFront" , "connections" : 1} , { "requests" : 2 , "bytes" : 1032 , "domain" : "b.scorecardresearch.com" , "cdn_provider" : "Akamai" , "connections" : 1} , { "requests" : 1 , "bytes" : 1164 , "domain" : "4754632.fls.doubleclick.net" , "connections" : 1} , { "requests" : 1 , "bytes" : 100 , "domain" : "clients1.google.com" , "cdn_provider" : "Google" , "connections" : 1} , { "requests" : 1 , "bytes" : 4533 , "domain" : "edge.sharethis.com" , "cdn_provider" : "Akamai" , "connections" : 1} , { "requests" : 2 , "bytes" : 778 , "domain" : "wd-edge.sharethis.com" , "cdn_provider" : "Akamai" , "connections" : 2} , { "requests" : 1 , "bytes" : 920 , "domain" : "googleads.g.doubleclick.net" , "connections" : 1} , { "requests" : 1 , "bytes" : 275 , "domain" : "rum-collector.pingdom.net" , "cdn_provider" : "Cloudflare" , "connections" : 1} , { "requests" : 2 , "bytes" : 1178 , "domain" : "e.nexac.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 1362 , "domain" : "pi.pardot.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 86 , "domain" : "www.googleapis.com" , "cdn_provider" : "Google" , "connections" : 1} , { "requests" : 1 , "bytes" : 629 , "domain" : "d.agkn.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 539 , "domain" : "analytics.twitter.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 664 , "domain" : "t.co" , "connections" : 1} , { "requests" : 2 , "bytes" : 36714 , "domain" : "platform.twitter.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 376 , "domain" : "www.google.ae" , "cdn_provider" : "Google" , "connections" : 1} , { "requests" : 2 , "bytes" : 38388 , "domain" : "www.googletagmanager.com" , "cdn_provider" : "Google" , "connections" : 1} , { "requests" : 2 , "bytes" : 12338 , "domain" : "www.google-analytics.com" , "cdn_provider" : "Google" , "connections" : 1} , { "requests" : 1 , "bytes" : 481 , "domain" : "script.crazyegg.com" , "cdn_provider" : "Amazon CloudFront" , "connections" : 1} , { "requests" : 1 , "bytes" : 740 , "domain" : "insight.adsrvr.org" , "connections" : 1} , { "requests" : 2 , "bytes" : 1024 , "domain" : "ib.adnxs.com" , "connections" : 1} , { "requests" : 1 , "bytes" : 396 , "domain" : "www.facebook.com" , "connections" : 1} , { "requests" : 2 , "bytes" : 1120 , "domain" : "p.nexac.com" , "connections" : 1} , { "requests" : 4 , "bytes" : 75554 , "domain" : "w.sharethis.com" , "cdn_provider" : "Akamai" , "connections" : 2} , { "requests" : 1 , "bytes" : 284 , "domain" : "adadvisor.net" , "connections" : 1} , { "requests" : 1 , "bytes" : 1199 , "domain" : "seg.sharethis.com" , "connections" : 1}]
//var breakdown = [ { "requests" : 0 , "bytes" : 0 , "type" : "flash"} , { "requests" : 0 , "bytes" : 0 , "type" : "other"} , { "requests" : 3 , "bytes" : 102853 , "type" : "font"} , { "requests" : 26 , "bytes" : 950581 , "type" : "js"} , { "requests" : 37 , "bytes" : 2140302 , "type" : "image"} , { "requests" : 10 , "bytes" : 25768 , "type" : "html"} , { "requests" : 8 , "bytes" : 86698 , "type" : "css"}]


//config vars
var percentile=100;
var interpolate="linear";
var colors = ['#d95f02','#7570b3','#e7298a','#e6ab02','#a6761d','#666666'];//colorbrewer.dark2[8]
var filterType = ['label','location','browser','network','isCustomer'];
var metricsA = ['firstView','repeatView'];
var metricsB = ['doccomplete','startrender','visuallycomplete','fullyloaded','TTFB','requests','bytesin'];

var count = 0;
//QUICKFIX
//metaWithDummyData
var metaData = [
	{color:"teal",h3:"3.2",small:"seconds",info:"672 records",icon:"fa-info","footer":"Average Response Time"},
	{color:"green",h3:"1.3",small:"seconds",info:"NewYork:Chrome",icon:"fa-thumbs-o-up","footer":"Fastest Response Time"},
	{color:"yellow",h3:"6.8",small:"seconds",info:"Sydney:Firefox",icon:"fa-thumbs-o-down" ,"footer":"Slowest Response Time"},
	];
//QFEND


var data = [
	[
	{head:"TABLE1",data:[["location","Paris"],["browser","chrome"],["network","cable"],["label","mindtree"]]},//table1
	{head:"TABLE2",data:[["image","6788","www.akdn.fav.ada/bigImage1.png"],["image","1788","www.akdn.fav.ada/bigImage2.png"],["image","2351","www.akdn.fav.ada/bigImage1.png"],["image","10020","www.akdn.fav.ada/bigImage3.png"],["image","6788","www.unknowa.cc/bigJS.js?please=removethis&thistoo"]]},//table2
	{head:"TABLE3",data:[["image","6788","www.akdn.fav.ada/slowImage1.png"],["css","2841","www.akdn.fav.ada/slowCss.css"],["js","12788","www.nmkdn.notgood/dontuse.js"],["image","6788","www.akdn.fav.ada/bigImage1.png"],["image","6788","www.akdn.fav.ada/bigImage1.png"]]},//table3
	],
];

//intializing vars   

//get RequestID from URL


var crossData = crossfilter();
var dims = {};

var filters = {}; 
var groupDim;
var indexDim;
var a = "firstView"; 
var b = "doccomplete";
var components=[];
var brushExtent;

//adding dropdowns
addSelect("tools","filterType",filterType,'col-xs-4');
addSelect("tools","metricsA",metricsA,'col-xs-4');
addSelect("tools","metricsB",metricsB,'col-xs-4');


//intializing charts
var mainChart = createMainChart();
var sub1Chart = createSub1Chart();
var pieChart1;
var pieChart2;
createLegend();
//fetching Data



		crossData = crossfilter();
		crossData = crossData.add(result);
		//console.log("Data Size:"+crossData.size());
		buildDimensions();
		buildFilters();
		drawFilters();
		
		//attach event
		//d3.selectAll('select').on('change',function(d){updateChart();});
		//$("#tools select").chosen().on('change',function(d){updateChart();});;
		$("#tools select").on('change',function(d){updateChart();});;
		$("#filters select").chosen().on('change',function(d){updateChart();});;
		
		//builddata(result);//ANWAR
		
		updateChart();



//var sub2Chart = createSub2Chart();

function updateChart(){
	var temp;
	//BADSTYLE
	//collect parameter
	var type  =  getSelectedValues("filterType");
	var a  =  getSelectedValues("metricsA");
	var b  =  getSelectedValues("metricsB");
	var nfilter = {};
	filterType.forEach(function(d){
		
		nfilter[d] = getSelectedValues(d);
	});
	console.log('nfilter');
	console.log(nfilter);
	//BSEND
	
	//apply percentile filter
	var tempDim = crossData.dimension(function(d) {return d['metrics'][a][b];});
	console.log('tempDim');
	console.log(tempDim);
	var s = crossData.size();
	console.log('crossData');
	console.log(crossData);
	var p = parseInt((100-percentile)/100 * s);
	if(p>0){
		var q = tempDim.top(p)[p-1]['metrics'][a][b];
		tempDim.filter(function(d){return (d < q) ;});
	}
	
	//filterData on all Dimensions
	
	filterType.forEach(function(d){
		if(d!==type){
			dims[d].filter(function(e){
				if(nfilter[d].length===0) return true;
				return nfilter[d].indexOf(e)>=0;
			})
		}
	});
	
	//build data for main-chart
	
	var mainData=[];
	console.log('filters');
	console.log(filters);
	console.log('filters[type]');
	console.log(filters[type]);
	filters[type].forEach(function(d){
		if(nfilter[type].length===0 || nfilter[type].indexOf(d.label)>=0){
				
			dims[type].filter(d.label);
			temp=[];
			groupDim.group().reduce(reduceAdd(a,b), reduceRemove(a,b), reduceInit(a,b)).all()
				.forEach(function(p,i) {
					if(p.value.count>0)
						temp.push({x:p.key,y:+p.value.avg});
			});
			if(temp.length>0)
				mainData.push({"key":d.label,"values":temp});
		}
	});
	console.log('mainData');
	console.log(mainData);
	
	dims[type].filter(function(e){
		if(nfilter[type].length===0) return true;
		return nfilter[type].indexOf(e)>=0;
	})
	
	//build data for sub1-chart
	var sub1Data=[];
	
	var temp1=[];
	var temp2=[];
	var temp3=[];
	var temp4=[];
	var temp5=[];
	var vc;
	var dc;
	var fl;
	var oldDate = 0;
	
	//apply Date/Group filter
	if(brushExtent)
		groupDim.filter(brushExtent);
	
	
	indexDim.bottom(Infinity).forEach(
		function(d){
			var x;
			//QUICKFIX
			x = d.date === oldDate ? d.date+1 : d.date;
			oldDate = x;
			//QFEND

			//TODO
			var fb=d.metrics[a]["TTFB"];
			var st = d.metrics[a]["startrender"]-fb;
			vc=(d.metrics[a]["visuallycomplete"])-st-fb;
			dc = (d.metrics[a]["doccomplete"] - st-fb-vc);
			fl = (d.metrics[a]['fullyloaded'] - dc - st-fb-vc);
			
			temp1.push({y:st,d:d,x:x,});
			temp2.push({y:dc,d:d,x:x,});
			temp3.push({y:fl,d:d,x:x,});
			temp4.push({y:fb,d:d,x:x,});
			temp5.push({y:vc,d:d,x:x,});
		}
	);
	
		sub1Data = [{key:"TTFB",values:temp4},{key:"startrender",values:temp1},{key:"visuallycomplete",values:temp5},{key:"doccomplete",values:temp2},{key:"fullyloaded",values:temp3}];
	
	

	
	


	//build Summary data	
	var filteredSize = crossData.groupAll().value();
	crossData.groupAll().value() != temp1.length ? alert("Error"+ temp1.length) : console.log(filteredSize);
	//console.log(temp.length) ; console.log(filteredSize);
	
	//apply filter to aggregate only customer data
	dims["isCustomer"].filter("true");
	
	
	//avg response
	metaData[0].h3 = Math.round(crossData.groupAll().reduce(reduceAdd(a,b), reduceRemove(a,b), reduceInit(a,b)).value().avg * 100) / 100;
	
	//fastest response
	var bottom = tempDim.bottom(1)[0];
	if(bottom){
		metaData[1].h3 = Math.round(bottom.metrics[a][b] * 100) / 100;
		metaData[1].info = bottom.location + ":" + bottom.browser;
	}
	else{
		metaData[1].h3 = "0";
		metaData[1].info = "NoData";	
	}
	//slowest response
	var top = tempDim.top(1)[0];
	if(top){
	metaData[2].h3 = Math.round(top.metrics[a][b] * 100) / 100;
	metaData[2].info = top.location + ":" + top.browser;
	}
	else{
		metaData[2].h3 = "0";
		metaData[2].info = "NoData";	
	}
	
	//size of records 
	metaData[0].info = crossData.groupAll().value() + " Records";	
	//QFEND	
	
	
	//clearing all filters
	
	filterType.forEach(function(d){
			dims[d].filterAll();
	})
	groupDim.filterAll();
	tempDim.filterAll();
	
	//removing tempDim, increases performance?!
	tempDim.dispose();

	mainChart.updateData(mainData);
	sub1Chart.updateData(sub1Data);
	drawSummary(metaData);
	
}

function getSelectedValues(id) {
	var select = document.getElementById(id);
	var i;
	var selected = [];
    for (i = 0; i < select.options.length;i++){
		if (select.options[i].selected) {
			selected.push(select.options[i].value)
		}
	}
	if(!select.multiple){
		selected =  selected[0];
	}
	return selected;
}
     
function createMainChart(){
	var chart = nv.models.lineChart()
                .margin({left: 60,right:60})  //Adjust chart margins to give the x-axis some breathing room.
                .useInteractiveGuideline(false)  //We want nice looking tooltips and a guideline!
                .transitionDuration(100)  //how fast do you want the lines to transition?
                .showLegend(true)       //Show the legend, allowing users to turn on/off line series.
                .showYAxis(true)        //Show the y-axis
                .showXAxis(true)        //Show the x-axis
				.color(colors)
				.forceY(0)
	;

	chart.xAxis     //Chart x-axis settings
		.axisLabel('Execution Date')		
		.tickFormat(function(d) { return d3.time.format('%d/%m-%H:%M')(new Date(d)); })
		.showMaxMin(false)
		;

	chart.yAxis     //Chart y-axis settings
		.axisLabel('Seconds')
		.axisLabelDistance(40)
		.tickFormat(d3.format('.3f'));
		
	  
	chart.updateData = function(data){
		console.log("Data for linechart");
		console.log(data);
		d3.select('#main-chart svg')    //Select the <svg> element you want to render the chart in.   
		.datum(data)         //Populate the <svg> element with chart data...
		.call(chart);          //Finally, render the chart!
		
	var brush  = d3.select('#main-chart svg g');
	
	brush.empty() ? brush.append('g'): brush.select('g')//NICEONE!
	.attr("class", "brush")
		.call(d3.svg.brush()		
			.x(chart.xAxis.scale())
			.on('brushend', onBrush)
			.extent(brushExtent||[0,0])	
			
		)
		.selectAll('rect')
		.attr('height',320 )
		;
    }
	chart.updateData([]); 
	
	nv.utils.windowResize(function() { chart.update() });
	return chart;
}

function onBrush() {
	brushExtent = d3.event.target.extent();
	//NICEONE!
	if(brushExtent[0]!==brushExtent[1]){
		brushExtent[0] -= 100;
		brushExtent[1] += 100;
	}else brushExtent = null;
	
	console.log(brushExtent);
	updateChart();
}


function createSub1Chart(){
	var chart = nv.models.multiBarChart()
		  .margin({left: 60,right:60}) 
      .staggerLabels(false)    //Too many bars and not enough room? Try staggering labels.
      .tooltips(false)        //Don't show tooltips
      .showControls(false)       //...instead, show the bar value right on top of each bar.
      .transitionDuration(100)
	  .stacked(true)
	  .color(['#9ecae1','#4292c6','#08519c'])
	  .groupSpacing(0.393)
      ;
	chart.xAxis     //Chart x-axis settings
		.axisLabel('Execution Date')
	
		.tickFormat(function(d) { return d3.time.format('%d/%m-%H:%M')(new Date(d)); });
		

	chart.yAxis     //Chart y-axis settings
		.axisLabel('Seconds')
		.axisLabelDistance(40)
		.tickFormat(d3.format('.1f'));
		
	 chart.multibar.dispatch.on("elementDblClick",
                function(e) {
				
					console.log(e);
                    toHAR(e.point.d.group+"/"+e.point.d.testID);
                }
            );
            
     chart.multibar.dispatch.on("elementMouseover", function(e){updateLegend(e.point.d);});
                    

	
	
	
	chart.updateData = function(data){
		d3.select('#sub-chart1 svg')    //Select the <svg> element you want to render the chart in.   
		.datum(data)         //Populate the <svg> element with chart data...
		.call(chart);          //Finally, render the chart!
	}
	chart.updateData([]);
	
	
		

	
	
	nv.utils.windowResize(function() { chart.update() });
	return chart;
}

	



function drawFilters(){
	var myNode = document.getElementById("filters");
	while (myNode.firstChild) {
		myNode.removeChild(myNode.firstChild);
	}
	for(var key in filters){
		var value=filters[key];
		addMultiSelect("filters",key,value,"all");
	//	console.log(key);
	//	console.log(value);
	}
}




function buildDimensions(){
	
	groupDim = crossData.dimension(function(e) {return +e["group"];});
	indexDim = crossData.dimension(function(e) {return +e["date"];});;
	
	filterType.forEach(function(d){
		dims[d] = crossData.dimension(function(e) {return e[ d];});
	});
}

function buildFilters(){
	filterType.forEach(function(d){
		filters[d] = [];
		var v = dims[d].group().all();
		v.forEach(function(e){
			filters[d].push({label:e.key,isSelected:false});
		});
	});
}



function addSelect(divID,name,data,className){
	var div = d3.select("#"+divID).append("div").attr('class',className);
	div.append("select")
	.attr("id",name)
	.attr("data-placeholder","Select "+name+" filters")
	.attr('class','form-control')
	.selectAll("option")
	.data(data)
	.enter()
	.append("option")
	.attr("value",function(d){return d;})
	.text(function(d){return d;});
}

function addMultiSelect(divID,name,data,placeHolder){
	// if(placeHolder)data.unshift(name);
	var div = d3.select("#"+divID).append("div").attr("class","col-lg-6 col-xs-12");
	
	div.append("select")
	.attr("id",name)
	.attr("data-placeholder",name+" filters...")
	.attr("multiple","multiple")
	.selectAll("option")
	.attr("id",name)
	.data(data)
	.enter()
	.append("option")
	.attr("value",function(d){return d.label;})
	.text(function(d){return d.label;})
	;
}


function reduceAdd(a,b) {
	return function(p,v){
		++p.count;
	
		p.sum = p.sum + v['metrics'][a][b];
		p.avg = p.sum/p.count;
	
		return p;
	};	
}   
function reduceRemove(a,b) {
	return function(p,v){
        --p.count;
		
		p.sum = p.sum - v['metrics'][a][b];
		p.avg = p.sum/p.count;
		
        return p;
	};		
}   
function reduceInit(a,b) {
	return function(p,v){
		var p = {};
		p.count = 0;
		p.sum =  0;
		p.avg =  0;
		return p;
	};
}
function drawSummary(metaData){
	var div = d3.select("#summary");
	
	//console.log(new Date()+ count++);

	sec = div.selectAll("section")
		.data(metaData)
		
	//update
	
	sec.select("h3").text(function(d){return d.h3})
	.append("small").text(function(d){return " "+d.small});
	sec.select("p").text(function(d){ return d.info});
	
	
	
	var main = sec.enter()
		.append("section")		
		.attr("class","col-lg-4")
		.append("div");
	
	
	var inner = main.attr("class",function(d){ return "small-box bg-"+d.color})
		.append("div");
		
	inner.attr("class","inner")
		.append("h3")
			.text(function(d){ return d.h3})
			.append("small")
				.text(function(d){ return " "+d.small})
	inner.append("p")
			.text(function(d){ return d.info})
		
		
	main.append("div")
				.attr("class","icon")
				.append("i")
					.attr("class",function(d){ return "fa "+d.icon})
		
	main.append("a")		
				.attr("class","small-box-footer")
				.text(function(d){ return d.footer})
	;
}
function brushed() {
  x.domain(brush.empty() ? x2.domain() : brush.extent());
  focus.select(".area").attr("d", area);
  focus.select(".x.axis").call(xAxis);
}


function toHAR(wpturl){
	wpturl = $("#_user").val() +"/"+ $("#_request").val() +"/"+wpturl;
	var url = window.location.href.split("?")[0]+"../harviewer/?harfile="+wpturl;
	console.log('url');
	console.log(url);
	window.open(url,'_blank');
} 


function createLegend(){
	createTable('info');
	createTable('slowElement');
	createTable('heavyElement');
	pieChart1=createPieChart("domain");
	pieChart2=createPieChart("type");
	updateLegend();
}

function drawLegend(t1,t2,t3,t4){	
	drawTable('info',t1);
	drawTable('slowElement',t2);
	drawTable('heavyElement',t3);
	pieChart1.updateData(t4.domains);
	pieChart2.updateData(t4.breakdown);
}

function createTable(divID){
	var table = d3.select("#"+divID+" table");
	table.append("thead").append("tr");
	table.append("tbody");
}

function createPieChart(x){
	var chart = nv.models.pieChart()
      .x(function(d) { return d[x] })
      .y(function(d) { return (d.bytes/1000).toFixed(2) })
      .showLabels(true)     //Display pie labels
      .labelThreshold(0.08)  //Configure the minimum slice size for labels to show up
      .labelType("key") //Configure what type of data to show in the label. Can be "key", "value" or "percent"
	//.donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
    //  .donutRatio(0.3)     //Configure how big you want the donut hole size to be.
	  .showLegend(false)	  
	  .color(['#8dd3c7','#ffffb3','#bebada','#fb8072','#80b1d3','#fdb462','#b3de69','#fccde5','#d9d9d9','#bc80bd','#ccebc5','#ffed6f'])
	  
      ;

	
	chart.updateData = function(data){
		d3.select("#"+x+" svg")
		.datum(data)         //Populate the <svg> element with chart data...
		.call(chart);          //Finally, render the chart!
	}
	chart.updateData([]);
	
	 return chart;
		

	
	
	nv.utils.windowResize(function() { chart.update() });
	return chart;
}



function drawTable(divID,t1){
	var th = d3.select("#"+divID+" thead tr").selectAll('th').data(t1.head);
	//enter
	th.enter().append('th');
	//enter+update
	th.text(function(d){return d});
	//exit
	th.exit().remove();
	
	var tr = d3.select("#"+divID+" tbody").selectAll('tr').data(t1.data);
	tr.enter().append('tr');
	
	var td = tr.selectAll('td').data(function(d){return d});
	var a = td.enter().append('td').style('min-width',"50px");
	
	td
	.attr("title",(function(d){return d}))
	.html(function(d,i){
		var s;
		if(i==2){
				s = d.length>40 ? "..."+d.substring(d.length-40) : d;
				s = "<a href="+d+" target='_blank' >" + s + "</a>";
		}
		else s=d;
		return s;
	})
	tr.exit().remove();
	td.exit().remove();			
}


function updateLegend(d,flag){
	
	//console.log(d);
	
	
	var t1={label:"Parameters",head:["key","value"],data:[]};
	var t2={label:"Heavy Elements",head:["Type","Size","Component"],data:[]};
	var t3={label:"Slow Elements",head:["Type","Time","Component"],data:[]};
	var t4={breakdown:[],domains:[]};
	
	
	if(d){
	t1.data=[
			["location",d.location+":"+d.browser+"."+d.network],
			["label",d.label],
			["Response firstView",d.metrics.firstView.TTFB+"/"+d.metrics.firstView.startrender+"/"+d.metrics.firstView.visuallycomplete+"/"+d.metrics.firstView.doccomplete+"/"+ d.metrics.firstView.fullyloaded + " Seconds"],
			["Response repeatView",d.metrics.repeatView.TTFB+"/"+d.metrics.repeatView.startrender+"/"+d.metrics.repeatView.visuallycomplete+"/"+d.metrics.repeatView.doccomplete+"/"+ d.metrics.repeatView.fullyloaded + " Seconds"],
		];
	//console.log(d);	
	//console.log(t1);
	
	
			var len = 0;
			len = Math.min(5, d.components.slow.length)
			for(i=0;i<len;i++){
				t3.data.push(
					[d.components.slow[i].type,
					(d.components.slow[i].resp/1000).toFixed(3)+" sec",
					decodeURIComponent(d.components.slow[i].url)]);
			}	
			len = Math.min(5, d.components.heavy.length)
			for(i=0;i<len;i++){
				t2.data.push(
					[d.components.heavy[i].type,
					(d.components.heavy[i].size/1000).toFixed(0)+" kB",
					decodeURIComponent(d.components.heavy[i].url)]);
			}
			
			
		t4.domains=d.metrics.firstView.domains.sort(function(a,b){return b.bytes - a.bytes});
		t4.breakdown=d.metrics.firstView.breakdown;
	}
	drawLegend(t1,t2,t3,t4);
}