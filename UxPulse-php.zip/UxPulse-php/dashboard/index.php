<!DOCTYPE html>
<?php
	session_start();
	if(!isset($_SESSION['user'])){
		$url = $_SERVER[REQUEST_URI];
		header("Location: ../index.php?&url=".$url);
		die();
	}
	else
	{		
		$user = $_SESSION['user'];
		
		if(isset($_GET['request']))$request = $_GET['request'];
		else $request="";
		if(isset($_GET['schedule']))$schedule = $_GET['schedule'];
		else $schedule="";
		$location="/dashboard";
		$jsList=[
			"../chosen/chosen.jquery.min.js",
			"../PwatchServer/getDashData.php?request=".$request."&schedule=".$schedule,
			"dashboard.js"
		];
		$cssList=["../chosen/chosen.bootstrap.min.css","dashboard.css"];
		$name="Dashboard/$request";
		require("../templates/header.inc.php");
?>
                <section class="content">

                   <!-- Small boxes (Stat box) -->
                    <div class="row">
						<section class="col-lg-12">
							<div id="head"></div>
						<section>
                    </div><!-- /.row -->
					<div id="summary" class="row">
					
                    </div><!-- /.row -->
			
                    <!-- Main row -->
                    <div class="row">
                        <!-- Left col -->
						<section class="col-lg-12">	
							<div  class="box" style="position: relative;">
                                <div class="box-header">
                                    <i class="fa fa-upload"></i>									
                                    <h3 class="box-title">Trending </h3> 
									
									<div id="tools" class="box-tools pull-right form-group">
											
									</div>
								</div>
								<div class="box-body">
										<input type="hidden" id="_request" value="<?php echo $request?>">
										<input type="hidden" id="_user" value="<?php echo $user?>">
										<div id="filters" class="row">
										</div>
										<div id="main-chart"  class="row" >
											<svg></svg>
										</div>
										
										<div id="sub-chart1"  class="row">
											<svg  ></svg>
										</div>
										<div id="sub-chart2"  class="row">
											<div class="row">
												<div id="info" class="col-lg-6">
												<h4>Parameters</h4>
												<table class="table table-bordered"></table></div>
												<div id="pieChart" class="col-lg-6">
													<h4>Size Breakdown</h4>
													<table class="table table-bordered">
														<thead>
															<tr>
																<th>Domain-Wise </th>
																<th>DataType-Wise </th>
														</thead>
														<tbody>
															<tr>
																<td id="domain"><svg></svg></td>
																<td id="type"><svg></svg></td>
															</tr>
														</tbody>
													</table>
												</div>													
											</div>
											<div class="row">
												<div id="slowElement" class="col-lg-6"><h4>Heavy Elements</h4><table class="table table-bordered"></table></div>
												<div id="heavyElement" class="col-lg-6"><h4>Slow Elements</h4><table class="table table-bordered"></table></div>
											</div>
										</div>
									
								</div>
							</div>
						</section><!-- left col -->
						 <!-- Right col -->
                    </div><!-- /.row (main row) -->

                </section><!-- /.content -->
 <?php
	require("../templates/footer.inc.php");
	}
?>
