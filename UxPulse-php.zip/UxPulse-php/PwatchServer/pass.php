<?php
require("config.php");
require_once('..\\mongoUtil.php');
$user=$_POST["user"];
$pass=$_POST["pass"];
try{
       // $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
		//  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $users = $connection->selectCollection(DB_NAME,'users');
		$q = array("_id"=>$user);
		$f = array("_id"=>1);
		
		//check if user Exists
		$temp = $users->findOne($q,$f);
		if(count($temp)==1)
			echo "$temp[_id] Already Exists";
		
		//Register User
		else if(count($temp)==0){
			//TODO change crypt function if required
			$q = array("_id"=>$user,"key"=>crypt($pass),"time"=>time());
			$users->insert($q);
			echo "$user Registered";
		}
		//Unexpected Situation
		else{
			echo "Some Error Occurred";
		}
	}
    catch(MongoClientException $e){
        error_log($e);
        echo '{"error":"Failure in Database Connection"}';
		die();
    }
    catch(Exception $e){
        error_log($e);
		echo '{"error":"'.$e.'"}';
		die();
    }
?>
