<?php
	
	require ("config.php");
	require_once('..\\mongoUtil.php');
	header("Content-Type","application/json");
	

	session_start();
	$invalid = false;
		
	echo json_encode($_POST);	
	if(!isset($_POST["startDate"]))$invalid = true;
	if(!isset($_POST["endDate"]))$invalid = true;
	if(!isset($_POST["interval"]))$invalid = true;
	if(!isset($_POST["intervalUnit"]))$invalid = true;
	if(!isset($_POST["request"]))$invalid = true;
	if(!isset($_SESSION['user']))$invalid = true;
	if($invalid){
		echo "error";
	die();}
	
	$sDate = $_POST["startDate"];		
	$eDate = $_POST["endDate"];
	$interval = $_POST["interval"];
	$intervalUnit = $_POST["intervalUnit"];	            
	$user = $_SESSION["user"];
	$request = json_decode($_POST["request"],true);
	//echo $_POST["request"];
	//echo json_last_error();
	//echo json_encode($request);
	$request["requestID"] = $request["label"];
	$request["taskname"] = $user.'-'.$request["requestID"];
	
	$taskname =$request["taskname"];
	
	$work = getcwd()."\\users\\".$user."\\".$request["requestID"]."\\work.json";
	$config = getcwd()."\\users\\".$user."\\".$request["requestID"]."\\config.json";
	$taskrun = "java -jar ".getcwd()."\\".PC." ".$work." ".$config ;
	
	
	switch ($intervalUnit) {
	case "DAILY":
		$intervalCommand = " /SC DAILY /MO ".$interval;
		break;
        
		case "HOURLY":
		$intervalCommand = " /SC DAILY /MO 1 /DU 24:00 /RI ".$interval*60;
		break;
		
    case "MINUTE":
		$intervalCommand = " /SC DAILY /MO 1 /DU 24:00 /RI ".$interval;
		break;
		
	case "WEEKLY":
		$intervalCommand = " /SC WEEKLY /MO ".$interval;
		break;	
	}

	$command = "schtasks /Create".
			" /RU ".SYS_USER.
			" /RP ".SYS_PASS.
			" /TN ".$taskname.
			" /TR \"".$taskrun."\"".
			" /SD ".$sDate.
			" /ST ".date("H:i",time() + 60).
			" /ED ".date("m/d/Y",strtotime($eDate.' +1day')).
			" /F ".
			$intervalCommand.
		"";
	
	echo $command;
	
	try{
        $connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'users');
		$q = array("_id"=>$user);
		
		if($collection->find($q)->count()==1){
			$o = array('$push'=>array("requests.".$request["requestID"].".schedules"=>$request["schedules"][0]));
			
			$collection->update($q,$o);
		}
		error_log("Database Inconsistent");
	}
    catch(MongoClientException $e){
        error_log($e);
		echo $e;
        echo '{"error":"Failure in Database Connection"}';
		die();
    }
    catch(Exception $e){
        error_log($e);
		echo $e;
		echo '{"error":"Failure in Database Connection"}';
		die();
    }
	
	if(!checkForErrors()){
		$str = file_get_contents($work);
		$json = json_decode($str, true); 
		
		$json['schedules'][0]=$request["schedules"][0];
		$newJsonString = json_encode($json);
        file_put_contents($work, $newJsonString);
		//if(!file_exists ("users\\".$user."\\".$request["requestID"] )){
			//mkdir("users\\".$user."\\".$request["requestID"], 0700,true);
		//}
		//$myfile = fopen($work, "w");	
		//fwrite($myfile, json_encode($request));
		//fclose($myfile);
		//$myfile = fopen($config, "w");
		//fwrite($myfile, json_encode(getConfig($user,$request["requestID"])));
		//fclose($myfile);
		echo  passthru($command);
		//echo $command;
	}
	
	function checkForErrors(){
		$errors = false;
		if(!(json_last_error() == JSON_ERROR_NONE)) $errors = true ;
		
		return $errors;
	}
	
	
  