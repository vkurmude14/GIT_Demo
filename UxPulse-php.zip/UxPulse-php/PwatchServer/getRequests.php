<?php
	session_start();
	require ("config.php");
	require_once('..\\mongoUtil.php');
	try{
        //$connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
		//  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $users= $connection->selectCollection(DB_NAME,'users');
		$user = $_SESSION['user'];
	}
    catch(MongoClientException $e){      
        error_log($e);	
		echo json_encode($e);
    }
    catch(Exception $e){
        error_log($e);		
		echo json_encode($e);
    }
	
        $query = array("_id"=>$user);
		$field = array("requests"=>1,"_id"=>0);
	
		$requests = $users->findone($query,$field);
		$response = array();
		if($requests===null){echo "{}";die();}
	
		
        foreach($requests['requests'] as $key => $value){
			array_push($response,$value["requestID"]);
			
		echo json_encode($response);
	}
