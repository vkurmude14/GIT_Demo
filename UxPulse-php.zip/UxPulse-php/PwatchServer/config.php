<?php
//time-zone setting
date_default_timezone_set ("Asia/Kolkata");
ini_set('mongo.long_as_object', 1);
//db settings
define ('DB_HOST', "localhost");
define ('DB_PORT', "27017");
define ('DB_NAME', "UxPulse");
define ('DB_USER', "user");
define ('DB_PASS', "user123");
//required by pwatchcore(pc)
define ('PC', "Kelloggs_may14th.jar");
//define ('PC', "pWatch_16May_1.jar");
define ('PC_TIMEOUT', "47000");//seconds
define ('PC_PING', "30");//seconds
define ('PC_KEY', serialize(array("c0b921a4c351419499f6afb5519509c8", "e544eee78c0a44889b1a137d7310956a", "d8b57dc9c1384d5eb3f479ba228aa65d","85419f04ca9b4771b9da7823d70ea79d" )));//1000key
//define ('PC_KEY', "e544eee78c0a44889b1a137d7310956a");//200key
//wptKey d8b57dc9c1384d5eb3f479ba228aa65d //200 key used
//define ('PC_KEY', "85419f04ca9b4771b9da7823d70ea79d");//200key-notMuchUsed
define ('SYS_PROXY',"true");
define ('SYS_PROXY_HOST',"172.22.218.218");
define ('SYS_PROXY_PORT',"8085");
define ('SYS_NOPROXYHOSTS',"localhost|10.60.224.22|172.17.26.48");
//required by scheduler
//when user is logged out
define ('SYS_USER',"M1049117@mindtree.com");
define ('SYS_PASS','Amma@123');
