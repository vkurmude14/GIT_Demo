<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
	require_once ("config.php");
	require_once('..\\mongoUtil.php');
	header("Content-Type","application/json");
	session_start();
	$invalid = false;
	
	if(isset($_GET["request"]))$request = $_GET["request"];
	else $invalid = true;
	if(isset($_GET["label"]))$label = $_GET["label"];
	else $label = '';
	if(isset($_GET["location"]))$location = $_GET["location"];
	else $location = '';
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	else $schedule = '';
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else $invalid = true;
	
	$labels=array();
	if($invalid){
		echo "error";
		die();
	}
	if($label==''){
	$labels = array();
	        require_once "../PwatchServer/getRequestDetails_ReportConfig.php";
	foreach ($echodata as $echo){  
	  foreach ($echo['runs'] as $run){ 
	    if($run['request']['isCustomer']){  
		 // $run['request']['label'] urlOrScript
		$label[]=trim($run['request']['label']," ");
    }}}
	$labels=array_unique($label);
	}
	else{
		$labels[]=$label;
	}
$audits=null;
  foreach($labels as $lab){
	  unset($locations);
	  unset($location1);
	  //$location1=null;
	//$locations=null;
	//echo($lab);
   if($location==''){
	   try{
        require_once "../PwatchServer/getRequestDetails_ReportConfig.php";
	      foreach ($echodata as $echo){  
	       foreach ($echo['runs'] as $run){ 
			 if($run['request']['isCustomer']&& $run['request']['label']==$lab){  
			 //$run['request']['label'] urlOrScript
			$location1[]=$run['request']['location'];
			}}}
		$locations=array_unique($location1);		
	}
	catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
	}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
   }
   else{
	   $locations[]=$location;
   }
   
	
		$connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'requests');
		//echo($locations);
		//for($loc=0;$loc<count($locations);$loc++){
		foreach($locations as $local){
			//echo($locations[$loc]);
		$query = array("requestID"=>$request,"scheduleID"=>$schedule,"request.label"=>$lab,'status'=>'COMPLETE','request.location'=>$local);	
		 $cursor = $collection->findone($query);
		 
		 if($cursor===null){echo "{}";die();}
		 $result=$cursor;
			 $data=$result['data'];
			 if(isset($data['lighthouse'])){
			  $test=$data['lighthouse'];
				$perfCount=count($test['reportCategories'][0]["audits"]);
				$perf=$test['reportCategories'][0]["audits"];
				
				for($i=0;$i<$perfCount;$i++){
					if(isset($perf[$i]['group'])&&$perf[$i]['group']=="perf-hint"){
						//&&$perf[$i]['score']!=100
						$audit=null;
						//$audit[$perf[$i]['id']]=array();
						$RUrls=array();
						for($j=0;isset($perf[$i]['result']['extendedInfo']['value']['results'])&&$j<count($perf[$i]['result']['extendedInfo']['value']['results']);$j++){
							array_push($RUrls,$perf[$i]['result']['extendedInfo']['value']['results'][$j]['url']);	
						}
						 $audit["components"]=$RUrls;
						 if (count($audits)==0||!array_key_exists($perf[$i]['id'], $audits)) {
							 $audits[$perf[$i]['id']]["score"]=$perf[$i]['score'];
						 $audits[$perf[$i]['id']]=$audit;
						 
						 }
						 else{
							$audits[$perf[$i]['id']]["score"]= $audits[$perf[$i]['id']]["score"]+$perf[$i]['score'];
							 for($j=0;$j<count($audit['components']);$j++){
						 if(!in_array($audit['components'][$j], $audits[$perf[$i]['id']]['components'])){
					    array_push($audits[$perf[$i]['id']]['components'],$audit['components'][$j]);
						 }
					 }
							// array_push($audits[$perf[$i]['id']]['urls'],$audit["urls"]);
						 }
						 
					}
				}
			 }
			$audits; 
		}
}
	//echo "var LighthouseData = ";
	echo json_encode($audits);	
	//echo ";" 	;
		
	
	