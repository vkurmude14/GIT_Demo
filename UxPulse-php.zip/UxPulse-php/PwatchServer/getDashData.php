<?php
	require ("config.php");
	require_once('..\\mongoUtil.php');
	require_once('..\\mongoUtil.php');
	header("Content-Type:application/javascript");
	error_reporting(0);
	session_start();
	$invalid = false;
	
	if(isset($_GET["request"]))$request = $_GET["request"];
	else	$invalid = true;
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	else $schedule="";
	//else	$invalid = true;
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else 	$invalid = true;
	
	try{
       // $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
      //  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
		$collection = $connection->selectCollection(DB_NAME,'requests');
	}
    catch(MongoClientException $e){
        error_log($e);
        echo '{"error":"Failure in Database Connection"}';
    }
    catch(Exception $e){
        error_log($e);
    }
	if($invalid){
		echo "//error";
	die();
	}
		//$users = $connection->selectCollection(DB_NAME,'users');
		//$query = array("_id"=>$user,"requests.".$request=>array('$exists'=>"true"));
		//$res = $users->findOne($query,array("_id"=>1));
		//if($res==null) die("Invalid Request Id");
				
		$rundata = array(); 
		if($schedule!=""){
		$query = array("requestID"=>$request,"scheduleID"=>$schedule);
		}
		else{
			$query = array("requestID"=>$request);
		}
        $cursor = $collection->find($query);
		
		$index = 0;
		foreach($cursor as $run){
				
				$obj = array();
				$firstView = array();
				$repeatView = array();
				$metrics = array();
				$location = array();				
				$components = array();
				
				if( $run["status"]!=="COMPLETE")
					continue;
				 
				$location = explode(':', $run["data"]["location"]);
				if(count($location) < 2) $location = explode('_', $run["request"]["location"]);
				if(!isset($run["data"]))continue;
				if(!isset($run["data"]["firstView"]))continue;
				if(!isset($run["data"]["repeatView"]))continue;
				
				if(isset($run["data"]["firstView"])){
					$firstView["fullyloaded"] = $run["data"]["firstView"]["fullyLoaded"]/1000 ;
					$firstView["startrender"] = $run["data"]["firstView"]["render"]/1000 ;
					$firstView["doccomplete"] = $run["data"]["firstView"]["docTime"]/1000 ;
					$firstView["visuallycomplete"]= $run["data"]["firstView"]["visualComplete"]/1000;
					if(array_key_exists('requestsDoc', $run["data"]["firstView"])){
						$firstView["requests"] = $run["data"]["firstView"]["requestsDoc"] ;
					}
					if(array_key_exists('bytesIn', $run["data"]["firstView"])){
						$firstView["bytesin"] = $run["data"]["firstView"]["bytesIn"]/1024 ;
					}
					$firstView["rtt"] = $run["data"]["firstView"]["server_rtt"] ;
					$firstView["TTFB"] = $run["data"]["firstView"]["TTFB"]/1000;
					if(array_key_exists('domains', $run["data"]["firstView"])){
						$firstView["domains"] = $run["data"]["firstView"]["domains"] ;
					}
					if(array_key_exists('breakdown', $run["data"]["firstView"])){
						$firstView["breakdown"] = $run["data"]["firstView"]["breakdown"] ;	
					}
					
					$metrics["firstView"] = $firstView;
				}
				
				if(isset($run["data"]["repeatView"])){
					$repeatView["fullyloaded"] = $run["data"]["repeatView"]["fullyLoaded"]/1000 ;
					$repeatView["startrender"] = $run["data"]["repeatView"]["render"]/1000 ;
					$repeatView["doccomplete"] = $run["data"]["repeatView"]["docTime"]/1000 ;
					$repeatView["visuallycomplete"]=$run["data"]["repeatView"]["visualComplete"]/1000;
					if(array_key_exists('requests', $run["data"]["repeatView"])){
						$repeatView["requests"] = $run["data"]["repeatView"]["requestsDoc"] ;
					}
					if(array_key_exists('bytesIn', $run["data"]["repeatView"])){
						$repeatView["bytesin"] = $run["data"]["repeatView"]["bytesIn"]/1024 ;
					}
					$repeatView["rtt"] = $run["data"]["repeatView"]["server_rtt"] ;
					$repeatView["TTFB"] = $run["data"]["repeatView"]["TTFB"]/1000;
				//	$repeatView["domains"] = $run["data"]["repeatView"]["domains"] ;
				//	$repeatView["breakdown"] = $run["data"]["repeatView"]["breakdown"] ;			
				
				
					$metrics["repeatView"] = $repeatView;
					
				}
			
				//slow and heavy component
				if(isset($run["recommondations"]["comps"])){
					$comps=$run["recommondations"]["comps"];
					usort($comps,function($a,$b){
						return $b["size"] - $a["size"];
					});
					$components['heavy'] = array_slice($comps,0,5); 
					usort($comps,function($a,$b){
						return $b["resp"] - $a["resp"];
					});
					$components['slow'] = array_slice($comps,0,5); 
					
				}
							
				
				$obj['index']= ++$index;
				$obj['group']=$run["groupID"];
				if(count($location)>0)
				$obj['location']= $location[0];
				if(count($location)>1)
				$obj['browser']= $location[1];				
				
				$obj['network']= $run["request"]["network"];
				$obj['date']=$run["data"]["completed"]*1000;
				$obj['latency']=$run["data"]["latency"];
				$obj['label']= $run["request"]["label"];
				$obj['urlOrScript']= $run["request"]["urlOrScript"];
				$obj['testID']= $run["testID"];
				$obj['metrics']= $metrics;
				$obj['isCustomer']=$run["request"]["isCustomer"]?"true":"false";				
				
				$obj['components']= $components;
				
				array_push($rundata,$obj);
			}
		
		echo "var result = ";
		echo json_encode($rundata);
		echo ";";
	
