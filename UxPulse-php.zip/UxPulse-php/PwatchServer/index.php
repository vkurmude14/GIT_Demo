<?php
echo "pWatch Server";
echo "<br>";
echo "Version : 0.6";
echo "<br>";
echo "Version Date : 6th July 2015 18:49:33 AM";