<?php
	require ("config.php");
	require_once('..\\mongoUtil.php');
	header("Content-Type:application/javascript");
	session_start();
	$invalid = false;
	
	if(isset($_GET["request"]))$request = $_GET["request"];
	else	$invalid = true;
	//if(isset($_SESSION['user']))$user = $_SESSION['user'];
	//else 	$invalid = true;
	
	try{
       // $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
       //  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
		$collection = $connection->selectCollection(DB_NAME,'requests');
	}
    catch(MongoClientException $e){
        error_log($e);
        echo '{"error":"Failure in Database Connection"}';
    }
    catch(Exception $e){
        error_log($e);
    }
	if($invalid){
		echo "//error";
	die();
	}
	//functions
	function filter($flatdata,$key,$value){
		$temp = array_filter($flatdata,function($element) use ($key, $value){
				return $element[$key]==$value;//compare 
			}
		);
		return $temp;
	}	
	
	function reduceAr($array,$keys1){
		
		$init = array();
		$keys0 = ["firstView","repeatView"];
		$keys = ["startrender","doccomplete","fullyloaded"];
		foreach($keys0 as $key0){
			$init[$key0] = array();
			foreach($keys as $key1){
				$init[$key0][$key1] = 0;
			}
		}
		$rd = array_reduce($array,"reduceSum",$init);
		$ra = array();
		$c = count($array);
		if($c!=0){
			foreach($keys0 as $key0){
				$ra[$key0]= array();
				foreach($keys1 as $key1){
					$ra[$key0][$key1] = $rd[$key0][$key1]/$c;
				}
			}
		}
		return $ra;
	}
	function reduceSum($p,$v){
		$m = $v["metrics"];
		foreach($m as $k1=>$v1){
			foreach($v1 as $k2=>$v2){
					$p[$k1][$k2]+=$v2;
				}
			}
		return $p;
	}
	//fetching data from base
	//$users = $connection->selectCollection(DB_NAME,'users');
	//$query = array("_id"=>$user,"requests.".$request=>array('$exists'=>"true"));
	//$res = $users->findOne($query,array("_id"=>1));
	//if($res==null) die("Invalid Request Id");
	
	$rundata = array(); 
    $query = array("requestID"=>$request);
	$field = array();
	$cursor = $collection->find($query,$field);
	$flatdata = array();
		
	$summary = array();
	$summary['group'] = array();
	$summary['location'] = array();
	$summary['browser'] = array();
	$summary['network'] = array();
	$summary['label'] = array();
		
	
		foreach ($cursor  as $run){
			$obj = array();
			$firstView = array();
			$repeatView = array();
			$metrics = array();
			
			//if( $run["status"]!=="COMPLETE")
			//	continue;
			
			$location = explode(':', $run["request"]["location"]);
			if(count($location) < 2) $location = explode('_', $run["request"]["location"]);
				
			if(!isset($run["data"]))continue;
			if(!isset($run["data"]["firstView"]))continue;
			if(!isset($run["data"]["repeatView"]))continue;
			if(isset($run["data"]["firstView"])){
					$firstView["fullyloaded"] = $run["data"]["firstView"]["fullyLoaded"]/1000 ;
					$firstView["startrender"] = $run["data"]["firstView"]["render"]/1000 ;
					$firstView["doccomplete"] = $run["data"]["firstView"]["docTime"]/1000 ;
					
					$metrics["firstView"] = $firstView;
			}
				
			if(isset($run["data"]["repeatView"])){
					$repeatView["fullyloaded"] = $run["data"]["repeatView"]["fullyLoaded"]/1000 ;
					$repeatView["startrender"] = $run["data"]["repeatView"]["render"]/1000 ;
					$repeatView["doccomplete"] = $run["data"]["repeatView"]["docTime"]/1000 ;
									
					$metrics["repeatView"] = $repeatView;					
			}
			$obj['group']=$run["groupID"];
			$obj['location']= $location[0];
			$obj['browser']= $location[1];				
			$obj['network']= $run["request"]["network"];				
			$obj['label']= $run["request"]["label"];
			$obj['isCustomer']=$run["request"]["isCustomer"]?"true":"false";
			$obj['metrics']= $metrics;
			
			$summary['group'][$run["groupID"]]=true;
			$summary['location'][$location[0]] =true;
			$summary['browser'][$location[1]] =true;				
			$summary['network'][$run["request"]["network"]]= true;
			$summary['label'][$run["request"]["label"]]= true;
			array_push($flatdata,$obj);
		}	
	//reducing data
	
	$filters = array("location","browser","network");
	$data = array();
	
	$keys1 = ["startrender","doccomplete","fullyloaded"];
	
	$type = "label" ;
	foreach($summary[$type] as $item=>$v){
		$data[$type][$item] = reduceAr(filter($flatdata,$type,$item),$keys1);
	}
	
	$keys1 = ["doccomplete"];
	
	
		
	foreach($filters as $type){
		$ndata[$type]=array();
		foreach($summary["label"] as $item1=>$v){
			$ndata[$type][$item1]=array();
			$filData = filter($flatdata,"label",$item1);
			foreach($summary[$type] as $item2=>$v){
				$ndata[$type][$item1][$item2] = reduceAr(filter($filData,$type,$item2),$keys1);
			}
		}
	}
	
	
	//foreach($filters as $type){
//		$data[$type]=array();
		//foreach($summary[$type] as $item=>$v){
//			$data[$type][$item] = reduceAr(filter($flatdata,$type,$item),$keys1);
		//}
	//}
	$returnData = array();
	$sum=array();
	//formatting data	
	foreach($summary as $key=>$type){
		$sum[$key]=array();
		foreach($type as $item=>$v){
			array_push($sum[$key],$item);
		}
	}
	//sending data
	 //echo "/*Modified: ".date("d/m/y G:i:s T*/");
	 
	
	 echo "var summary=";
	 echo json_encode($sum);
	 echo ";";
	 echo "var chartData=";
	 echo json_encode($data);
	 echo ";";
	
	 echo "var csvData=";
	 echo json_encode($ndata);
	 echo ";";

	
	//echo json_encode(array("sum"=>$sum,"data"=>$data,"ndata"=>$ndata));
	//sending data
	