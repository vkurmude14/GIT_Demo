<?php
// setting up things
function getCollection($name) {
	try {
		//$connection = new MongoClient ( 'mongodb://' . DB_HOST . ':' . DB_PORT );
		$connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$collection = $connection->selectCollection ( DB_NAME, $name );
	} catch ( MongoClientException $e ) {
		// TODO default
		throw $e;
	} catch ( Exception $e ) {
		// TODO default
		throw $e;
	}
}
function getVar($name, $type = 'default') {
	switch ($type) {
		case 'post' :
		case 'POST' :
			if (isset ( $_POST [$name] ))
				$value = $_POST [$name];
			else
				throw "InvalidVariableName:$name in POST";
			break;
		case 'get' :
		case 'GET' :
			if (isset ( $_GET [$name] ))
				$value = $_GET [$name];
			else
				throw "InvalidVariableName:$name in GET";
		default :
			throw "InvalidType:$type";
	}
}
function getVar($name, $type = 'No $type Given') {
	switch ($type) {
		case 'post' :
		case 'POST' :
			if (isset ( $_POST [$name] ))
				$value = $_POST [$name];
			else
				throw "InvalidVariableName:$name in POST";
			break;
		case 'get' :
		case 'GET' :
			if (isset ( $_GET [$name] ))
				$value = $_GET [$name];
			else
				throw "InvalidVariableName:$name in GET";
		default :
			throw "InvalidType:$type";
	}
}

?>