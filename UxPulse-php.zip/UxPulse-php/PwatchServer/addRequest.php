
<?php
	require ("config.php");
	require_once('..\\mongoUtil.php');
	header("Content-Type","application/json");
	$invalid = false;
	
	//if(!isset($_POST["request"]))$invalid = true;
	//if(!isset($_SESSION['user']))$invalid = true;
	
	if($invalid){
	die();}
	
	try{
       // $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
	  //  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $users= $connection->selectCollection(DB_NAME,'users');
		
		$json = '{"label":"PTCOE","tasks":[{"location":"Test:Firefox","urlOrScript":"http:\/\/www.mindtree.com","server":"http:\/\/a2md19234","label":"mindtree","isScript":"false","network":"Cable"},{"location":"Test:Chrome","urlOrScript":"http:\/\/www.mindtree.com","server":"http:\/\/a2md19234","label":"mindtree","isScript":"false","network":"Cable"},{"location":"Test:Firefox","urlOrScript":"http:\/\/www.mindtree.com","server":"http:\/\/a2md19234","label":"mindtree","isScript":"false","network":"Cable"},{"location":"Test:Chrome","urlOrScript":"http:\/\/www.mindtree.com","server":"http:\/\/a2md19234","label":"mindtree","isScript":"false","network":"Cable"}],"requestID":"PTCOE"}';
		//TODO hard-coded  $json = $_POST['request'];
		$request = json_decode($json);
		
		////TODO hard-coded $user = $_SESSION['user'];
		$user = "Chitkarsh";
		
		if(json_last_error() != JSON_ERROR_NONE){
			throw '{"JSONParseException":$json}';
		}
	}
    catch(MongoClientException $e){       
        //echo '{"error":"Failure in Database Connection"}';
		echo json_encode($e);
    }
    catch(Exception $e){
        error_log($e);
		//echo '{"error":"Failure in Database Connection"}';
		echo json_encode($e);
    }
		
        $query = array("_id"=>$user);
		$value = array("requests"=>$request);
		
        $response = $users->update($query,array('$push'=>$value));
		
		echo json_encode($response);