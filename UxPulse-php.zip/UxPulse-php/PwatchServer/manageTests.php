<?php
	require ("config.php");
	require_once("..\\mongoUtil.php");
	header("Content-Type","application/json");
	session_start();
	$invalid = false;
	
	if(isset($_GET["request"]))$request = $_GET["request"];
	else $invalid = true;
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else $invalid = true;
	
	//else $invalid = true;
	if(isset($_GET["manageType"]))$manageType = $_GET["manageType"];
	else $invalid = true;
	if($invalid){
		echo "error";
		die();
	}
	else{
		if($manageType=='delete'){
			$echodata='';
			$connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'requests');
			if(isset($_SESSION['selectedtests'])){
				$selectedtests = $_SESSION['selectedtests'];
		   foreach($selectedtests as $selected) {
		    $collection->remove(array("_id"=>$selected));
			//echo($selected);
			$echodata=$echodata.'  tests deleted Successful';
		     }
			 unset($_SESSION['selectedtests']);
			}
			if(isset($_SESSION['selectedgroups'])){
				$selectedgroups = $_SESSION['selectedgroups'];
				foreach($selectedgroups as $selected) {
		        $collection->remove(array("groupID"=>$selected));
				$echodata=$echodata.'delete groups mode successful';
		      }
				unset($_SESSION['selectedgroups']);
			}
			if(isset($_SESSION['selectedrequests'])){
				$selectedrequests = $_SESSION['selectedrequests'];
				foreach($selectedrequests as $selected) {
					echo($selected);
		        $collection->remove(array("requestID"=>$selected));
				// $collection1 = $connection->selectCollection(DB_NAME,'users');
				 //$collection1->remove(array("requestID"=>$selected));
				$echodata=$echodata.'delete selected requests mode successful';
		      }
				unset($_SESSION['selectedrequests']);
			}
		}
		//$_SESSION['message'] = $echodata;
		//header("Location: ../?request=".$request."&message=".$echodata);
 	echo "var message = ";
	echo json_encode($echodata);	
	echo ";" 	;
	}
	