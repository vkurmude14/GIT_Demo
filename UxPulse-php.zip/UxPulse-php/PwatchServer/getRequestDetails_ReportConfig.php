
<?php
	require_once ("config.php");
	require_once('..\\mongoUtil.php');
	header("Content-Type","application/json");
	session_start();
	$invalid = false;
	
	if(isset($_GET["request"]))$request = $_GET["request"];
	else $invalid = true;
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	else $invalid = true;
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else $invalid = true;
	
	if($invalid){
		echo "error";
		die();
	}

	
	try{
       // $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
	  //  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'requests');
	}
    catch(MongoClientException $e){
        error_log($e);
        echo '{"error":"Failure in Database Connection"}';
		die();
    }
    catch(Exception $e){
        error_log($e);
		//echo ($e);
		die();
    }
		//$users = $connection->selectCollection(DB_NAME,'users');
		//$query = array("_id"=>$user,"requests.".$request=>array('$exists'=>"true"));
		//$res = $users->findOne($query,array("_id"=>1));
		//if($res==null) die("Invalid Request Id");
	    $query = array("requestID"=>$request,"scheduleID"=>$schedule);
		$fields = array("status"=>1,"groupID"=>1,"errors"=>1,"start"=>1,"request"=>1,"testID"=>1,"statusText"=>1);
        $cursor = $collection->find($query,$fields);
		$index = 0;
		$rundata = array(); 
		if($cursor===null){echo "{null}";die();}
		foreach ($cursor as $run) {
			if(!array_key_exists ( $run["groupID"] ,$rundata)){
				$rundata[$run["groupID"]] = array();
				$rundata[$run["groupID"]]["runs"] = array();
				$rundata[$run["groupID"]]["complete"] = 0;
				$rundata[$run["groupID"]]["failed"] = 0;
				$rundata[$run["groupID"]]["running"] = 0;
			}
			if($run["status"]=="COMPLETE")$rundata[$run["groupID"]]["complete"]++;
			else if($run["status"]=="FAILED")$rundata[$run["groupID"]]["failed"]++;
			else $rundata[$run["groupID"]]["running"]++;
			array_push($rundata[$run["groupID"]]["runs"],$run);
		}
		$arr = array();
		
	
	$echodata = [];
	foreach ($rundata as $key => $value){
		$value["group"] = $key;
		if($value["running"]>0)
				$value["status"] = "RUNNING";
			else if($value["failed"]==0&&$value["complete"]>0)
				$value["status"] = "COMPLETED";
			else if($value["complete"]==0)
				$value["status"] = "FAILED";
			else 
				$value["status"] = "PARTIAL";
		$echodata[] = $value;

    }
	
		
	//echo "var data = ";
	//echo json_encode($echodata);	
	//echo ";"	;