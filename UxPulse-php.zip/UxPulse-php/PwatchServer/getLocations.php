<?php
	if(isset($_GET["request"]))$request = $_GET["request"];
	else{
		http_response_code(400);
		echo "400 Bad Request: request parameter not set";
		die();
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	else{
		http_response_code(400);
		echo "400 Bad Request: request parameter not set";
		die();
	}
	$locations = array();
	try{
		
		include "../PwatchServer/getRequestDetails_ReportConfig.php";
										   
												                                          
                                             foreach ($echodata as $echo)
                                              {  
											     foreach ($echo['runs'] as $run){ 
													 if($run['request']['isCustomer']&& $run['request']['label']==$label){  
											             //$run['request']['label'] urlOrScript
														 
													$location[]=$run['request']['location'];
                                 
													}}}
										             $locations=array_unique($location);
				
	}
	catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
	}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
	header("Content-Type:application/json");
	if($locations){
	echo json_encode($locations);
	}
	else{
		http_response_code(404);
		die();
	}
	
	
	?>
