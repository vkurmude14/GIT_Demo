<?php
	
	require ("config.php");
	header("Content-Type","application/json");
	

	session_start();
	$invalid = false;
	
	//echo json_encode($_POST);	
	if(!isset($_POST["startDate"]))$invalid = true;
	if(!isset($_POST["endDate"]))$invalid = true;
	if(!isset($_POST["interval"]))$invalid = true;
	if(!isset($_POST["intervalUnit"]))$invalid = true;
	if(!isset($_POST["request"]))$invalid = true;
	if(!isset($_SESSION['user']))$invalid = true;
	
	
	if($invalid){
		echo "error";
	die();}
	
	$sDate = $_POST["startDate"];		
	$eDate = $_POST["endDate"];
	$interval = $_POST["interval"];
	$intervalUnit = $_POST["intervalUnit"];	            
	$user = $_SESSION["user"];
	$request = json_decode($_POST["request"],true);
	//echo json_last_error();
	//echo json_encode($request);
	$request["requestID"] = $request["label"];
	//echo "Ravi".$request["requestID"];
	$request["taskname"] = $user.'-'.$request["requestID"];
	$taskname =$request["taskname"];
	//file_put_contents ( "err.txt", json_encode($request).PHP_EOL, FILE_APPEND ); 
	//file_put_contents ( "err.txt", json_encode($request)['label']. PHP_EOL, FILE_APPEND ); 
	//file_put_contents ( "err.txt", json_encode($request)['requestID']. PHP_EOL, FILE_APPEND ); 
	
	$work = getcwd()."\\users\\".$user."\\".$request["requestID"]."\\work.json";
	$config = getcwd()."\\users\\".$user."\\".$request["requestID"]."\\config.json";
	$taskrun = "java -jar ".getcwd()."\\".PC." ".$work." ".$config ;
	
	
	switch ($intervalUnit) {
    case "DAILY":
        $intervalCommand = " /SC DAILY /MO ".$interval;
		break;
        
    case "HOURLY":
		$intervalCommand = " /SC DAILY /MO 1 /DU 24:00 /RI ".$interval*60;
        break;
		
    case "MINUTE":
		$intervalCommand = " /SC DAILY /MO 1 /DU 24:00 /RI ".$interval;
        break;
		
	case "WEEKLY":
        $intervalCommand = " /SC WEEKLY /MO ".$interval;
		break;	
	}

	$command = "schtasks /Create".
			" /RU ".SYS_USER.
			" /RP ".SYS_PASS.
			" /TN ".$taskname.
			" /TR \"".$taskrun."\"".
			" /SD ".date("d.m.Y",strtotime($sDate)).
			" /ST ".date("H:i",time() + 60).
			" /ED ".date("d.m.Y",strtotime($eDate.' +1day')).
			" /F ".
			$intervalCommand.
		"";
	
	//echo $command;
	file_put_contents ( "err.txt", $request['requestID']. PHP_EOL, FILE_APPEND ); 
	try{
        $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
        $collection = $connection->selectCollection(DB_NAME,'users');
		$q = array("_id"=>$user);
		
		if($collection->find($q)->count()==1){
			$o = array('$set'=>array("requests.".$request["requestID"]=>$request));
			
			//$collection->update($q,$o);
		}
		error_log("Database Inconsistent");
	}
    catch(MongoClientException $e){
        error_log($e);
		echo $e;
        echo '{"error":"Failure in Database Connection"}';
		die();
    }
    catch(Exception $e){
        error_log($e);
		echo $e;
		echo '{"error":"Failure in Database Connection"}';
		die();
    }
	
	if(!checkForErrors()){
		if(!file_exists ("users\\".$user."\\".$request["requestID"] )){
			mkdir("users\\".$user."\\".$request["requestID"], 0700,true);
		}
		$myfile = fopen($work, "w");	
		fwrite($myfile, json_encode($request));
		fclose($myfile);
		$myfile = fopen($config, "w");
		fwrite($myfile, json_encode(getConfig($user,$request["requestID"])));
		fclose($myfile);
		echo  passthru($command);
		//echo $command;
	}
	
	function checkForErrors(){
		$errors = false;
		if(!(json_last_error() == JSON_ERROR_NONE)) $errors = true ;
		
		return $errors;
	}
	
	function getConfig($a,$b){
		$configs = array();
		$configs["dbhost"] = DB_HOST;
		$configs["dbport"] = DB_PORT;
		$configs["dbname"] = DB_NAME;
		$configs["dbuser"] = DB_USER;
		$configs["dbpass"] = DB_PASS;
		$configs["timeout"] = PC_TIMEOUT;
		$configs["pingInterval"] = PC_PING;
		$configs["apiKey"] = PC_KEY;
		$configs["useProxy"] = SYS_PROXY;
		$configs["proxyHost"] = SYS_PROXY_HOST;
		$configs["proxyPort"] = SYS_PROXY_PORT;
		$configs["nonProxyHosts"] = SYS_NOPROXYHOSTS;	
		$configs["logpath"] = getcwd()."\\logs\\".$a."\\".$b."\\";
		$configs["harpath"] = getcwd()."\\hars\\".$a."\\".$b."\\";
	//	echo json_encode($configs);
		return $configs;
	}
  