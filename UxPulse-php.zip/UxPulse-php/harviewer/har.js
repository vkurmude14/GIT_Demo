(function(){
	functiond(a,
	b,
	c,
	d){
		d=d||!1,
		a.addEventListener?a.addEventListener(b,
		c,
		d): a.attachEvent("on"+b,
		c)
	}functionc(){
		varb=[];if(document.getElementsByClassName)b=document.getElementsByClassName("har");elseif(document.getElementsByTagName){
			varc=document.getElementsByTagName("div");for(vard=0;d<c.length;d++){
				vare=c[d].className;e&&e.match(a)&&b.push(c[d])
			}
		}varf=[];for(vard=0;d<b.length;d++)f.push(b[d]);returnf
	}functionb(b){
		varc=b.className.replace(a,
		" ");b.className=c.replace(/^\s*|\s*$/g,
		"")
	}window.harInitialize=function(){
		vara=document.getElementById("har"),
		d=a.src.lastIndexOf("/"),
		e=a.src.substr(0,
		d+1),
		f=c();for(varg=0;g<f.length;g++){
			varh=f[g],
			i=h.getAttribute("data-har");if(!i)continue;varj=h.getAttribute("width"),
			k=h.getAttribute("height"),
			l=h.getAttribute("expand"),
			m=h.getAttribute("validate"),
			n="?"+(i.indexOf("http:")==0?"inputUrl": "path")+"="+i;l!="false"&&(n+="&expand="+(l?l: "true")),
			m=="false"&&(n+="&validate=false");varo=document.createElement("iframe");o.setAttribute("style",
			"border: 1px solid lightgray;"),
			o.setAttribute("frameborder",
			"0"),
			o.setAttribute("width",
			j?j: "100%"),
			o.setAttribute("height",
			k?k: "150px"),
			o.setAttribute("src",
			e+"preview.php"+n),
			h.appendChild(o),
			b(h)
		}
	};vara=newRegExp("(^|\\s)har(\\s|$)",
	"g");harInitialize(),
	d(window,
	"load",
	harInitialize,
	!1)
})()