<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>HTTP Archive Preview 2.0.15</title>
</head>
<body style="margin:0">
    <div id="content" version="2.0.15"></div>
    <script src="scripts/jquery.js"></script>
    <script data-main="scripts/harPreview" src="scripts/require.js"></script>
    <link rel="stylesheet" href="css/harPreview.css" type="text/css"/>
	<script>
    $("#content").bind("onPreviewInit", function(event)
	{
		var viewer = event.target.repObject;
		viewer.loadHar("http://d1ml09858:8080/pwatchWeb/har/1436161500546/150706_TC_d42e243ef9b017ee26c79712bef27d2c.har");
	});
	</script>
</body>
</html>
