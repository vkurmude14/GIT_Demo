
    <?php
		$path = $_GET["harfile"];
		$testIdArray = explode("/",$path);
		$testId = $testIdArray[sizeof($testIdArray)-1];
		echo "<img src=data:image/png;base64,";
		echo base64_encode(file_get_contents("http://www.webpagetest.org/waterfall.php?test=".$testId));
		echo "></img>";
	?>
