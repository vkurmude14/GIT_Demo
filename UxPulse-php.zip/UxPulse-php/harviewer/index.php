<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>UxPulse HAR Viewer</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="css/harViewer.css" type="text/css"/>
</head>
<body class="harBody">
    <h1>UxPulse HAR Viewer </h1>
	<div id="content" version="test"></div>
    <script src="scripts/jquery.js"></script>
    <script data-main="scripts/harViewer" src="scripts/require.js"></script>
	<script>
	<?php
		session_start();
		if(isset($_GET['harfile']))echo "var request = '".$_GET['harfile']."';";
		//if(isset($_SESSION['user']))echo "var user = '".$_SESSION['user']."';";
		
	?>
		
	
	</script>
	<script>
	$("#content").bind("onViewerPreInit", function(event)
	{
		// Get application object
		var viewer = event.target.repObject;
		console.log('viewer');
		console.log(viewer);
		// Remove unnecessary tabs
		viewer.removeTab("Home");
		viewer.removeTab("DOM");
		viewer.removeTab("About");
		viewer.removeTab("Schema");
		//viewer.removeTab("Preview");

		// Hide the tab bar
		viewer.showTabBar(false);
		
		var preview = viewer.getTab("Preview");
		preview.showStats(true);
		preview.showTimeline(false);
		
		
		//?harfile=../PwatchServer/hars/awadhoot/mindtree/1453899840381/160127_9C_229f3aa6b3945ef24afe497c3ac1b72b.har
		//?harfile=http://localhost:9090/mobilon/harviewer/examples/Bloomberg_Dulles_Chrome.Cable.140311_2H_38dff75463b97a890b68c6f3e905f2eb.har
		//viewer.loadHar("http://localhost:9090/mobilon/harviewer/examples/Bloomberg_Dulles_Chrome.Cable.140311_2H_38dff75463b97a890b68c6f3e905f2eb.har");
		//viewer.loadHar("D:\Work\Projects\2014\MobileMonitoring\Web\harviewer\examples\google.com.har");
		//var harfile = getUrlParameter('harfile');
		console.log('request is');
		console.log(request);
		var path = "../PwatchServer/hars/"+request+".har";
		console.log('har path');
		console.log(path);
		viewer.loadHar(path);
	});
	
	function getUrlParameter(sParam)
	{	console.log('sPageURL');
		console.log(sPageURL);
		console.log(sParam);
		var sPageURL = window.location.search.substring(1);
		var sURLVariables = sPageURL.split('&');
		for (var i = 0; i < sURLVariables.length; i++) 
		{
			var sParameterName = sURLVariables[i].split('=');
			if (sParameterName[0] == sParam) 
			{
				return sParameterName[1];
			}
		}
	}  
	</script>
	 <!--  http://localhost:9090/mobilon/harviewer/index.php?harfile=http://localhost:9090/mobilon/harviewer/examples/Bloomberg_Dulles_Chrome.Cable.140311_2H_38dff75463b97a890b68c6f3e905f2eb.har -->
</body>
</html>