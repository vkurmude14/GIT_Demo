<?php
	require ("../pwatchserver/config.php");
	//header("Content-Type:application/javascript");
	set_time_limit(600);
	session_start();
	$invalid = false;
	
	//$_SESSION['user'] = "demo";
	$response = array();
	
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else{
		http_response_code(403);
	echo "403 Forbidden: session login required";
		die();
	}
	if(isset($_GET["request"]))$request = $_GET["request"];
	else{
		http_response_code(400);
		echo "400 Bad Request: request parameter not set";
		die();
	}
	if(isset($_GET["schedule"])&&$_GET["schedule"]!=null)$schedule = $_GET["schedule"];
	else{
		$schedule='';
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	else{
		http_response_code(400);
		echo "400 Bad Request: label parameter not set";
		die();
	}
	if(isset($_GET["tag"]))$tag = $_GET["tag"];
	else{
		http_response_code(400);
		echo "400 Bad Request: tag parameter not set";
		die();
	}
	//'combine','etags','cookies'
	$tags= array('OnPageRedirects','keep-alive','gzip','compress','progressive_jpeg','minify','cache','cdn','renderBlockingJs','cssDelivery','BrowserResponseTime');
	//$tags= array('renderBlockingJs');
	try{
		
		$connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
		$runs = $connection->selectCollection(DB_NAME,'requests');
		//$variable='data.firstView.score_'.$tag;
		//,'request.location'=>'{'$regex':'.*:Chrome'}'
		if($label=="ALL"){
			if($schedule!=''){
			$query = array("requestID"=>$request,'scheduleID'=>$schedule,'status'=>'COMPLETE');
			}
			else{
				$query = array("requestID"=>$request,'status'=>'COMPLETE');
			}
		}
		else{
			if($schedule!=''){
			//$query = array("requestID"=>$request,'status'=>'COMPLETE');
			$query = array("requestID"=>$request,'scheduleID'=>$schedule,"request.label"=>$label,'status'=>'COMPLETE');
			}
			else{
				$query = array("requestID"=>$request,"request.label"=>$label,'status'=>'COMPLETE');
			}
	     
		}
		//$field = array('request'=>1,'data.firstView'=>1,'data.firstView.date'=>1);
		$cursor = $runs->find($query);
		$response["query"] = $_GET;
		$totalScore = array();
		
		foreach($tags as $tag){
		$TTFB=0;
		$Render=0;
		$visual=0;
		$docTime=0;
		$Fully=0;
		$count = 0;
		$tagScore=0;
		foreach($cursor as $test){
			//echo($test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["9"]["score"]);
			//echo json_encode($test["data"]["firstView"]["score_".$tag]);
			if($tag=="minify"){
				
				if(isset($test["data"]["lighthouse"])&&$test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			//echo("minfiy condition pass");data.lighthouse.audits.unminified-javascript.scoreunminified
			if(isset($test["data"]["lighthouse"]["audits"]["unminified-javascript"]["score"])&&isset($test["data"]["lighthouse"]["audits"]["unminified-css"]["score"])){
				
				$temp=$test["data"]["lighthouse"]["audits"]["unminified-javascript"]["score"] +$test["data"]["lighthouse"]["audits"]["unminified-css"]["score"];
				$temp =$temp*50;
			$tagScore=$tagScore+$temp;
			//echo($tag);
			//echo($tagScore);
			$count++;
				}
				}
			}else if($tag=="renderBlockingJs"){
				//echo('inside render blocking');data.lighthouse.audits.render-blocking-resources.score
					if(isset($test["data"]["lighthouse"])&&$test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") != false){
			//echo("renderBlockingJs condition pass");
			if(isset($test["data"]["lighthouse"]["audits"]["render-blocking-resources"]["score"])){
				//echo($test["request"]["location"]);
				//&&$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["6"]["score"]!=null
			$tagScore=$tagScore+($test["data"]["lighthouse"]["audits"]["render-blocking-resources"]["score"]*100);
			//echo($tag);
			//echo($tagScore);
			//echo($count);
			$count++;
				}
				}
				
			}
			else if($tag=="cssDelivery"){
				
					if(isset($test["data"]["lighthouse"])&&$test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			//echo("minfiy condition pass");
			if(isset($test["data"]["lighthouse"]["audits"]["unused-css-rules"]["score"])){
				//echo($test["request"]["location"]);
				//&&$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["6"]["score"]!=null
			$tagScore=$tagScore+($test["data"]["lighthouse"]["audits"]["unused-css-rules"]["score"]*100);
			//echo($tag);
			//echo($tagScore);
			//echo($count);
			$count++;
				}
				}
				
			}
			else if($tag=="BrowserResponseTime"){
				
			if(isset($test["data"])&&$test["data"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			     
			     $TTFB=$TTFB+($test['data']['firstView']['TTFB']/1000);
				 $Render=$Render+($test['data']['firstView']['render']/1000);
				 $visual=$visual+($test['data']['firstView']['visualComplete'])/1000;
				 $docTime=$docTime+($test['data']['firstView']['docTime'])/1000;
				 $Fully=$Fully+($test['data']['firstView']['fullyLoaded'])/1000;
				 if(!($TTFB==0)&&!($Render==0)&&!($visual==0)&&!($docTime==0)&&!($Fully==0)){
					$TTFB=$TTFB/2;
					$Render=$Render/2;
					$visual=$visual/2;
					$docTime=$docTime/2;
					$Fully=$Fully/2;
				 }
				 if($TTFB<=0.5){
					 $tagScore=$tagScore+20;
				 }
				 if($Render<=2){
					 $tagScore=$tagScore+20;
				 }
				 if($visual<=3){
					 $tagScore=$tagScore+20;
				 }
				 if($docTime<=5){
					 $tagScore=$tagScore+20;
				 }
				 if($Fully<=7){
					 $tagScore=$tagScore+20;
				 }
				//data.firstView.TTFB
				//data.firstView.fullyLoaded
				//data.firstView.visualComplete
				$count++;
				}
				
			}else if($tag=="OnPageRedirects"){
				
					if(isset($test["data"]["lighthouse"])&&$test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			//echo("minfiy condition pass");data.lighthouse.audits.network-requests.rawValue
			//data.lighthouse.audits.network-requests.details.items.statusCode
			if(isset($test["data"]["lighthouse"]["audits"]["redirects"]["score"])){
				//echo($test["request"]["location"]);
				//&&$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["6"]["score"]!=null
			$tagScore=$tagScore+($test["data"]["lighthouse"]["audits"]["redirects"]["score"]*100);
			//echo($tag);
			//echo($tagScore);
			//echo($count);
			$count++;
				}
				}
				
			}else{
			if(isset($test["data"]["firstView"])&&$test["data"]["firstView"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			
			if(isset($test["data"]["firstView"]["score_".$tag])&&$test["data"]["firstView"]["score_".$tag]>=0){
				
				
			$tagScore=$tagScore+$test["data"]["firstView"]["score_".$tag];
			//echo($tag);
			//echo($tagScore);
			$count++;
			}
			}
			}
			}
			if($count==0){
				$totalScore["score_".$tag]="NA";
			}
			else if($tagScore==0 && $count!=0){
				$totalScore["score_".$tag]=0;
				}
				else if($count!=0&& $tagScore!=0){	
			$tagScore=$tagScore/$count;
			$totalScore["score_".$tag]=round($tagScore,2);
			}
		
		
		
		}
		
		$response["score"]=$totalScore;
		
		echo json_encode($totalScore);
		
	}
	catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
	}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
	