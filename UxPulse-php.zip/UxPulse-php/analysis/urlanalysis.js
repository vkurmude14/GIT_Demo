
$('[data-id="request"]').on('DOMSubtreeModified',function(){
	
 getLabels();
 loadData();
})
var lbl = "";
var lbl_tag = "";
function getLabels(){
	var url_string =window.location.href;
var url = new URL(url_string);
var request = url.searchParams.get("request");
var schedule = url.searchParams.get("schedule");
console.log(request);
	//if(isset($_GET['request']))$request = $_GET['request'];
	// request = localStorage.getItem("request");
$('option[id=added_opt]').empty();
$.ajax("getLabels.php?request="+request+"&schedule="+schedule).done(function( data ) {
	//var labelshtm = "<option selected value='select'>-select-</option>";	
	var labelshtm = "<option id= added_opt value='ALL'>--select All--</option>";	
	for (var prop in data) {
		if(!data.hasOwnProperty(prop)) continue;
		lbl = data[prop];
		labelshtm += "<option id= added_opt value='"+data[prop]+"'>"+data[prop]+"</option>";
		$("#labels").html(labelshtm);
    }
	loadData();
	//$("#labels").chosen();
});
}


function loadData(){
	$('div[id=urls]').empty();
	var url_string =window.location.href;
        var url = new URL(url_string);
        var request = url.searchParams.get("request");
		var schedule = url.searchParams.get("schedule");
		if(schedule==null){
			schedule='';
		}
	var label = $("#labels").val();
	
	if(label==='select'){
		return;
	}
	$.ajax({
		url:"getUrlData_wpt.php?request="+request+"&schedule="+schedule+"&label="+label+"&tag=ALL",		
		dataType:"json"
	}).done(function(data,a){
		var tabledata="";
		//var a = [{key:"score",values:data['score']}];
		for (var key in data) {
			switch(key) {
               case "score_gzip":
			   var value="NA";
			   var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]/10,2)+" (10)";
				  if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
               tabledata=tabledata+"<tr bgcolor="+color+"><td>Gzip Compression</td><td>"+value+"</td></tr>";
                break;
				case "score_cdn":
				var value="NA";
				var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Use of CDN</td><td>"+value+"</td></tr>";
				break;
				case "score_keep-alive":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Keep Alive </td><td>"+value+"</td></tr>";
				break;
				case "score_cache":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Browser Caching Policy</td><td>"+value+"</td></tr>";
				break;
				case "score_compress":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]*0.07,2)+" (7)";
				   if(round(data[key]*0.07,2)>4){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Image Compression</td><td>"+value+"</td></tr>";
				break;
				case "score_progressive_jpeg":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]*0.03,2)+" (3)";
				   if(round(data[key]*0.03,2)>1.5){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Progressive Images</td><td>"+value+"</td></tr>";
				break;
				case "score_minify":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
					
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Minification</td><td>"+value+"</td></tr>";
				break;
				case "score_renderBlockingJs":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
					
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Render Blocking JavaScript</td><td>"+value+"</td></tr>";
				break;
				case "score_BrowserResponseTime":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
					
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Browser Response Time</td><td>"+value+"</td></tr>";
				break;
				case "score_cssDelivery":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
				  value=round(data[key]/10,2)+" (10)";
				   if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				  }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Css Content Delivery links</td><td>"+value +"</td></tr>";
				break;
				case "score_OnPageRedirects":
				var value="NA";
				 var color="";
				if(!isNaN(data[key])){
					var value=round(data[key]/10,2)+" (10)";
					 if(round(data[key]/10,2)>=6){
					  color ="#90EE90";
				    }
				  else{
					  color ="#FFA07A";
				  }
						}
				tabledata=tabledata+"<tr bgcolor="+color+"><td>Page level Redirects</td><td>"+ value+"</td></tr>";
				break;
				default:
				var color="#FFFFE0";
				tabledata=tabledata+"<tr bgcolor="+color+"><td>"+key+"</td><td>"+data[key]+"</td></tr>";
				break;
       
}
    
             
        console.log(key, data[key]);
    
}
		details = document.getElementById("checkpoints");

    var table="<table><tr><th>Check Points</th><th>Score (CutOff : 6.0)</th></tr>"+tabledata+"</table>";
	//$('#checkpoints').empty();
    details.innerHTML=details.innerHTML+"<font size=+1><br>SELECTED LABEL :   "+label+"<br>SELECTED SCHEDULE    : "+schedule+"</font><br>"+table+"<br><br>";

		
	}).fail(function(a) {
		console.log( "error" );
	})
};

function round(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
};