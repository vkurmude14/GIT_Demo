<!DOCTYPE html>
<?php
	require ("pwatchserver/session.php");
	?>
<html>
	<head>
    <?php require('imports\meta.html') ?>
		<title>pWatch | URL Analysis</title>
    <?php require('imports\cssimports.html') ?>
	
	</head>
	<body class="skin-green layout-top-nav"onload = "getLabels()">
		<div class="wrapper">
			<?php require('imports\headerbar.html') ?>
			<div class="content-wrapper">
				<div class="container-fluid">
					<section class="content">
						<div class="row">
							<div class="box box-solid">
									<div class="box-header with-border">
										<h3 class="box-title">Url Analysis</h3>
										<div class="box-tools pull-right">
											<select id="labels" onchange="loadData()">
												<option selected value="select">-select-</option>	
											</select>
											<select id="tags" onchange="loadData()">
												
											</select>
										</div>
									</div>
									<div class="box-body">
										<div class="row">
											<div id="bar-chart" class="col-xs-12">
												<svg></svg>
											</div>
											<div id="urls" class="col-xs-12 div-fix">
											</div>
										</div>
									</div>
							</div>
						</div>
					</section>
				</div>
			</div>
			<?php require('imports\footerbar.html') ?>
    </div>
		<?php require('imports\jsimports.html') ?>
		<script src="js/urlanalysis.js" type="text/javascript"></script>
		<link href="css/urlanalysis.css" rel="stylesheet" type="text/css" >
	</body>
</html>
