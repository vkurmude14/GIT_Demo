<?php
	require ("../pwatchserver/config.php");
	header("Content-Type:application/javascript");
	session_start();
	$invalid = false;
	
	//$_SESSION['user'] = "demo";
	$response = array();
	
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else{
		http_response_code(403);
		echo "403 Forbidden: session login required";
		die();
	}
	if(isset($_GET["request"]))$request = $_GET["request"];
	else{
		http_response_code(400);
		echo "400 Bad Request: request parameter not set";
		die();
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	else{
		http_response_code(400);
		echo "400 Bad Request: label parameter not set";
		die();
	}
	if(isset($_GET["tag"]))$tag = $_GET["tag"];
	else{
		http_response_code(400);
		echo "400 Bad Request: tag parameter not set";
		die();
	}
	$tags= array('cache','cdn','gzip','progressive_jpeg','keep-alive','minify','combine','compress','etags','cookies');
	try{
		
		$connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
		$runs = $connection->selectCollection(DB_NAME,'requests');
		//$variable='data.firstView.score_'.$tag;
		//,'request.location'=>'{'$regex':'.*:Chrome'}'
		if($label=="ALL"){
			$query = array("requestID"=>$request,'status'=>'COMPLETE');
		}
		else{
	     $query = array("requestID"=>$request,"request.label"=>$label,'status'=>'COMPLETE');
		}
		//$field = array('request'=>1,'data.firstView'=>1,'data.firstView.date'=>1);
		$cursor = $runs->find($query);
		$response["query"] = $_GET;
		$totalScore = array();
		
		foreach($tags as $tag){
			
		$count = 0;
		$tagScore=0;
		foreach($cursor as $test){
			//echo($test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["9"]["score"]);
			//echo json_encode($test["data"]["firstView"]["score_".$tag]);
			if($tag=="minify"){
				
				if($test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			echo("minfiy condition pass");
			if(isset($test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["9"]["score"])&&$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["9"]["score"]!=null){
				
				$temp=$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["9"]["score"] +$test["data"]["lighthouse"]["reportCategories"]["0"]["audits"]["10"]["score"];
				$temp =$temp/2;
			$tagScore=$tagScore+$temp;
			echo($tag);
			echo($tagScore);
			$count++;
				}
				}
			}else{
			if($test["data"]["firstView"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			
			if(isset($test["data"]["firstView"]["score_".$tag])&&$test["data"]["firstView"]["score_".$tag]!=null&&$test["data"]["firstView"]["score_".$tag]!=-1){
				
				
			$tagScore=$tagScore+$test["data"]["firstView"]["score_".$tag];
			//echo($tag);
			//echo($tagScore);
			$count++;
			}
			}
			}
			}
			if($count==0){
				$totalScore["score_".$tag]="NA";
			}
			else if($tagScore==0 && $count!=0){
				$totalScore["score_".$tag]=0;
				}
				else if($count!=0&& $tagScore!=0){	
			$tagScore=$tagScore/$count;
			$totalScore["score_".$tag]=round($tagScore,2);
			}
		
		
		
		}
		
		$response["score"]=$totalScore;
		
		echo json_encode($totalScore);
		
	}
	catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
	}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
	