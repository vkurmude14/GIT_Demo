<?php
set_time_limit(600);
session_start();
if (! isset($_SESSION['user'])) {
    $url = $_SERVER[HTTP_HOST] . $_SERVER[REQUEST_URI];
    header("Location: ../index.php?&url=" . $url);
    die();
} else {
    $user = $_SESSION['user'];
    
    if (isset($_GET['request'])){
	$request = $_GET['request'];
	}
    else
        $request = "";
    $location = "/Analysis";
    $jsList = [
        "urlanalysis.js"
    ];
    $cssList = [
        "urlanalysis.css"
    ];
    $name = "Analysis/$request";
    require ("../templates/header.inc.php");
    ?>
<!-- Main content -->
<body class="skin-green layout-top-nav"onload = "getLabels()">
                <!-- Main content -->
                <section class="content">
				
                    <!-- Main row -->
                    <div class="row">
						<section class="col-lg-12">
							<div  class="box" style="position: relative;">
                                <div class="box-header" >
								
                                    <i class="fa fa-flask"></i>									
                                    <h3 class="box-title">Analysis</h3> 
									<div class="box-tools pull-right">
											<select id="labels" onchange="loadData()">
												<option selected value="select">-select-</option>	
											</select>
										</div>
         					
                                </div>
								
								<!-- /.box-header -->
								<div id="checkpoints" class="box-body">
								
								</div>
							

</div>
                        </section><!-- right col -->
                    </div><!-- /.row (main row) -->

                </section>

<?php
    require ("../templates/footer.inc.php");
}
?>