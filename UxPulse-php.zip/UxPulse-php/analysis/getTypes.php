<?php
	$types= array();
	//$array= array('cache','cdn','gzip','cookies','keep-alive','minify','combine','compress','etags','progressive_jpeg');
	array_push($types,"cache","cdn","gzip","cookies","keep-alive","minify","combine","compress","etags","progressive_jpeg");
	header("Content-Type:application/json");
	echo json_encode($types);	
	
	?>
