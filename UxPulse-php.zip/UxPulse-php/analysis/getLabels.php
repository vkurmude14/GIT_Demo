<?php
	if(isset($_GET["request"]))$request = $_GET["request"];
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	
	$labels = array();
	try{
		
		include "../PwatchServer/getRequestDetails_ReportConfig.php";
										   
												                                          
                                             foreach ($echodata as $echo)
                                              {  
											     foreach ($echo['runs'] as $run){ 
													 if($run['request']['isCustomer']){  
											             //$run['request']['label'] urlOrScript
														 
													$label[]=trim($run['request']['label']," ");
                                 
													}}}
										             $labels=array_unique($label);
				
	}
	catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
	}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
	header("Content-Type:application/json");
	if($labels){
	echo json_encode($labels);
	}
	else{
		http_response_code(404);
		die();
	}
	
	
	?>
