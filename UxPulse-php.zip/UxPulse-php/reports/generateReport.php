<?php
session_start();
set_time_limit(300);
require ("../PwatchServer/config.php");
require_once('..\\mongoUtil.php');
    $customer_urls = array ();
	$invalid = false;
	$reporttype ='pagespeed';
	$label='';
	$location='';
	if(isset($_POST['reporttype']))$reporttype = $_POST["reporttype"];
	if(isset($_POST['submit'])){
    if(!empty($_POST['check_list'])){
		
		if(isset($_GET["request"]))$request = $_GET["request"];
	//else	$invalid = true;
	else{
		echo "request parameter not set";
	}
		if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	//else	$invalid = true;
	else{
		$schedule='';
	}
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	//else	$invalid = true;
	else{
		echo "user  not set in session";
	}
	if(isset($_GET["format"]))$format = $_GET["format"];
	//else	$invalid = true;
	else{
		echo "format parameter not set";
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	//else	$invalid = true;
	else{
		//echo "label parameter not set";
	}
	if ($invalid) {
		echo "error $invalid";
		die ();
	}
		foreach($_POST['check_list'] as $selected) {
		$customer_urls[]=$selected;
		//echo $selected;
		//console.log($selected);
		}
		switch ($format) {
		case 'word' :
			$fileName = $request . "_" . $user . "_" . "wordReport.docx";
			$customer_url = $customer_urls[0];
			//$fileName=$customer_url;
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			unlink($file);
			require("reportModule/generateWordReport.php");
			downloadFile($file, $fileName);
			break;
		
		case 'excel' :
			$fileName = $request . "_" . $schedule . "_" . $user . "_" . "ExcelReport.xlsx";
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			unlink($file);
			{
				require("reportModule/generateExcelReport.php");
			}
			
			downloadFile($file, $fileName);
			break;
		
		default :
			echo 'invalid format specified';
	}
		
	}
}
else{
if(isset($_GET["request"]))$request = $_GET["request"];
	//else	$invalid = true;
	else{
		echo "request parameter not set";
	}
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	//else	$invalid = true;
	else{
		$schedule='';
	}
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	//else	$invalid = true;
	else{
		echo "user  not set in session";
	}
	if(isset($_GET["format"]))$format = $_GET["format"];
	//else	$invalid = true;
	else{
		echo "format parameter not set";
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	//else	$invalid = true;
	else{
		//echo "label parameter not set";
	}
	if ($invalid) {
		echo "error $invalid";
		die ();
	}
	switch ($format) {
		case 'word' :
			$fileName = $request . "_" . $schedule . "_" . $user . "_" . "wordReport.docx";
			$customer_url = $customer_urls[0];
			//$fileName=$customer_url;
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			unlink($file);
			require("reportModule/generateWordReport.php");
			
			downloadFile($file, $fileName);
			break;
		
		case 'excel' :
			$fileName = $request . "_" . $schedule . "_" . $user . "_" . "ExcelReport.xlsx";
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			{
				require("reportModule/generateExcelReport.php");
			}
			
			downloadFile($file, $fileName);
			break;
		
		default :
			echo 'invalid format specified';
	}
}
	
	//$customer_urls = array ();

function downloadFile($file, $fileName) {
	header ( "Content-Description: File Transfer" );
	header ( "Content-Type: application/octet-stream" );
	header ( 'Content-Disposition: attachment; filename="' . basename($file).'"' );
	//header ( "Content-Type: application/download" );
	header ( "Content-Length: " . filesize ( $file ) );
	ob_clean();
    flush();
	readfile($file);
}