<?php
session_start();

require ("../PwatchServer/config.php");
require_once('..\\mongoUtil.php');
	$invalid = false;
	$label='';
	$location='';
	if(isset($_GET["request"]))$request = $_GET["request"];
	//else	$invalid = true;
	else{
		echo "request parameter not set";
	}
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	//else	$invalid = true;
	else{
		echo "user  not set in session";
	}
	if(isset($_GET["format"]))$format = $_GET["format"];
	//else	$invalid = true;
	else{
		echo "format parameter not set";
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	//else	$invalid = true;
	else{
		echo "label parameter not set";
	}
	/*if(isset($_GET["location"]))$location = $_GET["location"];
	//else	$invalid = true;
	else{
		echo "location parameter not set";
	}*/
	
	//echo "<br>".$_GET["request"]."<br>".$_GET["format"]."<br>".$_SESSION['user'];
	if ($invalid) {
		echo "error $invalid";
		die ();
	}
	$customer_urls = array ();
	try {
		//  $connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
		$collection = $connection->selectCollection ( DB_NAME, 'users' );
		$query = array (
				"_id" => $user 
		);
		$field = array (
				"requests." . $request . '.tasks' => 1 
		);
		$cursor = $collection->find ( $query, $field );
		foreach ( $cursor as $result ) {
			$tasks = $result ['requests'] [$request] ['tasks'];
			break;
		}
		
		foreach ( $tasks as $task ) {
			if ($task ['isCustomer'] == 'true') {
				if (! in_array ( $task ['urlOrScript'], $customer_urls )) {
					array_push ( $customer_urls, $task ['urlOrScript'] );
				}
			}
		}
	} catch ( MongoClientException $e ) {
		error_log ( $e );
		echo '{"error":"Failure in Database Connection"}';
		die ();
	} catch ( Exception $e ) {
		error_log ( $e );
		die ();
	}
	switch ($format) {
		case 'word' :
			/* if (sizeof ( $customer_urls ) > 1) {
				echo sizeof ( $customer_urls ) . ' customerUrls exists';
			} */
			/*
			 * foreach ( $customer_urls as $customer_url ) {
			 *
			 * }
			 */
			$fileName = $request . "_" . $user . "_" . "wordReport.docx";
			//echo $fileName.'  label is '.$label;
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			if (! file_exists ( $file )) {
				$customer_url = $customer_urls [0];
				echo $customer_url;
				//header ( "Location: ../reportModule/generateWordReport.php?&user=" . $user . '&request=' . $request . '&customer_url=' . $customer_url );
				//require("reportModule/generateWordReport.php");
			}
			//downloadFile($file, $fileName);
			break;
		
		case 'excel' :
			$fileName = $request . "_" . $user . "_" . "ExcelReport.xlsx";
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			//if (! file_exists ( $file )) 
			{
				//header ( "Location: ../reportModule/generateExcelReport.php?&user=" . $user . '&request=' . $request );
				require("reportModule/generateExcelReport.php");
			}
			
			downloadFile($file, $fileName);
			break;
		
		default :
			echo 'invalid format specified';
	}

function downloadFile($file, $fileName) {
	header ( "Content-Description: File Transfer" );
	header ( "Content-Type: application/octet-stream" );
	header ( 'Content-Disposition: attachment; filename="' . basename($file).'"' );
	//header ( "Content-Type: application/download" );
	header ( "Content-Length: " . filesize ( $file ) );
	ob_clean();
    flush();
	readfile($file);
}