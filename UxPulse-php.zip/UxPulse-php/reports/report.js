transformD(chartData);
transformDC(csvData);
$(".domain").remove();

function transformDC(chartData){
	var data={};
	for(k1 in chartData){
		data[k1]={};
		var v1=chartData[k1];
		for(k2 in v1){
			if(k2 in data[k1]);else data[k1][k2]={};
			var v2=v1[k2];
			for(k3 in v2){				
				var v3=v2[k3];
				for(k4 in v3){
					if(k4 in data[k1][k2]);else data[k1][k2][k4]=[];
					var v4=v3[k4];
					for(k5 in v4){
						//if(k5 in data[k1][k3][k4]);else data[k1][k3][k4][k5]=[];
						var v5=v4[k5];	
					//	console.log("1:"+k1+",3:"+k3+",4:"+k4+",2:"+k2+",v:"+v5);	
						data[k1][k2][k4].push({"x":k3,"y":v5});
					}
				}
			}
		}
	}
	
	 var newdata = {};
	 for(k1 in data){
		newdata[k1] = {};
		var v1 = data[k1];
		for(k2 in v1){
			var v2 = v1[k2];
			for(k3 in v2){
				if(k3 in newdata[k1]);else newdata[k1][k3]=[];
				var v3 = v2[k3];
				//console.log("1:"+k1+",2:"+k2+",3:"+k3+"v:"+v3); 
				newdata[k1][k3].push({"key":k2,"values":v3});
			}
		}
	}
	//console.log(newdata);
	for(k1 in newdata){
		var v1 = newdata[k1];
		for(k2 in v1){
				//console.log("1:"+k1+"2:"+k2);
				createBarChart(k1.substr(0,2)+k2.substr(0,2),newdata[k1][k2],k1 +"s");
				createTable(k1.substr(0,2)+k2.substr(0,2),newdata[k1][k2]);
		
		}
	}	
	return newdata;
}
function transformD(chartData){
	var data=[];
	for(k1 in chartData){
		data[k1]={};
		var v1=chartData[k1];
		for(k2 in v1){
			var v2=v1[k2];
			for(k3 in v2){
				if(k3 in data[k1]);else data[k1][k3]={};
				var v3=v2[k3];
				for(k4 in v3){
					if(k4 in data[k1][k3]);else data[k1][k3][k4]=[];
					var v4=v3[k4];
					data[k1][k3][k4].push({"x":k2,"y":v4});
				}
			}
		}
	}
	var newdata = {};
	for(k1 in data){
		var v1 = data[k1];
		newdata[k1]={};
		for(k2 in v1){
			newdata[k1][k2]=[];
			var v2 = v1[k2];
			for(k3 in v2){
				var v3 = v2[k3];
				newdata[k1][k2].push({"key":k3,"values":v3});
			}
		}
	}
	
	for(k1 in data){
		var v1 = data[k1];
		for(k2 in v1){
			createBarChart(k1.substr(0,2)+k2.substr(0,2),newdata[k1][k2],k1 +"s");
			createTable(k1.substr(0,2)+k2.substr(0,2),newdata[k1][k2]);
		}
	}
	//console.log(newdata);
	return newdata;
	
}



function createBarChart(id,data,label){
	//console.log(id);
	//console.log(data);
	var chart = nv.models.multiBarChart()
		.margin({left: 60,right:0}) 
		.staggerLabels(false)    //Too many bars and not enough room? Try staggering labels.
		.tooltips(false)        //Don't show tooltips
		.showControls(false)       //...instead, show the bar value right on top of each bar.
		.transitionDuration(250)
		//.stacked(true)
		.color(['#9ecae1','#4292c6','#08519c'])
		.groupSpacing(0.393)
		
     ;
	chart.xAxis     //Chart x-axis settings
		.axisLabel(label)
		
	chart.yAxis     //Chart y-axis settings
		.axisLabel('Seconds')
		.axisLabelDistance(40)
		.tickFormat(d3.format('.1f'));
		
	d3.select('#'+id+' svg')    //Select the <svg> element you want to render the chart in.   
		.datum(data)         //Populate the <svg> element with chart data...
		.call(chart);          //Finally, render the chart!
	return chart;
}
function createTable(id,data){
	//console.log(id);
	//console.log(data);
	var rows=[];
	var cols=[[]];
	
	for(row in data){
		rows[row]=[];		
		rows[row][0] = data[row].key;
		cols[0][0] = "";
		for(val in data[row].values){
			rows[row][1+parseInt(val)] = data[row].values[val].y;
			cols[0][1+parseInt(val)] = data[row].values[val].x;
		}
	}
	//cols[0]=cols;
	console.log(rows);
	console.log(cols);
	var table = d3.select("#"+id+" table");
	table.attr("class","table-bordered");
	table.attr("width","100%");
	var thead = table.select("thead").empty() ? table.append("thead") : table.select("thead");	
	var trth = thead.selectAll("tr").data(cols);
	var th = trth.enter().append("tr").selectAll("th").data(function(d,i){ return d;});
	th.enter().append("th");
	th.text(function(d){ return d;});
	var tbody = table.select("tbody").empty() ? table.append("tbody") : table.select("tbody");	
	var trtd = tbody.selectAll("tr").data(rows);
	var td = trtd.enter().append("tr").selectAll("td").data(function(d,i){ return d;});
	td.enter().append("td");
	td.text(function(d){ return d;});
}