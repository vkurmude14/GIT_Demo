<?php
session_start();
set_time_limit(300);
require ("../PwatchServer/config.php");
require_once('..\\mongoUtil.php');
$invalid = false;
$message ='';
	if(isset($_GET["request"]))$request = $_GET["request"];
	else{
		$invalid = true;
		$message = "request parameter not set";
	}
	if(isset($_GET["schedule"]))$schedule = $_GET["schedule"];
	else{
		$invalid = true;
		$message = "Schedule parameter not set";
	}
	if($schedule==''){
		$invalid = true;
		$message ="Select a schedule to process";
	}
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else{
		$invalid = true;
		$message = "user  not set in session";
	}
if ($invalid) {
		echo "error $message";
		die ();
}
else{
			$fileName = $request . "_" . $schedule . "_" . $user . "_" . "ExcelReport.xlsx";
			$file = __DIR__ . "/reportModule/results/" . $fileName;
			unlink($file);
			{
				require("reportModule/generateGovernanceReportCORE.php");
			}
			downloadFile($file, $fileName);
}
function downloadFile($file, $fileName) {
	header ( "Content-Description: File Transfer" );
	header ( "Content-Type: application/octet-stream" );
	header ( 'Content-Disposition: attachment; filename="' . basename($file).'"' );
	//header ( "Content-Type: application/download" );
	header ( "Content-Length: " . filesize ( $file ) );
	ob_clean();
    flush();
	readfile($file);
}