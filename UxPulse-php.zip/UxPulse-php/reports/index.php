<!DOCTYPE html>
<?php
	error_reporting(0);
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
	error_reporting(0);
	error_reporting( E_NOTICE | NOTICE);
	session_start();
	$label=array();
    $Labels = array();
	if(!isset($_SESSION['user'])){
		$url = $_SERVER[REQUEST_URI];
		header("Location: ../index.php?&url=".$url);
		die();
	}
	else
	{		
		$user = $_SESSION['user'];
		
		if(isset($_GET['request']))$request = $_GET['request'];
		else $request="";
		if(isset($_GET['schedule']))$schedule = $_GET['schedule'];
		else $schedule="";
		//

	
		//
		$location="/dashboard";
		$jsList=[
			"../chosen/chosen.jquery.min.js",
			"report-new.js"
		];
		$cssList=["../chosen/chosen.bootstrap.min.css","report.css"];
		$name="Report/$request";
		require("../templates/header.inc.php");
		
?>
                <section class="content">
                   <!-- Small boxes (Stat box) -->
                    <div class="row">
						<section class="col-xs-12">	
		
       
						</section>
                    </div><!-- /.row -->
			
                    <!-- Main row -->
                    <div class="row">
						<section class="col-xs-12">	
							<div  class="box" style="position: relative;">
                                <div class="box-header">
                                    <i class="fa fa-check"></i>									
                                    <h3 class="box-title">Summary </h3>
									<div style="cursor: pointer;" class="box-tools pull-right" id="DownloadFile">
									<a><span <button type="button" data-toggle="modal" data-target="#myModal" class="btn-sm bg-blue" id="wordDownload"><i class="fa fa-download"></i>Download Recommendations Report</button></span></a>
							</button>

						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">
                               <form action="generateReport.php?format=word<?php if($request!=="") echo "&request=$request&schedule=$schedule"?>" method="post">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header" >
									
										<button type="button"class="close" data-dismiss="modal" >&times;</button>
										<h4 class="modal-title">Select URLS for report generation</h4>
										<input type="checkbox"  name="reporttype" value="yslow">OFFLINE<br>
									</div>
									<div class="modal-body">
										<?php
										  error_reporting(0);
										  $label=array();
										  if($request !=""){
                                          include "../PwatchServer/getRequestDetails_ReportConfig.php";
										   
												                                          
                                             foreach ($echodata as $echo)
                                              {  
											     foreach ($echo['runs'] as $run){ 
													 if($run['request']['isCustomer']){  
											             //$run['request']['label'] urlOrScript
														 
													//$label[]=trim($run['request']['label']," ");
                                                    //$label[$run['request']['label']]=$run['request']['label'];
													//$label1[$run['request']['label']];
													//$label1[$run['request']['label']]['url']=$run['request']['urlOrScript'];
													//$label[$run['request']['label']]=null;
													$label[$run['request']['label']]=$run['request']['urlOrScript']; 
													
													}
													
													}
													}
										             //$result=array_unique($label);
													foreach ($label as $key => $a){ ?>
											<input type="checkbox"  name="check_list[]" value="<?php echo $a;?>"><?php echo $key;?><br>
											<?php
													}
													}		
										 ?>
									</div>
									<div class="modal-footer">
										<input type="submit" class="btn-sm bg-blue" name="submit" Value="Download"/>
									</div>
								</div>
								</form>
							</div>
						</div>
			<a href="generateReport.php?format=excel<?php if($request!=="") echo "&request=$request&schedule=$schedule"?>"><span class="btn-sm bg-blue" id="excelDownload"><i class="fa fa-download"></i> Download End User Experience Report</span></a>
			<a href="generateGovernanceReport.php?<?php if(request!=="") echo "request=$request&schedule=$schedule"?>"><span class="btn-sm bg-blue" id="excelDownload"><i class="fa fa-download"></i> Download Governance Report</span></a>
									</div>
									
                                </div>
								<div class="box-body">
										<input type="hidden" id="_request" value="<?php echo $request?>">
										<input type="hidden" id="_user" value="<?php echo $user?>">
									<div id="summary">
									<table class="table table-bordered" ></table>
									</div>
								</div>
							</div>
						</section>
                    </div>
					<div class="row">
						<section class="col-xs-12">	
							<div  class="box" style="position: relative;">
                                <div class="box-header">
                                    <i class="fa fa-bar-chart"></i>									
                                    <h3 class="box-title">Chart</h3>                                   
									</div>
								<div class="box-body">
									<div id="charts">
										<div id="locationChart">
											<label>Location Wise</label>
											<svg></svg>
										</div>
										<div id="labelChart">
											<label>Label Wise</label>
											<svg></svg>
										</div>
									</div>
								</div>
							</div>
						</section>
                    </div>
					<!--div class="row">
						<section class="col-xs-12">	
							<div  class="box" style="position: relative;">
                                <div class="box-header">
                                    <i class="fa fa-lightbulb-o "></i>									
                                    <h3 class="box-title">Recommendations </h3> 
									< div class="box-tools pull-right">
										<span class="badge">Score:</span>
										<span class="badge bg-green" data-toggle="tooltip" title="Score:100">100</span>
										<span class="badge">></span>
										<span class="badge bg-yellow" data-toggle="tooltip" title="Score:70">70</span>
										<span class="badge">></span>
										<span class="badge bg-red" data-toggle="tooltip" title="Score:50">50</span>
										</div >                                  
                                </div>
								<div class="box-body">
									<div class="box-group" id="accordion">
									</div>
									<!--<div id="recommendations">
									<table class="table table-bordered" ></table>
									</div>-->
								</div>
							</div>
						</section>
                    </div>
                </section>

				<!-- /.content -->
 <?php
	require("../templates/footer.inc.php");
	}
?>
