<?php
	//require ("../../pwatchserver/config.php");
	//header("Content-Type:application/javascript");
	set_time_limit(600);
	//session_start();
	$invalid = false;
	
	//$_SESSION['user'] = "demo";
	$response = array();
	
	if(isset($_SESSION['user']))$user = $_SESSION['user'];
	else{
		http_response_code(403);
	echo "403 Forbidden: session login required";
		die();
	}
	if(isset($_GET["request"]))$request = $_GET["request"];
	else{
		http_response_code(400);
		echo "400 Bad Request: request parameter not set";
		die();
	}
	if(isset($_GET["schedule"])&&$_GET["schedule"]!=null)$schedule = $_GET["schedule"];
	else{
		$schedule='';
	}
	if(isset($_GET["label"]))$label = $_GET["label"];
	elseif(isset($label)){
		$label ='ALL';
	}
	else{
		$label ='ALL';
	}
	try{
		
		$connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
		$runs = $connection->selectCollection(DB_NAME,'requests');
		//$variable='data.firstView.score_'.$tag;
		//,'request.location'=>'{'$regex':'.*:Chrome'}'
		if($label=="ALL"){
			if($schedule!=''){
			$query = array("requestID"=>$request,'scheduleID'=>$schedule,'status'=>'COMPLETE');
			}
			else{
				$query = array("requestID"=>$request,'status'=>'COMPLETE');
			}
		}
		else{
			if($schedule!=''){
			//$query = array("requestID"=>$request,'status'=>'COMPLETE');
			$query = array("requestID"=>$request,'scheduleID'=>$schedule,"request.label"=>$label,'status'=>'COMPLETE');
			}
			else{
				$query = array("requestID"=>$request,"request.label"=>$label,'status'=>'COMPLETE');
			}
	     
		}
		//$field = array('request'=>1,'data.firstView'=>1,'data.firstView.date'=>1);
		$cursor = $runs->find($query);
		$response["query"] = $_GET;
		$Audits=[];
		foreach($cursor as $test){
		
		if(isset($test["data"]["lighthouse"])&&$test["data"]["lighthouse"]!=null&&strpos($test["request"]["location"],":Chrome") !== false){
			foreach($test["data"]["lighthouse"]["categories"]["performance"]["auditRefs"] as $category){
				//echo $category["id"].":";
				//echo $category["group"].'<br>';
			$Audit[$category["id"]]=[];
			if(isset($category["group"])){
			$Audit[$category["id"]]['group']=$category["group"];
			}
			elseif(!isset($category["group"])){
			$Audit[$category["id"]]["group"]="ungrouped";
			}
			if(isset($test["data"]["lighthouse"]['audits'][$category["id"]]['score'])){
			$Audit[$category["id"]]['score']=$test["data"]["lighthouse"]['audits'][$category["id"]]['score'];
			}
			if(isset($test["data"]["lighthouse"]['audits'][$category["id"]]['displayValue'])){
			$Audit[$category["id"]]['displayValue']=$test["data"]["lighthouse"]['audits'][$category["id"]]['displayValue'];
			}
			$Audit[$category["id"]]['description']=$test["data"]["lighthouse"]['audits'][$category["id"]]['description'];
			$Audit[$category["id"]]['title']=$test["data"]["lighthouse"]['audits'][$category["id"]]['title'];
			$Audit[$category["id"]]['id']=$test["data"]["lighthouse"]['audits'][$category["id"]]['id'];
			if(isset($test["data"]["lighthouse"]['audits'][$category["id"]]['details']['items'])){
			$Audit[$category["id"]]['resources']=$test["data"]["lighthouse"]['audits'][$category["id"]]['details']['items'];
			}
			//data.lighthouse.audits.render-blocking-resources.details.items
			//load-opportunities
				//metrics
				//diagnostics
				//ungrouped
				//data.lighthouse.categories.performance.auditRefs
		}
		}
		//echo json_encode($Audit);
		$Audits[$test["data"]["testUrl"]]=$Audit;
		$Audits[$test["data"]["testUrl"]]['AUDITURL']=$test["data"]["testUrl"];
		//echo $test["data"]["testUrl"];
		}
		$response["Audits"]=$Audits;
		//echo json_encode($Audits);
		}
		catch(MongoClientException $e){
		error_log($e);
		http_response_code(500);
		echo '500 Internal Server Error: failure in database connection';
		die();
		}
	catch(Exception $e){
		http_response_code(500);
		error_log($e);
		echo '500 Internal Server Error: unexpected internal error';
		die();
	}
	