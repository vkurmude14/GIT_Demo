<?php
date_default_timezone_set ( 'Asia/Kolkata' );
require_once __DIR__ . '/bootstrap.php';


$result_json = array ();

//$test = 'pagespeed';
$test = 'yslow';

switch ($test) {
	case 'pagespeed' :
		$url = "https://www.googleapis.com/pagespeedonline/v1/runPagespeed?url=" . $customer_url . "&strategy=desktop";
		$aContext = array (
			'http' => array (
				'proxy'=>'tcp://172.22.218.218:8085',
				'request_fulluri' => true 
			),
			'ssl' => array (
					'verify_peer' => false,
					'verify_peer_name' => false 
			) 
		);
		
		$cxContext = stream_context_create ( $aContext );
		$jsonobj = file_get_contents ( $url, False, $cxContext );
		$contents = json_decode ( $jsonobj, "true" );
		$urls = array ();
		$jsonFile = array ();
		$filedata = file_get_contents ( __DIR__ . '\tmp\template_pagespeed.json' );
		$template = json_decode ( $filedata,true);
		prepareJsonForPageSpeed ( $template, $contents, '', $urls, $jsonFile );
		$result_json ['pagespeed'] = $jsonFile;
		
		break;
	
	case 'yslow' :
		$requests = $connection->selectCollection( DB_NAME, 'requests');
		$jsonobj = $requests->findOne(array('requestID'=>$request,'status'=>'COMPLETE','request.label'=>$label),array("recommondations.g"=>1))['recommondations']['g'];
		$contents = $jsonobj;
		$urls = array ();
		$jsonFile = array ();
		$filedata = file_get_contents (  __DIR__ . '\tmp\template_yslow.json' );
		$template = json_decode( $filedata,"true");
		
		prepareJsonForYslow ( $template, $contents, '', $urls, $jsonFile );
		$result_json ['yslow'] = $jsonFile;
		break;
	
	default :
		echo 'Test not found ' . $test;
		break;
}


// generate common json
file_put_contents ( __DIR__ . '\tmp\final_result.json', json_encode ( $result_json ) );

// writing to word file
$fd = file_get_contents ( __DIR__ . '\tmp\final_result.json' );
$data = json_decode ( $fd, 'true' );

foreach ( $data as $test => $result ) {
	//$fileName = $request . "_" . $user . "_" . "wordReport.docx";
	//$file = __DIR__ . "/results/" . $fileName ;
	if (!file_exists ( $file )) {
		generateReport ( $result, $test ,$request,$user);
	}
}

// $file=__DIR__ . "/results/".$fileName.".docx";
// if (file_exists($file)) {

// header("Pragma: public"); // required
// header("Expires: 0");
// header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
// header("Cache-Control: private", false); // required for certain browsers
// header("Content-Type: application/msword");
// header('Content-Disposition: attachment; filename="'.basename($file).'"');
// header("Content-Transfer-Encoding: binary");
// header("Content-Length: ". filesize($file));
// ob_clean();
// flush();
// readfile($file);
// exit;
// }
function generateReport($data, $fileName,$request,$user) {
	
	$fileName = $request . "_" . $user . "_" . "wordReport";
	
	
	$title = 'pWatch Analysis';
	
	$phpWord = new \PhpOffice\PhpWord\PhpWord ();
	
	$phpWord->addTitleStyle ( 1, array (
			'size' => 16,
			'name' => 'Calibri Light (Headings)',
			'color' => '#397fc6' 
	) );
	$phpWord->addTitleStyle ( 2, array (
			'size' => 13,
			'name' => 'Calibri Light (Headings)',
			'color' => '#397fc6' 
	) );
	$phpWord->addParagraphStyle ( 'pStyle', array (
			'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER,
			'spaceAfter' => 100 
	) );
	$phpWord->addFontStyle ( 'pstyle', array (
			'size' => 13,
			'name' => 'Calibri (Body)' 
	) );
	$section = $phpWord->addSection ();
	$section->addTitle ( htmlspecialchars ( $title, ENT_COMPAT, 'UTF-8' ), 1 );
	
	// Table of Contents
	
	 // $toc = $section->addTOC(array('size' => 11, 'name' => 'Calibri (Body)'),array('tabLeader ' => '-','tabPos' => 9000,'indent' => 100));
	 // $toc->setMinDepth(1);
	 // $toc->setMaxDepth(2);
	 // $section->addPageBreak();
	// 
	
	$footer = $section->addFooter ();
	$section->getStyle ()->setPageNumberingStart ( 1 );
	$footer->addPreserveText ( '{PAGE} ' );
	
	$cnt = 1;
	display_json ( $data, '', $phpWord, $section, $cnt );
	
	$phpWord->save ( __DIR__ . "/results/" . $fileName . ".docx", "Word2007" );
	
	return $fileName;
}
function display_json($data, $prevkey, $phpWord, $section, &$cnt) {
	global $result;
	if (strcmp ( $prevkey, 'urls' ) == 0) {
		// for display
		// echo $prevkey . '<br>';
		// for file
		// $section->addText(htmlspecialchars($prevkey, ENT_COMPAT, 'UTF-8'));
	}
	$bFontStyle ['name'] = 'Calibri';
	$bFontStyle ['size'] = '11';
	foreach ( $data as $key => $value ) {
		
		switch ($prevkey) {
			case 'Summary' :
				if (strcmp ( $key, 'descBefTable' ) == 0) {
					$section->addTitle ( htmlspecialchars ( 'Summary', ENT_COMPAT, 'UTF-8' ), 1 );
					$section->addText ( htmlspecialchars ( $value, ENT_COMPAT, 'UTF-8' ), $bFontStyle );
					createTable ( $phpWord, $section, $result );
					$section->addText ( htmlspecialchars ( '', ENT_COMPAT, 'UTF-8' ) );
				} else if (strcmp ( $key, 'descAftTable' ) == 0) {
					$section->addText ( htmlspecialchars ( $value, ENT_COMPAT, 'UTF-8' ), $bFontStyle );
					// $section->addPageBreak();
				}
				
				break;
			default :
				if (is_array ( $value ) == 0) {
					
					if (strcmp ( 'urls', $prevkey ) == 0) {
						// for display
						// echo $value . '<br>';
						// for file
						$section->addListItem ( htmlspecialchars ( urldecode ( $value ), ENT_COMPAT, 'UTF-8' ) );
						// $section->addLink($value, null, array('color' => '#397fc6', 'underline' => \PhpOffice\PhpWord\Style\Font::UNDERLINE_SINGLE));
						// $section->addText(htmlspecialchars($value, ENT_COMPAT, 'UTF-8'));
					} else {
						// for display
						// echo $key ." " . $value . '<br>';
						// for file
						if (strcmp ( $key, 'name' ) == 0) {
							
							$section->addTitle ( htmlspecialchars ( 'Observation ' . $cnt ++ . ': ' . $value, ENT_COMPAT, 'UTF-8' ), 1 );
						} else if (strcmp ( $key, 'description' ) == 0) {
							$section->addText ( htmlspecialchars ( $value, ENT_COMPAT, 'UTF-8' ), $bFontStyle );
						} else if (strcmp ( $key, 'Analysis' ) == 0) {
							$section->addTitle ( htmlspecialchars ( $key, ENT_COMPAT, 'UTF-8' ), 2 );
							$section->addText ( htmlspecialchars ( $value, ENT_COMPAT, 'UTF-8' ), $bFontStyle );
						} else if (strcmp ( $key, 'Recommendation' ) == 0) {
							$section->addTitle ( htmlspecialchars ( $key, ENT_COMPAT, 'UTF-8' ), 2 );
							$section->addText ( htmlspecialchars ( $value, ENT_COMPAT, 'UTF-8' ), $bFontStyle );
						}
					}
				} else {
					
					display_json ( $value, $key, $phpWord, $section, $cnt );
				}
				break;
		}
	}
}
function createTable($phpWord, $section, $data) {
	$cnt = 1;
	$styleTable = array (
			'borderSize' => 6,
			'borderColor' => '006699',
			'cellMargin' => 80,
			'alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER 
	);
	$styleFirstRow = array (
			'borderBottomSize' => 18,
			'borderBottomColor' => '0000FF',
			'bgColor' => '66BBFF' 
	);
	$styleCell = array (
			'valign' => 'center' 
	);
	$styleCellBTLR = array (
			'valign' => 'center',
			'textDirection' => \PhpOffice\PhpWord\Style\Cell::TEXT_DIR_BTLR 
	);
	$fontStyle = array (
			'bold' => true 
	);
	$phpWord->addTableStyle ( 'Fancy Table', $styleTable, $styleFirstRow );
	$table = $section->addTable ( 'Fancy Table' );
	$table->addRow ( 100 );
	$table->addCell ( 200, $styleCell )->addText ( htmlspecialchars ( 'S.No.', ENT_COMPAT, 'UTF-8' ), $fontStyle );
	$table->addCell ( 4000, $styleCell )->addText ( htmlspecialchars ( 'Recommendation', ENT_COMPAT, 'UTF-8' ), $fontStyle );
	$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( 'Priority', ENT_COMPAT, 'UTF-8' ), $fontStyle );
	$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( 'Impact', ENT_COMPAT, 'UTF-8' ), $fontStyle );
	$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( 'Effort', ENT_COMPAT, 'UTF-8' ), $fontStyle );
	foreach ( $data as $key => $value ) {
		
		if (! strcmp ( $key, 'Summary' ) == 0) {
			$table->addRow ();
			$table->addCell ( 200, $styleCell )->addText ( htmlspecialchars ( $cnt ++, ENT_COMPAT, 'UTF-8' ) );
			$table->addCell ( 3000, $styleCell )->addText ( htmlspecialchars ( $value ['name'], ENT_COMPAT, 'UTF-8' ) );
			$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( $value ['priority'], ENT_COMPAT, 'UTF-8' ) );
			$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( $value ['impact'], ENT_COMPAT, 'UTF-8' ) );
			$table->addCell ( 1000, $styleCell )->addText ( htmlspecialchars ( $value ['effort'], ENT_COMPAT, 'UTF-8' ) );
		}
	}
}

// for pagespeed_mindtree
function prepareJsonForPageSpeed($template, $contents, $prevKey, $urls, &$jsonFile) {
	$name = "name";
	$description = "Description";
	$analysis = "Analysis description";
	$recomendations = "Recommendations";
	$perjson = array ();
	
	// write summary
	$perjson = array (
			'descBefTable' => $template ['Summary'] ['descBefTable'],
			'descAftTable' => $template ['Summary'] ['descAftTable'] 
	);
	$jsonFile ['Summary'] = $perjson;
	
	// for test results
	foreach ( $contents as $key => $elements ) {
		// echo "<br> ";
		if (strcmp ( $key, 'urlBlocks' ) == 0 && count ( $elements ) != 0) {
			// for display
			// echo $prevKey . '<br>';
			// echo $key . "_";
			// echo count($elements) . '<br>';
			write_urls ( $elements, $urls );
			// echo "<br>";
			
			// for file
			// $name=$prevKey;
			if (count ( $urls ) != 0) {
				$perjson = array (
						'name' => $name,
						'description' => $template [$name] ['description'],
						'Analysis' => $template [$name] ['Analysis'],
						'urls' => $urls,
						'Recommendation' => $template [$name] ['Recommendation'],
						'priority' => $template [$name] ['priority'],
						'impact' => $template [$name] ['impact'],
						'effort' => $template [$name] ['effort'] 
				);
				$jsonFile [$name] = $perjson;
			}
		} else if (is_array ( $elements ) == 0) {
			if (strcmp ( $key, "localizedRuleName" ) == 0) {
				// echo $elements . '<br>';
				$name = $elements;
			}
		} else {
			$urls = array (); // resetting $urls empty
			prepareJsonForPageSpeed ( $template, $elements, $key, $urls, $jsonFile );
		}
	}
}

// for pagespeed_mindtree
function write_urls($elements, &$urls) {
	$prevVal = '';
	foreach ( $elements as $element => $el ) {
		if (is_array ( $el ) == 1) {
			write_urls ( $el, $urls );
		} else {
			if (strcmp ( $prevVal, 'URL' ) == 0) {
				// for display
				// echo $el . '<br>';
				
				// for file
				array_push ( $urls, $el );
				// echo $urlsExists;
			}
			$prevVal = $el;
		}
	}
}

// for yslow
function prepareJsonForYslow($template, $contents, $prevKey, $urls, &$jsonFile) {
	$name;
	$description = "Description";
	$analysis = "Analysis description";
	$recomendations = "Recommendations";
	$perjson = array ();
	
	// write summary
	$perjson = array (
			'descBefTable' => $template ['Summary'] ['descBefTable'],
			'descAftTable' => $template ['Summary'] ['descAftTable'] 
	);
	$jsonFile ['Summary'] = $perjson;
	foreach ( $contents as $key => $elements ) {
		// echo "<br> ";
		if (strcmp ( $key, 'components' ) == 0 && count ( $elements ) != 0) {
			// for display
			// echo $prevKey . '<br>';
			// echo $key . "_";
			display_array ( $elements, $urls );
			// echo "<br>";
			
			// for file
			$name = $prevKey;
			$perjson = array (
					
					'name' => $template [$name] ['name'],
					'description' => $template [$name] ['description'],
					'Analysis' => $template [$name] ['Analysis'],
					'urls' => $urls,
					'Recommendation' => $template [$name] ['Recommendation'],
					'priority' => $template [$name] ['priority'],
					'impact' => $template [$name] ['impact'],
					'effort' => $template [$name] ['effort'] 
			);
			//echo json_encode($name);
			$jsonFile [$name] = $perjson;
		} else if (is_array ( $elements ) == 0) {
		} else {
			prepareJsonForYslow ( $template, $elements, $key, $urls, $jsonFile );
		}
	}
}

// for yslow
function display_array($elements, &$urls) {
	foreach ( $elements as $element ) {
		// echo $element . '<br>';
		
		// for file
		array_push ( $urls, $element );
	}
}

?>
