<?php
require_once('/../../mongoUtil.php');
require('getChecklistData.php');
require('getLighthouseAudits.php');
//?request=".$request."&schedule=".$schedule."&&tag=ALL"
date_default_timezone_set ( 'Asia/Kolkata' );
//connect to DB
$Lighthousedata=$Audits;
try{
       //$connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
		$connection=connect();
        $collection = $connection->selectCollection(DB_NAME,'requests');
	}
    catch(MongoClientException $e){
        error_log($e);
        echo '{"error":"Failure in Database Connection"}';
    }
    catch(Exception $e){
        error_log($e);
    }
	//functions
	function filter($flatdata,$key,$value){
		$temp = array_filter($flatdata,function($element) use ($key, $value){
				return $element[$key]==$value;//compare 
			}
		);
		return $temp;
	}
	
	function reduce($array){
		$c = sizeof($array);
		
		$init = array("First Response Time"=>0
			,"Time TO First BYTE"=>0
			,"Perceived Response Time"=>0
			,"Visually Complete Time"=>0
			,"Actual Response Time"=>0
			,"Page Size"=>0
			,"No of Requests to Load Page"=>0);
		$reducedArray = array_reduce($array,"reduce_sum",$init);
		if($c!=0){
			foreach($reducedArray as $key=>$value){
				$reducedArray[$key] = round($value/$c,2);
			}
		}
		return $reducedArray;
	}
	function cellColor($cells,$color){
    global $objPHPExcel;

    $objPHPExcel->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray(array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'startcolor' => array(
             'rgb' => $color
        )
    ));
}
/*
cellColor('B5', 'F28A8C');
cellColor('G5', 'F28A8C');
cellColor('A7:I7', 'F28A8C');
cellColor('A17:I17', 'F28A8C');
cellColor('A30:Z30', 'F28A8C');*/
	function reduce_sum($carry,$item){
		foreach($carry as $key=>$value){
			//echo json_encode($item);
			if(array_key_exists($key, $item)){
				$carry[$key] = $value + $item[$key];
			}
		}
		return $carry;
	}
	
	//echo($totalScore);
	//fetching data from base
	//$users = $connection->selectCollection(DB_NAME,'users');
	//$query = array("_id"=>$user,"requests.".$request=>array('$exists'=>"true"));
	//$res = $users->findOne($query,array("_id"=>1));
	//if($res==null) die("Invalid Request Id");
	
	$rundata = array(); 
	if($schedule==''){
	$query = array("requestID"=>$request);
	}else{
		$query = array("requestID"=>$request,'scheduleID'=>$schedule);
	}
    
	$field = array();
	$cursor = $collection->find($query,$field);
	$flatdata = array();
		
	$summary = array();
	$summary['group'] = array();
	$summary['location'] = array();
	$summary['browser'] = array();
	$summary['network'] = array();
	$summary['label'] = array();
	
		foreach ($cursor  as $run){
			$obj = array();
			$firstView = array();
			$repeatView = array();
			$metrics = array();
			
			//if( $run["status"]!=="COMPLETE")
			//	continue;
			if(!isset($run["data"]))continue;
			$location = explode(':', $run["data"]["location"]);
			if(count($location) < 2) $location = explode('_', $run["request"]["location"]);
			if(!isset($run["data"]["firstView"]))continue;
			if(!isset($run["data"]["repeatView"]))continue;
			if(isset($run["data"]["firstView"])){
					$obj["Time TO First BYTE"] = $run["data"]["firstView"]["TTFB"]/1000 ;
					$obj["Actual Response Time"] = $run["data"]["firstView"]["fullyLoaded"]/1000 ;
					$obj["First Response Time"] = $run["data"]["firstView"]["render"]/1000 ;
					$obj["Visually Complete Time"] = $run["data"]["firstView"]["visualComplete"]/1000 ;
					$obj["Perceived Response Time"] = $run["data"]["firstView"]["docTime"]/1000 ;
					if(array_key_exists('requestsDoc', $run["data"]["firstView"])){
						$obj['No of Requests to Load Page']= $run["data"]["firstView"]["requestsDoc"];
					}
					if(array_key_exists('bytesIn', $run["data"]["firstView"])){
						$obj['Page Size']= $run["data"]["firstView"]["bytesIn"]/1024;
					}
					
					$obj['type']= "non-cached";
					$obj['group']=$run["groupID"];
					$obj['location']= $location[0];
					$obj['browser']= $location[1];				
					$obj['network']= $run["request"]["network"];				
					$obj['label']= $run["request"]["label"];
					$obj['isCustomer']=$run["request"]["isCustomer"]?"true":"false";
					
					$summary['group'][$run["groupID"]]=true;
					$summary['location'][$location[0]] =true;
					$summary['browser'][$location[1]] =true;				
					$summary['network'][$run["request"]["network"]]= true;
					$summary['label'][$run["request"]["label"]]= $run["request"]["urlOrScript"];
					//$summary['labelGroup'][$run["request"]["label"]]= 
					
					array_push($flatdata,$obj);
			}
				
			if(isset($run["data"]["repeatView"])){
					$obj["Time TO First BYTE"] = $run["data"]["firstView"]["TTFB"]/1000 ;
					$obj["Actual Response Time"] = $run["data"]["repeatView"]["fullyLoaded"]/1000 ;
					$obj["First Response Time"] = $run["data"]["repeatView"]["render"]/1000 ;
					$obj["Perceived Response Time"] = $run["data"]["repeatView"]["docTime"]/1000 ;
					$obj["Visually Complete Time"] = $run["data"]["firstView"]["visualComplete"]/1000 ;
					if(array_key_exists('requestsDoc', $run["data"]["repeatView"])){
						$obj['No of Requests to Load Page']= $run["data"]["repeatView"]["requestsDoc"];
					}
					if(array_key_exists('bytesIn', $run["data"]["repeatView"])){
						$obj['Page Size']= $run["data"]["repeatView"]["bytesIn"]/1024;
					}
					
					$obj['type']= "cached";	
					$obj['group']=$run["groupID"];
					$obj['location']= $location[0];
					$obj['browser']= $location[1];				
					$obj['network']= $run["request"]["network"];				
					$obj['label']= $run["request"]["label"];
					$obj['isCustomer']=$run["request"]["isCustomer"]?"true":"false";
					
					
					$summary['group'][$run["groupID"]]=true;
					$summary['location'][$location[0]] =true;
					$summary['browser'][$location[1]] =true;				
					$summary['network'][$run["request"]["network"]]= true;
					$summary['label'][$run["request"]["label"]]= $run["request"]["urlOrScript"];;
					
					array_push($flatdata,$obj);
			}
		}
		
		
	$temp = filter($flatdata,"label","Zurich");
	//echo json_encode($temp);
	
	$types = ["location","browser","network"];
	$viewTypes = ["non-cached","cached"];
	
	$result = array();
	
	
	$result["summary"]= array();
	foreach($viewTypes as $viewKey){
		$result["summary"][$viewKey]= array();
		$level1 = filter($flatdata,"type",$viewKey);
		foreach($summary["label"] as $labelKey=>$labelValue){
			//$result["summary"][$viewKey][$labelKey]= array();
			$level2 = filter($level1,"label",$labelKey);
			$result["summary"][$viewKey][$labelKey] = reduce($level2);
			
		}
	}
	
	foreach($types as $type){
		$result[$type]= array();
		foreach($viewTypes as $viewType){
			$result[$type][$viewType]= array();
			$level1 = filter($flatdata,"type",$viewType);
			foreach($summary[$type] as $typeKey=>$typeValue){
				$result[$type][$viewType][$typeKey]= array();
				$level2 = filter($level1,$type,$typeKey);
				foreach($summary["label"] as $labelKey=>$labelValue){
					//$result[$type][$viewType][$typeKey][$labelKey]= array();
					$level3 = filter($level2,"label",$labelKey);
					$result[$type][$viewType][$typeKey][$labelKey] = reduce($level3);
				}
			}
		}
	}
	
	$testProfiles = array();
	$testProfiles["locations"] = array();
	foreach($summary["location"] as $key=>$value){
		array_push($testProfiles["locations"],$key);
	}
	$testProfiles["browsers"] = array();
	foreach($summary["browser"] as $key=>$value){
		array_push($testProfiles["browsers"],$key);
	}
	$testProfiles["networks"] = array();
	foreach($summary["network"] as $key=>$value){
		array_push($testProfiles["networks"],$key);
	}
	$testProfiles["URLSTested"] = array();
	foreach($summary["label"] as $key=>$value){
		$obj = array();
		$obj["url"] = $value;
		$obj["labelgroup"] = $key;
		$obj["label"] = "homepage";
		array_push($testProfiles["URLSTested"],$obj);
	}
	$testProfiles["dateAndTime"] = array();
	$max = max(array_keys($summary["group"]))/1000;
	$min = min(array_keys($summary["group"]))/1000;
	$testProfiles["dateAndTime"]["StartDate"] = date("Y-m-d",$min);
	$testProfiles["dateAndTime"]["StartTime"] = date("H:i:s",$min);
	$testProfiles["dateAndTime"]["EndDate"] = date("Y-m-d",$max);
	$testProfiles["dateAndTime"]["EndTime"] = date("H:i:s",$max);
	
	$result["testProfiles"] = $testProfiles;


$jsonFile = ($result);
//echo json_encode($jsonFile);
$templateFile = __DIR__ . "\PostlaunchAuditTemplate_2.xlsx";
$fname = $request ."_".$schedule. "_" . $user . "_" . "ExcelReport.xlsx";
$outputFile = __DIR__ . "\\results\\" . $fname;

define ( 'EOL', (PHP_SAPI == 'cli') ? PHP_EOL : '<br />' );

/**
 * Include PHPExcel
 */
require_once dirname ( __FILE__ ) . '\PHPExcel.php';

// Create new PHPExcel object
// echo date('H:i:s') , " Create new PHPExcel object" , EOL;
// echo date('H:i:s') , " Create new PHPExcel object" , EOL;

// $data = json_decode(file_get_contents($jsonFile),true);
$data = $jsonFile;
$customer = "Mindtree";
// Set document properties

$objReader = PHPExcel_IOFactory::createReader ( 'Excel2007' );
$objReader->setIncludeCharts ( TRUE );
$objPHPExcel = $objReader->load ( $templateFile );

$sheetnames = $objPHPExcel->getSheetNames ();

// $objPHPExcel = PHPExcel_IOFactory::load("EndUserExperience.xlsx");

// echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties ()->setCreator ( "Aravind Kumar" )->setLastModifiedBy ( "Aravind Kumar" )->setTitle ( "Pwatch Report" )->setSubject ( "$customer Pwatch Report" )->setDescription ( "Pwatch Analysis for $customer" )->setKeywords ( "pwatch 2007 openxml php $customer phpexcel" )->setCategory ( "Report" );

// add Data

// Test Profile
$objPHPExcel->setActiveSheetIndex ( 0 );
$activeSheet = $objPHPExcel->getActiveSheet ();
$row = 8;
$activeSheet->setCellValue ( "D$row",$request);
$activeSheet->mergeCells ( "D$row:I$row" );
$row = 9;
$activeSheet->setCellValue ( "E$row", $data ['testProfiles'] ['dateAndTime'] ['StartDate'] );
$activeSheet->setCellValue ( "H$row", $data ['testProfiles'] ['dateAndTime'] ['StartTime'] );
$activeSheet->mergeCells ( "E$row:G$row" );
$activeSheet->mergeCells ( "H$row:I$row" );
$row = 10;
$activeSheet->setCellValue ( "E$row", $data ['testProfiles'] ['dateAndTime'] ['EndDate'] );
$activeSheet->setCellValue ( "H$row", $data ['testProfiles'] ['dateAndTime'] ['EndTime'] );
$activeSheet->mergeCells ( "E$row:G$row" );
$activeSheet->mergeCells ( "H$row:I$row" );
$row = 11;
$activeSheet->setCellValue ( "D$row",$request);
$activeSheet->mergeCells ( "D$row:I$row" );
$row = 12;
$URlsCount_1=0;
foreach ( $data ['testProfiles'] ['URLSTested'] as $i => $value ) {
	$activeSheet->setCellValue ( "D$row", $value ['url'] );
	$activeSheet->mergeCells ( "D$row:I$row" );
	$URlsCount_1++;
	$row ++;
	$activeSheet->insertNewRowBefore ( $row, 1 );
}
$activeSheet->removeRow ( $row );
$row ++;
$row=30+$URlsCount_1-1;
$AvgTTFB=0;
$AvgART=0;
$AvgSR=0;
$AvgDC=0;
$AvgVC=0;
foreach ( $data ['summary'] ['non-cached'] as $i => $value ) {
	$AvgTTFB=$AvgTTFB+$value ["Time TO First BYTE"];
	$AvgART=$AvgART+$value ["Actual Response Time"];
	$AvgSR=$AvgSR+$value ["First Response Time"];
	$AvgDC=$AvgDC+$value ["Perceived Response Time"];
	$AvgVC=$AvgVC+$value ["Visually Complete Time"];
	
	$activeSheet->setCellValue ( "C$row", $i );
	$activeSheet->mergeCells ( "C$row:H$row" );
	$activeSheet->setCellValue ( "I$row", $value ["Actual Response Time"] );
	$row ++;
	$activeSheet->insertNewRowBefore ( $row, 1 );
}
$activeSheet->removeRow ( $row );
$row=19+$URlsCount_1-1;
$activeSheet->setCellValue ( "Q$row",round(($AvgART/$URlsCount_1),2));
$row++;
$activeSheet->setCellValue ( "Q$row",round(($AvgTTFB/$URlsCount_1),2));
//Checklist
$objPHPExcel->setActiveSheetIndex (1);
$sheet = $sheetnames [1];
$activeSheet = $objPHPExcel->getActiveSheet ();
	checkstatusandUpdateCellvalue_Color("D2",'E2',$totalScore ["score_OnPageRedirects"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D3","E3",$totalScore ["score_gzip"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D4","E4",$totalScore ["score_cache"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D5","E5",$totalScore ["score_minify"],$activeSheet);
	if(($totalScore ["score_progressive_jpeg"])=='NA'){
	checkstatusandUpdateCellvalue_Color("D6","E6",($totalScore ["score_compress"]),$activeSheet);
	}
	else{
	checkstatusandUpdateCellvalue_Color("D6","E6",(($totalScore ["score_progressive_jpeg"])*0.3)+(($totalScore ["score_compress"])*0.7),$activeSheet);
	}
	checkstatusandUpdateCellvalue_Color("D7","E7",$totalScore ["score_cssDelivery"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D8",'E8',$totalScore ["score_renderBlockingJs"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D9","E9",$totalScore ["score_keep-alive"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D10","E10",$totalScore ["score_cdn"],$activeSheet);
	checkstatusandUpdateCellvalue_Color("D11","E11",$totalScore ["score_BrowserResponseTime"],$activeSheet);
	$AvgResponseValues="Time to First Byte:".round(($AvgTTFB/$URlsCount_1),2).
	"\n First Response Time :".round(($AvgSR/$URlsCount_1),2).
	"\n Visually Complete Time:".round(($AvgVC/$URlsCount_1),2).
	"\n Doc complete time:".round(($AvgDC/$URlsCount_1),2).
	"\n Fully Load Time:".round(($AvgART/$URlsCount_1),2);
	$activeSheet->setCellValue ( "E11",$AvgResponseValues );
	$activeSheet->getStyle('E11')->getAlignment()->setWrapText(true);
	//checkstatusandUpdateCellvalue_Color("D12",$totalScore ["score_compress"],$activeSheet);
	//$activeSheet->setCellValue ( "E6", $totalScore ["score_progressive_jpeg"] );
//ResponseDetails
$objPHPExcel->setActiveSheetIndex (2);
$sheet = $sheetnames [2];
$activeSheet = $objPHPExcel->getActiveSheet ();
$row = 20;
foreach ( $data ['summary'] ['non-cached'] as $i => $value ) {
	
	$activeSheet->setCellValue ( "B$row", $i );
	
	$activeSheet->setCellValue ( "C$row", $value ["Time TO First BYTE"] );
	$activeSheet->setCellValue ( "D$row", $value ["First Response Time"] );
	$activeSheet->setCellValue ( "F$row", $value ["Perceived Response Time"] );
	$activeSheet->setCellValue ( "E$row", $value ["Visually Complete Time"] );
	$activeSheet->setCellValue ( "G$row", $value ["Actual Response Time"] );
	$activeSheet->setCellValue ( "H$row", $value ["Page Size"] );
	$activeSheet->setCellValue ( "I$row", $value ["No of Requests to Load Page"] );
	$row ++;
	$activeSheet->insertNewRowBefore ( $row, 1 );
}
$activeSheet->removeRow ( $row );
$dataExtent = 'B19G' . ($row - 1);
$chartExtent = 'B2O16';

buildChart ( "Percieved Response Time First Time User(Non - cached)", $sheet, $activeSheet, $dataExtent, $chartExtent );
$objPHPExcel->setActiveSheetIndex ( 0 );
$activeSheet = $objPHPExcel->getActiveSheet ();
$sheet = $sheetnames [0];
$dataExtent = 'AF2AG3';
$chartExtent = 'K6O16';
$ChartType='TYPE_DONUTCHART';
buildMYChart( "Overall Result - Performance", $sheet, $activeSheet, $dataExtent, $chartExtent);
//Recommendations
//$objPHPExcel->setActiveSheetIndex (3);
//$sheet = $sheetnames [3];
//$activeSheet = $objPHPExcel->getActiveSheet ();
//$row=2;
  //foreach ($Lighthousedata as $Audit){
	
	//$activeSheet->setCellValue ( "A$row",$Audit['AUDITURL'] );
	//foreach ($Audit as $checkpoints){
		//if($checkpoints["group"]=='load-opportunities'){
			//$activeSheet->setCellValue( "B$row",$checkpoints["title"]);
			//$row++;
		//}
		
	//}
	//$row++;
 //}



// Output
$objPHPExcel->setActiveSheetIndex ( 0 );
$objWriter = PHPExcel_IOFactory::createWriter ( $objPHPExcel, 'Excel2007' );
$objWriter->setIncludeCharts ( TRUE );
$objWriter->save ( $outputFile );
function checkstatusandUpdateCellvalue_Color($cell1,$cell2,$value,$activeSheet){
	if($value!=null&&$value!='NA'){
	if(($value)>=60){
		$activeSheet->setCellValue ( $cell1,"Pass");
		cellColor($cell1, '006400');
	}
	else {
		$activeSheet->setCellValue ( $cell1,"Fail");
		$activeSheet->setCellValue ( $cell2 ,"More no of resources were observed failing the criteria,please check the Detailed Report for links of failing resources");
		cellColor($cell1, 'ff0000');
	
	}
	}else{
		$activeSheet->setCellValue ( $cell1,"Check Manually");
		cellColor($cell1, 'ff8c00');
	}
}

//TYPE_DONUTCHART 
function buildMYChart($title, $sheetName, $activeSheet, $dataExtent, $chartExtent) {
	//echo "<br>" . $dataExtent;
	//echo "<br>" . $chartExtent;
	preg_match_all ( "/[A-Z]{1,2}|[0-9]{1,3}/", $dataExtent, $dataSplit );
	// echo '<br>'.json_encode($dataSplit);
	$dataFirstCol = $dataSplit [0] [0];
	$dataFirstRow = $dataSplit [0] [1];
	$dataLastCol = $dataSplit [0] [2];
	$dataLastRow = $dataSplit [0] [3];
	preg_match_all ( "/[A-Z]{1,2}[0-9]{1,3}/", $chartExtent, $chartSplit );
	$chartTopLeft = $chartSplit [0] [0];
	$chartBottomRight = $chartSplit [0] [1];
	$dataSeriesLabels = array ();
	// echo "<br>dataLabel<br>";
	for($i = $dataFirstRow + 1; $i <= $dataLastRow; $i ++) {
		$dataSeriesLabels [] = new PHPExcel_Chart_DataSeriesValues ( 'String', $sheetName . '!$' . $dataFirstCol . '$' . $i, NULL, 1 );
		// echo '<br>'.$sheetName.'!$'.$dataFirstCol.'$'.$i;
	}
	$xAxisTickValues = array (
			new PHPExcel_Chart_DataSeriesValues ( 'String', $sheetName . '!$' . chr ( ord ( $dataFirstCol ) + 1 ) . '$' . $dataFirstRow . ':$' . ($dataLastCol) . '$' . $dataFirstRow, NULL, ord ( $dataLastCol - $dataFirstCol ) ) 
	);
	// echo "<br>AxisLabel<br>";
	// echo $sheetName.'!$'.chr(ord($dataFirstCol)+1).'$'.$dataFirstRow.':$'.($dataLastCol).'$'.$dataFirstRow;
	
	// echo "<br>Data<br>";
	$dataSeriesValues = array ();
	
	// echo $dataFirstRow;
	for($i = $dataFirstRow + 1; $i <= $dataLastRow; $i ++) {
		$dataSeriesValues [] = new PHPExcel_Chart_DataSeriesValues ( 'Number', $sheetName . '!$' . chr ( ord ( $dataFirstCol ) + 1 ) . '$' . ($i) . ':$' . $dataLastCol . '$' . $i, NULL, ord ( $dataLastCol - $dataFirstCol ) );
		// echo '<br>'.$sheetName.'!$'.chr(ord($dataFirstCol)+1).'$'.($i).':$'.$dataLastCol.'$'.$i;
	}
	
	$series = new PHPExcel_Chart_DataSeries ( PHPExcel_Chart_DataSeries::TYPE_DONUTCHART, // plotType
	PHPExcel_Chart_DataSeries::GROUPING_STANDARD, // plotGrouping
	range ( 0, count ( $dataSeriesValues ) - 1 ), // plotOrder
	$dataSeriesLabels, // plotLabel
	$xAxisTickValues, // plotCategory
	$dataSeriesValues ); // plotValues
	
	$series->setPlotDirection ( PHPExcel_Chart_DataSeries::DIRECTION_COL );
	$plotArea = new PHPExcel_Chart_PlotArea ( NULL, array (
			$series 
	) );
	$legend = new PHPExcel_Chart_Legend ( PHPExcel_Chart_Legend::POSITION_TOP, NULL, false );
	$title = new PHPExcel_Chart_Title ( $title );
	//$yAxisLabel = new PHPExcel_Chart_Title ( 'Seconds' );
	
	$chart = new PHPExcel_Chart ( $title, // name
	$title, // title
	$legend, // legend
	$plotArea, // plotArea
	true, // plotVisibleOnly
	0, // displayBlanksAs
	NULL // xAxisLabel
	 ); // yAxisLabel//$yAxisLabel
	
	$chart->setTopLeftPosition ( $chartTopLeft );
	$chart->setBottomRightPosition ( $chartBottomRight );
	$activeSheet->addChart ( $chart );
}
function buildChart($title, $sheetName, $activeSheet, $dataExtent, $chartExtent) {
	//echo "<br>" . $dataExtent;
	//echo "<br>" . $chartExtent;
	preg_match_all ( "/[A-Z]{1,2}|[0-9]{1,3}/", $dataExtent, $dataSplit );
	// echo '<br>'.json_encode($dataSplit);
	$dataFirstCol = $dataSplit [0] [0];
	$dataFirstRow = $dataSplit [0] [1];
	$dataLastCol = $dataSplit [0] [2];
	$dataLastRow = $dataSplit [0] [3];
	preg_match_all ( "/[A-Z]{1,2}[0-9]{1,3}/", $chartExtent, $chartSplit );
	$chartTopLeft = $chartSplit [0] [0];
	$chartBottomRight = $chartSplit [0] [1];
	$dataSeriesLabels = array ();
	// echo "<br>dataLabel<br>";
	for($i = $dataFirstRow + 1; $i <= $dataLastRow; $i ++) {
		$dataSeriesLabels [] = new PHPExcel_Chart_DataSeriesValues ( 'String', $sheetName . '!$' . $dataFirstCol . '$' . $i, NULL, 1 );
		// echo '<br>'.$sheetName.'!$'.$dataFirstCol.'$'.$i;
	}
	$xAxisTickValues = array (
			new PHPExcel_Chart_DataSeriesValues ( 'String', $sheetName . '!$' . chr ( ord ( $dataFirstCol ) + 1 ) . '$' . $dataFirstRow . ':$' . ($dataLastCol) . '$' . $dataFirstRow, NULL, ord ( $dataLastCol - $dataFirstCol ) ) 
	);
	// echo "<br>AxisLabel<br>";
	// echo $sheetName.'!$'.chr(ord($dataFirstCol)+1).'$'.$dataFirstRow.':$'.($dataLastCol).'$'.$dataFirstRow;
	
	// echo "<br>Data<br>";
	$dataSeriesValues = array ();
	
	// echo $dataFirstRow;
	for($i = $dataFirstRow + 1; $i <= $dataLastRow; $i ++) {
		$dataSeriesValues [] = new PHPExcel_Chart_DataSeriesValues ( 'Number', $sheetName . '!$' . chr ( ord ( $dataFirstCol ) + 1 ) . '$' . ($i) . ':$' . $dataLastCol . '$' . $i, NULL, ord ( $dataLastCol - $dataFirstCol ) );
		// echo '<br>'.$sheetName.'!$'.chr(ord($dataFirstCol)+1).'$'.($i).':$'.$dataLastCol.'$'.$i;
	}
	
	$series = new PHPExcel_Chart_DataSeries ( PHPExcel_Chart_DataSeries::TYPE_BARCHART, // plotType
	PHPExcel_Chart_DataSeries::GROUPING_STANDARD, // plotGrouping
	range ( 0, count ( $dataSeriesValues ) - 1 ), // plotOrder
	$dataSeriesLabels, // plotLabel
	$xAxisTickValues, // plotCategory
	$dataSeriesValues ); // plotValues
	
	$series->setPlotDirection ( PHPExcel_Chart_DataSeries::DIRECTION_COL );
	$plotArea = new PHPExcel_Chart_PlotArea ( NULL, array (
			$series 
	) );
	$legend = new PHPExcel_Chart_Legend ( PHPExcel_Chart_Legend::POSITION_LEFT, NULL, false );
	$title = new PHPExcel_Chart_Title ( $title );
	$yAxisLabel = new PHPExcel_Chart_Title ( 'Seconds' );
	
	$chart = new PHPExcel_Chart ( $title, // name
	$title, // title
	$legend, // legend
	$plotArea, // plotArea
	true, // plotVisibleOnly
	0, // displayBlanksAs
	NULL, // xAxisLabel
	$yAxisLabel ); // yAxisLabel
	
	$chart->setTopLeftPosition ( $chartTopLeft );
	$chart->setBottomRightPosition ( $chartBottomRight );
	$activeSheet->addChart ( $chart );
}