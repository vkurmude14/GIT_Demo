<!DOCTYPE html>
<html>
<body>
	<form action="../PwatchServer/pass.php" method="post">
		username:
		<input type="text" name="user"></br>
		password:
		<input type="password" name="pass"></br>
		<input type="submit" name="submit" value="Register">
	</form>
</body>
</html>