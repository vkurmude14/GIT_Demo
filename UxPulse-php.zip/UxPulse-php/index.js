	//console.log(detaildata);
	//console.log('data');
details = document.getElementById("details");

if(window.Testsdata != undefined) {
Testsdata.forEach(function(value){
	console.log(value);
	for (var key in value) {
		var testdata=value[key];
		var TaskData ="";
		//console.log(value[key]);
		var Uidata="<ll><input type="+"checkbox"+" name="+"selectedrequests[]"+" value="+testdata.requestID+">"+testdata.requestID+"</ll>";
		var tasks=testdata.tasks;
		
        for(i=0;i<tasks.length;i++){
			var task = tasks[i];
			 for(j=0;j<task.length;j++){
			
			console.log(task[j]);
			TaskData=TaskData+"<li>("+tasks[i][j].label+"/"+tasks[i][j].location+"/"+tasks[i][j].network+")</li>";
			 }
		}
		var button="<button type="+"button"+"class="+"btn btn-info"+"data-toggle="+"collapse" +"data-target="+"#demo"+">expand</button>";
		details.innerHTML=details.innerHTML+"<div>"+Uidata+"</div>";
	}
});
}
else if(window.detaildata!= undefined){
detaildata.forEach(function(value) {
				//var classes = "pull-right";
				var classes="";
				if(value.status==="COMPLETED") classes=" label-success";
				else if(value.status==="FAILED") classes=" label-danger";
				else if(value.status==="PARTIAL") classes=" label-warning";
				else  classes=classes+" label-info";
		var data1="";
		var data2;
		data2="<ll><input type="+"checkbox"+" name="+"selectedgroups[]"+" value="+value.group+">"+new Date (+value.group) + "("+value.complete+"/"+value.failed+"/"+value.running+")<span class='pull-right"+classes+"'>"+value.status+"</span>"+ "</ll>";
		value.runs.forEach(function(run){
			var classes="";
				if(run.status==="COMPLETE") {
				//classes = classes +" label-success";
				var rundata=run.data;
				var firstviw=rundata.firstView;
				
			    console.log(rundata);
				if(firstviw!=null){
				if(firstviw.docTime==0){
					classes = classes +" label-warning";
				}
				else{
					classes = classes +"label-success"
				}
				}
				else{
					classes = classes +" label-warning";
				}
				}
				else if(run.status==="FAILED") classes=" label-danger";
				else if(run.status==="WAITING") classes=" label-info";
				else  classes=classes+" label-info";
			//console.log(run);
			data1=data1+"<li title="+"'"+run.statusText+" (Errors: " + (run.errors.toString()||"None")+" )"+"'"+" <label><input type="+"checkbox"+" name="+"selectedtests[]"+" value="+run.testID+">"+run.testID +" ("+run.request.label+" - "+run.request.location + "."+run.request.network+") : <span style='font-size: 75%'class='"+classes+"'>"+run.status+"</span></input></label></li>";
		});
		details.innerHTML=details.innerHTML+"<div>"+data2+"<ul>"+data1+"</ul></div>";
        console.log(value);
});
}