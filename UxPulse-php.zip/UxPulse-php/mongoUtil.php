<?php
//require('PwatchServer\\config.php');
function connect()
{
	 //$connection = new MongoClient('mongodb://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.':'.DB_PORT.'/'.DB_NAME);
	 $connection = new MongoClient('mongodb://'.DB_HOST.':'.DB_PORT);
    return $connection;
}
?>