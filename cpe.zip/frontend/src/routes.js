const routes = {
  "/": "Home",
  "/dashboard": "Dashboard",
  "/configurations": "Configurations",
  "/job/createJob": "CreateJob",
  "/job/editJob": "EditJob",
  "/job/PC": "PerformanceCenter",
  "/job/createPCJob": "CreatePCJob",
  "/job/editPCJob": "EditPCJob",
  "/job/createLRJob": "CreateLRJob",
  "/job/editLRJob": "EditLRJob",
  "/pipeline/addJobToExisting": "AddJobToExisting",
  "/pipeline/createPipeline": "CreatePipeline",
  "/pipeline/editPipeline": "EditPipeline",
  "/node/createNode": "CreateNode",
  "/node/editNode": "EditNode",
};
export default routes;
