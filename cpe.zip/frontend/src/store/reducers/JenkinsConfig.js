import * as actionTypes from '../actions/ActionTypes';
import { updateObject } from '../utility';

const initialState = {
  updateUser: {
    loading: false,
    error: null,
    success: false
  },
  updateUrl: {
    loading: false,
    error: null,
    success: false
  },
  updateConfig: {
    loading: false,
    error: null,
    success: false
  },
  fetch: {
    url: {
      hostname: null,
      port: null,
      hosttype:null,
    },
    user: {
      username: null,
      password: null,
    },
    config: {
      jmf: null,
      grafana: null,
      jenkinsPath: null,
      jmeterHome: null,
    },
    loading: false,
    error: null,
    success: false,
  }
}

const getConfigsStart = (state) => {
  return updateObject(state, {
    fetch: updateObject(state.fetch, {
      loading: true,
      error: null,
      success: false,
    })

  })
}

const getConfigsSuccess = (state, action) => {
  console.log(action);
  return updateObject(state, {
    fetch: updateObject(state.fetch, {
      loading: false,
      success: true,
      user: {
        username: action.configs.user.username,
        password: action.configs.user.password,
      },
      url: {
        hostname: action.configs.url.hostname,
        port: action.configs.url.port,
        hosttype:action.configs.url.hosttype,
      },
      config: {
        jmf: action.configs.config.jmf,
        grafana: action.configs.config.grafana,
        jenkinsPath: action.configs.config.jenkinsPath,
        jmeterHome: action.configs.config.jmeterHome,
      }
    })

  })
}

const getConfigsFail = (state, action) => {
  return updateObject(state, {
    fetch: updateObject(state.fetch, {
      loading: false,
      error: action.error,
      success: false,
    })
  })
}

const updateConfigStart = (state) => {
  return updateObject(state, {
    updateConfig: updateObject(state.updateConfig, {
      loading: true,
      error: null,
      success: false,
    })
  })
}

const updateConfigSuccess = (state, action) => {
  console.log(action);
  return updateObject(state, {
    updateConfig: updateObject(state.updateConfig, {
      loading: false,
      success: true,
    }),
    fetch: updateObject(state.fetch, {
      config: {
        jmf: action.config.jmf,
        grafana: action.config.grafana,
        jenkinsPath: action.config.jenkinsPath,
        jmeterHome: action.config.jmeterHome,
      }
    })
  })
}

const updateConfigFail = (state, action) => {
  return updateObject(state, {
    updateConfig: updateObject(state.updateConfig, {
      loading: false,
      error: action.error,
      success: false,
    }),
  })
}

const updateUrlStart = (state) => {
  return updateObject(state, {
    updateUrl: updateObject(state.updateUrl, {
      loading: true,
      error: null,
      success: false,
    })
  })
}

const updateUrlSuccess = (state, action) => {
  console.log(action);
  return updateObject(state, {
    updateUrl: updateObject(state.updateUrl, {
      loading: false,
      success: true,
    }),
    fetch: updateObject(state.fetch, {
      url: {
        hostname: action.url.hostname,
        port: action.url.port,
        hosttype:action.url.hosttype,
      }
    })
  })
}

const updateUrlFail = (state, action) => {
  return updateObject(state, {
    updateUrl: updateObject(state.updateUrl, {
      loading: false,
      error: action.error,
      success: false,
    })
  })
}

const updateUserStart = (state) => {
  return updateObject(state, {
    updateUser: updateObject(state.updateUser, {
      loading: true,
      error: null,
      success: false,
    })
  })
}

const updateUserSuccess = (state, action) => {
  console.log(action);
  return updateObject(state, {
    updateUser: updateObject(state.updateUser, {
      loading: false,
      success: true,
    }),
    fetch: updateObject(state.fetch, {
      user: {
        username: action.user.username,
        password: action.user.password,
      }
    })
  })
}

const updateUserFail = (state, action) => {
  return updateObject(state, {
    updateUser: updateObject(state.updateUser, {
      loading: false,
      error: action.error,
      success: false,
    })
  })
}

export default (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_CONFIGS_START: return getConfigsStart(state);
    case actionTypes.GET_CONFIGS_SUCCESS: return getConfigsSuccess(state, action);
    case actionTypes.GET_CONFIGS_FAIL: return getConfigsFail(state, action);

    case actionTypes.UPDATE_CONFIG_START: return updateConfigStart(state);
    case actionTypes.UPDATE_CONFIG_SUCCESS: return updateConfigSuccess(state, action);
    case actionTypes.UPDATE_CONFIG_FAIL: return updateConfigFail(state, action);

    case actionTypes.UPDATE_USER_START: return updateUserStart(state);
    case actionTypes.UPDATE_USER_SUCCESS: return updateUserSuccess(state, action);
    case actionTypes.UPDATE_USER_FAIL: return updateUserFail(state, action);

    case actionTypes.UPDATE_URL_START: return updateUrlStart(state);
    case actionTypes.UPDATE_URL_SUCCESS: return updateUrlSuccess(state, action);
    case actionTypes.UPDATE_URL_FAIL: return updateUrlFail(state, action);

    default:
      return state
  }
}
