import { combineReducers } from 'redux';
import JenkinsConfig from './JenkinsConfig';
import JenkinsJob from './JenkinsJob';
import JenkinsPipeline from './JenkinsPipeline';
import JenkinsNode from './JenkinsNode';
import auth from './auth';

export default combineReducers({
  JenkinsConfig,
  JenkinsJob,
  JenkinsPipeline,
  JenkinsNode,
  auth
});