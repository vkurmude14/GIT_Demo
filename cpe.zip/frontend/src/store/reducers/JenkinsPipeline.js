import * as actionTypes from '../actions/ActionTypes';
import { updateObject } from '../utility';

const initialState = {
  pipelines: {
    pipelineList: null,
    loading: false,
    success: false,
    error: null
  },
  addJobToExisting: {
    pipelineName: null,
    loading: false,
    success: false,
    error: null
  },
  createPipeline: {
    pipelineName: null,
    loading: false,
    success: false,
    error: null
  },
  fetchPipeline: {
    pipeline: null,
    loading: false,
    success: false,
    error: null
  },
  updatePipeline: {
    pipelineName: null,
    loading: false,
    success: false,
    error: null
  },
  deletePipeline: {
    pipelineName: null,
    loading: false,
    error: null,
    success: false,
  },
  pipelineStages: {
    list: null,
    loading: false,
    success: false,
    error: null
  }
  
}

/**
|--------------------------------------------------
| Fetch All pipeline names
|--------------------------------------------------
*/

const fetchAllPipelinesStart = state => {
  return updateObject(state, {
    pipelines: updateObject(state.pipelines, { loading: true, success: false, error: null })
  })
}

const fetchAllPipelinesSuccess = (state, action) => {
  return updateObject(state, {
    pipelines: updateObject(state.pipelines, { pipelineList: action.pipelines,  success: true, loading: false, error: null })
  })
}

const fetchAllPipelinesFail = (state, action) => {
  return updateObject(state, {
    pipelines: updateObject(state.pipelines, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Add job to existing Pipeline
|--------------------------------------------------
*/

const addJobToExistingStart = (state) => {
  return updateObject(state, {
    addJobToExisting: updateObject(state.addJobToExisting, { loading: true, success: false, error: null })
  })
}

const addJobToExistingSuccess = (state, action) => {
  return updateObject(state, {
    addJobToExisting: updateObject(state.addJobToExisting, { pipelineName: action.pipelineName,  success: true, loading: false, error: null })
  })
}

const addJobToExistingFail = (state, action) => {
  return updateObject(state, {
    addJobToExisting: updateObject(state.addJobToExisting, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Create Pipeline
|--------------------------------------------------
*/

const createPipelineStart = (state) => {
  return updateObject(state, {
    createPipeline: updateObject(state.createPipeline, { loading: true, success: false, error: null })
  })
}

const createPipelineSuccess = (state, action) => {
  return updateObject(state, {
    createPipeline: updateObject(state.createPipeline, { pipelineName: action.pipelineName,  success: true, loading: false, error: null })
  })
}

const createPipelineFail = (state, action) => {
  return updateObject(state, {
    createPipeline: updateObject(state.createPipeline, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Fetch pipeline details
|--------------------------------------------------
*/

const fetchPipelineStart = (state) => {
  return updateObject(state, {
    fetchPipeline: updateObject(state.fetchPipeline, { loading: true, success: false, error: null })
  })
}

const fetchPipelineSuccess = (state, action) => {
  return updateObject(state, {
    fetchPipeline: updateObject(state.fetchPipeline, { pipeline: action.pipeline,  success: true, loading: false, error: null })
  })
}

const fetchPipelineFail = (state, action) => {
  return updateObject(state, {
    fetchPipeline: updateObject(state.fetchPipeline, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Update Pipeline
|--------------------------------------------------
*/

const updatePipelineStart = (state) => {
  return updateObject(state, {
    updatePipeline: updateObject(state.updatePipeline, { loading: true, success: false, error: null })
  })
}

const updatePipelineSuccess = (state, action) => {
  return updateObject(state, {
    updatePipeline: updateObject(state.updatePipeline, { pipelineName: action.pipelineName,  success: true, loading: false, error: null })
  })
}

const updatePipelineFail = (state, action) => {
  return updateObject(state, {
    updatePipeline: updateObject(state.updatePipeline, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Delete Pipeline
|--------------------------------------------------
*/

const deletePipelineStart = (state) => {
  return updateObject(state, {
    deletePipeline: updateObject(state.deletePipeline, { loading: true, success: false, error: null })
  })
}

const deletePipelineSuccess = (state, action) => {
  const pipelineList = state.pipelines.pipelineList.filter(pipeline => pipeline !== action.pipelineName);
  return updateObject(state, {
    deletePipeline: updateObject(state.deletePipeline, { pipelineName: action.pipelineName,  success: true, loading: false, error: null }),
    pipelines: updateObject(state.pipelines, { pipelineList: pipelineList })
  })
}

const deletePipelineFail = (state, action) => {
  return updateObject(state, {
    deletePipeline: updateObject(state.deletePipeline, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Fetch pipeline stages
|--------------------------------------------------
*/

const fetchPipelineStagesStart = state => {
  return updateObject(state, {
    pipelineStages: updateObject(state.pipelineStages, { loading: true, success: false, error: null })
  })
}

const fetchPipelineStagesSuccess = (state, action) => {
  return updateObject(state, {
    pipelineStages: updateObject(state.pipelineStages, { list: action.pipelineStages,  success: true, loading: false, error: null })
  })
}

const fetchPipelineStagesFail = (state, action) => {
  return updateObject(state, {
    pipelineStages: updateObject(state.pipelineStages, { loading: false, error: action.error })
  })
}

export default (state = initialState, action) => {
  switch (action.type) {

    case actionTypes.FETCH_ALL_PIPELINES_START: return fetchAllPipelinesStart(state);
    case actionTypes.FETCH_ALL_PIPELINES_SUCCESS: return fetchAllPipelinesSuccess(state, action);
    case actionTypes.FETCH_ALL_PIPELINES_FAIL: return fetchAllPipelinesFail(state, action);

    case actionTypes.ADD_JOB_TO_EXISTING_START: return addJobToExistingStart(state);
    case actionTypes.ADD_JOB_TO_EXISTING_SUCCESS: return addJobToExistingSuccess(state, action);
    case actionTypes.ADD_JOB_TO_EXISTING_FAIL: return addJobToExistingFail(state, action);

    case actionTypes.CREATE_PIPELINE_START: return createPipelineStart(state);
    case actionTypes.CREATE_PIPELINE_SUCCESS: return createPipelineSuccess(state, action);
    case actionTypes.CREATE_PIPELINE_FAIL: return createPipelineFail(state, action);

    case actionTypes.FETCH_PIPELINE_START: return fetchPipelineStart(state);
    case actionTypes.FETCH_PIPELINE_SUCCESS: return fetchPipelineSuccess(state, action);
    case actionTypes.FETCH_PIPELINE_FAIL: return fetchPipelineFail(state, action);

    case actionTypes.UPDATE_PIPELINE_START: return updatePipelineStart(state);
    case actionTypes.UPDATE_PIPELINE_SUCCESS: return updatePipelineSuccess(state, action);
    case actionTypes.UPDATE_PIPELINE_FAIL: return updatePipelineFail(state, action);

    case actionTypes.DELETE_PIPELINE_START: return deletePipelineStart(state);
    case actionTypes.DELETE_PIPELINE_SUCCESS: return deletePipelineSuccess(state, action);
    case actionTypes.DELETE_PIPELINE_FAIL: return deletePipelineFail(state, action);

    case actionTypes.FETCH_PIPELINE_STAGES_START: return fetchPipelineStagesStart(state);
    case actionTypes.FETCH_PIPELINE_STAGES_SUCCESS: return fetchPipelineStagesSuccess(state, action);
    case actionTypes.FETCH_PIPELINE_STAGES_FAIL: return fetchPipelineStagesFail(state, action);

    default:
      return state
  }
}
