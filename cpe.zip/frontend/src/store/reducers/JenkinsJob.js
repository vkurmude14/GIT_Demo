import * as actionTypes from "../actions/ActionTypes";
import { updateObject } from "../utility";

const initialState = {
  jobs: {
    jobList: null,
    loading: false,
    error: null,
  },
  getRunningJobs: {
    list: null,
    loading: false,
    error: null,
    success: false,
  },
  createJob: {
    jobName: null,
    loading: false,
    error: null,
    success: false,
  },
  fetchJob: {
    job: null,
    loading: false,
    error: null,
    success: false,
  },
  updateJob: {
    jobName: null,
    loading: false,
    error: null,
    success: false,
  },
  deleteJob: {
    jobName: null,
    loading: false,
    error: null,
    success: false,
  },
};

/**
|--------------------------------------------------
| Fetch All job names
|--------------------------------------------------
*/

const ftechAllJobsStart = (state) => {
  return updateObject(state, {
    jobs: updateObject(state.jobs, { loading: true, error: null }),
  });
};
const ftechAllRelativeJobsStart = (state) => {
  return updateObject(state, {
    jobs: updateObject(state.jobs, { loading: true, error: null }),
  });
};

const ftechAllJobsSuccess = (state, action) => {
  console.log(action.jobs);
  return updateObject(state, {
    jobs: updateObject(state.jobs, {
      jobList: action.jobs,
      loading: false,
      error: null,
    }),
  });
};

const ftechAllJobsFail = (state, action) => {
  return updateObject(state, {
    jobs: updateObject(state.jobs, { loading: false, error: action.error }),
  });
};

/**
|--------------------------------------------------
| Check if job exists
|--------------------------------------------------
*/

const getRunningJobsStart = (state) => {
  return updateObject(state, {
    getRunningJobs: updateObject(state.getRunningJobs, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const getLRMetricsStart = (state) => {
  return updateObject(state, {
    getRunningJobs: updateObject(state.getLRMetrics, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const getRunningJobsSuccess = (state, action) => {
  return updateObject(state, {
    getRunningJobs: updateObject(state.getRunningJobs, {
      list: action.jobs,
      loading: false,
      error: null,
      success: true,
    }),
  });
};

const getRunningJobsFail = (state, action) => {
  return updateObject(state, {
    getRunningJobs: updateObject(state.getRunningJobs, {
      loading: false,
      error: action.error,
    }),
  });
};

/**
|--------------------------------------------------
| Create Job
|--------------------------------------------------
*/

const createJobStart = (state) => {
  return updateObject(state, {
    createJob: updateObject(state.createJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const createJobSuccess = (state, action) => {
  return updateObject(state, {
    createJob: updateObject(state.createJob, {
      jobName: action.jobName,
      loading: false,
      error: null,
      success: true,
    }),
  });
};

const createJobFail = (state, action) => {
  return updateObject(state, {
    createJob: updateObject(state.createJob, {
      loading: false,
      error: action.error,
    }),
  });
};

/**
|--------------------------------------------------
| PC Job
|--------------------------------------------------
*/
const createPCJobStart = (state) => {
  return updateObject(state, {
    createJob: updateObject(state.createPCJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const updatePCJobStart = (state) => {
  return updateObject(state, {
    updateJob: updateObject(state.updateJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const fetchPCJobStart = (state) => {
  return updateObject(state, {
    fetchPCJob: updateObject(state.fetchPCJob, {
      job: null,
      loading: true,
      success: false,
      error: null,
    }),
  });
};

/**
|--------------------------------------------------
| LR Job
|--------------------------------------------------
*/
const createLRJobStart = (state) => {
  return updateObject(state, {
    createJob: updateObject(state.createLRJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const updateLRJobStart = (state) => {
  return updateObject(state, {
    updateJob: updateObject(state.updateLRJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const fetchLRJobStart = (state) => {
  return updateObject(state, {
    fetchPCJob: updateObject(state.fetchLRJob, {
      job: null,
      loading: true,
      success: false,
      error: null,
    }),
  });
};
/**
|--------------------------------------------------
| Fetch job details
|--------------------------------------------------
*/

const fetchJobStart = (state) => {
  return updateObject(state, {
    fetchJob: updateObject(state.fetchJob, {
      job: null,
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const fetchJobSuccess = (state, action) => {
  return updateObject(state, {
    fetchJob: updateObject(state.fetchJob, {
      job: action.job,
      loading: false,
      error: null,
      success: true,
    }),
  });
};

const fetchJobFail = (state, action) => {
  return updateObject(state, {
    fetchJob: updateObject(state.fetchJob, {
      loading: false,
      error: action.error,
    }),
  });
};

/**
|--------------------------------------------------
| Update Job
|--------------------------------------------------
*/

const updateJobStart = (state) => {
  return updateObject(state, {
    updateJob: updateObject(state.updateJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const updateJobSuccess = (state, action) => {
  return updateObject(state, {
    updateJob: updateObject(state.updateJob, {
      jobName: action.jobName,
      loading: false,
      error: null,
      success: true,
    }),
  });
};

const updateJobFail = (state, action) => {
  return updateObject(state, {
    updateJob: updateObject(state.updateJob, {
      loading: false,
      error: action.error,
    }),
  });
};

/**
|--------------------------------------------------
| Delete Job
|--------------------------------------------------
*/

const deleteJobStart = (state) => {
  return updateObject(state, {
    deleteJob: updateObject(state.deleteJob, {
      loading: true,
      success: false,
      error: null,
    }),
  });
};

const deleteJobSuccess = (state, action) => {
  const jobList = state.jobs.jobList.filter((job) => job !== action.jobName);
  return updateObject(state, {
    deleteJob: updateObject(state.deleteJob, {
      jobName: action.jobName,
      loading: false,
      error: null,
      success: true,
    }),
    jobs: updateObject(state.jobs, { jobList: jobList }),
  });
};

const deleteJobFail = (state, action) => {
  return updateObject(state, {
    deleteJob: updateObject(state.deleteJob, {
      loading: false,
      error: action.error,
    }),
  });
};

export default (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.FETCH_ALL_JOBS_START:
      return ftechAllJobsStart(state);
    case actionTypes.FETCH_ALL_JOBS_SUCCESS:
      return ftechAllJobsSuccess(state, action);
    case actionTypes.FETCH_ALL_JOBS_FAIL:
      return ftechAllJobsFail(state, action);
    case actionTypes.FETCH_ALL_RELATIVEJOBS_START:
      return ftechAllRelativeJobsStart(state);
    case actionTypes.GET_RUNNING_JOBS_START:
      return getRunningJobsStart(state);
    case actionTypes.GET_RUNNING_JOBS_SUCCESS:
      return getRunningJobsSuccess(state, action);
    case actionTypes.GET_RUNNING_JOBS_FAIL:
      return getRunningJobsFail(state, action);
    case actionTypes.GET_LRMETRICS_START:
      return getLRMetricsStart(state);

    case actionTypes.CREATE_JOB_START:
      return createJobStart(state);
    case actionTypes.CREATE_JOB_SUCCESS:
      return createJobSuccess(state, action);
    case actionTypes.CREATE_JOB_FAIL:
      return createJobFail(state, action);

    case actionTypes.CREATE_PC_JOB_START:
      return createPCJobStart(state);
    case actionTypes.FETCH_PC_JOB_START:
      return fetchPCJobStart(state);
    case actionTypes.UPDATE_PC_JOB_START:
      return updatePCJobStart(state);

    case actionTypes.CREATE_LR_JOB_START:
      return createLRJobStart(state);
    case actionTypes.FETCH_LR_JOB_START:
      return fetchLRJobStart(state);
    case actionTypes.UPDATE_LR_JOB_START:
      return updateLRJobStart(state);

    case actionTypes.FETCH_JOB_START:
      return fetchJobStart(state);
    case actionTypes.FETCH_JOB_SUCCESS:
      return fetchJobSuccess(state, action);
    case actionTypes.FETCH_JOB_FAIL:
      return fetchJobFail(state, action);

    case actionTypes.UPDATE_JOB_START:
      return updateJobStart(state);
    case actionTypes.UPDATE_JOB_SUCCESS:
      return updateJobSuccess(state, action);
    case actionTypes.UPDATE_JOB_FAIL:
      return updateJobFail(state, action);

    case actionTypes.DELETE_JOB_START:
      return deleteJobStart(state);
    case actionTypes.DELETE_JOB_SUCCESS:
      return deleteJobSuccess(state, action);
    case actionTypes.DELETE_JOB_FAIL:
      return deleteJobFail(state, action);

    default:
      return state;
  }
};
