import * as actionTypes from '../actions/ActionTypes';
import { updateObject } from '../utility';

const initialState = {
  nodes: {
    nodeList: null,
    loading: false,
    error: null,
    success: false,
  },
  createNode: {
    nodeName: null,
    loading: false,
    error: null,
    success: false,
  },
  fetchNode: {
    node: null,
    loading: false,
    error: null,
    success: false,
  },
  updateNode: {
    nodeName: null,
    loading: false,
    error: null,
    success: false,
  },
  deleteNode: {
    nodeName: null,
    loading: false,
    error: null,
    success: false,
  }
}

/**
|--------------------------------------------------
| Fetch All node names
|--------------------------------------------------
*/

const ftechAllNodesStart = state => {
  return updateObject(state, {
    nodes: updateObject(state.nodes, { loading: true, success: false, error: null })
  })
}

const ftechAllNodesSuccess = (state, action) => {
  console.log(action.nodes);
  return updateObject(state, {
    nodes: updateObject(state.nodes, { nodeList: action.nodes, success: true, loading: false, error: null })
  })
}

const ftechAllNodesFail = (state, action) => {
  return updateObject(state, {
    nodes: updateObject(state.nodes, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Create Node
|--------------------------------------------------
*/

const createNodeStart = (state) => {
  return updateObject(state, {
    createNode: updateObject(state.createNode, { loading: true, success: false, error: null })
  })
}

const createNodeSuccess = (state, action) => {
  return updateObject(state, {
    createNode: updateObject(state.createNode, { nodeName: action.nodeName, success: true, loading: false, error: null })
  })
}

const createNodeFail = (state, action) => {
  return updateObject(state, {
    createNode: updateObject(state.createNode, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Fetch node details
|--------------------------------------------------
*/

const fetchNodeStart = (state) => {
  return updateObject(state, {
    fetchNode: updateObject(state.fetchNode, { loading: true, success: false, error: null })
  })
}

const fetchNodeSuccess = (state, action) => {
  return updateObject(state, {
    fetchNode: updateObject(state.fetchNode, { node: action.node, success: true, loading: false, error: null })
  })
}

const fetchNodeFail = (state, action) => {
  return updateObject(state, {
    fetchNode: updateObject(state.fetchNode, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Update Node
|--------------------------------------------------
*/

const updateNodeStart = (state) => {
  return updateObject(state, {
    updateNode: updateObject(state.updateNode, { loading: true, success: false, error: null })
  })
}

const updateNodeSuccess = (state, action) => {
  return updateObject(state, {
    updateNode: updateObject(state.updateNode, { nodeName: action.nodeName, success: true, loading: false, error: null })
  })
}

const updateNodeFail = (state, action) => {
  return updateObject(state, {
    updateNode: updateObject(state.updateNode, { loading: false, error: action.error })
  })
}

/**
|--------------------------------------------------
| Delete Node
|--------------------------------------------------
*/

const deleteNodeStart = (state) => {
  return updateObject(state, {
    deleteNode: updateObject(state.deleteNode, { loading: true, success: false, error: null })
  })
}

const deleteNodeSuccess = (state, action) => {
  const nodeList = state.nodes.nodeList.filter(node => node !== action.nodeName);
  return updateObject(state, {
    deleteNode: updateObject(state.deleteNode, { nodeName: action.nodeName, success: true, loading: false, error: null }),
    nodes: updateObject(state.nodes, { nodeList: nodeList })
  })
}

const deleteNodeFail = (state, action) => {
  return updateObject(state, {
    deleteNode: updateObject(state.deleteNode, { loading: false, error: action.error })
  })
}

export default (state = initialState, action) => {
  switch (action.type) {

    case actionTypes.FETCH_ALL_NODES_START: return ftechAllNodesStart(state);
    case actionTypes.FETCH_ALL_NODES_SUCCESS: return ftechAllNodesSuccess(state, action);
    case actionTypes.FETCH_ALL_NODES_FAIL: return ftechAllNodesFail(state, action);

    case actionTypes.CREATE_NODE_START: return createNodeStart(state);
    case actionTypes.CREATE_NODE_SUCCESS: return createNodeSuccess(state, action);
    case actionTypes.CREATE_NODE_FAIL: return createNodeFail(state, action);

    case actionTypes.FETCH_NODE_START: return fetchNodeStart(state);
    case actionTypes.FETCH_NODE_SUCCESS: return fetchNodeSuccess(state, action);
    case actionTypes.FETCH_NODE_FAIL: return fetchNodeFail(state, action);

    case actionTypes.UPDATE_NODE_START: return updateNodeStart(state);
    case actionTypes.UPDATE_NODE_SUCCESS: return updateNodeSuccess(state, action);
    case actionTypes.UPDATE_NODE_FAIL: return updateNodeFail(state, action);

    case actionTypes.DELETE_NODE_START: return deleteNodeStart(state);
    case actionTypes.DELETE_NODE_SUCCESS: return deleteNodeSuccess(state, action);
    case actionTypes.DELETE_NODE_FAIL: return deleteNodeFail(state, action);

    default:
      return state
  }
}
