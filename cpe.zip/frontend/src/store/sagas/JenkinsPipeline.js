import { put } from "redux-saga/effects";

import axios from "../../axios";
import * as actions from "../actions";

export function* fetchAllPipelinesSaga(action) {
  console.log("fetchAllPipelinesSaga");
  try {
    const config = {
      responseType: 'json'
    };
    const response = yield axios.get('/getAllJobs', config)
      .then(response => response.data.pipelines)
      .catch(error => {
        throw new Error(error.message)
      });
    yield put(actions.fetchAllPipelinesSuccess(response));
  } catch (error) {
    yield put(actions.fetchAllPipelinesFail(error.message));
  }
}

export function* fetchPipelineSaga(action) {
  console.log(action);
  try {
    const config = {
      params: {
        pipelineName: action.pipelineName
      },
      responseType: 'json'
    };
    const response = yield axios.get('/getPipelineDetails', config)
      .then(response => response.data)
      .catch(error => {
        throw new Error(error.message)
      });
    console.log(response);
    yield put(actions.fetchPipelineSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchPipelineFail(error.message));
  }
}

export function* addJobToExistingSaga(action) {
  console.log("addJobToExistingSaga");
  console.log(action);
  try {
    const response = yield axios({
      method: 'POST',
      url: '/addJobToExistingPipeline',
      data: JSON.stringify(action.pipeline),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ? yield put(actions.addJobToExistingSuccess(action.pipeline.name)) : () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.addJobToExistingFail(error.message));
  }
}

export function* createPipelineSaga(action) {
  console.log("createPipelineSaga");
  console.log(action);
  try {
    const response = yield axios({
      method: 'POST',
      url: '/createPipeline',
      data: {
        "name": action.pipeline.name,
        "jobName": action.pipeline.job,
        "release": action.pipeline.release
      },
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.createPipelineSuccess(action.pipeline.name)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.createPipelineFail(error.message));
  }
}

export function* updatePipelineSaga(action) {
  console.log("updatePipelineSaga")
  console.log(action);
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updatePipeline',
      data: JSON.stringify(action.pipeline),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    console.log(response);
    (response.status === 200) ?
      yield put(actions.updatePipelineSuccess(action.pipeline.name)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.updatePipelineFail(error.message));
  }
}

export function* deletePipelineSaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/deleteItem',
      data: action.pipelineName,
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });

    (response.status === 200) ?
      yield put(actions.deletePipelineSuccess(action.pipelineName)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.deletePipelineFail(error.message));
  }
}

export function* fetchPipelineStagesSaga(action) {
  console.log("fetchPipelineStagesSaga");
  console.log(action.pipelineName);
  try {
    const config = {
      params: {
        pipelineName: action.pipelineName
      },
      responseType: 'json',
    };
    const response = yield axios.get('/getAllPipelineStages', config)
      .then(response => response.data
      )
      .catch(error => {
        throw new Error(error.message)
      });
    yield put(actions.fetchPipelineStagesSuccess(response));
  } catch (error) {
    yield put(actions.fetchPipelineStagesFail(error.message));
  }
}