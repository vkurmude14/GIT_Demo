import { put } from "redux-saga/effects";

import axios from "../../axios";
import * as actions from "../actions";

export function* fetchAllNodesSaga(action) {
  console.log("fetchAllNodesSaga");
  try {
    const config = {
      responseType: 'json'
    };
    const response = yield axios.get('/getAllNodes', config)
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    console.log(response);
    yield put(actions.fetchAllNodesSuccess(response.data));
  } catch (error) {
    console.log(error.message);
    yield put(actions.fetchAllNodesFail(error.message));
  }
}

export function* createNodeSaga(action) {
  console.log(action.node);
  try {
    const response = yield axios({
      method: 'POST',
      url: '/createNode',
      data: JSON.stringify(action.node),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.createNodeSuccess(action.node.name)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.createNodeFail(error.message));
  }
}

export function* fetchNodeSaga(action) {
  console.log(action);
  try {
    const config = {
      params: {
        nodeName: action.nodeName
      },
      responseType: 'json'
    };
    const response = yield axios.get('/getNodeDetails', config)
      .then(response => response.data)
      .catch(error => {
        throw new Error(error.message)
      });
    console.log(response);
    yield put(actions.fetchNodeSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchNodeFail(error.message));
  }
}

export function* updateNodeSaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updateNode',
      data: JSON.stringify(action.node),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.updateNodeSuccess(action.node.name)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.updateNodeFail(error.message));
  }
}

export function* deleteNodeSaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/deleteNode',
      params: { nodeName: action.nodeName },
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.deleteNodeSuccess(action.nodeName)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.deleteNodeFail(error.message));
  }
}