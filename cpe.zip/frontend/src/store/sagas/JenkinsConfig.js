import { put } from "redux-saga/effects";

import axios from "../../axios";
import * as actions from "../actions";

export function* fetchConfigsSaga(action) {
  try {
    const response = yield axios({
      method: 'GET',
      url: '/getConfigDetails',
      responseType: 'json'
    })
      .then(response => response.data)
      .catch(error => {
        throw new Error(error.message)
      });
      console.log(response);
    yield put(actions.getConfigsSuccess(response));
  } catch (error) {
    yield put(actions.getConfigsFail(error.message));
  }
}

export function* updateConfigSaga(action) {
  console.log(action);
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updateConfig',
      data: JSON.stringify(action.config),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.updateConfigSuccess(action.config)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.updateConfigFail(error.message));
  }
}

export function* updateUserSaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updateUser',
      data: JSON.stringify(action.user),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.updateUserSuccess(action.user)) :
      () => { throw new Error('Something went wrong!') };

  } catch (error) {
    yield put(actions.updateUserFail(error.message));
  }
}

export function* updateUrlSaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updateUrl',
      data: JSON.stringify(action.url),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response)
      .catch(error => {
        throw new Error(error.message)
      });
    (response.status === 200) ?
      yield put(actions.updateUrlSuccess(action.url)) :
      () => { throw new Error('Something went wrong!') };
  } catch (error) {
    yield put(actions.updateUrlFail(error.message));
  }
}

export function* updateProxySaga(action) {
  try {
    const response = yield axios({
      method: 'POST',
      url: '/updateProxy',
      data: JSON.stringify(action.proxy),
      headers: {
        'Content-Type': 'application/json'
      },
      responseType: 'json'
    })
      .then(response => response.data)
      .catch(error => {
        throw new Error(error.message)
      });
    yield put(actions.updateProxySuccess(action.url));
  } catch (error) {
    yield put(actions.updateProxyFail(error.message));
  }
}