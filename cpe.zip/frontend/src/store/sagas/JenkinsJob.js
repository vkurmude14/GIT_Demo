import { put } from "redux-saga/effects";

import axios from "../../axios";
import * as actions from "../actions";

export function* fetchAllJobsSaga() {
  console.log("fetchAllJobsSaga");
  try {
    const config = {
      responseType: "json",
    };
    const response = yield axios
      .get("/getAllJobs", config)
      .then((response) => {
        console.log(response.data.jobs);
        return response.data.jobs;
      })
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.fetchAllJobsSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchAllJobsFail(error.message));
  }
}
export function* fetchAllRelativeJobsSaga(action) {
  try {
    const config = {
      params: {
        jobType: action.jobType,
      },
      responseType: "json",
    };
    const response = yield axios
      .get("/getAllRelativeJobs", config)
      .then((response) => {
        console.log(response.data.jobs);
        return response.data.jobs;
      })
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.fetchAllJobsSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchAllJobsFail(error.message));
  }
}

export function* getRunningJobsSaga() {
  console.log("getRunningJobsSaga");
  try {
    const config = {
      responseType: "json",
    };
    const response = yield axios
      .get("/getRunningJobs", config)
      .then((response) => {
        console.log(response.data);
        return response.data;
      })
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.getRunningJobsSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.getRunningJobsFail(error.message));
  }
}

export function* getLRMetricsSaga() {
  console.log("getLRMetricsSaga");
  try {
    const config = {
      responseType: "json",
    };
    const response = yield axios
      .get("/getLRMetric", config)
      .then((response) => {
        console.log(response.data);
        return response.data;
      })
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.getRunningJobsSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.getRunningJobsFail(error.message));
  }
}

export function* createJobSaga(action) {
  console.log(action.job);
  try {
    const response = yield axios({
      method: "POST",
      url: "/createJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.createJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.createJobFail(error.message));
  }
}

export function* createPCJobSaga(action) {
  console.log(action.job + " API call");
  try {
    const response = yield axios({
      method: "POST",
      url: "/createPCJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.createJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.createJobFail(error.message));
  }
}

export function* createLRJobSaga(action) {
  console.log(action.job + " API call");
  try {
    const response = yield axios({
      method: "POST",
      url: "/createLRJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.createJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.createJobFail(error.message));
  }
}

export function* fetchJobSaga(action) {
  console.log(action);
  try {
    const config = {
      params: {
        jobName: action.jobName,
      },
      responseType: "json",
    };
    const response = yield axios
      .get("/getJobDetails", config)
      .then((response) => response.data)
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.fetchJobSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchJobFail(error.message));
  }
}

export function* fetchPCJobSaga(action) {
  console.log(action);
  try {
    const config = {
      params: {
        jobName: action.jobName,
      },
      responseType: "json",
    };
    const response = yield axios
      .get("/getPCJobDetails", config)
      .then((response) => response.data)
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.fetchJobSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchJobFail(error.message));
  }
}

export function* fetchLRJobSaga(action) {
  console.log(action);
  try {
    const config = {
      params: {
        jobName: action.jobName,
      },
      responseType: "json",
    };
    const response = yield axios
      .get("/getLRJobDetails", config)
      .then((response) => response.data)
      .catch((error) => {
        throw new Error(error.message);
      });
    yield put(actions.fetchJobSuccess(response));
  } catch (error) {
    console.log(error);
    yield put(actions.fetchJobFail(error.message));
  }
}
export function* updateJobSaga(action) {
  try {
    const response = yield axios({
      method: "POST",
      url: "/updateJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.updateJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.updateJobFail(error.message));
  }
}

export function* updatePCJobSaga(action) {
  try {
    const response = yield axios({
      method: "POST",
      url: "/updatePCJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.updateJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.updateJobFail(error.message));
  }
}

export function* updateLRJobSaga(action) {
  try {
    const response = yield axios({
      method: "POST",
      url: "/updateLRJob",
      data: JSON.stringify(action.job),
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.updateJobSuccess(action.job.name))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.updateJobFail(error.message));
  }
}

export function* deleteJobSaga(action) {
  try {
    const response = yield axios({
      method: "POST",
      url: "/deleteItem",
      data: action.jobName,
      headers: {
        "Content-Type": "application/json",
      },
      responseType: "json",
    })
      .then((response) => response)
      .catch((error) => {
        throw new Error(error.message);
      });
    response.status === 200
      ? yield put(actions.deleteJobSuccess(action.jobName))
      : () => {
          throw new Error("Something went wrong!");
        };
  } catch (error) {
    yield put(actions.deleteJobFail(error.message));
  }
}
