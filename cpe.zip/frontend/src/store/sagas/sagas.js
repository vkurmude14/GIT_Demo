import { takeEvery, all, takeLatest } from "redux-saga/effects";

import * as actionTypes from "../actions/ActionTypes";
import * as configSaga from "./JenkinsConfig";
import * as jobSaga from "./JenkinsJob";
import * as pipelineSaga from "./JenkinsPipeline";
import * as nodeSaga from "./JenkinsNode";

export function* watchConfigs() {
  yield takeEvery(actionTypes.GET_CONFIGS_START, configSaga.fetchConfigsSaga);
  yield takeEvery(actionTypes.UPDATE_CONFIG_START, configSaga.updateConfigSaga);
  yield takeEvery(actionTypes.UPDATE_USER_START, configSaga.updateUserSaga);
  yield takeEvery(actionTypes.UPDATE_URL_START, configSaga.updateUrlSaga);
  yield takeEvery(actionTypes.UPDATE_PROXY_START, configSaga.updateProxySaga);
}

export function* watchJobs() {
  yield takeEvery(actionTypes.FETCH_ALL_JOBS_START, jobSaga.fetchAllJobsSaga);
  yield takeEvery(
    actionTypes.GET_RUNNING_JOBS_START,
    jobSaga.getRunningJobsSaga
  );
  yield takeEvery(
    actionTypes.FETCH_ALL_RELATIVEJOBS_START,
    jobSaga.fetchAllRelativeJobsSaga
  );
  yield takeEvery(actionTypes.GET_LRMETRICS_START, jobSaga.getLRMetricsSaga);
  yield takeEvery(actionTypes.CREATE_JOB_START, jobSaga.createJobSaga);
  yield takeEvery(actionTypes.FETCH_JOB_START, jobSaga.fetchJobSaga);
  yield takeEvery(actionTypes.UPDATE_JOB_START, jobSaga.updateJobSaga);
  yield takeEvery(actionTypes.DELETE_JOB_START, jobSaga.deleteJobSaga);
  yield takeEvery(actionTypes.CREATE_PC_JOB_START, jobSaga.createPCJobSaga);
  yield takeEvery(actionTypes.FETCH_PC_JOB_START, jobSaga.fetchPCJobSaga);
  yield takeEvery(actionTypes.UPDATE_PC_JOB_START, jobSaga.updatePCJobSaga);
  yield takeEvery(actionTypes.CREATE_LR_JOB_START, jobSaga.createLRJobSaga);
  yield takeEvery(actionTypes.FETCH_LR_JOB_START, jobSaga.fetchLRJobSaga);
  yield takeEvery(actionTypes.UPDATE_LR_JOB_START, jobSaga.updateLRJobSaga);
}

export function* watchPipelines() {
  yield takeEvery(
    actionTypes.FETCH_ALL_PIPELINES_START,
    pipelineSaga.fetchAllPipelinesSaga
  );
  yield takeEvery(
    actionTypes.ADD_JOB_TO_EXISTING_START,
    pipelineSaga.addJobToExistingSaga
  );
  yield takeEvery(
    actionTypes.CREATE_PIPELINE_START,
    pipelineSaga.createPipelineSaga
  );
  yield takeEvery(
    actionTypes.FETCH_PIPELINE_START,
    pipelineSaga.fetchPipelineSaga
  );
  yield takeEvery(
    actionTypes.UPDATE_PIPELINE_START,
    pipelineSaga.updatePipelineSaga
  );
  yield takeEvery(
    actionTypes.DELETE_PIPELINE_START,
    pipelineSaga.deletePipelineSaga
  );
  yield takeEvery(
    actionTypes.FETCH_PIPELINE_STAGES_START,
    pipelineSaga.fetchPipelineStagesSaga
  );
}

export function* watchNodes() {
  yield takeEvery(
    actionTypes.FETCH_ALL_NODES_START,
    nodeSaga.fetchAllNodesSaga
  );
  yield takeEvery(actionTypes.CREATE_NODE_START, nodeSaga.createNodeSaga);
  yield takeEvery(actionTypes.FETCH_NODE_START, nodeSaga.fetchNodeSaga);
  yield takeEvery(actionTypes.UPDATE_NODE_START, nodeSaga.updateNodeSaga);
  yield takeEvery(actionTypes.DELETE_NODE_START, nodeSaga.deleteNodeSaga);
}
