import {createStore, compose, applyMiddleware} from 'redux';
// import thunkMiddleware from 'redux-thunk';
import createSagaMiddleware from "redux-saga";
import Reducer from './reducers';
import { watchConfigs, watchJobs, watchPipelines, watchNodes } from './sagas/';
export default function configureStore(initialState) {

  const sagaMiddleware = createSagaMiddleware();

  const middewares = [
    sagaMiddleware,
  ];

  const store = createStore(Reducer, initialState, compose(
    applyMiddleware(...middewares),
    window.devToolsExtension ? window.devToolsExtension() : f => f // add support for Redux dev tools
    )
  );


  if (module.hot) {
    // Enable Webpack hot module replacement for reducers
    module.hot.accept('./reducers', () => {
      const nextReducer = require('./reducers').default; // eslint-disable-line global-require
      store.replaceReducer(nextReducer);
    });
  }

  sagaMiddleware.run(watchConfigs);
  sagaMiddleware.run(watchJobs);
  sagaMiddleware.run(watchPipelines);
  sagaMiddleware.run(watchNodes);

  return store;
}