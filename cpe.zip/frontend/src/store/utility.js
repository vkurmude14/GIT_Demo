export const updateObject = (oldObject, updatedProperties) => {
    return {
        ...oldObject,
        ...updatedProperties
    };
};

export const removeObject = (objectArray, key) => {
    // objectArray.splice(objectArray.findIndex(i => {
    //     return i === removeObject;
    // }), 1);
    delete objectArray[key];
    console.log(objectArray);
   // const newArray = objectArray.filter(obj => !removeObject.has(obj.id));
    return objectArray;
};