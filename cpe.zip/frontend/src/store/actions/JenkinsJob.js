import * as actionTypes from "./ActionTypes";

export const fetchAllJobsStart = (job) => {
  return {
    type: actionTypes.FETCH_ALL_JOBS_START,
    job: job,
  };
};

export const fetchAllRelativeJobsStart = (jobType) => {
  return {
    type: actionTypes.FETCH_ALL_RELATIVEJOBS_START,
    jobType: jobType,
  };
};

fetchAllRelativeJobsStart;
export const fetchAllJobsSuccess = (jobs) => {
  return {
    type: actionTypes.FETCH_ALL_JOBS_SUCCESS,
    jobs: jobs,
  };
};

export const fetchAllJobsFail = () => {
  return {
    type: actionTypes.FETCH_ALL_JOBS_FAIL,
    error: error,
  };
};

export const getRunningJobsStart = () => {
  return {
    type: actionTypes.GET_RUNNING_JOBS_START,
  };
};

export const getRunningJobsSuccess = (jobs) => {
  return {
    type: actionTypes.GET_RUNNING_JOBS_SUCCESS,
    jobs: jobs,
  };
};

export const getRunningJobsFail = (error) => {
  return {
    type: actionTypes.GET_RUNNING_JOBS_FAIL,
    error: error,
  };
};

export const getLRMetricsStart = () => {
  return {
    type: actionTypes.GET_LRMETRICS_START,
  };
};

export const createJobStart = (job) => {
  return {
    type: actionTypes.CREATE_JOB_START,
    job: job,
  };
};

export const createPCJobStart = (job) => {
  return {
    type: actionTypes.CREATE_PC_JOB_START,
    job: job,
  };
};

export const createLRJobStart = (job) => {
  return {
    type: actionTypes.CREATE_LR_JOB_START,
    job: job,
  };
};

export const createJobSuccess = (jobName) => {
  return {
    type: actionTypes.CREATE_JOB_SUCCESS,
    jobName: jobName,
  };
};

export const createJobFail = (error) => {
  return {
    type: actionTypes.CREATE_JOB_FAIL,
    error: error,
  };
};

export const fetchJobStart = (jobName) => {
  return {
    type: actionTypes.FETCH_JOB_START,
    jobName: jobName,
  };
};

export const fetchPCJobStart = (jobName) => {
  return {
    type: actionTypes.FETCH_PC_JOB_START,
    jobName: jobName,
  };
};

export const fetchLRJobStart = (jobName) => {
  return {
    type: actionTypes.FETCH_LR_JOB_START,
    jobName: jobName,
  };
};

export const fetchJobSuccess = (job) => {
  return {
    type: actionTypes.FETCH_JOB_SUCCESS,
    job: job,
  };
};

export const fetchJobFail = (error) => {
  return {
    type: actionTypes.FETCH_JOB_FAIL,
    error: error,
  };
};

export const updateJobStart = (job) => {
  return {
    type: actionTypes.UPDATE_JOB_START,
    job: job,
  };
};

export const updatePCJobStart = (job) => {
  return {
    type: actionTypes.UPDATE_PC_JOB_START,
    job: job,
  };
};

export const updateLRJobStart = (job) => {
  return {
    type: actionTypes.UPDATE_LR_JOB_START,
    job: job,
  };
};
export const updateJobSuccess = (jobName) => {
  return {
    type: actionTypes.UPDATE_JOB_SUCCESS,
    jobName: jobName,
  };
};

export const updateJobFail = (error) => {
  return {
    type: actionTypes.UPDATE_JOB_FAIL,
    error: error,
  };
};

export const deleteJobStart = (jobName) => {
  return {
    type: actionTypes.DELETE_JOB_START,
    jobName: jobName,
  };
};

export const deleteJobSuccess = (jobName) => {
  return {
    type: actionTypes.DELETE_JOB_SUCCESS,
    jobName: jobName,
  };
};

export const deleteJobFail = (error) => {
  return {
    type: actionTypes.DELETE_JOB_FAIL,
    error: error,
  };
};
