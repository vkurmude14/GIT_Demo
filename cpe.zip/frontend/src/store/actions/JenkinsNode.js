import * as actionTypes from './ActionTypes';

export const fetchAllNodesStart = (node) => {
  return {
    type: actionTypes.FETCH_ALL_NODES_START,
    node: node
  };
};

export const fetchAllNodesSuccess = (nodes) => {
  return {
    type: actionTypes.FETCH_ALL_NODES_SUCCESS,
    nodes: nodes
  };
};

export const fetchAllNodesFail = (error) => {
  return {
    type: actionTypes.FETCH_ALL_NODES_FAIL,
    error: error,
  };
};

export const createNodeStart = (node) => {
  return {
    type: actionTypes.CREATE_NODE_START,
    node: node,
  };
};

export const createNodeSuccess = (nodeName) => {
  return {
    type: actionTypes.CREATE_NODE_SUCCESS,
    nodeName: nodeName
  };
};

export const createNodeFail = (error) => {
  return {
    type: actionTypes.CREATE_NODE_FAIL,
    error: error,
  };
};

export const fetchNodeStart = (nodeName) => {
  return {
    type: actionTypes.FETCH_NODE_START,
    nodeName: nodeName,
  };
};

export const fetchNodeSuccess = (node) => {
  return {
    type: actionTypes.FETCH_NODE_SUCCESS,
    node: node,
  };
};

export const fetchNodeFail = (error) => {
  return {
    type: actionTypes.FETCH_NODE_FAIL,
    error: error,
  };
};

export const updateNodeStart = (node) => {
  return {
    type: actionTypes.UPDATE_NODE_START,
    node: node,
  };
};

export const updateNodeSuccess = (nodeName) => {
  return {
    type: actionTypes.UPDATE_NODE_SUCCESS,
    nodeName: nodeName,
  };
};

export const updateNodeFail = (error) => {
  return {
    type: actionTypes.UPDATE_NODE_FAIL,
    error: error,
  };
};

export const deleteNodeStart = (nodeName) => {
  return {
    type: actionTypes.DELETE_NODE_START,
    nodeName: nodeName,
  };
};

export const deleteNodeSuccess = (nodeName) => {
  return {
    type: actionTypes.DELETE_NODE_SUCCESS,
    nodeName: nodeName,
  };
};

export const deleteNodeFail = (error) => {
  return {
    type: actionTypes.DELETE_NODE_FAIL,
    error: error,
  };
};
