import * as actionTypes from './ActionTypes';

export const getConfigsStart = () => {
  return {
    type: actionTypes.GET_CONFIGS_START
  };
};

export const getConfigsSuccess = (configs) => {
  console.log(configs);
  return {
    type: actionTypes.GET_CONFIGS_SUCCESS,
    configs: configs
  };
};

export const getConfigsFail = (error) => {
  console.log(error)
  return {
    type: actionTypes.GET_CONFIGS_FAIL,
    error: error
  };
};

export const updateConfigStart = (config) => {
  return {
    type: actionTypes.UPDATE_CONFIG_START,
    config: config
  };
};

export const updateConfigSuccess = (config) => {
  console.log(config);
  return {
    type: actionTypes.UPDATE_CONFIG_SUCCESS,
    config: config,
  };
};

export const updateConfigFail = (error) => {
  return {
    type: actionTypes.UPDATE_CONFIG_FAIL,
    error: error
  };
};

export const updateUrlStart = (url) => {
  return {
    type: actionTypes.UPDATE_URL_START,
    url: url
  };
};

export const updateUrlSuccess = (url) => {
  return {
    type: actionTypes.UPDATE_URL_SUCCESS,
    url: url
  };
};

export const updateUrlFail = (error) => {
  return {
    type: actionTypes.UPDATE_URL_FAIL,
    error: error
  };
};

export const updateUserStart = (user) => {
  return {
    type: actionTypes.UPDATE_USER_START,
    user: user
  };
};

export const updateUserSuccess = (user) => {
  return {
    type: actionTypes.UPDATE_USER_SUCCESS,
    user: user,
  };
};

export const updateUserFail = (error) => {
  return {
    type: actionTypes.UPDATE_USER_FAIL,
    error: error
  };
};

export const updateProxyStart = (proxy) => {
  return {
    type: actionTypes.UPDATE_PROXY_START,
    proxy: proxy,
  };
};

export const updateProxySuccess = (proxy) => {
  return {
    type: actionTypes.UPDATE_PROXY_SUCCESS,
    proxy: proxy,
  };
};

export const updateProxyFail = (error) => {
  return {
    type: actionTypes.UPDATE_PROXY_FAIL,
    error: error
  };
};