/**
|--------------------------------------------------
|  ActioTypes for fetch, create, update, delete job
|--------------------------------------------------
*/

export const FETCH_ALL_JOBS_START = "FETCH_ALL_JOBS_START";
export const FETCH_ALL_JOBS_SUCCESS = "FETCH_ALL_JOBS_SUCCESS";
export const FETCH_ALL_JOBS_FAIL = "FETCH_ALL_JOBS_FAIL";
export const FETCH_ALL_RELATIVEJOBS_START = "FETCH_ALL_RELATIVEJOBS_START";

export const GET_RUNNING_JOBS_START = "GET_RUNNING_JOBS_START";
export const GET_RUNNING_JOBS_SUCCESS = "GET_RUNNING_JOBS_SUCCESS";
export const GET_RUNNING_JOBS_FAIL = "GET_RUNNING_JOBS_FAIL";

export const GET_LRMETRICS_START = "GET_LRMETRICS_START";

export const CREATE_JOB_START = "CREATE_JOB_START";
export const CREATE_JOB_SUCCESS = "CREATE_JOB_SUCCESS";
export const CREATE_JOB_FAIL = "CREATE_JOB_FAIL";

export const CREATE_PC_JOB_START = "CREATE_PC_JOB_START";
export const FETCH_PC_JOB_START = "FETCH_PC_JOB_START";
export const UPDATE_PC_JOB_START = "UPDATE_PC_JOB_START";

export const CREATE_LR_JOB_START = "CREATE_LR_JOB_START";
export const FETCH_LR_JOB_START = "FETCH_LR_JOB_START";
export const UPDATE_LR_JOB_START = "UPDATE_LR_JOB_START";

export const FETCH_JOB_START = "FETCH_JOB_START";
export const FETCH_JOB_SUCCESS = "FETCH_JOB_SUCCESS";
export const FETCH_JOB_FAIL = "FETCH_JOB_FAIL";

export const UPDATE_JOB_START = "UPDATE_JOB_START";
export const UPDATE_JOB_SUCCESS = "UPDATE_JOB_SUCCESS";
export const UPDATE_JOB_FAIL = "UPDATE_JOB_FAIL";

export const DELETE_JOB_START = "DELETE_JOB_START";
export const DELETE_JOB_SUCCESS = "DELETE_JOB_SUCCESS";
export const DELETE_JOB_FAIL = "DELETE_JOB_FAIL";

/**
|--------------------------------------------------
| ActioTypes for fetch, create, update, delete pipeline
|--------------------------------------------------
*/

export const FETCH_ALL_PIPELINES_START = "FETCH_ALL_PIPELINES_START";
export const FETCH_ALL_PIPELINES_SUCCESS = "FETCH_ALL_PIPELINES_SUCCESS";
export const FETCH_ALL_PIPELINES_FAIL = "FETCH_ALL_PIPELINES_FAIL";

export const ADD_JOB_TO_EXISTING_START = "ADD_JOB_TO_EXISTING_START";
export const ADD_JOB_TO_EXISTING_SUCCESS = "ADD_JOB_TO_EXISTING_SUCCESS";
export const ADD_JOB_TO_EXISTING_FAIL = "ADD_JOB_TO_EXISTING_FAIL";

export const CREATE_PIPELINE_START = "CREATE_PIPELINE_START";
export const CREATE_PIPELINE_SUCCESS = "CREATE_PIPELINE_SUCCESS";
export const CREATE_PIPELINE_FAIL = "CREATE_PIPELINE_FAIL";

export const FETCH_PIPELINE_START = "FETCH_PIPELINE_START";
export const FETCH_PIPELINE_SUCCESS = "FETCH_PIPELINE_SUCCESS";
export const FETCH_PIPELINE_FAIL = "FETCH_PIPELINE_FAIL";

export const UPDATE_PIPELINE_START = "UPDATE_PIPELINE_START";
export const UPDATE_PIPELINE_SUCCESS = "UPDATE_PIPELINE_SUCCESS";
export const UPDATE_PIPELINE_FAIL = "UPDATE_PIPELINE_FAIL";

export const DELETE_PIPELINE_START = "DELETE_PIPELINE_START";
export const DELETE_PIPELINE_SUCCESS = "DELETE_PIPELINE_SUCCESS";
export const DELETE_PIPELINE_FAIL = "DELETE_PIPELINE_FAIL";

export const FETCH_PIPELINE_STAGES_START = "FETCH_PIPELINE_STAGES_START";
export const FETCH_PIPELINE_STAGES_SUCCESS = "FETCH_PIPELINE_STAGES_SUCCESS";
export const FETCH_PIPELINE_STAGES_FAIL = "FETCH_PIPELINE_STAGES_FAIL";

/**
|--------------------------------------------------
| ActioTypes for fetch, create, update, delete node
|--------------------------------------------------
*/

export const FETCH_ALL_NODES_START = "FETCH_ALL_NODES_START";
export const FETCH_ALL_NODES_SUCCESS = "FETCH_ALL_NODES_SUCCESS";
export const FETCH_ALL_NODES_FAIL = "FETCH_ALL_NODES_FAIL";

export const CREATE_NODE_START = "CREATE_NODE_START";
export const CREATE_NODE_SUCCESS = "CREATE_NODE_SUCCESS";
export const CREATE_NODE_FAIL = "CREATE_NODE_FAIL";

export const FETCH_NODE_START = "FETCH_NODE_START";
export const FETCH_NODE_SUCCESS = "FETCH_NODE_SUCCESS";
export const FETCH_NODE_FAIL = "FETCH_NODE_FAIL";

export const UPDATE_NODE_START = "UPDATE_NODE_START";
export const UPDATE_NODE_SUCCESS = "UPDATE_NODE_SUCCESS";
export const UPDATE_NODE_FAIL = "UPDATE_NODE_FAIL";

export const DELETE_NODE_START = "DELETE_NODE_START";
export const DELETE_NODE_SUCCESS = "DELETE_NODE_SUCCESS";
export const DELETE_NODE_FAIL = "DELETE_NODE_FAIL";

/**
|--------------------------------------------------
| ActioTypes for fetch, create, update, delete configurations
|--------------------------------------------------
*/

export const GET_CONFIGS_START = "GET_CONFIGS_START";
export const GET_CONFIGS_SUCCESS = "GET_CONFIGS_SUCCESS";
export const GET_CONFIGS_FAIL = "GET_CONFIGS_FAIL";

export const UPDATE_USER_START = "UPDATE_USER_START";
export const UPDATE_USER_SUCCESS = "UPDATE_USER_SUCCESS";
export const UPDATE_USER_FAIL = "UPDATE_USER_FAIL";

export const UPDATE_URL_START = "UPDATE_URL_START";
export const UPDATE_URL_SUCCESS = "UPDATE_URL_SUCCESS";
export const UPDATE_URL_FAIL = "UPDATE_URL_FAIL";

export const UPDATE_CONFIG_START = "UPDATE_CONFIG_START";
export const UPDATE_CONFIG_SUCCESS = "UPDATE_CONFIG_SUCCESS";
export const UPDATE_CONFIG_FAIL = "UPDATE_CONFIG_FAIL";

export const UPDATE_PROXY_START = "UPDATE_PROXY_START";
export const UPDATE_PROXY_SUCCESS = "UPDATE_PROXY_SUCCESS";
export const UPDATE_PROXY_FAIL = "UPDATE_PROXY_FAIL";

/**
|--------------------------------------------------
| Auth
|--------------------------------------------------
*/

export const AUTH_START = "AUTH_START";
export const AUTH_SUCCESS = "AUTH_SUCCESS";
export const AUTH_FAIL = "AUTH_FAIL";
export const AUTH_LOGOUT = "AUTH_LOGOUT";

export const SET_AUTH_REDIRECT_PATH = "SET_AUTH_REDIRECT_PATH";
