import * as actionTypes from './ActionTypes';

export const fetchAllPipelinesStart = () => {
  return {
    type: actionTypes.FETCH_ALL_PIPELINES_START,
  };
};

export const fetchAllPipelinesSuccess = (pipelines) => {
  return {
    type: actionTypes.FETCH_ALL_PIPELINES_SUCCESS,
    pipelines: pipelines,
  };
};

export const fetchAllPipelinesFail = () => {
  return {
    type: actionTypes.FETCH_ALL_PIPELINES_FAIL,
    error: error,
  };
};

export const addJobToExistingStart = (pipeline) => {
  console.log("addJobToExistingStart");
  return {
    type: actionTypes.ADD_JOB_TO_EXISTING_START,
    pipeline: pipeline,
  };
};

export const addJobToExistingSuccess = (pipelineName) => {
  return {
    type: actionTypes.ADD_JOB_TO_EXISTING_SUCCESS,
    pipelineName: pipelineName,
  };
};

export const addJobToExistingFail = (error) => {
  return {
    type: actionTypes.ADD_JOB_TO_EXISTING_FAIL,
    error: error,
  };
};

export const createPipelineStart = (pipeline) => {
  console.log("createPipelineStart");
  return {
    type: actionTypes.CREATE_PIPELINE_START,
    pipeline: pipeline,
  };
};

export const createPipelineSuccess = (pipelineName) => {
  return {
    type: actionTypes.CREATE_PIPELINE_SUCCESS,
    pipelineName: pipelineName,
  };
};

export const createPipelineFail = (error) => {
  return {
    type: actionTypes.CREATE_PIPELINE_FAIL,
    error: error,
  };
};

export const fetchPipelineStart = (pipelineName) => {
  return {
    type: actionTypes.FETCH_PIPELINE_START,
    pipelineName: pipelineName,
  };
};

export const fetchPipelineSuccess = (pipeline) => {
  return {
    type: actionTypes.FETCH_PIPELINE_SUCCESS,
    pipeline: pipeline,
  };
};

export const fetchPipelineFail = (error) => {
  return {
    type: actionTypes.FETCH_PIPELINE_FAIL,
    error: error,
  };
};

export const updatePipelineStart = (pipeline) => {
  return {
    type: actionTypes.UPDATE_PIPELINE_START,
    pipeline: pipeline,
  };
};

export const updatePipelineSuccess = (pipelineName) => {
  return {
    type: actionTypes.UPDATE_PIPELINE_SUCCESS,
    pipelineName: pipelineName,
  };
};

export const updatePipelineFail = (error) => {
  return {
    type: actionTypes.UPDATE_PIPELINE_FAIL,
    error: error,
  };
};

export const deletePipelineStart = (pipelineName) => {
  return {
    type: actionTypes.DELETE_PIPELINE_START,
    pipelineName: pipelineName,
  };
};

export const deletePipelineSuccess = (pipelineName) => {
  return {
    type: actionTypes.DELETE_PIPELINE_SUCCESS,
    pipelineName: pipelineName,
  };
};

export const deletePipelineFail = (error) => {
  return {
    type: actionTypes.DELETE_PIPELINE_FAIL,
    error: error,
  };
};

export const fetchPipelineStagesStart = (pipelineName) => {
  return {
    type: actionTypes.FETCH_PIPELINE_STAGES_START,
    pipelineName: pipelineName,
  };
};

export const fetchPipelineStagesSuccess = (pipelineStages) => {
  return {
    type: actionTypes.FETCH_PIPELINE_STAGES_SUCCESS,
    pipelineStages: pipelineStages,
  };
};

export const fetchPipelineStagesFail = () => {
  return {
    type: actionTypes.FETCH_PIPELINE_STAGES_FAIL,
    error: error,
  };
};