import React from 'react';
import { Segment, Form, Message } from 'semantic-ui-react';
const filterGraph = (props) => {
  console.log(props);
  let pageBody = null;
  if (!props.loading) {
    pageBody = props.jobList.length < 1 ? <Message icon warning>
      <Message.Content>
        <Message.Header>Sorry</Message.Header>
        Currently there are no running jobs.
    </Message.Content>
    </Message> : <Form>
    <Form.Group widths='3'>
      <Form.Dropdown search selection
        label="Job"
        placeholder='Select Job'
        value={props.selectedJob.name}
        options={props.jobList}
        onChange={props.jobChangeHandler} />
      <Form.Dropdown search selection
        label="Server"
        placeholder='Select Server'
        value={props.selectedJob.selectedServer.name}
        disabled={!props.selectedJob.name}
        options={props.filteredServers}
        onChange={props.serverChangeHandler}
        loading={props.serverLoading} />
    </Form.Group>
  </Form>;
  }
  return (
    <Segment loading={props.loading}>
      {pageBody}
    </Segment>
  )
}

export default filterGraph;