import React from "react";
import {
  Segment,
  Embed,
  Button,
  Icon,
  Dropdown,
  Header,
  Grid,
} from "semantic-ui-react";

const graph = (props) => {
  console.log("inside graph.js");
  console.log(props);
  let url = props.grafanaURL;
  const jmeterDashboard =
    "/d/fr--ToImk/jmeter-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now&var-Application=" +
    props.selectedJob.applicationName +
    "&var-request=all&var-aggregation=10s&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const lrDashboard =
    "/d/pGPE2dpGk/lr-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now" +
    "&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const serverWin =
    "/d/-ZGmrzZiz/windows-host-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now&var-hostname=" +
    props.selectedJob.selectedServer.name +
    "&var-disk=All&var-process=All&var-network=All&&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const serverLinux =
    "/d/MfS2FDOmz/linux-host-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now&var-datasource=default&var-server=" +
    props.selectedJob.selectedServer.name +
    "&var-inter=10s&var-netif=All&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const correlatedWin =
    "/d/cvj5jvOmz/windows-correlated-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now&var-hostname=" +
    props.selectedJob.selectedServer.name +
    "&var-Application=" +
    props.selectedJob.applicationName +
    "&var-request=all&var-aggregation=10s&var-process=All&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const correlatedLinux =
    "/d/h39jXzWmz/linux-correlated-dashboard?orgId=1&from=" +
    props.selectedJob.startTime +
    "&to=now&var-hostname=" +
    props.selectedJob.selectedServer.name +
    "&var-Application=" +
    props.selectedJob.applicationName +
    "&var-request=checkout&var-aggregation=10s&var-process=All&refresh=5s&kiosk=true&theme=" +
    props.graphTheme;

  const graphTitle =
    props.selectedGraph === "jmeter"
      ? "JMeter"
      : props.selectedGraph === "server"
      ? "Server"
      : props.selectedGraph === "LR"
      ? "Load Runner"
      : "Correlated";

  const graphSubTitle =
    props.selectedGraph === "correlated" ? "JMeter vs Server" : "Dashboard";

  if (props.selectedGraph === "jmeter") {
    url = url + jmeterDashboard;
  } else if (props.selectedGraph === "server") {
    props.selectedJob.selectedServer.os === "windows"
      ? (url = url + serverWin)
      : (url = url + serverLinux);
  } else if (props.selectedGraph === "LR") {
    url = url + lrDashboard;
  } else {
    props.selectedJob.selectedServer.os === "windows"
      ? (url = url + correlatedWin)
      : (url = url + correlatedLinux);
  }

  return (
    <Segment>
      <Grid padded="horizontally" width="equal">
        <Grid.Column width={7}>
          <Header as="h4" floated="left">
            <Icon name="area graph" />
            <Header.Content>
              {graphTitle}
              <Header.Subheader as="h6">{graphSubTitle}</Header.Subheader>
            </Header.Content>
          </Header>
        </Grid.Column>
        <Grid.Column width={7}>
          <Button.Group floated="right" basic>
            <Button
              id="jmeter"
              disabled={
                !props.selectedJob.selectedServer.name ||
                props.selectedJob.jobType === "LR"
              }
              active={props.selectedGraph === "jmeter"}
              onClick={props.graphChangeHandler}
            >
              JMeter
            </Button>
            <Button
              id="LR"
              disabled={
                !props.selectedJob.selectedServer.name ||
                props.selectedJob.jobType === "jmeter"
              }
              active={props.selectedGraph === "LR"}
              onClick={props.graphChangeHandler}
            >
              Load Runner
            </Button>
            <Button
              id="server"
              disabled={!props.selectedJob.selectedServer.name}
              active={props.selectedGraph === "server"}
              onClick={props.graphChangeHandler}
            >
              Server
            </Button>
            <Button
              id="correlated"
              disabled={
                !props.selectedJob.selectedServer.name ||
                props.selectedJob.jobType === "LR"
              }
              active={props.selectedGraph === "correlated"}
              onClick={props.graphChangeHandler}
            >
              Correlated
            </Button>
          </Button.Group>
        </Grid.Column>
        <Grid.Column floated="right" width={1}>
          <Dropdown
            trigger={
              <Button icon>
                {" "}
                <Icon
                  color={props.graphTheme === "dark" ? "black" : "grey"}
                  name="theme"
                />{" "}
              </Button>
            }
            pointing="top left"
            icon={null}
          >
            <Dropdown.Menu>
              <Dropdown.Header icon="tags" content="Select a theme" />
              <Dropdown.Divider />
              <Dropdown.Item
                onClick={props.changeGraphThemeHandler}
                label={{ color: "black", empty: true, circular: true }}
                text="Dark"
                value="dark"
              />
              <Dropdown.Item
                onClick={props.changeGraphThemeHandler}
                label={{ color: "grey", empty: true, circular: true }}
                text="Light"
                value="light"
              />
            </Dropdown.Menu>
          </Dropdown>
        </Grid.Column>
        <Grid.Column floated="right" width={1}>
          <Button
            circular
            icon={
              props.isRefreshing ? <Icon loading name="spinner" /> : "refresh"
            }
            onClick={props.refreshGraph}
            disabled={!props.selectedJob.selectedServer.name}
          />
        </Grid.Column>
      </Grid>
      <br />

      <Embed
        active={props.showGraph}
        icon={
          props.graphLoading ? <Icon loading name="spinner" /> : "chart area"
        }
        url={url}
        aspectRatio="21:9"
      />
    </Segment>
  );
};
export default graph;
