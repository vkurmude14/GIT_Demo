import React from 'react';
import { Form } from 'semantic-ui-react';

const formInput = (input) => {
  console.log(input)
  return <Form><Form.Input type={input.type} id={input.id} value={input.value} onChange={input.onChange}
    label={input.label}  fluid disabled={input.disabled} placeholder={input.id} /> </Form>
}

export default formInput;