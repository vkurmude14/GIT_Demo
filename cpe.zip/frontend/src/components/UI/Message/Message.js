import React from 'react';
import { message } from 'antd';

message.config({
    top: 70,
    duration: 3,
    maxCount: 3,
  });

export const successMsg = (msg) => {
    message.success(msg);
};

export const errorMsg = (msg) => {
    message.error(msg);
};

export const warningMsg = (msg) => {
    message.warning(msg);
};

export const infoMsg = (msg) => {
    message.info(msg);
};