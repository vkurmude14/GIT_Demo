import React from 'react';

const Footer = () => (
  <footer className="app-footer">
    <span><a href="#" onClick={(e) => e.preventDefault()} >Mindtree</a> &copy; 2018 PerformanceTesting.</span>
    <span className="ml-auto">Powered by <a href="#" onClick={(e) => e.preventDefault()}>Mindtree</a></span>
  </footer>
)

export default Footer;
