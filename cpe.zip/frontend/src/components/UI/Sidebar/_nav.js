export default {
  items: [
    {
      name: "Dashboard",
      url: "/dashboard",
      icon: "fa fa-area-chart",
    },
    {
      title: true,
      name: "Jenkins",
      wrapper: {
        element: "",
        attributes: {},
      },
    },
    {
      name: "Jobs",
      url: "/job",
      icon: "icon-list",
      children: [
        {
          name: "Jmeter Jobs",
          icon: "icon-list",
          children: [
            {
              name: " Create Job",
              url: "/job/createJob",
              icon: "fa fa-plus-square",
            },
            {
              name: " Edit Job",
              url: "/job/editJob",
              icon: "fa fa-edit",
            },
            // {
            //   name: 'Jmeter Results',
            //   url: '/job/jmeterResults',
            //   icon: 'fa fa-edit',
            // }
          ],
        },
        {
          name: "Performance Center Jobs",
          icon: "icon-list",
          children: [
            {
              name: " Create PC Job",
              url: "/job/createPCJob",
              icon: "fa fa-plus-square",
            },
            {
              name: " Edit PC Job",
              url: "/job/editPCJob",
              icon: "fa fa-edit",
            },
          ],
        },
        {
          name: "Load Runner Jobs",
          icon: "icon-list",
          children: [
            {
              name: " Create LR Job",
              url: "/job/createLRJob",
              icon: "fa fa-plus-square",
            },
            {
              name: " Edit LR Job",
              url: "/job/editLRJob",
              icon: "fa fa-edit",
            },
          ],
        },
      ],
    },
    {
      name: "Pipeline",
      url: "/pipeline",
      icon: "icon-layers",
      children: [
        {
          name: " Add Job to Existing",
          url: "/pipeline/addJobToExisting",
          icon: "fa fa-tag",
        },
        {
          name: " Create New Pipeline",
          url: "/pipeline/createPipeline",
          icon: "fa fa-plus-square",
        },
        {
          name: " Edit Pipeline",
          url: "/pipeline/editPipeline",
          icon: "fa fa-edit",
        },
      ],
    },
    {
      name: "Manage Nodes",
      url: "/node",
      icon: "icon-link",
      children: [
        {
          name: " Create New Node",
          url: "/node/createNode",
          icon: "fa fa-plus-square",
        },
        {
          name: " Edit Node",
          url: "/node/editNode",
          icon: "fa fa-edit",
        },
      ],
    },
    {
      title: true,
      name: "Settings",
      wrapper: {
        element: "",
        attributes: {},
      },
      class: "",
    },
    {
      name: "Configurations",
      url: "/configurations",
      icon: "icon-settings",
    },
  ],
};
