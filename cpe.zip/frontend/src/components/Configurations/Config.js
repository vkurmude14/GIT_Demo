import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

import isEqual from "react-fast-compare";
import RegularCard from "../../components/UI/RegularCard/";
import Spinner from "../../components/Spinner/Spinner";
import * as actions from "../../store/actions";
import {
  EditContent,
  EditFooter,
} from "./EditConfigurations/EditConfigurations";
import {
  ViewContent,
  ViewFooter,
} from "./ViewConfigurations/ViewConfigurations";

import { errorMsg, successMsg } from "../UI/Message/Message";

class ConfigDetails extends Component {
  state = {
    config: {
      jmf: "",
      grafana: "",
      jenkinsPath: "",
      jmeterHome: "",
    },
    tempData: {
      jmf: "",
      grafana: "",
      jenkinsPath: "",
      jmeterHome: "",
    },
    editConfig: false,
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.updateConfig.success && !prevProps.updateConfig.success) {
      successMsg("Config details updated!");
      this.setState({
        ...prevState,
        editConfig: false,
      });
    }
    if (this.props.updateConfig.error && !prevProps.updateConfig.error) {
      errorMsg(this.props.updateConfig.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEqual(prevState.config, nextProps.config)) {
      return {
        ...prevState,
        config: nextProps.config,
        tempData: nextProps.config,
      };
    }
    return null;
  }

  formChangeHandler = (event) => {
    const target = event.target;
    this.setState({
      ...this.state,
      tempData: {
        ...this.state.tempData,
        [target.id]: target.value,
      },
    });
  };

  showEditPageHandler = () => {
    this.setState({
      ...this.state,
      editConfig: true,
    });
  };

  updateConfigHandler = () => {
    const config = {
      user: "config",
      jmf: this.state.tempData.jmf,
      grafana: this.state.tempData.grafana,
      jenkinsPath: this.state.tempData.jenkinsPath,
      jmeterHome: this.state.tempData.jmeterHome,
    };
    this.props.updateConfigFn(config);
  };

  discardChangesHandler = () => {
    this.setState({
      ...this.state,
      editConfig: false,
      tempData: {
        ...this.state.config,
      },
    });
  };

  render() {
    let configContent = <Spinner>Loading...</Spinner>;

    let configFooter = null;

    if (this.state.editConfig) {
      const inputFields = [
        {
          label: "TrendingTool URL",
          id: "jmf",
          value: this.state.tempData.jmf,
          placeholder: "Enter TrendingTool URL...",
        },
        {
          label: "Grafana URL",
          id: "grafana",
          value: this.state.tempData.grafana,
          placeholder: "Enter Grafana URL...",
        },
        {
          label: "Jenkins Installation Path",
          id: "jenkinsPath",
          value: this.state.tempData.jenkinsPath,
          placeholder: "Enter Jenkins Installation Path...",
        },
        {
          label: "Jmeter Home",
          id: "jmeterHome",
          value: this.state.tempData.jmeterHome,
          placeholder: "Enter Jmeter Home...",
        },
      ];
      configContent = (
        <EditContent
          inputFields={inputFields}
          formChangeHandler={this.formChangeHandler}
        />
      );

      configFooter = (
        <EditFooter
          updateHandler={this.updateConfigHandler}
          discardChangesHandler={this.discardChangesHandler}
          loading={this.props.updateConfig.loading}
        />
      );
    } else {
      const tableFields = [
        {
          name: "TrendingTool URL",
          value: this.state.config.jmf,
          icon: "line graph",
        },
        {
          name: "Grafana URL",
          value: this.state.config.grafana,
          icon: "area graph",
        },
        {
          name: "Jenkins Installation Path",
          value: this.state.config.jenkinsPath,
          icon: "location arrow",
        },
        {
          name: "Jmeter Home",
          value: this.state.config.jmeterHome,
          icon: "home",
        },
      ];

      configContent = <ViewContent tableFields={tableFields} />;

      configFooter = (
        <ViewFooter showEditPageHandler={this.showEditPageHandler} />
      );
    }
    return (
      <RegularCard
        cardTitle="Config"
        cardSubtitle="Jenkins Configurations"
        content={configContent}
        footer={configFooter}
      />
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    updateConfig: {
      loading: state.JenkinsConfig.updateConfig.loading,
      error: state.JenkinsConfig.updateConfig.error,
      success: state.JenkinsConfig.updateConfig.success,
    },
    config: {
      jmf: state.JenkinsConfig.fetch.config.jmf,
      grafana: state.JenkinsConfig.fetch.config.grafana,
      jenkinsPath: state.JenkinsConfig.fetch.config.jenkinsPath,
      jmeterHome: state.JenkinsConfig.fetch.config.jmeterHome,
    },
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    updateConfigFn: (config) => dispatch(actions.updateConfigStart(config)),
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ConfigDetails)
);
