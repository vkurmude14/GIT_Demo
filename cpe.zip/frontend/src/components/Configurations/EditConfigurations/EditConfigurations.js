import React from 'react';
import {
  Label
} from 'reactstrap';
import Aux from '../../../hoc/_Aux/_Aux';
import { Grid, Input, Button, Icon } from 'semantic-ui-react';


export const EditContent = (props) => {
  const getInput = (input, index) => (
    <Grid.Row key={index} >
      <Grid.Column width={6}>
        <Label>{input.label}</Label>
      </Grid.Column>
      <Grid.Column width={6}>
        <Input size="tiny" fluid
          type="text"
          id={input.id}
          value={input.value}
          onChange={props.formChangeHandler}
          placeholder={input.placeholder} />
      </Grid.Column>
    </Grid.Row>);

  return (
    <Grid padded="horizontally" columns={3}>
      {props.inputFields.map((inputField, index) => (
        getInput(inputField, index)
      ))}
    </Grid>
  )
}

export const EditFooter = (props) => (
  <Aux>
    <Button.Group size="mini">
      <Button animated onClick={props.updateHandler} color="green" loading={props.loading}>
        <Button.Content visible>Update</Button.Content>
        <Button.Content hidden>
          <Icon name='arrow circle right' />
        </Button.Content>
      </Button>
      <Button.Or />
      <Button animated onClick={props.discardChangesHandler} color="red">
        <Button.Content visible>Cancel</Button.Content>
        <Button.Content hidden>
          <Icon name='cancel' />
        </Button.Content>
      </Button>
    </Button.Group>
  </Aux>
)
