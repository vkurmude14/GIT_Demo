
import React from 'react';
import { Button, Icon, Table } from 'semantic-ui-react';


export const ViewContent = (props) => {

  return (
    <Table celled fixed>
      <Table.Body>
        {props.tableFields.map((row, index) => (
          <Table.Row positive key={index}>
            <Table.Cell> <Icon name={row.icon} /> {row.name}</Table.Cell>
            <Table.Cell>{row.value}</Table.Cell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  )
}

export const ViewFooter = (props) => (
  <Button size="mini" animated onClick={props.showEditPageHandler} primary>
    <Button.Content visible>Edit</Button.Content>
    <Button.Content hidden>
      <Icon name='edit' />
    </Button.Content>
  </Button>
)