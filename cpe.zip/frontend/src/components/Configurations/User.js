import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";

import isEqual from "react-fast-compare";
import RegularCard from '../../components/UI/RegularCard/';
import Spinner from '../../components/Spinner/Spinner';
import * as actions from '../../store/actions';
import { EditContent, EditFooter } from './EditConfigurations/EditConfigurations';
import { ViewContent, ViewFooter } from './ViewConfigurations/ViewConfigurations';

import { errorMsg, successMsg } from '../UI/Message/Message';


class User extends Component {

  state = {
    user: {
      username: "",
      password: "",
    },
    tempData: {
      username: "",
      password: "",
    },
    editUser: false,
  }

  componentDidUpdate(prevProps, prevState) {

    if (this.props.updateUser.success && !prevProps.updateUser.success) {
      successMsg("User details updated!");
      this.setState({
        ...prevState,
        editUser: false,
      });
    }

    if (this.props.updateUser.error && !prevProps.updateUser.error) {
      errorMsg(this.props.updateUser.error);
    }

  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.updateUser);
    if (!isEqual(prevState.user, nextProps.user)) {
      return {
        ...prevState,
        user: nextProps.user,
        tempData: nextProps.user
      }
    }
    return null;
  }

  formChangeHandler = event => {
    const target = event.target;
    this.setState({
      ...this.state,
      tempData: {
        ...this.state.tempData,
        [target.id]: target.value
      }
    });
  }

  userCardHandler = () => {
    this.setState({
      ...this.state,
      editUser: true
    });
  }

  updateUser = () => {
    const user = {
      user: "user",
      username: this.state.tempData.username,
      password: this.state.tempData.password
    }
    this.props.updateUserFn(user);
  }

  discardChanges = () => {
    this.setState({
      ...this.state,
      editUser: false,
      tempData: {
        ...this.state.user
      }
    })
  }

  render() {
    console.log(this.state.tempData);
    let userContent = (
      <Spinner>Loading...</Spinner>
    );

    let userFooter = null;

    if (this.state.editUser) {

      const inputFields = [
        { label: "UserName", id: "username", value: this.state.tempData.username, placeholder: "Enter Username...", },
        { label: "Password", id: "password", value: this.state.tempData.password, placeholder: "Enter Password...", },
      ];

      userContent = (
        <EditContent
          formChangeHandler={this.formChangeHandler}
          inputFields={inputFields} />
      );

      userFooter = (
        <EditFooter
          updateHandler={this.updateUser}
          discardChangesHandler={this.discardChanges}
          loading={this.props.updateUser.loading} />
      );
    }
    else {
      const tableFields = [
        { name: "UserName", value: this.state.user.username, icon: "user", },
        { name: "Password", value: this.state.user.password, icon: "eye", },
      ];

      userContent = (
        <ViewContent
          tableFields={tableFields} />
      );

      userFooter = (
        <ViewFooter
          showEditPageHandler={this.userCardHandler} />
      );
    }

    return (
      <RegularCard
        cardTitle="User"
        cardSubtitle="Jenkins User Details"
        content={userContent}
        footer={userFooter}
      />
    )
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    updateUser: {
      loading: state.JenkinsConfig.updateUser.loading,
      error: state.JenkinsConfig.updateUser.error,
      success: state.JenkinsConfig.updateUser.success
    },
    user: {
      username: state.JenkinsConfig.fetch.user.username,
      password: state.JenkinsConfig.fetch.user.password,
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    updateUserFn: user => dispatch(actions.updateUserStart(user)),
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(User));