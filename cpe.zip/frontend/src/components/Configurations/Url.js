import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

import isEqual from "react-fast-compare";
import RegularCard from "../../components/UI/RegularCard/";
import Spinner from "../../components/Spinner/Spinner";
import * as actions from "../../store/actions";
import {
  EditContent,
  EditFooter,
} from "./EditConfigurations/EditConfigurations";
import {
  ViewContent,
  ViewFooter,
} from "./ViewConfigurations/ViewConfigurations";

import { errorMsg, successMsg } from "../UI/Message/Message";

class UrlConfig extends Component {
  state = {
    url: {
      hostname: "",
      port: "",
      hosttype: "",
    },
    tempData: {
      hostname: "",
      port: "",
      hosttype: "",
    },
    editUrl: false,
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.updateUrl.success && !prevProps.updateUrl.success) {
      successMsg("Jenkins URL details updated!");
      this.setState({
        ...prevState,
        editUrl: false,
      });
    }
    if (this.props.updateUrl.error && !prevProps.updateUrl.error) {
      errorMsg(this.props.updateUrl.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEqual(prevState.url, nextProps.url)) {
      return {
        ...prevState,
        url: nextProps.url,
        tempData: nextProps.url,
      };
    }
    return null;
  }

  formChangeHandler = (event) => {
    const target = event.target;
    this.setState({
      ...this.state,
      tempData: {
        ...this.state.tempData,
        [target.id]: target.value,
      },
    });
  };

  showEditPageHandler = () => {
    this.setState({
      ...this.state,
      editUrl: true,
    });
  };

  updateUrlHandler = () => {
    const url = {
      user: "url",
      hostname: this.state.tempData.hostname,
      port: this.state.tempData.port,
      hosttype: this.state.tempData.hosttype,
    };
    this.props.updateUrlFn(url);
  };

  discardChangesHandler = () => {
    this.setState({
      ...this.state,
      editUrl: false,
      tempData: {
        ...this.state.url,
      },
    });
  };

  render() {
    let urlContent = <Spinner>Loading...</Spinner>;

    let urlFooter = null;

    if (this.state.editUrl) {
      const inputFields = [
        {
          label: "Hostname",
          id: "hostname",
          value: this.state.tempData.hostname,
          placeholder: "Enter Hostname...",
        },
        {
          label: "Port",
          id: "port",
          value: this.state.tempData.port,
          placeholder: "Enter Port...",
        },
        {
          label: "Hosttype",
          id: "hosttype",
          value: this.state.tempData.hosttype,
          placeholder: "Enter Hosttype...",
        },
      ];

      urlContent = (
        <EditContent
          inputFields={inputFields}
          formChangeHandler={this.formChangeHandler}
        />
      );

      urlFooter = (
        <EditFooter
          updateHandler={this.updateUrlHandler}
          discardChangesHandler={this.discardChangesHandler}
          loading={this.props.updateUrl.loading}
        />
      );
    } else {
      const tableFields = [
        {
          name: "Hostname",
          id: "hostname",
          value: this.state.url.hostname,
          icon: "desktop",
        },
        {
          name: "Port",
          id: "port",
          value: this.state.url.port,
          icon: "bullseye",
        },
        {
          name: "Hosttype",
          id: "hosttype",
          value: this.state.url.hosttype,
          icon: "desktop",
        },
      ];
      urlContent = <ViewContent tableFields={tableFields} />;

      urlFooter = <ViewFooter showEditPageHandler={this.showEditPageHandler} />;
    }
    return (
      <RegularCard
        cardTitle="URL"
        cardSubtitle="Jenkins hostname and port"
        content={urlContent}
        footer={urlFooter}
      />
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    updateUrl: {
      loading: state.JenkinsConfig.updateUrl.loading,
      error: state.JenkinsConfig.updateUrl.error,
      success: state.JenkinsConfig.updateUrl.success,
    },
    url: {
      hostname: state.JenkinsConfig.fetch.url.hostname,
      port: state.JenkinsConfig.fetch.url.port,
      hosttype: state.JenkinsConfig.fetch.url.hosttype,
    },
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    updateUrlFn: (url) => dispatch(actions.updateUrlStart(url)),
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UrlConfig)
);
