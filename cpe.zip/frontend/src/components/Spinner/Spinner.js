import React from 'react';

import './Spinner.css';

const spinner = () => (
     <div className="loader">Loading...</div>
    // <div class="loader1"><div></div><div></div></div>
);

export default spinner;