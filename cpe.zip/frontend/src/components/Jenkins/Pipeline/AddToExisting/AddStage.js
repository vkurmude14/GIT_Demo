import React from 'react'
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label as Label1,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';

import { Button, Icon, Grid, Segment, Header, Modal, Message, Step, Accordion, Label, Dropdown, Input } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';
import Spinner from '../../../Spinner/Spinner';
import Aux from '../../../../hoc/_Aux/_Aux'

import 'react-select/dist/react-select.css';
import { Tab } from 'material-ui';


const addStage = (props) => {

  const addStageconfirm = (e) => {
    props.submitHandler();

  }

  const options = [
    { key: "before", value: "before", text: "Before" },
    { key: "after", value: "after", text: "After" }
  ]

  let pStage = false;
  let pipelineStages = [];
  let panels = [];
  if (props.pipelineStages) {
    pStage = props.pipelineStages.includes('Performance Test');
    props.pipelineStages.forEach(stage => {
      pipelineStages.push({ key: stage, value: stage, text: stage })
    });

    panels = [{
      title: {
        content: <Label color='blue' content="Add Performance Test Stage" />,
        key: 1
      },
      content: {
        content: <Aux>
          <FormGroup row>
            {pipelineStages.length !== 0 ? <Col md="4">
              <FormGroup>
                <Label1 htmlFor="stageRef"> Add Performance Stage- </Label1>
                <Dropdown id="where" placeholder='Select choice'
                  defaultValue="after" scrolling options={options}
                  onChange={props.formChangeHandler} />
                <Dropdown id="stageRef" placeholder='Select A Stage' fluid search
                  selection options={pipelineStages}
                  onChange={props.dropdownChangeHandler} />
              </FormGroup>
            </Col> : null}
            <Col md="4">
              <Label1 htmlFor="jobName" className="pr-1">Select a Job</Label1>
              <Dropdown id="jobName" placeholder='Select a Job to build' fluid search
                selection options={props.jobList}
                onChange={props.dropdownChangeHandler} />
            </Col>
            <Col md="4">
              <FormGroup>
                <Label1 htmlFor="release">Release</Label1>
                <Input fluid type="text" id="release" value={1}
                  value={props.pipeline.release} onChange={props.formChangeHandler} placeholder="RELEASE-1" />
              </FormGroup>
            </Col>
          </FormGroup>
        </Aux>,
        key: 2
      },
    }]
  }



  let card = <Spinner />;

  if (!props.stagesloading) {
    let cardBody = <Aux> <Message warning>
      <Message.Header>Warning!</Message.Header>
      <p>There are no stages in this pipeline!</p>
    </Message>
      <br />
      <Accordion defaultActiveIndex={1} panels={panels} /> </Aux>;

    let cardFooter = null;

    if (props.pipelineStages && props.pipelineStages.length !== 0) {
      console.log(JSON.stringify(props.pipelineStages));
      cardBody = (<Aux><Step.Group ordered>
        {props.pipelineStages.map((stageName, index) =>
          <Step active completed={stageName == 'Performance Test'} key={index}>
            <Step.Content>
              <Step.Title>{stageName}</Step.Title>
            </Step.Content>
          </Step>
        )}</Step.Group>
        <br />
        {pStage ? <Message info>
          <Message.Header>Please note!</Message.Header>
          <p>Performance-Test Stage is Already Added to Pipeline!</p>
        </Message> :
          <Accordion defaultActiveIndex={1} panels={panels} />}
      </Aux>)
    }

    cardFooter = !pStage ?
      <Button.Group size="mini">
        <Popconfirm placement="topLeft" title="Are you sure delete this pipeline?"
          onConfirm={() => addStageconfirm()} okText="Yes" cancelText="No">
          <Button animated size="mini" primary disabled={!props.isFormValid} loading={props.submitLoading}>
            <Button.Content visible>Submit</Button.Content>
            <Button.Content hidden>
              <Icon name='edit' />
            </Button.Content>
          </Button>
        </Popconfirm>
        <Button.Or />
        <Button animated color="red" onClick={props.discardChangesHandler}>
          <Button.Content visible>Discard</Button.Content>
          <Button.Content hidden>
            <Icon name='trash' />
          </Button.Content>
        </Button>
      </Button.Group> : null;

    card = <Aux>
      <CardBody>{cardBody}</CardBody>
      <CardFooter>{cardFooter}</CardFooter>
    </Aux>;
  }

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Add Performance stage</small>
        </CardHeader>
        {card}
      </Card>
    </Col>
  )
}
export default addStage;