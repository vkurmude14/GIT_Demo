import React, { Component } from 'react';
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Dropdown, Segment, Dimmer, Loader } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';

class EditPipeline extends Component {
  state = {
    pipeline: {
      name: '',
      jobName: '',
      release: '',
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    if (prevState.pipeline.name !== nextProps.pipeline.name) {
      return {
        ...prevState,
        pipeline: {
          ...nextProps.pipeline
        }
      }
    }
  }

  updatePipelineConfirm = (e) => {
    this.props.updatePipeline(this.state.pipeline);
  }

  formChangeHandler = event => {
    console.log("formChangeHandler")
    const target = event.target;
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [target.id]: target.value
      }
    }, () => {
      if (this.state.pipeline.jobname !== "" && this.state.pipeline.release !== "" && this.state.pipeline.jobName !== "") {
        this.setState({
          ...this.state,
          isFormValid: true
        }, () => {
        })
      } else {
        this.setState({
          ...this.state,
          isFormValid: false
        }, () => {
        })
      }
    });
  }

  dropdownChangeHandler = (p, target) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        jobName: target.value
      }
    });
  }

  toggleCheckbox = event => {
    const target = event.target;
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [target.id]: target.checked
      }
    });
  }

  render() {
    console.log(this.state.pipeline);
    console.log(this.props.jobList);
    return (
      <Col md="12">
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Edit Pipeline </small>
          </CardHeader>
            <CardBody>
            <FormGroup row>
              <Col md="4">
                <FormGroup>
                  <Label htmlFor="name">Pipeline</Label>
                  <Input type="text" id="name" value={this.state.pipeline.name}
                    disabled placeholder="JOB-XYZ" />
                </FormGroup>
              </Col>
              <Col md="4">
                <Label htmlFor="jobName" className="pr-1">Job</Label>
                <Dropdown id="jobName" placeholder='State' fluid search selection options={this.props.jobList}
                  value={this.state.pipeline.jobName} onChange={this.dropdownChangeHandler} />
              </Col>
              <Col md="4">
                <FormGroup>
                  <Label htmlFor="release">Release Version</Label>
                  <Input type="text" id="release" value={this.state.pipeline.release}
                    onChange={this.formChangeHandler} placeholder="RELEASE-1" />
                </FormGroup>
              </Col>
            </FormGroup>
          </CardBody>

          <CardFooter >
            <Button.Group size="mini">
              <Popconfirm placement="topLeft" title="Are you sure update this pipeline?"
                onConfirm={this.updatePipelineConfirm} okText="Yes" cancelText="No">
                <Button animated color="green" loading={this.props.updateLoading}>
                  <Button.Content visible>Submit</Button.Content>
                  <Button.Content hidden>
                    <Icon name='check circle' />
                  </Button.Content>
                </Button>
              </Popconfirm>
              <Button.Or />
              <Button animated secondary onClick={this.props.discardChangesHandler}>
                <Button.Content visible>Discard</Button.Content>
                <Button.Content hidden>
                  <Icon name='remove circle' />
                </Button.Content>
              </Button>
            </Button.Group>
          </CardFooter>       
        </Card>
      </Col>
    )
  }
}
export default EditPipeline;