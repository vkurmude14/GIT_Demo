import React from 'react'
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';

import { Button, Icon, Grid, Segment, Header, Modal, Table, Step, Message } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';
import HorizontalScroll from 'react-scroll-horizontal';
import Aux from '../../../../hoc/_Aux/_Aux';

import 'react-select/dist/react-select.css';

import Select from 'react-select';

const viewPipeline = (props) => {

  let pStage = false;
  let pipelineStages = [];
  if (props.pipelineStages) {
    pStage = props.pipelineStages.includes('Performance Test');
    props.pipelineStages.forEach(stage => {
      pipelineStages.push({ key: stage, value: stage, text: stage })
    });
  }

  const deletePipelineConfirm = (e) => {
    // successMsg("Pipeline Deleted Successfully");
    props.deletePipelineHandler();
  }

  const child = { width: `30em`, height: `100%` }
  const parent = { width: `60em`, height: `100%` }
  const scroll = (e) => {
    window.scrollBy(e.deltaY, 0)
  }


  const pipelineTableData = [
    { icon: 'folder outline', header: 'Pipeline Name', cell: props.pipeline.name },
    { icon: 'folder', header: 'Job', cell: props.pipeline.jobName },
    { icon: 'numbered list', header: 'Release', cell: props.pipeline.release },
  ];

  const pipelineTable = pipelineTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  );

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Pipeline Details</small>
        </CardHeader>
        <CardBody>
          {props.pipelineStages.length > 0 ? <Aux>
            <h6> Pipeline Stages: </h6>
            <div style={{ overflow: 'auto' }}>
              <Step.Group ordered>
                {props.pipelineStages.map((stageName, index) =>
                  <Step active completed={stageName == 'Performance Test'} key={index}>
                    <Step.Content>
                      <Step.Title>{stageName}</Step.Title>
                    </Step.Content>
                  </Step>
                )}</Step.Group>
            </div>
            <br /> </Aux> : null}
          {!pStage ? <Message warning>
            <Message.Header>Warning!</Message.Header>
            <p>Performance-Test Stage is not added to this pipeline!</p>
          </Message> : <Aux>
              <h6> Performance Stage: </h6>
              <Table compact celled >
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell>Name</Table.HeaderCell>
                    <Table.HeaderCell>Value</Table.HeaderCell>
                  </Table.Row>
                </Table.Header>
                <Table.Body>
                  {pipelineTable}
                </Table.Body>
              </Table> </Aux>}
        </CardBody>
        <CardFooter>

          {!pStage ? <Popconfirm placement="topLeft" title="Are you sure delete this pipeline?"
            onConfirm={() => deletePipelineConfirm()} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
            <Button animated color="red">
              <Button.Content visible>Delete</Button.Content>
              <Button.Content hidden>
                <Icon name='trash' />
              </Button.Content>
            </Button>
          </Popconfirm> :
            <Button.Group size="mini">
              <Button animated onClick={props.editPipelineHandler} size="mini" primary>
                <Button.Content visible>Edit</Button.Content>
                <Button.Content hidden>
                  <Icon name='edit' />
                </Button.Content>
              </Button>
              <Button.Or />
              <Popconfirm placement="topLeft" title="Are you sure delete this pipeline?"
                onConfirm={() => deletePipelineConfirm()} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
                <Button animated color="red" loading={props.deleteLoading}>
                  <Button.Content visible>Delete</Button.Content>
                  <Button.Content hidden>
                    <Icon name='trash' />
                  </Button.Content>
                </Button>
              </Popconfirm>
            </Button.Group>}
        </CardFooter>
      </Card>
    </Col>
  )
}
export default viewPipeline;