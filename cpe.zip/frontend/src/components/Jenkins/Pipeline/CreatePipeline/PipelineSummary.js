import React, { Component } from 'react'
import { Button, Icon, Grid, Segment, Header, Modal, Table } from 'semantic-ui-react';
import { Popconfirm } from 'antd';


const PipelineSummary = (props) => {

  const addJobconfirm = () => props.addPipelineHandler();

  const pipelineTableData = [
    { icon: 'folder outline', header: 'Pipeline Name', cell: props.pipeline.name },
    { icon: 'folder', header: 'Job', cell: props.pipeline.job },
    { icon: 'numbered list', header: 'Release', cell: props.pipeline.release },
  ];

  const pipelineTable = pipelineTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  );

  const buttons = (
    <Button.Group size="tiny">
      <Popconfirm placement="topLeft" title="Are you sure add this Pipeline?"
        onConfirm={addJobconfirm} okText="Yes" cancelText="No">
        <Button animated color="green" loading={props.submitLoading}
          disabled={!props.isFormValid} >
          <Button.Content visible>Submit</Button.Content>
          <Button.Content hidden>
            <Icon name='check circle' />
          </Button.Content>
        </Button>
      </Popconfirm>
      <Button.Or />
      <Button animated primary onClick={props.discardPipelineHandler} >
        <Button.Content visible>Discard</Button.Content>
        <Button.Content hidden>
          <Icon name='remove circle' />
        </Button.Content>
      </Button>
    </Button.Group>
  )

  return (
    <div>
      <Table compact celled >
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Name</Table.HeaderCell>
            <Table.HeaderCell>Value</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {pipelineTable}
        </Table.Body>
        <Table.Footer fullWidth>
          <Table.Row>
            <Table.HeaderCell colSpan='4'>
              {buttons}
            </Table.HeaderCell>
          </Table.Row>
        </Table.Footer>
      </Table>
    </div>
  )
}

export default PipelineSummary;