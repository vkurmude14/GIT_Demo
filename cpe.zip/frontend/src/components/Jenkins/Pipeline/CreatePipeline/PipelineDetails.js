import React from 'react'
import {
  Card,
  CardHeader,
  CardBody,
  Label,
} from 'reactstrap';
import { Dropdown, Input, Form } from 'semantic-ui-react'

const PipelineDetails = (props) => {
  return (
    <Card>
      <CardHeader>
        <strong>Jenkins</strong>
        <small> Create Pipeline</small>
      </CardHeader>
      <CardBody>
        <Form loading={props.submitLoading}>
          <Form.Group widths='equal'>
            <Form.Field required error={props.pipelineExists}>
              <Label htmlFor="name">Name</Label>
              <Input type="text" id="name" value={props.pipeline.name} fluid
                onChange={props.formChangeHandler} placeholder="PIPELINE-XYZ" />
            </Form.Field>

            <Form.Field required>
              <Label htmlFor="job" className="pr-1">Select a Job</Label>
              <Dropdown id="job" placeholder='Select a Job'
                fluid search selection
                options={props.jobList}
                value={props.pipeline.job}
                onChange={props.dropdownChangeHandler} />
            </Form.Field>

            <Form.Field required>
              <Label htmlFor="release">Release</Label>
              <Input type="text" id="release" value={props.pipeline.release} fluid
                onChange={props.formChangeHandler} placeholder="RELEASE-1" />
            </Form.Field>
          </Form.Group>
        </Form>
      </CardBody>
    </Card>
  )
}

export default PipelineDetails;