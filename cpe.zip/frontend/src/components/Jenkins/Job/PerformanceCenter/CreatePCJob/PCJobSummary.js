import React, { Component } from 'react'
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import Spinner from '../../../../Spinner/Spinner';
import { Button, Icon, Grid, Segment, Header, Modal, Table, List } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../../UI/Message/Message';

const PCJobSummary = (props) => {

  let triggers = [];
  props.job.successTrigger ? triggers.push("Success") : null;
  props.job.failureTrigger ? triggers.push("Failure") : null;
  props.job.beforebuildTrigger ? triggers.push("BeforeBuild") : null;
  console.log(triggers);
  let trig = triggers ? triggers.join(", ") : "-";

  const addJobconfirm = (e) => {
    console.log(e);
    props.addJobHandler();
  }

  const discardJobconfirm = (e) => {
    warningMsg("Discarding Job..");
    props.discardJobHandler();
  }

  let cardFooter = null;
  let submitPage = null;

  if (props.page === 2) {
    cardFooter = (<CardFooter>
      <Button.Group size="mini">
        <Button animated onClick={props.prevPageHandler} color="yellow">
          <Button.Content visible>Back</Button.Content>
          <Button.Content hidden>
            <Icon name='left arrow' />
          </Button.Content>
        </Button>
        <Button.Or />
        <Button animated onClick={props.nextPageHandler} primary>
          <Button.Content visible>next</Button.Content>
          <Button.Content hidden>
            <Icon name='right arrow' />
          </Button.Content>
        </Button>
      </Button.Group>
    </CardFooter>);
    submitPage = null;
  } else {
    cardFooter = null;
    submitPage = (
      <Grid columns='equal'>
        <Grid.Row stretched>
          <Grid.Column>
          </Grid.Column>
          <Grid.Column width={6}>
            <Segment>
              <Row>
                <Col md="6">
                  <h5>Create PC Jenkins job: </h5>
                </Col>
                <Col md="6">
                  <Popconfirm placement="topLeft" title="Are you sure to create this job?"
                 
                    onConfirm={addJobconfirm} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
                    <Button animated='vertical' size="mini" color="green">
                      <Button.Content visible>Submit</Button.Content>
                      <Button.Content hidden>
                        <Icon name='chevron circle right' />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                  <Popconfirm placement="topLeft" title="Are you sure discard this job?"
                    onConfirm={discardJobconfirm} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
                    <Button animated='vertical' size="mini" color="red">
                      <Button.Content visible>Discard</Button.Content>
                      <Button.Content hidden>
                        <Icon name='remove' />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                </Col>
              </Row>
            </Segment>
          </Grid.Column>
          <Grid.Column>
          </Grid.Column>
        </Grid.Row>
      </Grid>)
  }

  const servers = (<List horizontal >
    {
      props.job.servers.map((server, index) =>
        <List.Item key={index} >
          <Icon name={server.os} />
          <List.Content size="small" verticalAlign='middle'>{server.name}</List.Content>
        </List.Item>
      )
    }
  </List>);
  const summaryTableData = [
    { icon: 'folder outline', header: 'Job Name', cell: props.job.name },
    { icon: 'comment alternate', header: 'Description', cell: props.job.description },
    { icon: 'mail', header: 'E-mail', cell: props.job.email },
    { icon: 'mail forward', header: 'E-mail Triggers', cell: trig },
    { icon: 'sign in alternate', header: 'Run in', cell: props.job.enableSlave ? "Slave: " + props.job.slave : "Master" },
    { icon: 'server', header: 'Servers to monitor', cell: servers },
    { icon: 'server', header: 'Release', cell: props.job.release },
    { icon: 'server', header: 'PC Server Name', cell: props.job.pcServerName },
    { icon: 'server', header: 'ALM Domain', cell: props.job.almDomain },
    { icon: 'server', header: 'ALM Project', cell: props.job.almProject },
    { icon: 'server', header: 'Duration(Hours)', cell: props.job.durationHours },
    { icon: 'server', header: 'Duration(Minutes)', cell: props.job.durationMinutes },
    { icon: 'server', header: 'test ID', cell: props.job.testID },
    { icon: 'server', header: 'PC Username', cell: props.job.pcUsername },
    { icon: 'server', header: 'PC password', cell: props.job.pcPassword },
    { icon: 'server', header: 'TestInstance ID', cell: props.job.testInstanceID },
    { icon: 'server', header: 'Post Run Action', cell: props.job.postRunAction },
    { icon: 'server', header: 'Add Run to Trend Report', cell: props.job.addRunToTrendReport },
    { icon: 'server', header: 'Trend Report ID', cell: props.job.trendReportId },
    { icon: 'server', header: 'Proxy Out URL', cell: props.job.proxyOutURL },
    { icon: 'server', header: 'Proxy Username', cell: props.job.proxyUsername },
    { icon: 'server', header: 'Proxy Password', cell: props.job.proxyPassword },    
    { icon: 'server', header: 'Retry', cell: props.job.retry? "RETRY" :"NO_RETRY" },
    { icon: 'server', header: 'Retry Delay', cell: props.job.retryDelay },
    { icon: 'server', header: 'Retry Occurrences', cell: props.job.retryOccurrences },
    { icon: 'align right', header: 'Https Protocol', cell: props.job.httpsProtocol? "true" : "false" },
    { icon: 'align right', header: 'VUDs Mode', cell: props.job.vudsMode? "true" : "false" },
    { icon: 'align right', header: 'Status By SLA', cell: props.job.statusBySLA? "true" : "false" },
    { icon: 'align right', header: 'Baseline', cell: props.job.baseline? "true" : "false" },
    { icon: 'align right', header: 'autoTestInstance', cell: props.job.autoTestInstance? "MANUAL" : "AUTO" },

  ];
  
  const summaryTable = summaryTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  )

  return (
    <div>
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Job Summary</small>
        </CardHeader>
        <CardBody>
          <Table compact celled >
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {summaryTable}
            </Table.Body>
          </Table>
        </CardBody>
        {cardFooter}
      </Card>
      {submitPage}
    </div>
  )
}

export default PCJobSummary;