import React, { Component } from "react";
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  FormGroup,
  FormText,
  Label,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  FormFeedback,
} from "reactstrap";
import Spinner from "../../../../Spinner/Spinner";
import {
  Button,
  Icon,
  Checkbox,
  Dropdown,
  Message,
  Select,
  Input,
  Form,
  List,
  Grid,
  Popup,
} from "semantic-ui-react";
import axios from "../../../../../axios";
import fileDownload from "js-file-download";
import ReactTags from "react-tag-autocomplete";
import { Tooltip } from "antd";
import Iframe from "react-iframe";

const handleFiles = (files) => {
  console.log(files);
};

const PCJobDetails = (props) => {
  console.log("component-JobDetails");
  const downloadSlaveAgent = () => {
    axios
      .get("downloadSlaveAgent", {
        params: { slaveName: props.job.slave },
      })
      .then((response) => {
        console.log(response.data);
        fileDownload(response.data, "slave-agent-" + props.job.slave + ".jnlp");
      })
      .catch((error) => console.log(error.message));
  };

  const options = [
    { key: "windows", text: "Windows", value: "windows", icon: "windows" },
    { key: "linux", text: "Linux", value: "linux", icon: "linux" },
  ];

  const options1 = [
    { key: "collateResults", text: "Collate Results", value: "COLLATE" },
    {
      key: "collateAndAnalyze",
      text: "Collate And Analyze",
      value: "COLLATE_AND_ANALYZE",
    },
    { key: "DoNotCollate", text: "Do Not Collate", value: "DO_NOTHING" },
  ];

  const options2 = [
    { key: "noTrend", text: "Do Not Trend", value: "NO_TREND" },
    {
      key: "trendWithTest",
      text: "Use Trend Report Associated with Test",
      value: "ASSOCIATED",
    },
    {
      key: "trendWithID",
      text: "Add run to trend report with ID",
      value: "USE_ID",
    },
  ];

  const infoboxSlaveAgent = (
    <Message warning>
      <Row>
        <Col md="1">
          <Button icon="download" color="orange" onClick={downloadSlaveAgent} />
        </Col>
        <Col md="10">
          <Message.Header>Slave-Agent</Message.Header>
          <p>Download slave-agent and run on slave machine..</p>
        </Col>
      </Row>
    </Message>
  );

  const emailTriggers = [
    { name: "successTrigger", text: "Success" },
    { name: "failureTrigger", text: "Failure" },
    { name: "beforebuildTrigger", text: "Beforebuild" },
  ];

  const emailTriggerCheckbox = emailTriggers.map((trigger, i) => (
    <FormGroup check className="checkbox" key={i}>
      <Input
        className="form-check-input"
        type="checkbox"
        id={trigger.name}
        name={trigger.name}
        value={props.job.successTrigger}
        onChange={props.toggleCheckbox}
        checked={props.job[trigger.name]}
      />
      <Label className="form-check-label" check htmlFor={trigger.name}>
        {trigger.text}
      </Label>
    </FormGroup>
  ));

  const inputFields = {
    name: {
      label: "Name",
      id: "name",
      type: "text",
      value: props.job.name,
      placeholder: "JOB-XYZ",
    },
    release: {
      label: "Release",
      id: "release",
      type: "text",
      placeholder: "Release-1",
    },
    email: {
      label: "Email Recipient",
      id: "email",
      type: "email",
      placeholder: "example@example.com",
    },
    pcServerName: {
      label: "PC Server name",
      id: "pcServerName",
      type: "text",
      placeholder: "Performance Center Server Name",
    },
    almDomain: {
      label: "Domain",
      id: "almDomain",
      type: "text",
      placeholder: "Domain Name",
    },
    almProject: {
      label: "Project",
      id: "almProject",
      type: "text",
      placeholder: "Project Name",
    },
    testID: {
      label: "Test ID",
      id: "testID",
      type: "text",
      placeholder: "Test ID",
    },
    durationHours: {
      label: "Duration (in hours)",
      id: "durationHours",
      type: "text",
      placeholder: "Duration (in hours)",
    },
    durationMinutes: {
      label: "Duration (in minutes)",
      id: "durationMinutes",
      type: "text",
      placeholder: "Duration (in minutes)",
    },
    pcUsername: {
      label: "Performance Center Username ",
      id: "pcUsername",
      type: "text",
      placeholder: "Username",
    },
    pcPassword: {
      label: "Performance Center password ",
      id: "pcPassword",
      type: "text",
      placeholder: "password",
    },
    testInstanceID: {
      label: "TestInstance Id ",
      id: "testInstanceID",
      type: "text",
      placeholder: "testInstance ID",
    },
    trendReportId: {
      label: "Trend Report Id ",
      id: "trendReportId",
      type: "text",
      placeholder: "trendReportId",
    },
    proxyOutURL: {
      label: "Local Proxy ",
      id: "proxyOutURL",
      type: "text",
      placeholder: "proxyOutURL",
    },
    proxyUsername: {
      label: "Proxy Username ",
      id: "proxyUsername",
      type: "text",
      placeholder: "Username",
    },
    proxyPassword: {
      label: "Proxy password ",
      id: "proxyPassword",
      type: "text",
      placeholder: "password",
    },
    retryDelay: {
      label: "Retry Delay ",
      id: "retryDelay",
      type: "text",
      placeholder: "retryDelay",
    },
    retryOccurrences: {
      label: "Retry Occurrences ",
      id: "retryOccurrences",
      type: "text",
      placeholder: "retryOccurrences",
    },
  };

  const getInput = (input) => (
    <Form.Input
      fluid
      type={input.type}
      id={input.id}
      value={props.job[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={input.id === "name" && props.jobExists}
    />
  );

  const getInputReq = (input) => (
    <Form.Input
      fluid
      required
      type={input.type}
      id={input.id}
      value={props.job[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={input.id === "name" && props.jobExists}
    />
  );

  const checkboxFields = [
    { id: "successTrigger", label: "Success" },
    { id: "failureTrigger", label: "Failure" },
    { id: "beforebuildTrigger", label: "Before Build" },
    { id: "enableSlave", label: "Run this Job in slave?" },
    { id: "httpsProtocol", label: "HTTPS Protocol" },
    { id: "vudsMode", label: "use VUD's" },
    { id: "statusBySLA", label: "Set Step Status according to SLA" },
    { id: "baseline", label: "baseline", type: "checkbox" },
    { id: "autoTestInstance", label: "Manual Selection" },
    { id: "retry", label: "Retry", type: "checkbox" },
  ];

  const getCheckbox = (checkbox) => (
    <Form.Checkbox
      id={checkbox.id}
      label={checkbox.label}
      name={checkbox.id}
      onChange={props.toggleCheckbox}
      checked={props.job[checkbox.id]}
      toggle={
        checkbox.id === "enableSlave" ||
        checkbox.id === "baseline" ||
        checkbox.id === "retry"
      }
    />
  );

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create PC Job</small>
        </CardHeader>
        <CardBody>
          <Form size="small">
            <Grid padded="horizontally" columns={3}>
              <Grid.Row stretched>
                <Grid.Column verticalAlign="top">
                  {getInputReq(inputFields.name)}
                  {getInputReq(inputFields.pcServerName)}
                  {getInputReq(inputFields.almDomain)}
                  {getInputReq(inputFields.almProject)}
                  {getInputReq(inputFields.testID)}
                  {getInputReq(inputFields.pcUsername)}
                  {getInputReq(inputFields.pcPassword)}

                  {/* <div>
                  <input
                    placeholder="Password"
                    type={props.isPasswordShown ? "text" : "password"}
                    name="pass"
                  />
                  <i
                    className="fa fa-eye password-icon"
                    onClick={props.togglePasswordVisiblity}
                  />
                  </div> */}

                  <Form.Field>
                    <Label>Post Run Action</Label>
                     
                    <Dropdown
                      fluid
                      search
                      selection
                      placeholder="Select a post run action"
                      options={options1}
                      onChange={props.handlePostRunActionChange}
                      value={props.job.postRunAction}
                    />
                  </Form.Field>
                  {props.job.postRunAction === "COLLATE_AND_ANALYZE" ? (
                    <Form.Field>
                      <Form.Field>
                        <Label>Add run to trend report</Label>
                         
                        <Dropdown
                          fluid
                          search
                          selection
                          placeholder="Add run to trend report Id"
                          options={options2}
                          onChange={props.handleTrendReportId}
                          value={props.job.addRunToTrendReport}
                        />
                      </Form.Field>
                      {props.job.addRunToTrendReport === "USE_ID"
                        ? getInputReq(inputFields.trendReportId)
                        : null}
                    </Form.Field>
                  ) : null}
                </Grid.Column>
                <Grid.Column verticalAlign="top">
                  {getInputReq(inputFields.release)}
                  {getInputReq(inputFields.durationHours)}
                  {getInputReq(inputFields.durationMinutes)}
                  {getInput(inputFields.proxyOutURL)}
                  {getInput(inputFields.proxyUsername)}
                  {getInput(inputFields.proxyPassword)}
                  {getInputReq(inputFields.email)}
                  <Form.Field>
                    <Label>Email Triggers</Label>
                    <Form.Group inline>
                      {getCheckbox(checkboxFields[0])}
                      {getCheckbox(checkboxFields[1])}
                      {getCheckbox(checkboxFields[2])}
                    </Form.Group>
                  </Form.Field>
                </Grid.Column>
                <Grid.Column verticalAlign="top">
                  <Form.TextArea
                    label="Description (Optional)"
                    id="description"
                    rows={4}
                    placeholder="Description about this job.."
                    value={props.job.description}
                    onChange={props.formChangeHandler}
                  />

                  <Form.Field>
                    <br />
                    <Row>
                      <Col md="5">{getCheckbox(checkboxFields[3])}</Col>
                      <Col md="7">
                        {props.job.enableSlave ? (
                          <Dropdown
                            fluid
                            search
                            selection
                            id="slave"
                            placeholder="Select a slave"
                            options={props.nodeList}
                            onChange={props.dropdownChangeHandler}
                            value={props.job.slave}
                          />
                        ) : null}
                      </Col>
                    </Row>
                  </Form.Field>
                  {getCheckbox(checkboxFields[9])}
                  {props.job.retry ? (
                    <Form.Field>
                      {getInputReq(inputFields.retryDelay)}
                      {getInputReq(inputFields.retryOccurrences)}
                    </Form.Field>
                  ) : null}

                  {getCheckbox(checkboxFields[7])}
                  {getCheckbox(checkboxFields[6])}
                  {getCheckbox(checkboxFields[5])}
                  {getCheckbox(checkboxFields[4])}
                  {getCheckbox(checkboxFields[8])}
                  {props.job.autoTestInstance
                    ? getInputReq(inputFields.testInstanceID)
                    : null}
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </Form>
          {/* <Grid padded="horizontally" columns={3}>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
                <label> Execute a PC Scenario </label>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
                 {getInput(inputFields.executable)}
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
                Project Type(local)
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
                {getInput(inputFields.localProjectFile)}
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
                Project Details
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
            {getInput(inputFields.scenarioName)} 
              </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched>
              <Grid.Column verticalAlign="top">
            License Type(Shared License) 
              </Grid.Column>
            </Grid.Row>
            {}
          </Grid>
          <RadioGroup horizontal>
            <RadioButton value="apple">
              Apple
  </RadioButton>
            <RadioButton value="orange">
              Orange
  </RadioButton>
            <RadioButton value="melon">
              Melon
  </RadioButton>
            <ReversedRadioButton value="melon">
              Melon
  </ReversedRadioButton>
                        </RadioGroup>*/}
          <Grid padded="horizontally" columns={2}>
            <Grid.Row>
              <Grid.Column>
                <Form>
                  <Form.Input
                    required
                    type="text"
                    placeholder="Server"
                    action
                    label="Add Servers to monitor"
                    fluid
                    value={props.tempServer.name}
                    onChange={props.handleServerChange}
                  >
                    <input />
                    <Select
                      options={options}
                      simple
                      item
                      value={props.tempServer.os}
                      onChange={props.handleOsChange}
                    />
                    <Button
                      type="submit"
                      onClick={props.addServersHandler}
                      disabled={!props.tempServer.name}
                    >
                      Add
                    </Button>
                  </Form.Input>
                </Form>
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <br />
          <Row>
            <List horizontal style={{ marginLeft: "10px" }}>
              {props.job.servers.map((server, index) => (
                <List.Item
                  key={index}
                  style={{
                    backgroundColor: "#c2cfd6",
                    borderRadius: "50px",
                    marginTop: "10px",
                  }}
                >
                  <List.Content floated="right" style={{ marginRight: "5px" }}>
                    <Button
                      size="mini"
                      circular
                      icon="delete"
                      onClick={() => props.removeServerHandler(index)}
                    />
                  </List.Content>
                  <Icon name={server.os} style={{ marginLeft: "10px" }} />
                  <List.Content size="small" verticalAlign="middle">
                    {server.name}
                  </List.Content>
                </List.Item>
              ))}
            </List>
          </Row>
        </CardBody>
        <CardFooter>
          <Button
            animated
            onClick={props.nextPageHandler}
            disabled={!props.isFormValid}
            size="mini"
            primary
          >
            <Button.Content visible>Next</Button.Content>
            <Button.Content hidden>
              <Icon name="right arrow" />
            </Button.Content>
          </Button>
        </CardFooter>
      </Card>

      {props.job.enableSlave && props.job.slave ? infoboxSlaveAgent : null}
    </Col>
  );
};
export default PCJobDetails;
