import React from 'react'
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';

import { Button, Icon, Grid, Segment, Header, Modal, Table, List } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../../UI/Message/Message';

import 'react-select/dist/react-select.css';

import Select from 'react-select';

const viewPCJob = (props) => {
  console.log(props);
  let triggers = [];
  props.job.successTrigger ? triggers.push("Success") : null;
  props.job.failureTrigger ? triggers.push("Failure") : null;
  props.job.beforebuildTrigger ? triggers.push("BeforeBuild") : null;
  let trig = triggers ? triggers.join(", ") : "-";

  const deleteJobConfirm = (e) => {
    props.deleteJobHandler();
  };

  const servers = (<List  horizontal >
    {
      props.job.servers.map((server, index) =>
        <List.Item key={index} >
          <Icon name={server.os} />
          <List.Content size="small" verticalAlign='middle'>{server.name}</List.Content>
        </List.Item>
      )
    }
  </List>);

  const summaryTableData = [
    { icon: 'folder outline', header: 'Job Name', cell: props.job.name },
    { icon: 'comment alternate', header: 'Description', cell: props.job.description },
    { icon: 'mail', header: 'E-mail', cell: props.job.email },
    { icon: 'mail forward', header: 'E-mail Triggers', cell: trig },
    { icon: 'sign in alternate', header: 'Run in', cell: props.job.enableSlave ? "Slave: " + props.job.slave : "Master" },
    { icon: 'server', header: 'Servers to monitor', cell: servers },
    { icon: 'server', header: 'Release', cell: props.job.release },
    { icon: 'server', header: 'PC Server Name', cell: props.job.pcServerName },
    { icon: 'server', header: 'ALM Domain', cell: props.job.almDomain },
    { icon: 'server', header: 'ALM Project', cell: props.job.almProject },
    { icon: 'server', header: 'Duration(Hours)', cell: props.job.durationHours },
    { icon: 'server', header: 'Duration(Minutes)', cell: props.job.durationMinutes },
    { icon: 'server', header: 'test ID', cell: props.job.testID },
    { icon: 'server', header: 'PC Username', cell: props.job.pcUsername },
    { icon: 'server', header: 'PC password', cell: props.job.pcPassword },
    { icon: 'server', header: 'TestInstance ID', cell: props.job.testInstanceID },
    { icon: 'server', header: 'Post Run Action', cell: props.job.postRunAction },
    { icon: 'server', header: 'Add Run to Trend Report', cell: props.job.addRunToTrendReport },
    { icon: 'server', header: 'Trend Report ID', cell: props.job.trendReportId },
    { icon: 'server', header: 'Proxy Out URL', cell: props.job.proxyOutURL },
    { icon: 'server', header: 'Proxy Username', cell: props.job.proxyUsername },
    { icon: 'server', header: 'Proxy Password', cell: props.job.proxyPassword },  
    { icon: 'align right', header: 'Retry', cell: props.job.retry? "Retry" : "NO_RETRY" },   
    { icon: 'server', header: 'Retry Delay', cell: props.job.retryDelay },
    { icon: 'server', header: 'Retry Occurrences', cell: props.job.retryOccurrences },
    { icon: 'align right', header: 'Https Protocol', cell: props.job.httpsProtocol? "true" : "false" },
    { icon: 'align right', header: 'VUDs Mode', cell: props.job.vudsMode? "true" : "false" },
    { icon: 'align right', header: 'Status By SLA', cell: props.job.statusBySLA? "true" : "false" },
    { icon: 'align right', header: 'Baseline', cell: props.job.baseline? "true" : "false" },
    { icon: 'align right', header: 'autoTestInstance', cell: props.job.autoTestInstance? "MANUAL" : "AUTO" },   
  ];

  const summaryTable = summaryTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  )
  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> PC Job Details</small>
        </CardHeader>
        <CardBody>
          <Table compact celled >
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {summaryTable}
            </Table.Body>
          </Table>
        </CardBody>
        <CardFooter>
          <Button.Group size="mini">
            <Button animated onClick={props.editJobHandler} size="mini" primary>
              <Button.Content visible>Edit</Button.Content>
              <Button.Content hidden>
                <Icon name='edit' />
              </Button.Content>
            </Button>
            <Button.Or />
            <Popconfirm placement="topLeft" title="Are you sure delete this job?"
              onConfirm={() => deleteJobConfirm()} okText="Yes" cancelText="No">
              <Button animated color="red">
                <Button.Content visible>Delete</Button.Content>
                <Button.Content hidden>
                  <Icon name='trash' />
                </Button.Content>
              </Button>
            </Popconfirm>
          </Button.Group>
        </CardFooter>
      </Card>
    </Col>
  )
}
export default viewPCJob;
