import React, { Component } from "react";
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Label,
} from "reactstrap";
import {
  Button,
  Icon,
  Checkbox,
  Dropdown,
  Message,
  List,
  Select,
  Input,
  Form,
  Grid,
} from "semantic-ui-react";
import { Popconfirm, Tooltip } from "antd";
import ReactTags from "react-tag-autocomplete";
import {
  errorMsg,
  successMsg,
  warningMsg,
} from "../../../../UI/Message/Message";
import FormInput from "../../../../UI/FormInput/FormInput";

const options = [
  { key: "windows", text: "Windows", value: "windows", icon: "windows" },
  { key: "linux", text: "Linux", value: "linux", icon: "linux" },
];

const options1 = [
  { key: "collateResults", text: "Collate Results", value: "COLLATE" },
  {
    key: "collateAndAnalyze",
    text: "Collate And Analyze",
    value: "COLLATE_AND_ANALYZE",
  },
  { key: "DoNotCollate", text: "Do Not Collate", value: "DO_NOTHING" },
];

const options2 = [
  { key: "noTrend", text: "Do Not Trend", value: "NO_TREND" },
  {
    key: "trendWithTest",
    text: "Use Trend Report Associated with Test",
    value: "ASSOCIATED",
  },
  {
    key: "trendWithID",
    text: "Add run to trend report with ID",
    value: "USE_ID",
  },
];

class PCJobDetails extends Component {
  state = {
    jobDetails: {
      name: "",
      description: "",
      email: "",
      release: "",
      successTrigger: true,
      failureTrigger: true,
      beforebuildTrigger: false,
      enableSlave: false,
      slave: "",
      servers: [],
      durationHours: 0,
      durationMinutes: 30,
      statusBySLA: false,
      pcServerName: "",
      pcUsername: "",
      pcPassword: "",
      almDomain: "",
      almProject: "",
      testID: "",
      testInstanceID: 0,
      postRunAction: "",
      vudsMode: "",
      addRunToTrendReport: "",
      trendReportId: 0,
      httpsProtocol: false,
      proxyOutURL: "",
      proxyUsername: "",
      proxyPassword: "",
      retryDelay: "",
      retryOccurrences: "",
      baseline: false,
      autoTestInstance: false,
      retry: false,
      jobType: "PC",
    },
    // tags: [
    //   { name: "localhost" },
    // ],
    isFormValid: false,
    tempServer: {
      name: "",
      os: "windows",
    },
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    if (prevState.jobDetails.name !== nextProps.jobDetails.name) {
      return {
        ...prevState,
        jobDetails: {
          ...nextProps.jobDetails,
        },
      };
    }
    return null;
  }

  updateJobConfirm = (e) => {
    // successMsg("Job Updated Successfully");
    this.props.updateJob(this.state.jobDetails);
  };

  isFormValid = () => {
    console.log(
      this.state.jobDetails.enableDistributedT
        ? this.state.jobDetails.remoteHosts
          ? true
          : false
        : true
    );
    if (
      this.state.jobDetails.name &&
      this.state.jobDetails.servers.length > 0 &&
      this.state.jobDetails.email &&
      (this.state.jobDetails.enableSlave
        ? this.state.jobDetails.slave
          ? true
          : false
        : true) &&
      this.state.jobDetails.pcServerName &&
      this.state.jobDetails.almDomain &&
      this.state.jobDetails.almProject
    ) {
      this.setState(
        {
          ...this.state,
          isFormValid: true,
        },
        () => {
          console.log("valid form!");
        }
      );
    } else {
      this.setState(
        {
          ...this.state,
          isFormValid: false,
        },
        () => {
          console.log("invalid form!");
        }
      );
    }
  };

  formChangeHandler = (event) => {
    console.log("formChangeHandler");
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.value,
        },
      },
      () => this.isFormValid()
    );
  };

  toggleCheckbox = (event) => {
    console.log("inside toggle checkbox");
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };
  toggleCheckboxInst = (event) => {
    console.log("inside toggle checkbox inst");
    const target = event.target;
    console.log(target);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };
  dropdownChangeHandler = (event, data) => {
    console.log(data.value);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [data.id]: data.value,
        },
      },
      () => this.isFormValid()
    );
  };

  addServersHandler = (event, data) => {
    console.log(data);
    const server = {
      name: this.state.tempServer.name,
      os: this.state.tempServer.os,
    };
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: [].concat(this.state.jobDetails.servers, server),
        },
        tempServer: {
          name: "",
          os: "windows",
        },
      },
      () => this.isFormValid()
    );
  };

  removeServerHandler = (index) => {
    const servers = this.state.jobDetails.servers.slice(0);
    servers.splice(index, 1);
    console.log(servers);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: servers,
        },
      },
      () => this.isFormValid()
    );
  };

  handleServerChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        name: data.value,
      },
    });
  };

  handleOsChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        os: data.value,
      },
    });
  };

  handlePostRunActionChange = (event, data) => {
    console.log("postrunaction" + data.value);
    this.setState({
      ...this.state,
      jobDetails: {
        ...this.state.jobDetails,
        postRunAction: data.value,
      },
    });
  };
  handleTrendReportId = (event, data) => {
    console.log("trendreportid " + data.value);
    this.setState({
      ...this.state,
      jobDetails: {
        ...this.state.jobDetails,
        addRunToTrendReport: data.value,
      },
    });
  };

  handleRemoteHostsDelete = (i) => {
    console.log(this.state);
    const tags = this.state.tags.slice(0);
    tags.splice(i, 1);
    this.setState(
      {
        ...this.state,
        tags: tags.filter((tag, index) => index !== i),
      },
      () => {
        let hosts = [];
        this.state.tags.map((host) => hosts.push(host.name));
        this.setState({
          ...this.state,
          jobDetails: {
            ...this.state.jobDetails,
            remoteHosts: hosts,
          },
        });
      }
    );
  };

  handleRemoteHostsAddition = (tag) => {
    const tags = [].concat(this.state.tags, tag);
    const hosts = this.state.jobDetails.remoteHosts;
    hosts.push(tag.name);
    this.setState({
      ...this.state,
      jobDetails: {
        ...this.state.jobDetails,
        remoteHosts: hosts,
      },
      tags: tags,
    });
  };

  downloadSlaveAgent = () => {
    axios
      .get("downloadSlaveAgent")
      .then((response) => {
        console.log(response.data);
        fileDownload(response.data, "slave-agent-" + props.job.slave + ".jnlp");
      })
      .catch((error) => console.log(error.message));
  };

  render() {
    console.log(this.state.jobDetails);

    const infoboxDT = (
      <Message
        info
        icon="info"
        header={"Please note.."}
        content={
          <p>
            Add all remote hosts in your{" "}
            <Tooltip title="prompt text">
              <span>
                <b>jmeter.properties</b>
              </span>
            </Tooltip>{" "}
            file
          </p>
        }
      />
    );

    const infoboxSlaveAgent = (
      <Message warning>
        <Row>
          <Col md="1">
            <Button
              icon="download"
              color="orange"
              onClick={this.downloadSlaveAgent}
            />
          </Col>
          <Col md="10">
            <Message.Header>Slave-Agent</Message.Header>
            <p>Download slave-agent and run on slave machine..</p>
          </Col>
        </Row>
      </Message>
    );

    const inputFields = {
      name: {
        label: "Name",
        id: "name",
        type: "text",
        value: this.state.jobDetails.name,
        placeholder: "JOB-XYZ",
      },
      release: {
        label: "Release",
        id: "release",
        type: "text",
        value: this.state.jobDetails.release,
        placeholder: "Release-1",
      },
      email: {
        label: "Email Recipient",
        id: "email",
        type: "email",
        value: this.state.jobDetails.email,
        placeholder: "example@example.com",
      },
      pcServerName: {
        label: "PC Server name",
        id: "pcServerName",
        type: "text",
        value: this.state.jobDetails.pcServerName,
        placeholder: "Performance Center Server Name",
      },
      almDomain: {
        label: "Domain",
        id: "almDomain",
        type: "text",
        value: this.state.jobDetails.almDomain,
        placeholder: "Domain Name",
      },
      almProject: {
        label: "Project",
        id: "almProject",
        type: "text",
        value: this.state.jobDetails.almProject,
        placeholder: "Project Name",
      },
      testID: {
        label: "Test ID",
        id: "testID",
        type: "text",
        value: this.state.jobDetails.testID,
        placeholder: "Test ID",
      },
      durationHours: {
        label: "Duration (in hours)",
        id: "durationHours",
        type: "text",
        value: this.state.jobDetails.durationHours,
        placeholder: "Duration (in hours)",
      },
      durationMinutes: {
        label: "Duration (in minutes)",
        id: "durationMinutes",
        type: "text",
        value: this.state.jobDetails.durationMinutes,
        placeholder: "Duration (in minutes)",
      },
      pcUsername: {
        label: "Performance Center Username ",
        id: "pcUsername",
        type: "text",
        value: this.state.jobDetails.pcUsername,
        placeholder: "Username",
      },
      pcPassword: {
        label: "Performance Center password ",
        id: "pcPassword",
        type: "text",
        value: this.state.jobDetails.pcPassword,
        placeholder: "password",
      },
      testInstanceID: {
        label: "TestInstance Id ",
        id: "testInstanceID",
        type: "text",
        value: this.state.jobDetails.testInstanceID,
        placeholder: "testInstance ID",
      },
      trendReportId: {
        label: "Trend Report Id ",
        id: "trendReportId",
        type: "text",
        value: this.state.jobDetails.testInstanceID,
        placeholder: "trendReportId",
      },
      proxyOutURL: {
        label: "Local Proxy ",
        id: "proxyOutURL",
        type: "text",
        value: this.state.jobDetails.proxyOutURL,
        placeholder: "proxyOutURL",
      },
      proxyUsername: {
        label: "Proxy Username ",
        id: "proxyUsername",
        type: "text",
        value: this.state.jobDetails.proxyUsername,
        placeholder: "Username",
      },
      proxyPassword: {
        label: "Proxy password ",
        id: "proxyPassword",
        type: "text",
        value: this.state.jobDetails.proxyPassword,
        placeholder: "password",
      },
      retryDelay: {
        label: "Retry Delay ",
        id: "retryDelay",
        type: "text",
        value: this.state.jobDetails.retryDelay,
        placeholder: "retryDelay",
      },
      retryOccurrences: {
        label: "Retry Occurrences ",
        id: "retryOccurrences",
        type: "text",
        value: this.state.jobDetails.retryOccurrences,
        placeholder: "retryOccurrences",
      },
    };

    const getInput = (input) => (
      <Form.Input
        fluid
        type={input.type}
        id={input.id}
        value={this.state.jobDetails[input.id]}
        onChange={this.formChangeHandler}
        label={input.label}
        placeholder={input.placeholder}
        disabled={input.id === "name"}
      />
    );

    const getInputReq = (input) => (
      <Form.Input
        fluid
        required
        type={input.type}
        id={input.id}
        value={this.state.jobDetails[input.id]}
        onChange={this.formChangeHandler}
        label={input.label}
        placeholder={input.placeholder}
        disabled={input.id === "name"}
      />
    );

    const checkboxFields = [
      { id: "successTrigger", label: "Success" },
      { id: "failureTrigger", label: "Failure" },
      { id: "beforebuildTrigger", label: "Before Build" },
      { id: "enableSlave", label: "Run this Job in slave?" },
      { id: "httpsProtocol", label: "HTTPS Protocol" },
      { id: "vudsMode", label: "use VUD's" },
      { id: "statusBySLA", label: "Set Step Status according to SLA" },
      { id: "baseline", label: "baseline", type: "checkbox" },
      { id: "autoTestInstance", label: "Manual Selection" },
      { id: "retry", label: "Retry", type: "checkbox" },
    ];

    const getCheckbox = (checkbox) => (
      <Form.Checkbox
        id={checkbox.id}
        label={checkbox.label}
        name={checkbox.id}
        onChange={this.toggleCheckbox}
        // cond1={checkbox.id === "autoTestInstance" && this.state.jobDetails[9] === "true" ? TRUE : FALSE}

        checked={this.state.jobDetails[checkbox.id]}
        toggle={
          checkbox.id === "enableSlave" ||
          checkbox.id === "baseline" ||
          checkbox.id === "retry"
        }
      />
    );

    return (
      <Col md="12">
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create PC Job</small>
          </CardHeader>
          <CardBody>
            <Form size="small">
              <Grid padded="horizontally" columns={3}>
                <Grid.Row stretched>
                  <Grid.Column verticalAlign="top">
                    {getInputReq(inputFields.name)}
                    {getInputReq(inputFields.pcServerName)}
                    {getInputReq(inputFields.almDomain)}
                    {getInputReq(inputFields.almProject)}
                    {getInputReq(inputFields.testID)}
                    {getInputReq(inputFields.pcUsername)}
                    {getInputReq(inputFields.pcPassword)}
                    <Form.Field>
                      <Label>Post Run Action</Label>
                       
                      <Dropdown
                        fluid
                        search
                        selection
                        placeholder="Select a post run action"
                        options={options1}
                        onChange={this.handlePostRunActionChange}
                        value={this.state.jobDetails.postRunAction}
                      />
                    </Form.Field>
                    {this.state.jobDetails.postRunAction ===
                    "COLLATE_AND_ANALYZE" ? (
                      <Form.Field>
                        <Form.Field>
                          <Label>Add run to trend report</Label>
                           
                          <Dropdown
                            fluid
                            search
                            selection
                            placeholder="Add run to trend report Id"
                            options={options2}
                            onChange={this.handleTrendReportId}
                            value={this.state.jobDetails.addRunToTrendReport}
                          />
                        </Form.Field>
                        {this.state.jobDetails.addRunToTrendReport === "USE_ID"
                          ? getInputReq(inputFields.trendReportId)
                          : null}
                      </Form.Field>
                    ) : null}
                  </Grid.Column>
                  <Grid.Column verticalAlign="top">
                    {getInputReq(inputFields.release)}
                    {getInputReq(inputFields.durationHours)}
                    {getInputReq(inputFields.durationMinutes)}
                    {getInput(inputFields.proxyOutURL)}
                    {getInput(inputFields.proxyUsername)}
                    {getInput(inputFields.proxyPassword)}
                    {getInputReq(inputFields.email)}
                    <Form.Field>
                      <Label>Email Triggers</Label>
                      <Form.Group inline>
                        {getCheckbox(checkboxFields[0])}
                        {getCheckbox(checkboxFields[1])}
                        {getCheckbox(checkboxFields[2])}
                      </Form.Group>
                    </Form.Field>
                  </Grid.Column>
                  <Grid.Column verticalAlign="top">
                    <Form.TextArea
                      label="Description (Optional)"
                      id="description"
                      rows={4}
                      placeholder="Description about this job.."
                      value={this.state.jobDetails.description}
                      onChange={this.formChangeHandler}
                    />

                    <Form.Field>
                      <br />
                      <Row>
                        <Col md="5">{getCheckbox(checkboxFields[3])}</Col>
                        <Col md="7">
                          {this.state.jobDetails.enableSlave ? (
                            <Dropdown
                              fluid
                              search
                              selection
                              id="slave"
                              placeholder="Select a slave"
                              options={this.props.nodeList}
                              onChange={this.dropdownChangeHandler}
                              value={this.state.jobDetails.slave}
                            />
                          ) : null}
                        </Col>
                      </Row>
                    </Form.Field>
                    {getCheckbox(checkboxFields[9])}
                    {this.state.jobDetails.retry ? (
                      <Form.Field>
                        {getInputReq(inputFields.retryDelay)}
                        {getInputReq(inputFields.retryOccurrences)}
                      </Form.Field>
                    ) : null}
                    {getCheckbox(checkboxFields[7])}
                    {getCheckbox(checkboxFields[6])}
                    {getCheckbox(checkboxFields[5])}
                    {getCheckbox(checkboxFields[4])}
                    {getCheckbox(checkboxFields[8])}

                    {this.state.jobDetails.autoTestInstance
                      ? getInputReq(inputFields.testInstanceID)
                      : null}
                  </Grid.Column>
                </Grid.Row>
              </Grid>
            </Form>
            <Grid padded="horizontally" columns={2}>
              <Grid.Row>
                <Grid.Column>
                  <Form>
                    <Form.Input
                      required
                      type="text"
                      placeholder="Server"
                      action
                      label="Add Servers to monitor"
                      fluid
                      value={this.state.tempServer.name}
                      onChange={this.handleServerChange}
                    >
                      <input />
                      <Select
                        options={options}
                        simple
                        item
                        value={this.state.tempServer.os}
                        onChange={this.handleOsChange}
                      />
                      <Button
                        type="submit"
                        onClick={this.addServersHandler}
                        disabled={!this.state.tempServer.name}
                      >
                        Add
                      </Button>
                    </Form.Input>
                  </Form>
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <br />
            <Row>
              <List horizontal style={{ marginLeft: "10px" }}>
                {this.state.jobDetails.servers.map((server, index) => (
                  <List.Item
                    key={index}
                    style={{
                      backgroundColor: "#c2cfd6",
                      borderRadius: "50px",
                      marginTop: "10px",
                    }}
                  >
                    <List.Content
                      floated="right"
                      style={{ marginRight: "5px" }}
                    >
                      <Button
                        size="mini"
                        circular
                        icon="delete"
                        onClick={() => this.removeServerHandler(index)}
                      />
                    </List.Content>
                    <Icon name={server.os} style={{ marginLeft: "10px" }} />
                    <List.Content size="small" verticalAlign="middle">
                      {server.name}
                    </List.Content>
                  </List.Item>
                ))}
              </List>
            </Row>
          </CardBody>

          <CardFooter>
            <Button.Group size="mini">
              <Popconfirm
                placement="topLeft"
                title="Are you sure update this job?"
                onConfirm={this.updateJobConfirm}
                onCancel={() => errorMsg("No..")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  animated
                  color="green"
                  disabled={!this.state.isFormValid}
                >
                  <Button.Content visible>Submit</Button.Content>
                  <Button.Content hidden>
                    <Icon name="check circle" />
                  </Button.Content>
                </Button>
              </Popconfirm>
              <Button.Or />
              <Button
                animated
                onClick={() => this.props.discardChangesHandler()}
                secondary
              >
                <Button.Content visible>Discard</Button.Content>
                <Button.Content hidden>
                  <Icon name="remove circle" />
                </Button.Content>
              </Button>
            </Button.Group>
          </CardFooter>
        </Card>

        {this.state.jobDetails.enableSlave && this.state.jobDetails.slave
          ? infoboxSlaveAgent
          : null}
      </Col>
    );
  }
}
export default PCJobDetails;
