import React, { Component } from "react";
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Label,
} from "reactstrap";
import {
  Button,
  Icon,
  Checkbox,
  Dropdown,
  Message,
  List,
  Select,
  Input,
  Form,
  Grid,
} from "semantic-ui-react";
import { Popconfirm, Tooltip } from "antd";
import ReactTags from "react-tag-autocomplete";
import {
  errorMsg,
  successMsg,
  warningMsg,
} from "../../../../UI/Message/Message";
import FormInput from "../../../../UI/FormInput/FormInput";

const options = [
  { key: "windows", text: "Windows", value: "windows", icon: "windows" },
  { key: "linux", text: "Linux", value: "linux", icon: "linux" },
];

class LRJobDetails extends Component {
  state = {
    jobDetails: {
      name: "",
      description: "",
      email: "",
      release: "",
      successTrigger: true,
      failureTrigger: true,
      beforebuildTrigger: false,
      enableSlave: false,
      slave: "",
      servers: [],
      testScriptsPath: [],
      resDir: "",
      pollInterval: 10,
      errorstoIgnore: [],
      analysisTemplate: "",
      scenarioTimeout: 10,
      baseline: false,
      jobType: "LR",
    },
    // tags: [
    //   { name: "localhost" },
    // ],
    isFormValid: false,
    tempLoc: "",
    tempError: "",
    tempServer: {
      name: "",
      os: "windows",
    },
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    if (prevState.jobDetails.name !== nextProps.jobDetails.name) {
      return {
        ...prevState,
        jobDetails: {
          ...nextProps.jobDetails,
        },
      };
    }
    return null;
  }

  updateJobConfirm = (e) => {
    // successMsg("Job Updated Successfully");
    this.props.updateJob(this.state.jobDetails);
  };

  isFormValid = () => {
    console.log(
      this.state.jobDetails.enableDistributedT
        ? this.state.jobDetails.remoteHosts
          ? true
          : false
        : true
    );
    if (
      this.state.jobDetails.name &&
      this.state.jobDetails.email &&
      (this.state.jobDetails.enableSlave
        ? this.state.jobDetails.slave
          ? true
          : false
        : true) &&
      this.state.jobDetails.testScriptsPath.length > 0
    ) {
      this.setState(
        {
          ...this.state,
          isFormValid: true,
        },
        () => {
          console.log("valid form!");
        }
      );
    } else {
      this.setState(
        {
          ...this.state,
          isFormValid: false,
        },
        () => {
          console.log("invalid form!");
        }
      );
    }
  };

  formChangeHandler = (event) => {
    console.log("formChangeHandler");
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.value,
        },
      },
      () => this.isFormValid()
    );
  };

  toggleCheckbox = (event) => {
    console.log("inside toggle checkbox");
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };
  toggleCheckboxInst = (event) => {
    console.log("inside toggle checkbox inst");
    const target = event.target;
    console.log(target);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };
  dropdownChangeHandler = (event, data) => {
    console.log(data.value);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [data.id]: data.value,
        },
      },
      () => this.isFormValid()
    );
  };

  addServersHandler = (event, data) => {
    console.log(data);
    const server = {
      name: this.state.tempServer.name,
      os: this.state.tempServer.os,
    };
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: [].concat(this.state.jobDetails.servers, server),
        },
        tempServer: {
          name: "",
          os: "windows",
        },
      },
      () => this.isFormValid()
    );
  };

  removeServerHandler = (index) => {
    const servers = this.state.jobDetails.servers.slice(0);
    servers.splice(index, 1);
    console.log(servers);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: servers,
        },
      },
      () => this.isFormValid()
    );
  };

  handleServerChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        name: data.value,
      },
    });
  };

  handleOsChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        os: data.value,
      },
    });
  };

  addScriptsPathHandler = (event, data) => {
    console.log(this.state.tempLoc);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          testScriptsPath: [].concat(
            this.state.jobDetails.testScriptsPath,
            this.state.tempLoc
          ),
        },
        tempLoc: "",
      },
      () => this.isFormValid()
    );
  };
  addErrorsHandler = (event, data) => {
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          errorstoIgnore: [].concat(
            this.state.jobDetails.errorstoIgnore,
            this.state.tempError
          ),
        },
        tempError: "",
      },
      () => this.isFormValid()
    );
  };
  removeTestScriptsPath = (index) => {
    const testScriptsPath = this.state.jobDetails.testScriptsPath.slice(0);
    testScriptsPath.splice(index, 1);
    console.log(testScriptsPath);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          testScriptsPath: testScriptsPath,
        },
      },
      () => this.isFormValid()
    );
  };
  removeErrorsHandler = (index) => {
    const errorstoIgnore = this.state.jobDetails.errorstoIgnore.slice(0);
    errorstoIgnore.splice(index, 1);
    console.log(errorstoIgnore);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          errorstoIgnore: errorstoIgnore,
        },
      },
      () => this.isFormValid()
    );
  };

  handleRemoteHostsDelete = (i) => {
    console.log(this.state);
    const tags = this.state.tags.slice(0);
    tags.splice(i, 1);
    this.setState(
      {
        ...this.state,
        tags: tags.filter((tag, index) => index !== i),
      },
      () => {
        let hosts = [];
        this.state.tags.map((host) => hosts.push(host.name));
        this.setState({
          ...this.state,
          jobDetails: {
            ...this.state.jobDetails,
            remoteHosts: hosts,
          },
        });
      }
    );
  };

  handleRemoteHostsAddition = (tag) => {
    const tags = [].concat(this.state.tags, tag);
    const hosts = this.state.jobDetails.remoteHosts;
    hosts.push(tag.name);
    this.setState({
      ...this.state,
      jobDetails: {
        ...this.state.jobDetails,
        remoteHosts: hosts,
      },
      tags: tags,
    });
  };

  handlePathChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempLoc: data.value,
    });
  };

  handleErrorChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempError: data.value,
    });
  };

  downloadSlaveAgent = () => {
    axios
      .get("downloadSlaveAgent")
      .then((response) => {
        console.log(response.data);
        fileDownload(response.data, "slave-agent-" + props.job.slave + ".jnlp");
      })
      .catch((error) => console.log(error.message));
  };

  render() {
    console.log(this.state.jobDetails);

    const infoboxDT = (
      <Message
        info
        icon="info"
        header={"Please note.."}
        content={
          <p>
            Add all remote hosts in your{" "}
            <Tooltip title="prompt text">
              <span>
                <b>jmeter.properties</b>
              </span>
            </Tooltip>{" "}
            file
          </p>
        }
      />
    );

    const infoboxSlaveAgent = (
      <Message warning>
        <Row>
          <Col md="1">
            <Button
              icon="download"
              color="orange"
              onClick={this.downloadSlaveAgent}
            />
          </Col>
          <Col md="10">
            <Message.Header>Slave-Agent</Message.Header>
            <p>Download slave-agent and run on slave machine..</p>
          </Col>
        </Row>
      </Message>
    );

    const inputFields = {
      name: {
        label: "Name",
        id: "name",
        type: "text",
        value: this.state.jobDetails.name,
        placeholder: "JOB-XYZ",
      },
      release: {
        label: "Release",
        id: "release",
        type: "text",
        placeholder: "Release-1",
      },
      email: {
        label: "Email Recipient",
        id: "email",
        type: "email",
        placeholder: "example@example.com",
      },
      testScriptsPath: {
        label: "Scripts Path",
        id: "testScriptsPath",
        type: "text",
        placeholder: "Script path",
      },
      resDir: {
        label: "Results Directory",
        id: "resDir",
        type: "text",
        placeholder: "C:\\results",
      },
      pollInterval: {
        label: "Controller Polling Interval(sec)",
        id: "pollInterval",
        type: "text",
        placeholder: "Controller Polling Interval",
      },
      errorstoIgnore: {
        label: "Errors to Ignore",
        id: "errorstoIgnore",
        type: "text",
        placeholder: "Errors to Ignore",
      },
      analysisTemplate: {
        label: "Path to Anaylsis Template",
        id: "analysisTemplate",
        type: "text",
        placeholder: "Path to Anaylsis Template",
      },
      scenarioTimeout: {
        label: "Scenario Excution Timeout(min)",
        id: "scenarioTimeout",
        type: "text",
        placeholder: "Scenario Excution Timeout",
      },
    };

    const getInput = (input) => (
      <Form.Input
        fluid
        type={input.type}
        id={input.id}
        value={this.state.jobDetails[input.id]}
        onChange={this.formChangeHandler}
        label={input.label}
        placeholder={input.placeholder}
        disabled={input.id === "name"}
      />
    );

    const getInputReq = (input) => (
      <Form.Input
        fluid
        required
        type={input.type}
        id={input.id}
        value={this.state.jobDetails[input.id]}
        onChange={this.formChangeHandler}
        label={input.label}
        placeholder={input.placeholder}
        disabled={input.id === "name" || input.id === "resDir"}
      />
    );

    const checkboxFields = [
      { id: "successTrigger", label: "Success" },
      { id: "failureTrigger", label: "Failure" },
      { id: "beforebuildTrigger", label: "Before Build" },
      { id: "enableSlave", label: "Run this Job in slave?" },
      { id: "baseline", label: "baseline", type: "checkbox" },
    ];

    const getCheckbox = (checkbox) => (
      <Form.Checkbox
        id={checkbox.id}
        label={checkbox.label}
        name={checkbox.id}
        onChange={this.toggleCheckbox}
        checked={this.state.jobDetails[checkbox.id]}
        toggle={checkbox.id === "enableSlave" || checkbox.id === "baseline"}
      />
    );

    return (
      <Col md="12">
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create LR Job</small>
          </CardHeader>
          <CardBody>
            <Form size="small">
              <Grid padded="horizontally" columns={3}>
                <Grid.Row stretched>
                  <Grid.Column verticalAlign="top">
                    {getInputReq(inputFields.name)}
                    <Form>
                      <Form.Input
                        required
                        type="text"
                        placeholder="path"
                        action
                        label="Add Scripts Path for the Scenario"
                        fluid
                        value={this.state.tempLoc}
                        onChange={this.handlePathChange}
                      >
                        <input />

                        <Button
                          type="submit"
                          onClick={this.addScriptsPathHandler}
                          disabled={!this.state.tempLoc}
                        >
                          Add
                        </Button>
                      </Form.Input>
                    </Form>
                    <Row>
                      <List horizontal style={{ marginLeft: "10px" }}>
                        {this.state.jobDetails.testScriptsPath.map(
                          (server, index) => (
                            <List.Item
                              key={index}
                              style={{
                                backgroundColor: "#c2cfd6",
                                borderRadius: "50px",
                                marginTop: "10px",
                              }}
                            >
                              <List.Content
                                floated="right"
                                style={{ marginRight: "5px" }}
                              >
                                <Button
                                  size="mini"
                                  circular
                                  icon="delete"
                                  onClick={() =>
                                    this.removeTestScriptsPath(index)
                                  }
                                />
                              </List.Content>
                              <Icon style={{ marginLeft: "10px" }} />
                              <List.Content size="small" verticalAlign="middle">
                                {server}
                              </List.Content>
                            </List.Item>
                          )
                        )}
                      </List>
                    </Row>
                    {getInputReq(inputFields.resDir)}
                    {getInput(inputFields.pollInterval)}
                    {getInputReq(inputFields.email)}
                  </Grid.Column>
                  <Grid.Column verticalAlign="top">
                    {getInputReq(inputFields.release)}
                    <Form>
                      <Form.Input
                        type="text"
                        placeholder="error"
                        action
                        label="Add Errors to Ignore"
                        fluid
                        value={this.state.tempError}
                        onChange={this.handleErrorChange}
                      >
                        <input />

                        <Button
                          type="submit"
                          onClick={this.addErrorsHandler}
                          disabled={!this.state.tempError}
                        >
                          Add
                        </Button>
                      </Form.Input>
                    </Form>
                    <Row>
                      <List horizontal style={{ marginLeft: "10px" }}>
                        {this.state.jobDetails.errorstoIgnore.map(
                          (server, index) => (
                            <List.Item
                              key={index}
                              style={{
                                backgroundColor: "#c2cfd6",
                                borderRadius: "50px",
                                marginTop: "10px",
                              }}
                            >
                              <List.Content
                                floated="right"
                                style={{ marginRight: "1px" }}
                              >
                                <Button
                                  size="mini"
                                  circular
                                  icon="delete"
                                  onClick={() =>
                                    this.removeErrorsHandler(index)
                                  }
                                />
                              </List.Content>
                              <Icon style={{ marginLeft: "10px" }} />
                              <List.Content size="small" verticalAlign="middle">
                                {server}
                              </List.Content>
                            </List.Item>
                          )
                        )}
                      </List>
                    </Row>

                    {getInput(inputFields.analysisTemplate)}

                    {getInput(inputFields.scenarioTimeout)}

                    <Form.Field>
                      <Label>Email Triggers</Label>
                      <Form.Group inline>
                        {getCheckbox(checkboxFields[0])}
                        {getCheckbox(checkboxFields[1])}
                        {getCheckbox(checkboxFields[2])}
                      </Form.Group>
                    </Form.Field>
                  </Grid.Column>
                  <Grid.Column verticalAlign="top">
                    <Form.TextArea
                      label="Description (Optional)"
                      id="description"
                      rows={4}
                      placeholder="Description about this job.."
                      value={this.state.jobDetails.description}
                      onChange={this.formChangeHandler}
                    />

                    <Form.Field>
                      <br />
                      <Row>
                        <Col md="5">{getCheckbox(checkboxFields[3])}</Col>
                        <Col md="7">
                          {this.state.jobDetails.enableSlave ? (
                            <Dropdown
                              fluid
                              search
                              selection
                              id="slave"
                              placeholder="Select a slave"
                              options={this.props.nodeList}
                              onChange={this.dropdownChangeHandler}
                              value={this.state.jobDetails.slave}
                            />
                          ) : null}
                        </Col>
                      </Row>
                    </Form.Field>
                  </Grid.Column>
                </Grid.Row>
              </Grid>
            </Form>
            <Grid padded="horizontally" columns={2}>
              <Grid.Row>
                <Grid.Column>
                  <Form>
                    <Form.Input
                      required
                      type="text"
                      placeholder="Server"
                      action
                      label="Add Servers to monitor"
                      fluid
                      value={this.state.tempServer.name}
                      onChange={this.handleServerChange}
                    >
                      <input />
                      <Select
                        options={options}
                        simple
                        item
                        value={this.state.tempServer.os}
                        onChange={this.handleOsChange}
                      />
                      <Button
                        type="submit"
                        onClick={this.addServersHandler}
                        disabled={!this.state.tempServer.name}
                      >
                        Add
                      </Button>
                    </Form.Input>
                  </Form>
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <br />
            <Row>
              <List horizontal style={{ marginLeft: "10px" }}>
                {this.state.jobDetails.servers.map((server, index) => (
                  <List.Item
                    key={index}
                    style={{
                      backgroundColor: "#c2cfd6",
                      borderRadius: "50px",
                      marginTop: "10px",
                    }}
                  >
                    <List.Content
                      floated="right"
                      style={{ marginRight: "5px" }}
                    >
                      <Button
                        size="mini"
                        circular
                        icon="delete"
                        onClick={() => this.removeServerHandler(index)}
                      />
                    </List.Content>
                    <Icon name={server.os} style={{ marginLeft: "10px" }} />
                    <List.Content size="small" verticalAlign="middle">
                      {server.name}
                    </List.Content>
                  </List.Item>
                ))}
              </List>
            </Row>
          </CardBody>

          <CardFooter>
            <Button.Group size="mini">
              <Popconfirm
                placement="topLeft"
                title="Are you sure update this job?"
                onConfirm={this.updateJobConfirm}
                onCancel={() => errorMsg("No..")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  animated
                  color="green"
                  disabled={!this.state.isFormValid}
                >
                  <Button.Content visible>Submit</Button.Content>
                  <Button.Content hidden>
                    <Icon name="check circle" />
                  </Button.Content>
                </Button>
              </Popconfirm>
              <Button.Or />
              <Button
                animated
                onClick={() => this.props.discardChangesHandler()}
                secondary
              >
                <Button.Content visible>Discard</Button.Content>
                <Button.Content hidden>
                  <Icon name="remove circle" />
                </Button.Content>
              </Button>
            </Button.Group>
          </CardFooter>
        </Card>

        {this.state.jobDetails.enableSlave && this.state.jobDetails.slave
          ? infoboxSlaveAgent
          : null}
      </Col>
    );
  }
}
export default LRJobDetails;
