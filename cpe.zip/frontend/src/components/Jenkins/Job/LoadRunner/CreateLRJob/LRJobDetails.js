import React, { Component } from "react";
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  FormGroup,
  FormText,
  Label,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  FormFeedback,
} from "reactstrap";
import Spinner from "../../../../Spinner/Spinner";
import {
  Button,
  Icon,
  Checkbox,
  Dropdown,
  Message,
  Select,
  Input,
  Form,
  List,
  Grid,
  Popup,
} from "semantic-ui-react";
import axios from "../../../../../axios";
import fileDownload from "js-file-download";
import ReactTags from "react-tag-autocomplete";
import { Tooltip } from "antd";
import Iframe from "react-iframe";

const handleFiles = (files) => {
  console.log(files);
};

const LRJobDetails = (props) => {
  console.log("component-JobDetails");
  console.log("env variables");
  console.log(process.env.JMETER_HOME);
  const downloadSlaveAgent = () => {
    axios
      .get("downloadSlaveAgent", {
        params: { slaveName: props.job.slave },
      })
      .then((response) => {
        console.log(response.data);
        fileDownload(response.data, "slave-agent-" + props.job.slave + ".jnlp");
      })
      .catch((error) => console.log(error.message));
  };

  const options = [
    { key: "windows", text: "Windows", value: "windows", icon: "windows" },
    { key: "linux", text: "Linux", value: "linux", icon: "linux" },
  ];

  const infoboxSlaveAgent = (
    <Message warning>
      <Row>
        <Col md="1">
          <Button icon="download" color="orange" onClick={downloadSlaveAgent} />
        </Col>
        <Col md="10">
          <Message.Header>Slave-Agent</Message.Header>
          <p>Download slave-agent and run on slave machine..</p>
        </Col>
      </Row>
    </Message>
  );

  const emailTriggers = [
    { name: "successTrigger", text: "Success" },
    { name: "failureTrigger", text: "Failure" },
    { name: "beforebuildTrigger", text: "Beforebuild" },
  ];

  const emailTriggerCheckbox = emailTriggers.map((trigger, i) => (
    <FormGroup check className="checkbox" key={i}>
      <Input
        className="form-check-input"
        type="checkbox"
        id={trigger.name}
        name={trigger.name}
        value={props.job.successTrigger}
        onChange={props.toggleCheckbox}
        checked={props.job[trigger.name]}
      />
      <Label className="form-check-label" check htmlFor={trigger.name}>
        {trigger.text}
      </Label>
    </FormGroup>
  ));

  const inputFields = {
    name: {
      label: "Name",
      id: "name",
      type: "text",
      value: props.job.name,
      placeholder: "JOB-XYZ",
    },
    release: {
      label: "Release",
      id: "release",
      type: "text",
      placeholder: "Release-1",
    },
    email: {
      label: "Email Recipient",
      id: "email",
      type: "email",
      placeholder: "example@example.com",
    },
    testScriptsPath: {
      label: "Scripts Path",
      id: "testScriptsPath",
      type: "text",
      placeholder: "Script path",
    },
    resDir: {
      label: "Results Directory",
      id: "resDir",
      type: "text",
      placeholder: "C:\\results",
    },
    pollInterval: {
      label: "Controller Polling Interval(sec)",
      id: "pollInterval",
      type: "text",
      placeholder: "Controller Polling Interval",
    },
    errorstoIgnore: {
      label: "Errors to Ignore",
      id: "errorstoIgnore",
      type: "text",
      placeholder: "Errors to Ignore",
    },
    analysisTemplate: {
      label: "Path to Anaylsis Template",
      id: "analysisTemplate",
      type: "text",
      placeholder: "Path to Anaylsis Template",
    },
    scenarioTimeout: {
      label: "Scenario Excution Timeout(min)",
      id: "scenarioTimeout",
      type: "text",
      placeholder: "Scenario Excution Timeout",
    },
  };

  const getInput = (input) => (
    <Form.Input
      fluid
      type={input.type}
      id={input.id}
      value={props.job[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={input.id === "name" && props.jobExists}
    />
  );

  const getInputReq = (input) => (
    <Form.Input
      fluid
      required
      type={input.type}
      id={input.id}
      value={props.job[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={input.id === "name" && props.jobExists}
      disabled={input.id === "resDir"}
    />
  );

  const checkboxFields = [
    { id: "successTrigger", label: "Success" },
    { id: "failureTrigger", label: "Failure" },
    { id: "beforebuildTrigger", label: "Before Build" },
    { id: "enableSlave", label: "Run this Job in slave?" },
    { id: "baseline", label: "baseline", type: "checkbox" },
  ];

  const getCheckbox = (checkbox) => (
    <Form.Checkbox
      id={checkbox.id}
      label={checkbox.label}
      name={checkbox.id}
      onChange={props.toggleCheckbox}
      checked={props.job[checkbox.id]}
      toggle={checkbox.id === "enableSlave" || checkbox.id === "baseline"}
    />
  );

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create LR Job</small>
        </CardHeader>
        <CardBody>
          <Form size="small">
            <Grid padded="horizontally" columns={3}>
              <Grid.Row stretched>
                <Grid.Column verticalAlign="top">
                  {getInputReq(inputFields.name)}
                  <Form>
                    <Form.Input
                      required
                      type="text"
                      placeholder="path"
                      action
                      label="Add Scripts Path for the Scenario"
                      fluid
                      value={props.tempLoc}
                      onChange={props.handlePathChange}
                    >
                      <input />

                      <Button
                        type="submit"
                        onClick={props.addScriptsPathHandler}
                        disabled={!props.tempLoc}
                      >
                        Add
                      </Button>
                    </Form.Input>
                  </Form>
                  <Row>
                    <List horizontal style={{ marginLeft: "10px" }}>
                      {props.job.testScriptsPath.map((server, index) => (
                        <List.Item
                          key={index}
                          style={{
                            backgroundColor: "#c2cfd6",
                            borderRadius: "50px",
                            marginTop: "10px",
                          }}
                        >
                          <List.Content
                            floated="right"
                            style={{ marginRight: "5px" }}
                          >
                            <Button
                              size="mini"
                              circular
                              icon="delete"
                              onClick={() => props.removeTestScriptsPath(index)}
                            />
                          </List.Content>
                          <Icon style={{ marginLeft: "10px" }} />
                          <List.Content size="small" verticalAlign="middle">
                            {server}
                          </List.Content>
                        </List.Item>
                      ))}
                    </List>
                  </Row>
                  {getInputReq(inputFields.resDir)}
                  {getInput(inputFields.pollInterval)}
                  {getInputReq(inputFields.email)}
                </Grid.Column>
                <Grid.Column verticalAlign="top">
                  {getInputReq(inputFields.release)}
                  <Form>
                    <Form.Input
                      type="text"
                      placeholder="error"
                      action
                      label="Add Errors to Ignore"
                      fluid
                      value={props.tempError}
                      onChange={props.handleErrorChange}
                    >
                      <input />

                      <Button
                        type="submit"
                        onClick={props.addErrorsHandler}
                        disabled={!props.tempError}
                      >
                        Add
                      </Button>
                    </Form.Input>
                  </Form>
                  <Row>
                    <List horizontal style={{ marginLeft: "10px" }}>
                      {props.job.errorstoIgnore.map((server, index) => (
                        <List.Item
                          key={index}
                          style={{
                            backgroundColor: "#c2cfd6",
                            borderRadius: "50px",
                            marginTop: "10px",
                          }}
                        >
                          <List.Content
                            floated="right"
                            style={{ marginRight: "1px" }}
                          >
                            <Button
                              size="mini"
                              circular
                              icon="delete"
                              onClick={() => props.removeErrorsHandler(index)}
                            />
                          </List.Content>
                          <Icon style={{ marginLeft: "10px" }} />
                          <List.Content size="small" verticalAlign="middle">
                            {server}
                          </List.Content>
                        </List.Item>
                      ))}
                    </List>
                  </Row>

                  {getInput(inputFields.analysisTemplate)}

                  {getInput(inputFields.scenarioTimeout)}

                  <Form.Field>
                    <Label>Email Triggers</Label>
                    <Form.Group inline>
                      {getCheckbox(checkboxFields[0])}
                      {getCheckbox(checkboxFields[1])}
                      {getCheckbox(checkboxFields[2])}
                    </Form.Group>
                  </Form.Field>
                </Grid.Column>
                <Grid.Column verticalAlign="top">
                  <Form.TextArea
                    label="Description (Optional)"
                    id="description"
                    rows={4}
                    placeholder="Description about this job.."
                    value={props.job.description}
                    onChange={props.formChangeHandler}
                  />

                  <Form.Field>
                    <br />
                    <Row>
                      <Col md="5">{getCheckbox(checkboxFields[3])}</Col>
                      <Col md="7">
                        {props.job.enableSlave ? (
                          <Dropdown
                            fluid
                            search
                            selection
                            id="slave"
                            placeholder="Select a slave"
                            options={props.nodeList}
                            onChange={props.dropdownChangeHandler}
                            value={props.job.slave}
                          />
                        ) : null}
                      </Col>
                    </Row>
                  </Form.Field>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </Form>
          <Grid padded="horizontally" columns={2}>
            <Grid.Row>
              <Grid.Column>
                <Form>
                  <Form.Input
                    required
                    type="text"
                    placeholder="Server"
                    action
                    label="Add Servers to monitor"
                    fluid
                    value={props.tempServer.name}
                    onChange={props.handleServerChange}
                  >
                    <input />
                    <Select
                      options={options}
                      simple
                      item
                      value={props.tempServer.os}
                      onChange={props.handleOsChange}
                    />
                    <Button
                      type="submit"
                      onClick={props.addServersHandler}
                      disabled={!props.tempServer.name}
                    >
                      Add
                    </Button>
                  </Form.Input>
                </Form>
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <br />
          <Row>
            <List horizontal style={{ marginLeft: "10px" }}>
              {props.job.servers.map((server, index) => (
                <List.Item
                  key={index}
                  style={{
                    backgroundColor: "#c2cfd6",
                    borderRadius: "50px",
                    marginTop: "10px",
                  }}
                >
                  <List.Content floated="right" style={{ marginRight: "5px" }}>
                    <Button
                      size="mini"
                      circular
                      icon="delete"
                      onClick={() => props.removeServerHandler(index)}
                    />
                  </List.Content>
                  <Icon name={server.os} style={{ marginLeft: "10px" }} />
                  <List.Content size="small" verticalAlign="middle">
                    {server.name}
                  </List.Content>
                </List.Item>
              ))}
            </List>
          </Row>
        </CardBody>
        <CardFooter>
          <Button
            animated
            onClick={props.nextPageHandler}
            disabled={!props.isFormValid}
            size="mini"
            primary
          >
            <Button.Content visible>Next</Button.Content>
            <Button.Content hidden>
              <Icon name="right arrow" />
            </Button.Content>
          </Button>
        </CardFooter>
      </Card>

      {props.job.enableSlave && props.job.slave ? infoboxSlaveAgent : null}
    </Col>
  );
};
export default LRJobDetails;
