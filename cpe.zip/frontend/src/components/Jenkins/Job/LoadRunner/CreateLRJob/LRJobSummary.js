import React, { Component } from "react";
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink,
} from "reactstrap";
import Spinner from "../../../../Spinner/Spinner";
import {
  Button,
  Icon,
  Grid,
  Segment,
  Header,
  Modal,
  Table,
  List,
} from "semantic-ui-react";
import { Popconfirm } from "antd";
import {
  errorMsg,
  successMsg,
  warningMsg,
} from "../../../../UI/Message/Message";

const LRJobSummary = (props) => {
  let triggers = [];
  props.job.successTrigger ? triggers.push("Success") : null;
  props.job.failureTrigger ? triggers.push("Failure") : null;
  props.job.beforebuildTrigger ? triggers.push("BeforeBuild") : null;
  console.log(triggers);
  let trig = triggers ? triggers.join(", ") : "-";

  const addJobconfirm = (e) => {
    console.log(e);
    props.addJobHandler();
  };

  const discardJobconfirm = (e) => {
    warningMsg("Discarding Job..");
    props.discardJobHandler();
  };

  let cardFooter = null;
  let submitPage = null;

  if (props.page === 2) {
    cardFooter = (
      <CardFooter>
        <Button.Group size="mini">
          <Button animated onClick={props.prevPageHandler} color="yellow">
            <Button.Content visible>Back</Button.Content>
            <Button.Content hidden>
              <Icon name="left arrow" />
            </Button.Content>
          </Button>
          <Button.Or />
          <Button animated onClick={props.nextPageHandler} primary>
            <Button.Content visible>next</Button.Content>
            <Button.Content hidden>
              <Icon name="right arrow" />
            </Button.Content>
          </Button>
        </Button.Group>
      </CardFooter>
    );
    submitPage = null;
  } else {
    cardFooter = null;
    submitPage = (
      <Grid columns="equal">
        <Grid.Row stretched>
          <Grid.Column></Grid.Column>
          <Grid.Column width={6}>
            <Segment>
              <Row>
                <Col md="6">
                  <h5>Create LR Jenkins job: </h5>
                </Col>
                <Col md="6">
                  <Popconfirm
                    placement="topLeft"
                    title="Are you sure to create this job?"
                    onConfirm={addJobconfirm}
                    onCancel={() => errorMsg("No..")}
                    okText="Yes"
                    cancelText="No"
                  >
                    <Button animated="vertical" size="mini" color="green">
                      <Button.Content visible>Submit</Button.Content>
                      <Button.Content hidden>
                        <Icon name="chevron circle right" />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                  <Popconfirm
                    placement="topLeft"
                    title="Are you sure discard this job?"
                    onConfirm={discardJobconfirm}
                    onCancel={() => errorMsg("No..")}
                    okText="Yes"
                    cancelText="No"
                  >
                    <Button animated="vertical" size="mini" color="red">
                      <Button.Content visible>Discard</Button.Content>
                      <Button.Content hidden>
                        <Icon name="remove" />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                </Col>
              </Row>
            </Segment>
          </Grid.Column>
          <Grid.Column></Grid.Column>
        </Grid.Row>
      </Grid>
    );
  }

  const servers = (
    <List horizontal>
      {props.job.servers.map((server, index) => (
        <List.Item key={index}>
          <Icon name={server.os} />
          <List.Content size="small" verticalAlign="middle">
            {server.name}
          </List.Content>
        </List.Item>
      ))}
    </List>
  );

  const testScriptsPath = (
    <List horizontal>
      {props.job.testScriptsPath.map((server, index) => (
        <List.Item key={index}>
          <List.Content size="small" verticalAlign="middle">
            {server}
          </List.Content>
        </List.Item>
      ))}
    </List>
  );

  const errorstoIgnore = (
    <List horizontal>
      {props.job.errorstoIgnore.map((server, index) => (
        <List.Item key={index}>
          <List.Content size="small" verticalAlign="middle">
            {server}
          </List.Content>
        </List.Item>
      ))}
    </List>
  );
  const summaryTableData = [
    { icon: "folder outline", header: "Job Name", cell: props.job.name },
    {
      icon: "comment alternate",
      header: "Description",
      cell: props.job.description,
    },
    { icon: "mail", header: "E-mail", cell: props.job.email },
    { icon: "mail forward", header: "E-mail Triggers", cell: trig },
    {
      icon: "sign in alternate",
      header: "Run in",
      cell: props.job.enableSlave ? "Slave: " + props.job.slave : "Master",
    },
    { icon: "server", header: "Release", cell: props.job.release },
    { icon: "server", header: "Scripts Path", cell: testScriptsPath },
    { icon: "server", header: "Results Directory", cell: props.job.resDir },
    {
      icon: "server",
      header: "Errors to Ignore",
      cell: errorstoIgnore,
    },
    {
      icon: "server",
      header: "Controller Polling Interval ",
      cell: props.job.pollInterval,
    },
    {
      icon: "server",
      header: "Path to Analysis Template",
      cell: props.job.analysisTemplate,
    },
    {
      icon: "server",
      header: "Scenario Execution Timeout",
      cell: props.job.scenarioTimeout,
    },
    {
      icon: "align right",
      header: "Baseline",
      cell: props.job.baseline ? "true" : "false",
    },
  ];

  const summaryTable = summaryTableData.map((row, index) => (
    <Table.Row key={index}>
      <Table.Cell>
        <Header as="h4">
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>{row.cell}</Table.Cell>
    </Table.Row>
  ));

  return (
    <div>
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Job Summary</small>
        </CardHeader>
        <CardBody>
          <Table compact celled>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>{summaryTable}</Table.Body>
          </Table>
        </CardBody>
        {cardFooter}
      </Card>
      {submitPage}
    </div>
  );
};

export default LRJobSummary;
