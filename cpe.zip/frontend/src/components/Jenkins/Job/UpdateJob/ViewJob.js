import React from 'react'
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';

import { Button, Icon, Grid, Segment, Header, Modal, Table, List } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';

import 'react-select/dist/react-select.css';

import Select from 'react-select';

const viewJob = (props) => {
  console.log(props);
  let triggers = [];
  props.job.successTrigger ? triggers.push("Success") : null;
  props.job.failureTrigger ? triggers.push("Failure") : null;
  props.job.beforebuildTrigger ? triggers.push("BeforeBuild") : null;
  let trig = triggers ? triggers.join(", ") : "-";

  const deleteJobConfirm = (e) => {
    props.deleteJobHandler();
  };

  const servers = (<List  horizontal >
    {
      props.job.servers.map((server, index) =>
        <List.Item key={index} >
          <Icon name={server.os} />
          <List.Content size="small" verticalAlign='middle'>{server.name}</List.Content>
        </List.Item>
      )
    }
  </List>);

  const summaryTableData = [
    { icon: 'folder outline', header: 'Job Name', cell: props.job.name },
    { icon: 'numbered list', header: 'Release', cell: props.job.release },
    { icon: 'comment alternate', header: 'Description', cell: props.job.description },
    { icon: 'mail', header: 'E-mail', cell: props.job.email },
    { icon: 'file', header: 'JMeter Script', cell: props.job.jmeterScript },
    { icon: 'tag', header: 'Application Name', cell: props.job.applicationName },
    { icon: 'server', header: 'Network Bandwidth', cell: props.job.bandwidth },
    { icon: 'external share', header: 'JMeter Distributed Testing', cell: props.job.enableDistributedT ? "RemoteHosts: " + (props.job.remoteHosts).join(", ") : 'Disabled' },
    { icon: 'world', header: 'Jmeter Proxy address', cell: props.job.enableProxy? "Proxy address: " + props.job.proxyAddress + " Port: "+ props.job.port :"Disabled" },
    { icon: 'mail forward', header: 'E-mail Triggers', cell: trig },
    { icon: 'sign in alternate', header: 'Run in', cell: props.job.enableSlave ? "Slave: " + props.job.slave : "Master" },
    { icon: 'server', header: 'Servers to monitor', cell: servers },
  ];

  const summaryTable = summaryTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  )
  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Job Details</small>
        </CardHeader>
        <CardBody>
          <Table compact celled >
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {summaryTable}
            </Table.Body>
          </Table>
        </CardBody>
        <CardFooter>
          <Button.Group size="mini">
            <Button animated onClick={props.editJobHandler} size="mini" primary>
              <Button.Content visible>Edit</Button.Content>
              <Button.Content hidden>
                <Icon name='edit' />
              </Button.Content>
            </Button>
            <Button.Or />
            <Popconfirm placement="topLeft" title="Are you sure delete this job?"
              onConfirm={() => deleteJobConfirm()} okText="Yes" cancelText="No">
              <Button animated color="red">
                <Button.Content visible>Delete</Button.Content>
                <Button.Content hidden>
                  <Icon name='trash' />
                </Button.Content>
              </Button>
            </Popconfirm>
          </Button.Group>
        </CardFooter>
      </Card>
    </Col>
  )
}
export default viewJob;
