import React, { Component } from "react";
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Label,
} from "reactstrap";
import {
  Button,
  Icon,
  Checkbox,
  Dropdown,
  Message,
  List,
  Select,
  Input,
  Form,
  Grid,
} from "semantic-ui-react";
import { Popconfirm, Tooltip } from "antd";
import ReactTags from "react-tag-autocomplete";
import { errorMsg, successMsg, warningMsg } from "../../../UI/Message/Message";
import FormInput from "../../../UI/FormInput/FormInput";

const options = [
  { key: "windows", text: "Windows", value: "windows", icon: "windows" },
  { key: "linux", text: "Linux", value: "linux", icon: "linux" },
];
const bandwidths = [
  {
    id: 0,
    text: "Fast Ethernet : 100 Mbit/s",
    key: "12800000",
    value: "12800000",
  },
  {
    id: 1,
    text: "Gigabit Ethernet : 1 Gbit/s",
    key: "128000000",
    value: "128000000",
  },
  {
    id: 2,
    text: "10 Gigabit Ethernet : 10 Gbit/s",
    key: "1280000000",
    value: "1280000000",
  },
  {
    id: 3,
    text: "WAN modems V.92 modems : 56 kbit/s ",
    key: "7168",
    value: "7168",
  },
  {
    id: 4,
    text: "Mobile data GPRS : 171 kbit/s",
    key: "21888",
    value: "21888",
  },
  {
    id: 5,
    text: "Mobile data HSPA : 14.4 Mbp/s",
    key: "1843200",
    value: "1843200",
  },
  {
    id: 6,
    text: "3G : 3.1 Mbp/s",
    key: "2688000",
    value: "2688000",
  },
  {
    id: 7,
    text: "4G : 21 Mbp/s",
    key: "19200000",
    value: "19200000",
  },
  {
    id: 8,
    text: "WIFI 802.11a/g : 54 Mbit/s",
    key: "6912000",
    value: "6912000",
  },
  {
    id: 9,
    text: "ADSL : 8 Mbit/s",
    key: "1024000",
    value: "1024000",
  },
  {
    id: 10,
    text: "None",
    key: "0",
    value: "0",
  },
];

class JobDetails extends Component {
  state = {
    jobDetails: {
      name: "",
      release: 1,
      jmeterScript: "",
      email: "",
      bandwidth: "",
      successTrigger: true,
      failureTrigger: true,
      beforebuildTrigger: false,
      enableSlave: false,
      slave: "",
      enableDistributedT: false,
      remoteHosts: ["localhost"],
      servers: [],
      enableProxy: false,
      proxyAddress: "",
      port: "",
      jobType: "jmeter",
    },
    tags: [{ name: "localhost" }],
    isFormValid: false,
    tempServer: {
      name: "",
      os: "windows",
    },
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    if (prevState.jobDetails.name !== nextProps.jobDetails.name) {
      return {
        ...prevState,
        jobDetails: {
          ...nextProps.jobDetails,
        },
      };
    }
    return null;
  }

  updateJobConfirm = (e) => {
    // successMsg("Job Updated Successfully");
    this.props.updateJob(this.state.jobDetails);
  };

  isFormValid = () => {
    console.log(
      this.state.jobDetails.enableDistributedT
        ? this.state.jobDetails.remoteHosts
          ? true
          : false
        : true
    );
    if (
      this.state.jobDetails.name &&
      this.state.jobDetails.release &&
      this.state.jobDetails.bandwidth &&
      (this.state.jobDetails.enableProxy
        ? this.state.jobDetails.proxyAddress && this.state.jobDetails.port
        : true) &&
      this.state.jobDetails.servers.length > 0 &&
      this.state.jobDetails.jmeterScript &&
      this.state.jobDetails.email &&
      (this.state.jobDetails.enableSlave
        ? this.state.jobDetails.slave
          ? true
          : false
        : true) &&
      this.state.jobDetails.enableDistributedT
        ? this.state.jobDetails.remoteHosts
          ? true
          : false
        : true
    ) {
      this.setState(
        {
          ...this.state,
          isFormValid: true,
        },
        () => {}
      );
    } else {
      this.setState(
        {
          ...this.state,
          isFormValid: false,
        },
        () => {
          console.log("invalid form!");
        }
      );
    }
  };

  formChangeHandler = (event) => {
    console.log("formChangeHandler");
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.value,
        },
      },
      () => this.isFormValid()
    );
  };

  toggleCheckbox = (event) => {
    const target = event.target;
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };

  dropdownChangeHandler = (event, data) => {
    console.log(data.value);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [data.id]: data.value,
        },
      },
      () => this.isFormValid()
    );
  };

  addServersHandler = (event, data) => {
    console.log(data);
    const server = {
      name: this.state.tempServer.name,
      os: this.state.tempServer.os,
    };
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: [].concat(this.state.jobDetails.servers, server),
        },
        tempServer: {
          name: "",
          os: "windows",
        },
      },
      () => this.isFormValid()
    );
  };

  removeServerHandler = (index) => {
    const servers = this.state.jobDetails.servers.slice(0);
    servers.splice(index, 1);
    console.log(servers);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          servers: servers,
        },
      },
      () => this.isFormValid()
    );
  };

  handleBandwidthChange = (event, data) => {
    console.log(data);
    this.setState(
      {
        ...this.state,
        jobDetails: {
          ...this.state.jobDetails,
          [data.id]: data.value,
          bandwidth: data.value,
        },
      },
      () => this.isFormValid()
    );
  };

  handleServerChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        name: data.value,
      },
    });
  };

  handleOsChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        os: data.value,
      },
    });
  };

  handleRemoteHostsDelete = (i) => {
    console.log(this.state);
    const tags = this.state.tags.slice(0);
    tags.splice(i, 1);
    this.setState(
      {
        ...this.state,
        tags: tags.filter((tag, index) => index !== i),
      },
      () => {
        let hosts = [];
        this.state.tags.map((host) => hosts.push(host.name));
        this.setState({
          ...this.state,
          jobDetails: {
            ...this.state.jobDetails,
            remoteHosts: hosts,
          },
        });
      }
    );
  };

  handleRemoteHostsAddition = (tag) => {
    const tags = [].concat(this.state.tags, tag);
    const hosts = this.state.jobDetails.remoteHosts;
    hosts.push(tag.name);
    this.setState({
      ...this.state,
      jobDetails: {
        ...this.state.jobDetails,
        remoteHosts: hosts,
      },
      tags: tags,
    });
  };

  downloadSlaveAgent = () => {
    axios
      .get("downloadSlaveAgent")
      .then((response) => {
        console.log(response.data);
        fileDownload(response.data, "slave-agent-" + props.job.slave + ".jnlp");
      })
      .catch((error) => console.log(error.message));
  };

  render() {
    console.log(this.state.jobDetails);

    const infoboxDT = (
      <Message
        info
        icon="info"
        header={"Please note.."}
        content={
          <p>
            Add all remote hosts in your{" "}
            <Tooltip title="prompt text">
              <span>
                <b>jmeter.properties</b>
              </span>
            </Tooltip>{" "}
            file
          </p>
        }
      />
    );

    const infoBoxProxy = (
      <Message
        info
        icon="info"
        header={"Please enter both proxy address and port"}
      />
    );

    const infoboxSlaveAgent = (
      <Message warning>
        <Row>
          <Col md="1">
            <Button
              icon="download"
              color="orange"
              onClick={this.downloadSlaveAgent}
            />
          </Col>
          <Col md="10">
            <Message.Header>Slave-Agent</Message.Header>
            <p>Download slave-agent and run on slave machine..</p>
          </Col>
        </Row>
      </Message>
    );

    const inputFields = {
      name: {
        label: "Name",
        id: "name",
        type: "text",
        value: this.state.jobDetails.name,
        placeholder: "JOB-XYZ",
      },
      jmeterScript: {
        label: "JMeter Script Locaion",
        id: "jmeterScript",
        type: "text",
        value: this.state.jobDetails.jmeterScript,
        placeholder: "D:\\Softwares\\JMeter\\Script\\test1.jmx",
      },
      email: {
        label: "Email Recipient",
        id: "email",
        type: "email",
        value: this.state.jobDetails.jmeterScript,
        placeholder: "example@example.com",
      },
      release: {
        label: "Release",
        id: "release",
        type: "text",
        value: this.state.jobDetails.release,
        placeholder: "Release-1",
      },
      applicationName: {
        label: "Application Name",
        id: "applicationName",
        type: "text",
        value: this.state.jobDetails.applicationName,
        placeholder: "App-1",
      },
      proxyAddress: {
        label: "Proxy address",
        id: "proxyAddress",
        type: "text",
        value: this.state.jobDetails.proxyAddress,
        placeholder: "Proxy Address",
      },
      port: {
        label: "Port",
        id: "port",
        type: "number",
        value: this.state.jobDetails.port,
        placeholder: "Port",
      },
    };

    const getInput = (input) => (
      <Form.Input
        type={input.type}
        id={input.id}
        value={this.state.jobDetails[input.id]}
        onChange={this.formChangeHandler}
        label={input.label}
        fluid
        disabled={input.id === "name"}
        placeholder={input.placeholder}
      />
    );

    const checkboxFields = [
      { id: "successTrigger", label: "Success" },
      { id: "failureTrigger", label: "Failure" },
      { id: "beforebuildTrigger", label: "Before Build" },
      { id: "enableSlave", label: "Run this Job in slave?" },
      {
        id: "enableDistributedT",
        label: "Enable distributed testing in JMeter ?",
      },
      { id: "enableProxy", label: "Proxy for running Jmeter scripts?" },
    ];

    const getCheckbox = (checkbox) => (
      <Form.Checkbox
        id={checkbox.id}
        label={checkbox.label}
        name={checkbox.id}
        onChange={this.toggleCheckbox}
        checked={this.state.jobDetails[checkbox.id]}
        toggle={
          checkbox.id === "enableSlave" ||
          checkbox.id === "enableDistributedT" ||
          checkbox.id === "enableProxy"
        }
      />
    );

    return (
      <Col md="12">
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Edit Job</small>
          </CardHeader>
          <CardBody>
            <Form size="small">
              <Grid padded="horizontally" columns={3}>
                <Grid.Row stretched>
                  <Grid.Column verticalAlign="top">
                    {getInput(inputFields.name)}
                    {getInput(inputFields.jmeterScript)}
                    {getInput(inputFields.email)}
                  </Grid.Column>
                  <Grid.Column verticalAlign="top">
                    {getInput(inputFields.release)}
                    {getInput(inputFields.applicationName)}
                    <Form.Field>
                      <Label>Email Triggers</Label>
                      <Form.Group inline>
                        {getCheckbox(checkboxFields[0])}
                        {getCheckbox(checkboxFields[1])}
                        {getCheckbox(checkboxFields[2])}
                      </Form.Group>
                    </Form.Field>
                  </Grid.Column>

                  <Grid.Column>
                    <Form.TextArea
                      label="Description"
                      id="description"
                      rows={4}
                      placeholder="Description about this job.."
                      value={this.state.jobDetails.description}
                      onChange={this.formChangeHandler}
                    />

                    <Form.Field>
                      <br />
                      <Row>
                        <Col md="5">{getCheckbox(checkboxFields[3])}</Col>
                        <Col md="7">
                          {this.state.jobDetails.enableSlave ? (
                            <Dropdown
                              fluid
                              search
                              selection
                              id="slave"
                              placeholder="Select a slave"
                              options={this.props.nodeList}
                              onChange={this.dropdownChangeHandler}
                              value={this.state.jobDetails.slave}
                            />
                          ) : null}
                        </Col>
                      </Row>
                    </Form.Field>
                  </Grid.Column>
                </Grid.Row>
              </Grid>
            </Form>
            <Grid padded="horizontally" columns={2}>
              <Grid.Row>
                <Col md="4">
                  {getCheckbox(checkboxFields[5])}
                  {this.state.jobDetails.enableProxy ? (
                    <Col>
                      {getInput(inputFields.proxyAddress)}
                      {getInput(inputFields.port)}
                      {this.state.jobDetails.enableProxy &&
                      !(
                        this.state.jobDetails.proxyAddress &&
                        this.state.jobDetails.port
                      )
                        ? infoBoxProxy
                        : null}
                    </Col>
                  ) : null}
                </Col>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column>
                  <Form>
                    <Label>Add Network Bandwidth</Label>
                    <Dropdown
                      fluid
                      search
                      selection
                      id="bandwidth"
                      placeholder="Select a bandwidth"
                      options={bandwidths}
                      onChange={this.handleBandwidthChange}
                      value={this.state.jobDetails.bandwidth}
                    />
                  </Form>
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column>
                  <Form>
                    <Form.Input
                      type="text"
                      placeholder="Server"
                      action
                      label="Add Servers to monitor"
                      fluid
                      value={this.state.tempServer.name}
                      onChange={this.handleServerChange}
                    >
                      <input />
                      <Select
                        options={options}
                        simple
                        item
                        value={this.state.tempServer.os}
                        onChange={this.handleOsChange}
                      />
                      <Button
                        type="submit"
                        onClick={this.addServersHandler}
                        disabled={!this.state.tempServer.name}
                      >
                        Add
                      </Button>
                    </Form.Input>
                  </Form>
                </Grid.Column>
                <Grid.Column>
                  <br />
                  <Row>
                    <Col md="5">{getCheckbox(checkboxFields[4])}</Col>
                    <Col md="7">
                      {this.state.jobDetails.enableDistributedT ? (
                        <ReactTags
                          tags={this.state.tags}
                          handleDelete={this.handleRemoteHostsDelete}
                          handleAddition={this.handleRemoteHostsAddition}
                          allowNew={true}
                          placeholder="Add new host"
                          delimiterChars={[",", " "]}
                        />
                      ) : null}
                    </Col>
                  </Row>
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <br />
            <Row>
              <List horizontal style={{ marginLeft: "10px" }}>
                {this.state.jobDetails.servers.map((server, index) => (
                  <List.Item
                    key={index}
                    style={{ backgroundColor: "#c2cfd6", borderRadius: "50px" }}
                  >
                    <List.Content
                      floated="right"
                      style={{ marginRight: "5px" }}
                    >
                      <Button
                        size="mini"
                        circular
                        icon="delete"
                        onClick={() => this.removeServerHandler(index)}
                      />
                    </List.Content>
                    <Icon name={server.os} style={{ marginLeft: "10px" }} />
                    <List.Content size="small" verticalAlign="middle">
                      {server.name}
                    </List.Content>
                  </List.Item>
                ))}
              </List>
            </Row>
          </CardBody>

          <CardFooter>
            <Button.Group size="mini">
              <Popconfirm
                placement="topLeft"
                title="Are you sure update this job?"
                onConfirm={this.updateJobConfirm}
                onCancel={() => errorMsg("No..")}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  animated
                  color="green"
                  disabled={!this.state.isFormValid}
                >
                  <Button.Content visible>Submit</Button.Content>
                  <Button.Content hidden>
                    <Icon name="check circle" />
                  </Button.Content>
                </Button>
              </Popconfirm>
              <Button.Or />
              <Button
                animated
                onClick={() => this.props.discardChangesHandler()}
                secondary
              >
                <Button.Content visible>Discard</Button.Content>
                <Button.Content hidden>
                  <Icon name="remove circle" />
                </Button.Content>
              </Button>
            </Button.Group>
          </CardFooter>
        </Card>

        {this.state.jobDetails.enableSlave && this.state.jobDetails.slave
          ? infoboxSlaveAgent
          : null}
        {this.state.jobDetails.enableDistributedT &&
        this.state.jobDetails.remoteHosts
          ? infoboxDT
          : null}
      </Col>
    );
  }
}
export default JobDetails;
