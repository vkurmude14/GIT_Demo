import React, { Component } from 'react'
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  FormGroup,
  FormText,
  Label,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  FormFeedback
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Checkbox, Dropdown, Message, Select, Input, Form, List, Grid, Popup } from 'semantic-ui-react';
import axios from '../../../../axios';
import fileDownload from 'js-file-download';
import ReactTags from 'react-tag-autocomplete';
import { Tooltip } from 'antd';

const JobDetails = (props) => {

  const downloadSlaveAgent = () => {
    axios.get('downloadSlaveAgent', {
      params: { slaveName: props.job.slave }
    })
      .then(response => {
        console.log(response.data);
        fileDownload(response.data, 'slave-agent-' + props.job.slave + '.jnlp')
      })
      .catch(error => console.log(error.message));
  }

  const options = [
    { key: 'windows', text: 'Windows', value: 'windows', icon: 'windows' },
    { key: 'linux', text: 'Linux', value: 'linux', icon: 'linux' },
  ]

  const infoboxDT = (
    <Message info
      icon='info'
      header={'Please note..'}
      content={<p>Add all remote hosts in your <Tooltip title="prompt text">
        <span><b>jmeter.properties</b></span>
      </Tooltip> file</p>}
    />);

  const infoBoxProxy = (
    <Message info
      icon='info'
      header={'Please enter both proxy address and port'}
    />);


  const bandwidths = [
    {
      id: 0,
      text: 'Fast Ethernet : 100 Mbit/s',
      key: '12800000',
      value: '12800000'
    },
    {
      id: 1,
      text: 'Gigabit Ethernet : 1 Gbit/s',
      key: '128000000',
      value: '128000000'
    },
    {
      id: 2,
      text: '10 Gigabit Ethernet : 10 Gbit/s',
      key: '1280000000',
      value: '1280000000'
    },
    {
      id: 3,
      text: 'WAN modems V.92 modems : 56 kbit/s ',
      key: '7168',
      value: '7168'
    },
    {
      id: 4,
      text: 'Mobile data GPRS : 171 kbit/s',
      key: '21888',
      value: '21888'
    },
    {
      id: 5,
      text: 'Mobile data HSPA : 14.4 Mbp/s',
      key: '1843200',
      value: '1843200'
    },
    {
      id: 6,
      text: '3G : 3.1 Mbp/s',
      key: '2688000',
      value: '2688000'
    },
    {
      id: 7,
      text: '4G : 21 Mbp/s',
      key: '19200000',
      value: '19200000'
    },
    {
      id: 8,
      text: 'WIFI 802.11a/g : 54 Mbit/s',
      key: '6912000',
      value: '6912000'
    },
    {
      id: 9,
      text: 'ADSL : 8 Mbit/s',
      key: '1024000',
      value: '1024000'
    },
    {
      id: 10,
      text: 'None',
      key: '0',
      value: '0'
    } 
  ]



  const infoboxSlaveAgent = (
    <Message warning >
      <Row>
        <Col md="1">
          <Button icon='download' color='orange' onClick={downloadSlaveAgent} />
        </Col>
        <Col md="10">
          <Message.Header>Slave-Agent</Message.Header>
          <p>Download slave-agent and run on slave machine..</p>
        </Col>
      </Row>
    </Message>);

  const emailTriggers = [
    { name: "successTrigger", text: "Success" },
    { name: "failureTrigger", text: "Failure" },
    { name: "beforebuildTrigger", text: "Beforebuild" }];

  const emailTriggerCheckbox = emailTriggers.map((trigger, i) =>
    <FormGroup check className="checkbox" key={i}>
      <Input className="form-check-input" type="checkbox" id={trigger.name}
        name={trigger.name} value={props.job.successTrigger}
        onChange={props.toggleCheckbox} checked={props.job[trigger.name]} />
      <Label className="form-check-label" check htmlFor={trigger.name}>{trigger.text}</Label>
    </FormGroup>
  );

  const inputFields = {
    name: {
      label: "Name", id: "name", type: "text",
      value: props.job.name,
      placeholder: "JOB-XYZ",
    },
    jmeterScript: {
      label: "JMeter Script Location", id: "jmeterScript", type: "text",
      placeholder: "D:\\Softwares\\JMeter\\Script\\test1.jmx",
    },
    email: {
      label: "Email Recipient", id: "email", type: "email",
      placeholder: "example@example.com",
    },
    release: {
      label: "Release", id: "release", type: "text",
      placeholder: "Release-1", accept: ".jmx"
    },
    applicationName: {
      label: <h6>Application Name  <Popup trigger={<Icon name='info circle' color="blue" />}
        content='Same name should be given in the backend-listener of your JMeter script' on='hover' size='mini' />  </h6>,
      id: "applicationName", type: "text",
      placeholder: "App-1",
    },
    proxyAddress: {
      label: "Proxy address", id: "proxyAddress", type: "text",
      placeholder: "Proxy Address",
    },
    port: {
      label: "Port", id: "port", type: "number",
      placeholder: "Port",
    },
  };

  const getInput = (input) => (
    <Form.Input fluid required
      type={input.type}
      id={input.id}
      value={props.job[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={input.id === "name" && props.jobExists} />);

  const checkboxFields = [
    { id: "successTrigger", label: "Success" },
    { id: "failureTrigger", label: "Failure" },
    { id: "beforebuildTrigger", label: "Before Build" },
    { id: "enableSlave", label: "Run this Job in slave?" },
    { id: "enableDistributedT", label: "Enable distributed testing in JMeter ?" },
    { id: "enableProxy", label: "Proxy for running Jmeter scripts?" }
  ]

  const getCheckbox = (checkbox) => (
    <Form.Checkbox id={checkbox.id}
      label={checkbox.label}
      name={checkbox.id}
      onChange={props.toggleCheckbox}
      checked={props.job[checkbox.id]}
      toggle={checkbox.id === "enableSlave" || checkbox.id === "enableDistributedT" || checkbox.id === "enableProxy"} />
  )

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create Job</small>
        </CardHeader>
        <CardBody>
          <Form size="small">
            <Grid padded="horizontally" columns={3}>
              <Grid.Row stretched>
                <Grid.Column verticalAlign="top">
                  {getInput(inputFields.name)}
                  {getInput(inputFields.jmeterScript)}
                  {getInput(inputFields.email)}
                </Grid.Column>
                <Grid.Column verticalAlign="top">
                  {getInput(inputFields.release)}
                  {getInput(inputFields.applicationName)}
                  <Form.Field >
                    <Label>Email Triggers</Label>
                    <Form.Group inline>
                      {getCheckbox(checkboxFields[0])}
                      {getCheckbox(checkboxFields[1])}
                      {getCheckbox(checkboxFields[2])}
                    </Form.Group>
                  </Form.Field>
                </Grid.Column>

                <Grid.Column>
                  <Form.TextArea label='Description (Optional)'
                    id="description" rows={4}
                    placeholder='Description about this job..'
                    value={props.job.description}
                    onChange={props.formChangeHandler} />

                  <Form.Field >
                    <br />
                    <Row>
                      <Col md="5">
                        {getCheckbox(checkboxFields[3])}
                      </Col>
                      <Col md="7">
                        {props.job.enableSlave ?
                          <Dropdown fluid search selection id="slave"
                            placeholder='Select a slave'
                            options={props.nodeList}
                            onChange={props.dropdownChangeHandler}
                            value={props.job.slave} /> : null}
                      </Col>
                    </Row>
                  </Form.Field>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </Form>
          <Grid padded="horizontally" columns={2}>
            <Grid.Row>
              <Col md="4" >
                {getCheckbox(checkboxFields[5])}
                {props.job.enableProxy ?
                  <Col>
                    {getInput(inputFields.proxyAddress)}
                    {getInput(inputFields.port)}
                    {props.job.enableProxy && !(props.job.proxyAddress && props.job.port) ? infoBoxProxy : null}
                  </Col> : null}
              </Col>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column>
                  <Form >
                    <Label>Add Network Bandwidth</Label>
                    <Dropdown fluid search selection id="bandwidth"
                      placeholder='Select a bandwidth'
                      options={bandwidths}
                      onChange={props.handleBandwidthChange}
                      value={props.job.bandwidth} />
                  </Form>
                </Grid.Column>
              </Grid.Row>
            <Grid.Row>
              <Grid.Column>
                <Form>
                  <Form.Input required type='text' placeholder='Server' action label="Add Servers to monitor"
                    fluid value={props.tempServer.name}
                    onChange={props.handleServerChange}>
                    <input />
                    <Select options={options}
                      simple item value={props.tempServer.os}
                      onChange={props.handleOsChange} />
                    <Button type='submit'
                      onClick={props.addServersHandler}
                      disabled={!props.tempServer.name}>Add</Button>
                  </Form.Input>
                </Form>
              </Grid.Column>
              <Grid.Column>
                <br />
                <Row>
                  <Col md="5">
                    {getCheckbox(checkboxFields[4])}
                  </Col>
                  <Col md="7">
                    {props.job.enableDistributedT ? <ReactTags
                      tags={props.tags}
                      handleDelete={props.handleRemoteHostsDelete}
                      handleAddition={props.handleRemoteHostsAddition}
                      allowNew={true}
                      placeholder='Add new host'
                      delimiterChars={[',', ' ']}
                    /> : null}
                  </Col>
                </Row>
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <br />
          <Row>
            <List horizontal style={{ marginLeft: '10px' }}>
              {
                props.job.servers.map((server, index) =>
                  <List.Item key={index} style={{ backgroundColor: '#c2cfd6', borderRadius: "50px", marginTop: "10px" }} >
                    <List.Content floated='right' style={{ marginRight: '5px' }}>
                      <Button size="mini" circular icon="delete" onClick={() => props.removeServerHandler(index)} />
                    </List.Content>
                    <Icon name={server.os} style={{ marginLeft: '10px' }} />
                    <List.Content size="small" verticalAlign='middle'>{server.name}</List.Content>
                  </List.Item>
                )
              }
            </List>
          </Row>
        </CardBody>
        <CardFooter >
          <Button animated onClick={props.nextPageHandler}
            disabled={!props.isFormValid} size="mini" primary>
            <Button.Content visible>Next</Button.Content>
            <Button.Content hidden>
              <Icon name='right arrow' />
            </Button.Content>
          </Button>
        </CardFooter>

      </Card>

      {props.job.enableSlave && props.job.slave ? infoboxSlaveAgent : null}
      {props.job.enableDistributedT && props.job.remoteHosts ? infoboxDT : null}
    </Col>
  )
}
export default JobDetails;