import React, { Component } from 'react'
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Grid, Segment, Header, Modal, Table, List } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../../components/UI/Message/Message';

const JobSummary = (props) => {

  let triggers = [];
  props.job.successTrigger ? triggers.push("Success") : null;
  props.job.failureTrigger ? triggers.push("Failure") : null;
  props.job.beforebuildTrigger ? triggers.push("BeforeBuild") : null;
  console.log(triggers);
  let trig = triggers ? triggers.join(", ") : "-";

  const addJobconfirm = (e) => {
    console.log(e);
    props.addJobHandler();
  }

  const discardJobconfirm = (e) => {
    warningMsg("Discarding Job..");
    props.discardJobHandler();
  }

  let cardFooter = null;
  let submitPage = null;

  if (props.page === 2) {
    cardFooter = (<CardFooter>
      <Button.Group size="mini">
        <Button animated onClick={props.prevPageHandler} color="yellow">
          <Button.Content visible>Back</Button.Content>
          <Button.Content hidden>
            <Icon name='left arrow' />
          </Button.Content>
        </Button>
        <Button.Or />
        <Button animated onClick={props.nextPageHandler} primary>
          <Button.Content visible>next</Button.Content>
          <Button.Content hidden>
            <Icon name='right arrow' />
          </Button.Content>
        </Button>
      </Button.Group>
    </CardFooter>);
    submitPage = null;
  } else {
    cardFooter = null;
    submitPage = (
      <Grid columns='equal'>
        <Grid.Row stretched>
          <Grid.Column>
          </Grid.Column>
          <Grid.Column width={6}>
            <Segment>
              <Row>
                <Col md="6">
                  <h5>Create Jenkins job: </h5>
                </Col>
                <Col md="6">
                  <Popconfirm placement="topLeft" title="Are you sure create this job?"
                 
                    onConfirm={addJobconfirm} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
                    <Button animated='vertical' size="mini" color="green">
                      <Button.Content visible>Submit</Button.Content>
                      <Button.Content hidden>
                        <Icon name='chevron circle right' />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                  <Popconfirm placement="topLeft" title="Are you sure discard this job?"
                    onConfirm={discardJobconfirm} onCancel={() => errorMsg("No..")} okText="Yes" cancelText="No">
                    <Button animated='vertical' size="mini" color="red">
                      <Button.Content visible>Discard</Button.Content>
                      <Button.Content hidden>
                        <Icon name='remove' />
                      </Button.Content>
                    </Button>
                  </Popconfirm>
                </Col>
              </Row>
            </Segment>
          </Grid.Column>
          <Grid.Column>
          </Grid.Column>
        </Grid.Row>
      </Grid>)
  }

  const servers = (<List horizontal >
    {
      props.job.servers.map((server, index) =>
        <List.Item key={index} >
          <Icon name={server.os} />
          <List.Content size="small" verticalAlign='middle'>{server.name}</List.Content>
        </List.Item>
      )
    }
  </List>);
  const summaryTableData = [
    { icon: 'folder outline', header: 'Job Name', cell: props.job.name },
    { icon: 'numbered list', header: 'Release', cell: props.job.release },
    { icon: 'comment alternate', header: 'Description', cell: props.job.description },
    { icon: 'mail', header: 'E-mail', cell: props.job.email },
    { icon: 'file', header: 'JMeter Script', cell: props.job.jmeterScript },
    { icon: 'tag', header: 'Application Name', cell: props.job.applicationName },
    { icon: 'server', header: 'Network Bandwidth', cell: props.job.bandwidth },
    { icon: 'external share', header: 'JMeter Distributed Testing', cell: props.job.enableDistributedT ? "RemoteHosts: " + (props.job.remoteHosts).join(", ") : 'Disabled' },
    { icon: 'world', header: 'Jmeter Proxy address', cell: props.job.enableProxy? "Proxy address: " + props.job.proxyAddress + " Port: "+ props.job.port :"Disabled" },
    { icon: 'mail forward', header: 'E-mail Triggers', cell: trig },
    { icon: 'sign in alternate', header: 'Run in', cell: props.job.enableSlave ? "Slave: " + props.job.slave : "Master" },
    { icon: 'server', header: 'Servers to monitor', cell: servers },
  ];
  
  const summaryTable = summaryTableData.map((row, index) =>
    <Table.Row key={index}>
      <Table.Cell>
        <Header as='h4' >
          <Header.Content>
            <Icon name={row.icon} /> {row.header}
          </Header.Content>
        </Header>
      </Table.Cell>
      <Table.Cell>
        {row.cell}
      </Table.Cell>
    </Table.Row>
  )

  return (
    <div>
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Job Summary</small>
        </CardHeader>
        <CardBody>
          <Table compact celled >
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {summaryTable}
            </Table.Body>
          </Table>
        </CardBody>
        {cardFooter}
      </Card>
      {submitPage}
    </div>
  )
}

export default JobSummary;