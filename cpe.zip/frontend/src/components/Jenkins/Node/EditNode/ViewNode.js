import React from 'react'
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';

import { Button, Icon, Grid, Segment, Header, Modal, Table } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';

import 'react-select/dist/react-select.css';

import Select from 'react-select';

const viewNode = (props) => {

  const deleteNodeConfirm = (e) => {
    props.deleteNodeHandler();
  }

  return (
    <Col md="12">
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Node Details</small>
        </CardHeader>
        <CardBody>
          <Table compact celled >
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Name</Table.HeaderCell>
                <Table.HeaderCell>Value</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>
                  <Header as='h4' >
                    <Header.Content>
                      <Icon name='code branch' /> Node Name
                  </Header.Content>
                  </Header>
                </Table.Cell>
                <Table.Cell>
                  {props.node.name}
                </Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Header as='h4' >
                    <Header.Content>
                      <Icon name='commenting' /> Description
                    </Header.Content>
                  </Header>
                </Table.Cell>
                <Table.Cell>
                  {props.node.description}
                </Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Header as='h4' >
                    <Header.Content>
                      <Icon name='folder open' /> Root Directory
                  </Header.Content>
                  </Header>
                </Table.Cell>
                <Table.Cell>
                  {props.node.rootDirectory}
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
        </CardBody>
        <CardFooter>
          <Button.Group size="mini">
            <Button animated onClick={props.editNodeHandler} size="mini" primary>
              <Button.Content visible>Edit</Button.Content>
              <Button.Content hidden>
                <Icon name='edit' />
              </Button.Content>
            </Button>
            <Button.Or />
            <Popconfirm placement="topLeft" title="Are you sure delete this node?"
              onConfirm={() => deleteNodeConfirm()} okText="Yes" cancelText="No">
              <Button animated color="red" loading={props.deleteLoading}>
                <Button.Content visible>Delete</Button.Content>
                <Button.Content hidden>
                  <Icon name='trash' />
                </Button.Content>
              </Button>
            </Popconfirm>
          </Button.Group>
        </CardFooter>
      </Card>
    </Col>
  )
}
export default viewNode;