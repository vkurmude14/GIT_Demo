import React, { Component } from 'react';
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Dropdown } from 'semantic-ui-react';
import { Popconfirm } from 'antd';
import { errorMsg, successMsg, warningMsg } from '../../../UI/Message/Message';

class EditNode extends Component {
  state = {
    node: {
      name: '',
      description: '',
      rootDirectory: '',
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    if (prevState.node.name !== nextProps.node.name) {
      return {
        ...prevState,
        node: {
          ...nextProps.node
        }
      }
    }
  }

  updateNodeConfirm = (e) => {
    // successMsg("Node Created Successfully");
    this.props.updateNode(this.state.node);
  }

  formChangeHandler = event => {
    console.log("formChangeHandler")
    const target = event.target;
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        [target.id]: target.value
      }
    }, () => {
      if (this.state.node.name && this.state.node.description && this.state.node.rootDirectory) {
        this.setState({
          ...this.state,
          isFormValid: true
        }, () => {
        })
      } else {
        this.setState({
          ...this.state,
          isFormValid: false
        }, () => {
        })
      }
    });
  }

  dropdownChangeHandler = (p, target) => {
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        jobName: target.value
      }
    });
  }

  toggleCheckbox = event => {
    const target = event.target;
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        [target.id]: target.checked
      }
    });
  }

  render() {
    console.log(this.state.node);
    console.log(this.props.jobList);
    return (
      <Col md="12">
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Edit Node </small>
          </CardHeader>
          <CardBody>
            <FormGroup row>
              <Col md="4">
                <FormGroup>
                  <Label htmlFor="name">Node Name</Label>
                  <Input type="text" id="name" value={this.state.node.name}
                    disabled placeholder="JOB-XYZ" />
                </FormGroup>
              </Col>
              <Col md="4">
                <FormGroup>
                  <Label htmlFor="description">Description</Label>
                  <Input type="text" id="description" value={this.state.node.description}
                    onChange={this.formChangeHandler} placeholder="**description**" />
                </FormGroup>
              </Col>
              <Col md="4">
                <FormGroup>
                  <Label htmlFor="rootDirectory">Root Directory</Label>
                  <Input type="text" id="rootDirectory" value={this.state.node.rootDirectory}
                    onChange={this.formChangeHandler} placeholder="Eg: 'C:\Jenkins'" />
                </FormGroup>
              </Col>
            </FormGroup>
          </CardBody>

          <CardFooter >
            <Button.Group size="mini">
              <Popconfirm placement="topLeft" title="Are you sure update this node?"
                onConfirm={this.updateNodeConfirm} okText="Yes" cancelText="No">
                <Button animated color="green" loading={this.props.updateLoading}>
                  <Button.Content visible>Submit</Button.Content>
                  <Button.Content hidden>
                    <Icon name='check circle' />
                  </Button.Content>
                </Button>
              </Popconfirm>
              <Button.Or />
              <Button animated secondary onClick={this.props.discardChangesHandler}>
                <Button.Content visible>Discard</Button.Content>
                <Button.Content hidden>
                  <Icon name='remove circle' />
                </Button.Content>
              </Button>
            </Button.Group>
          </CardFooter>
        </Card>
      </Col>
    )
  }
}
export default EditNode;