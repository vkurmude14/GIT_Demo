import React, { Component } from 'react'
import {
  Card,
  CardHeader,
  CardFooter,
  CardBody,
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Dropdown, Input, Form } from 'semantic-ui-react'

const NodeDetails = (props) => {

  console.log(props.isFormValid);

  const inputFields = [
    { label: "Name", id: "name", type: "text", placeholder: "Node-XYZ", },
    { label: "Description", id: "description", type: "text", placeholder: "**Description**", },
    { label: "Root Directory", id: "rootDirectory", type: "text", placeholder: "C:\\Jenkins", }]

  const getInput = (input, index) => (
    <Form.Input fluid required key={index}
      type={input.type}
      id={input.id}
      value={props.node[input.id]}
      onChange={props.formChangeHandler}
      label={input.label}
      placeholder={input.placeholder}
      error={props.nodeExists && input.id ==="name"} />);

  return (
    <Card>
      <CardHeader>
        <strong>Jenkins</strong>
        <small> Create Node</small>
      </CardHeader>
      <CardBody>
        <Form loading={props.createLoading} size="tiny">
        <Form.Group widths='equal'>
          {inputFields.map((input, index) => getInput(input, index))}
          </Form.Group>
        </Form>
      </CardBody>
    </Card >
  )
}

export default NodeDetails;