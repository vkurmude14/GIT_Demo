import React, { Component } from 'react'
import {
  Row,
  Col,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import Spinner from '../../../../components/Spinner/Spinner';
import { Button, Icon, Grid, Segment, Header, Modal, Table } from 'semantic-ui-react';
import { Popconfirm } from 'antd';

const NodeSummary = (props) => {

  const addJobconfirm = (e) => {
    props.addNodeHandler();
  }

  const pipelineTableData = [
    { icon: 'code branch', header: 'Node Name', cell: 'name' },
    { icon: 'commenting', header: 'Description', cell: 'description' },
    { icon: 'folder open', header: 'Root Directory', cell: 'rootDirectory' },
  ];

  return (
    <div>
      <Table compact celled >
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Name</Table.HeaderCell>
            <Table.HeaderCell>Value</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {pipelineTableData.map((row, index) =>
            <Table.Row key={index}>
              <Table.Cell>
                <Header as='h4' >
                  <Header.Content>
                    <Icon name={row.icon} /> {row.header}
                  </Header.Content>
                </Header>
              </Table.Cell>
              <Table.Cell>
                {props.node[row.cell]}
              </Table.Cell>
            </Table.Row>
          )}
        </Table.Body>
        <Table.Footer fullWidth>
          <Table.Row>
            <Table.HeaderCell colSpan='4'>
              <Button.Group size="tiny">
                <Popconfirm placement="topLeft" title="Are you sure add this node?"
                  onConfirm={addJobconfirm} okText="Yes" cancelText="No">
                  <Button animated color="green"
                    loading={props.createLoading}
                    disabled={!props.isFormValid} >
                    <Button.Content visible>Submit</Button.Content>
                    <Button.Content hidden>
                      <Icon name='check circle' />
                    </Button.Content>
                  </Button>
                </Popconfirm>
                <Button.Or />
                <Button animated primary onClick={props.discardNodeHandler} >
                  <Button.Content visible >Discard</Button.Content>
                  <Button.Content hidden>
                    <Icon name='remove circle' />
                  </Button.Content>
                </Button>
              </Button.Group>
            </Table.HeaderCell>
          </Table.Row>
        </Table.Footer>
      </Table>
    </div>
  )
}

export default NodeSummary;