import React, { Component } from 'react';
import { connect } from 'react-redux'
import { withRouter } from "react-router-dom";
import * as actions from '../../store/actions';
import { Grid } from 'semantic-ui-react';
import { User, Url, Config } from '../../components/Configurations';

class Configurations extends Component {

  componentDidMount = () => {
    this.props.fetchConfigs();
  }
  
  render() {

    return (
      <Grid centered columns={2}>
        <Grid.Column>
          <User />
        </Grid.Column>

        <Grid.Column>
          <Url />
        </Grid.Column>

        <Grid.Column>
          <Config />
        </Grid.Column>
      </Grid >
    )
  }
}

const mapStateToProps = (state) => ({
  fetch: {
    loading: state.JenkinsConfig.fetch.loading,
    error: state.JenkinsConfig.fetch.error,
    success: state.JenkinsConfig.fetch.success
  },
})

const mapDispatchToProps = (dispatch) => {
  return {
    fetchConfigs: () => dispatch(actions.getConfigsStart()),
  }
}


export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Configurations));