import React, { Component } from "react";
import { connect } from "react-redux";
import isEqual from "react-fast-compare";
import { Segment, Icon, Message } from "semantic-ui-react";
import { withRouter, Link } from "react-router-dom";
import ScrollLock from "react-scroll-lock-component";

import * as actions from "../../store/actions";
import Aux from "../../hoc/_Aux/_Aux";
import FilterGraph from "../../components/Dashboard/FilterGraph";
import Graph from "../../components/Dashboard/Graph";
import { warningMsg, infoMsg } from "../../components/UI/Message/Message";

const initialState = {
  selectedJob: {
    name: "",
    selectedServer: {
      name: "",
      os: "",
    },
    startTime: null,
    applicationName: "All",
    jobType: "",
  },
  filteredServers: [],
  serverLoading: false,
  showGraph: false,
  graphLoading: false,
};

class Dashboard extends Component {
  state = {
    ...initialState,
    jobList: [],
    jobNames: [],
    jobs: null,
    selectedGraph: "jmeter",
    graphTheme: "dark",
    isRefreshing: false,
    isConfigured: false,
    isConfigloading: true,
  };

  async componentDidMount() {
    this.props.getRunningJobs();
    setInterval(async () => this.props.getRunningJobs(), 10000);
    //this.props.getLRMetrics();
    // setInterval(async () => this.props.getLRMetrics(), 10000);
  }

  componentDidUpdate(prevProps, prevState) {
    if (!isEqual(prevState.jobNames, this.state.jobNames)) {
      const runningJobs = this.state.jobNames;

      if (runningJobs.length > prevState.jobNames.length) {
        infoMsg(
          "Build started for " +
            runningJobs
              .filter((jobname) => prevState.jobNames.indexOf(jobname) === -1)
              .join(", ")
        );
      } else if (runningJobs.length < prevState.jobs.length) {
        warningMsg(
          "Build completed for " +
            prevState.jobNames
              .filter((jobname) => runningJobs.indexOf(jobname) === -1)
              .join(", ")
        );

        if (runningJobs.indexOf(prevState.selectedJob.name) === -1) {
          this.setState({
            ...this.state,
            ...initialState,
          });
        }
      }
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      };
    }
    if (prevState.isConfigloading !== nextProps.configLoading) {
      return {
        ...prevState,
        isConfigloading: nextProps.configLoading,
      };
    }
    if (nextProps.JenkinsJob.getRunningJobs.list) {
      if (nextProps.JenkinsJob.getRunningJobs.list !== prevState.joblist) {
        let jobList = [];
        let jobNames = [];
        nextProps.JenkinsJob.getRunningJobs.list.map((job, index) => {
          console.log("inside Dashboard.js");
          console.log(job);
          jobList.push({ key: job.name, value: job.name, text: job.name });
          jobNames.push(job.name);
        });
        return {
          ...prevState,
          jobs: nextProps.JenkinsJob.getRunningJobs.list,
          jobList: jobList,
          jobNames: jobNames,
        };
      }
    }
    return null;
  }

  jobChangeHandler = (event, data) => {
    if (data.value !== this.state.selectedJob.name) {
      this.setState({
        ...this.state,
        serverLoading: true,
      });
      let filteredServers = [];
      const selectedJob = this.state.jobs.filter(
        (jobs) => jobs.name == data.value
      )[0];
      selectedJob.servers.map((server) => {
        filteredServers.push({
          key: server.name,
          value: server.name,
          text: server.name,
          icon: server.os,
        });
      });
      this.setState({
        ...this.state,
        selectedJob: {
          name: data.value,
          selectedServer: {
            name: "",
            os: "",
          },
          startTime: selectedJob.startTime,
          applicationName: selectedJob.applicationName,
          jobType: selectedJob.jobType,
        },
        filteredServers: filteredServers,
        serverLoading: false,
        showGraph: false,
      });
    }
  };

  serverChangeHandler = (event, data) => {
    if (this.state.selectedJob.selectedServer.name !== data.value) {
      this.setState(
        {
          ...this.state,
          selectedJob: {
            ...this.state.selectedJob,
            selectedServer: {
              name: data.value,
              os: this.state.filteredServers.filter(
                (server) => server.value == data.value
              )[0].icon,
            },
          },
          showGraph: false,
          graphLoading: true,
        },
        () => {
          setTimeout(() => {
            this.setState({
              ...this.state,
              showGraph: true,
              graphLoading: false,
            });
          }, 500);
        }
      );
    }
  };

  graphChangeHandler = (event, data) => {
    console.log(data);
    this.setState(
      {
        ...this.state,
        selectedGraph: data.id,
        graphLoading: true,
      },
      () => {
        setTimeout(() => {
          this.setState({
            ...this.state,
            graphLoading: false,
          });
        }, 1000);
      }
    );
  };

  changeGraphThemeHandler = (event, data) => {
    console.log(data.value);
    if (this.state.graphTheme !== data.value) {
      this.setState({
        ...this.state,
        graphTheme: data.value,
      });
    }
  };

  refreshGraph = () => {
    this.setState(
      {
        ...this.state,
        graphLoading: true,
        showGraph: false,
        selectedGraph: this.state.selectedGraph,
        isRefreshing: true,
      },
      () => {
        setTimeout(() => {
          this.setState({
            ...this.state,
            showGraph: true,
            graphLoading: false,
            isRefreshing: false,
          });
        }, 500);
      }
    );
  };

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.log(this.props);
    this.props.history.push("/configurations");
  };

  render() {
    let page = (
      <Segment>
        <Message icon info>
          <Icon name="circle notched" loading />
          <Message.Content>
            <Message.Header>Just one second</Message.Header>
            We are validating configs..
          </Message.Content>
        </Message>
      </Segment>
    );
    if (this.state.isConfigured) {
      page = (
        <Aux>
          <FilterGraph
            jobList={this.state.jobList}
            selectedJob={this.state.selectedJob}
            filteredServers={this.state.filteredServers}
            jobChangeHandler={this.jobChangeHandler}
            serverChangeHandler={this.serverChangeHandler}
            serverLoading={this.state.serverLoading}
            loading={
              this.props.JenkinsJob.getRunningJobs.loading && !this.state.jobs
            }
          />
          <ScrollLock>
            <div>
              <Graph
                showGraph={this.state.showGraph}
                grafanaURL={this.props.config.grafana}
                selectedJob={this.state.selectedJob}
                selectedGraph={this.state.selectedGraph}
                graphChangeHandler={this.graphChangeHandler}
                graphLoading={this.state.graphLoading}
                changeGraphThemeHandler={this.changeGraphThemeHandler}
                graphTheme={this.state.graphTheme}
                refreshGraph={this.refreshGraph}
                isRefreshing={this.state.isRefreshing}
              />
            </div>
          </ScrollLock>
        </Aux>
      );
    } else {
      page = (
        <Segment style={{ marginTop: "10px" }}>
          <Message warning>
            <Message.Header>
              You must update configuration before you can do that!
            </Message.Header>
            <p>
              Visit &nbsp; <Link to="/configurations">Configuration</Link>&nbsp;
              page, then try again.
            </p>
          </Message>
        </Segment>
      );
    }

    return page;
  }
}

const mapStateToProps = (state) => ({
  JenkinsJob: {
    getRunningJobs: {
      list: state.JenkinsJob.getRunningJobs.list,
      loading: state.JenkinsJob.getRunningJobs.loading,
      error: state.JenkinsJob.getRunningJobs.error,
      success: state.JenkinsJob.getRunningJobs.success,
    },
  },
  config: {
    grafana: state.JenkinsConfig.fetch.config.grafana,
  },
});

const mapDispatchToProps = (dispatch) => ({
  getRunningJobs: () => dispatch(actions.getRunningJobsStart()),
  fetchJob: () => dispatch(actions.fetchJobStart()),
  fetchPCJob: () => dispatch(actions.fetchPCJobStart()),
  fetchLRJob: () => dispatch(actions.fetchLRJobStart()),
  getLRMetrics: () => dispatch(actions.getLRMetricsStart()),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Dashboard)
);
