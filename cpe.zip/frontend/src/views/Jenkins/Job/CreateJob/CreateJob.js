import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter, Link } from "react-router-dom";
import { Card, CardHeader, CardBody } from "reactstrap";
import { Icon, Message } from "semantic-ui-react";
import JobDetails from "../../../../components/Jenkins/Job/CreateJob/JobDetails";
import JobSummary from "../../../../components/Jenkins/Job/CreateJob/JobSummary";
import * as actions from "../../../../store/actions";
import {
  errorMsg,
  successMsg,
  warningMsg,
} from "../../../../components/UI/Message/Message";

const initialState = {
  job: {
    name: "",
    release: "",
    description: "",
    jmeterScript: "",
    applicationName: "",
    email: "",
    bandwidth: 0,
    successTrigger: true,
    failureTrigger: true,
    beforebuildTrigger: false,
    enableSlave: false,
    slave: "",
    enableDistributedT: false,
    remoteHosts: ["localhost"],
    servers: [],
    enableProxy: false,
    proxyAddress: "",
    port: "",
    jobType: "jmeter",
  },
  tags: [{ name: "localhost" }],
  page: 1,
  isFormValid: false,
  tempServer: {
    name: "",
    os: "windows",
  },
  jobExists: false,
};
class CreateJob extends Component {
  state = {
    ...initialState,
    nodeList: null,
    isConfigured: false,
    isConfigloading: true,
  };

  componentDidMount = () => {
    this.props.fetchAllNodes();
    this.props.fetchAllJobs();
  };

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.JenkinsJob.createJob.success &&
      !prevProps.JenkinsJob.createJob.success
    ) {
      successMsg(
        "Job " +
          this.props.JenkinsJob.createJob.jobName +
          " created successfully!!"
      );
      this.setState({
        ...this.state,
        ...initialState,
      });
    }
    if (
      this.props.JenkinsJob.createJob.error &&
      !prevProps.JenkinsJob.createJob.error
    ) {
      errorMsg(this.props.JenkinsJob.createJob.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);
    let nodeList = [];

    if (nextProps.JenkinsNode.nodes.nodeList) {
      nextProps.JenkinsNode.nodes.nodeList.forEach((nodeName) => {
        console.log(nodeName);
        nodeList.push({ key: nodeName, value: nodeName, text: nodeName });
      });
    }

    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      };
    }
    if (prevState.isConfigloading !== nextProps.configLoading) {
      return {
        ...prevState,
        isConfigloading: nextProps.configLoading,
      };
    }

    if (nodeList !== prevState.nodeList) {
      return {
        ...prevState,
        nodeList: nodeList,
      };
    } else {
      return null;
    }
  }

  prevPageHandler = () => {
    this.setState({
      ...this.state,
      page: this.state.page - 1,
    });
  };

  nextPageHandler = () => {
    //alert(this.props.JenkinsJob.jobs.jobList);
    if (this.props.JenkinsJob.jobs.jobList === null) {
      this.setState({
        ...this.state,
        page: this.state.page + 1,
      });
    } else if (
      this.props.JenkinsJob.jobs.jobList.includes(this.state.job.name)
    ) {
      warningMsg("Job '" + this.state.job.name + "' already exists!");
      this.setState({
        ...this.state,
        jobExists: true,
      });
    } else {
      this.setState({
        ...this.state,
        page: this.state.page + 1,
      });
    }
  };

  isFormValid = () => {
    if (
      this.state.job.name &&
      this.state.job.release &&
      this.state.job.applicationName &&
      this.state.job.jmeterScript &&
      this.state.job.servers.length > 0 &&
      (this.state.job.enableProxy
        ? this.state.job.proxyAddress && this.state.job.port
        : true) &&
      this.state.job.email &&
      (this.state.job.enableSlave
        ? this.state.job.slave
          ? true
          : false
        : true) &&
      (this.state.job.enableDistributedT
        ? this.state.job.remoteHosts
          ? true
          : false
        : true)
    ) {
      this.setState(
        {
          ...this.state,
          isFormValid: true,
        },
        () => {
          console.log("valid form!");
        }
      );
    } else {
      this.setState(
        {
          ...this.state,
          isFormValid: false,
        },
        () => {
          console.log("invalid form!");
        }
      );
    }
  };

  dropdownChangeHandler = (event, data) => {
    console.log(data.value);
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          [data.id]: data.value,
        },
      },
      () => this.isFormValid()
    );
  };

  formChangeHandler = (event, data) => {
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          [data.id]: data.value,
        },
        jobExists:
          data.id == "name" && this.state.jobExists
            ? false
            : this.state.jobExists,
      },
      () => this.isFormValid()
    );
  };

  toggleCheckbox = (event) => {
    const target = event.target;
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          [target.id]: target.checked,
        },
      },
      () => this.isFormValid()
    );
  };

  handleBandwidthChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      job: {
        ...this.state.job,
        [data.id]: data.value,
        bandwidth: data.value,
      },
    });
  };

  addServersHandler = (event, data) => {
    console.log(data);
    const server = {
      name: this.state.tempServer.name,
      os: this.state.tempServer.os,
    };
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          servers: [].concat(this.state.job.servers, server),
        },
        tempServer: {
          name: "",
          os: "windows",
        },
      },
      () => this.isFormValid()
    );
  };

  removeServerHandler = (index) => {
    const servers = this.state.job.servers.slice(0);
    servers.splice(index, 1);
    console.log(servers);
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          servers: servers,
        },
      },
      () => this.isFormValid()
    );
  };

  handleServerChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        name: data.value,
      },
    });
  };

  handleOsChange = (event, data) => {
    console.log(data);
    this.setState({
      ...this.state,
      tempServer: {
        ...this.state.tempServer,
        os: data.value,
      },
    });
  };

  handleRemoteHostsDelete = (i) => {
    console.log(this.state);
    const tags = this.state.tags.slice(0);
    tags.splice(i, 1);
    this.setState(
      {
        ...this.state,
        tags: tags.filter((tag, index) => index !== i),
      },
      () => {
        let hosts = [];
        this.state.tags.map((host) => hosts.push(host.name));
        this.setState(
          {
            ...this.state,
            job: {
              ...this.state.job,
              remoteHosts: hosts,
            },
          },
          () => this.isFormValid()
        );
      }
    );
  };

  handleRemoteHostsAddition = (tag) => {
    const tags = [].concat(this.state.tags, tag);
    const hosts = this.state.job.remoteHosts;
    hosts.push(tag.name);
    this.setState(
      {
        ...this.state,
        job: {
          ...this.state.job,
          remoteHosts: hosts,
        },
        tags: tags,
      },
      () => this.isFormValid()
    );
  };

  discardJobHandler = () => {
    console.log("discardJobHandler");
    this.setState({
      ...this.state,
      ...initialState,
    });
  };

  addJobHandler = () => {
    this.props.createJob(this.state.job);
  };

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.log(this.props);
    this.props.history.push("/configurations");
  };

  render() {
    console.log(this.state.isConfigloading);
    let formPage = (
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create Job</small>
        </CardHeader>
        <CardBody>
          <Message icon info>
            <Icon name="circle notched" loading />
            <Message.Content>
              <Message.Header>Just one second</Message.Header>
              We are validating configs..
            </Message.Content>
          </Message>
        </CardBody>
      </Card>
    );
    if (this.state.isConfigured) {
      console.log(this.state);
      switch (this.state.page) {
        case 1:
          formPage = (
            <JobDetails
              job={this.state.job}
              jobExists={this.state.jobExists}
              formChangeHandler={this.formChangeHandler}
              nextPageHandler={this.nextPageHandler}
              toggleCheckbox={this.toggleCheckbox}
              dropdownChangeHandler={this.dropdownChangeHandler}
              isFormValid={this.state.isFormValid}
              nodeList={this.state.nodeList}
              handleRemoteHostsDelete={this.handleRemoteHostsDelete}
              handleRemoteHostsAddition={this.handleRemoteHostsAddition}
              handleRemoteHostsDrag={this.handleRemoteHostsDrag}
              tags={this.state.tags}
              addServersHandler={this.addServersHandler}
              removeServerHandler={this.removeServerHandler}
              handleServerChange={this.handleServerChange}
              handleOsChange={this.handleOsChange}
              handleBandwidthChange={this.handleBandwidthChange}
              tempServer={this.state.tempServer}
            />
          );
          break;
        case 2:
          formPage = (
            <JobSummary
              job={this.state.job}
              prevPageHandler={this.prevPageHandler}
              nextPageHandler={this.nextPageHandler}
              page={this.state.page}
            />
          );
          break;
        case 3:
          formPage = (
            <JobSummary
              job={this.state.job}
              prevPageHandler={this.prevPageHandler}
              nextPageHandler={this.nextPageHandler}
              page={this.state.page}
              addJobHandler={this.addJobHandler}
              discardJobHandler={this.discardJobHandler}
            />
          );
          break;
      }
    } else if (!this.state.isConfigloading) {
      formPage = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Job</small>
          </CardHeader>
          <CardBody>
            <Message warning>
              <Message.Header>
                You must update configuration before you can do that!
              </Message.Header>
              <p>
                Visit &nbsp; <Link to="/configurations">Configuration</Link>
                &nbsp; page, then try again.
              </p>
            </Message>
          </CardBody>
        </Card>
      );
    }
    return <div>{formPage}</div>;
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList,
      },
      createJob: {
        jobName: state.JenkinsJob.createJob.jobName,
        loading: state.JenkinsJob.createJob.loading,
        error: state.JenkinsJob.createJob.error,
        success: state.JenkinsJob.createJob.success,
      },
    },
    JenkinsNode: {
      nodes: {
        nodeList: state.JenkinsNode.nodes.nodeList,
        loading: state.JenkinsNode.nodes.loading,
        error: state.JenkinsNode.nodes.error,
      },
    },
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    createJob: (job) => dispatch(actions.createJobStart(job)),
    checkJob: (jobName) => dispatch(actions.checkForJobStart(jobName)),
    fetchAllNodes: () => dispatch(actions.fetchAllNodesStart()),
    fetchAllJobs: () => dispatch(actions.fetchAllJobsStart()),
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreateJob)
);
