import React, { Component } from "react";
import { connect } from "react-redux";
import { Col, Card, CardHeader, CardFooter, CardBody } from "reactstrap";
import { Button, Message, Dropdown } from "semantic-ui-react";
import { withRouter, Link } from "react-router-dom";

import "react-select/dist/react-select.css";
import ViewJob from "../../../../components/Jenkins/Job/UpdateJob/ViewJob";
import EditJob from "../../../../components/Jenkins/Job/UpdateJob/EditJob";
import * as actions from "../../../../store/actions";
import {
  errorMsg,
  successMsg,
} from "../../../../components/UI/Message/Message";

const initialState = {
  jobDetails: {
    name: "",
    release: 1,
    description: "",
    jmeterScript: "",
    applicationName: "",
    email: "",
    bandwidth: "",
    successTrigger: true,
    failureTrigger: true,
    beforebuildTrigger: false,
    enableSlave: false,
    slave: "",
    enableDistributedT: false,
    remoteHosts: ["localhost"],
    servers: [],
    enableProxy: false,
    proxyAddress: "",
    port: "",
    jobType: "jmeter",
  },
  page: "search",
  selectedJob: "",
  tags: [{ name: "localhost" }],
};

class UpdateJob extends Component {
  state = {
    ...initialState,
    jobList: null,
    nodeList: null,
    jobs: [{ value: "", label: "" }],
    isConfigured: false,
  };

  componentDidMount() {
    console.log("[UpdateJob] componentDidMount");
    this.props.fetchAllJobs(this.state.jobDetails.jobType);
    this.props.fetchAllNodes();
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.JenkinsJob.updateJob.success &&
      !prevProps.JenkinsJob.updateJob.success
    ) {
      successMsg(
        "Job " +
          this.props.JenkinsJob.updateJob.jobName +
          " updated successfully!!"
      );
      this.setState({
        ...this.state,
        ...initialState,
      });
    }

    if (
      this.props.JenkinsJob.updateJob.error &&
      !prevProps.JenkinsJob.updateJob.error
    ) {
      errorMsg(this.props.JenkinsJob.updateJob.error);
    }

    if (
      this.props.JenkinsJob.deleteJob.success &&
      !prevProps.JenkinsJob.deleteJob.success
    ) {
      successMsg(
        "Job " +
          this.props.JenkinsJob.deleteJob.jobName +
          " deleted successfully!!"
      );
      this.setState({
        ...this.state,
        ...initialState,
      });
    }

    if (
      this.props.JenkinsJob.deleteJob.error &&
      !prevProps.JenkinsJob.deleteJob.error
    ) {
      errorMsg(this.props.JenkinsJob.deleteJob.error);
    }

    if (
      this.props.JenkinsJob.fetchJob.error &&
      !prevProps.JenkinsJob.fetchJob.error
    ) {
      errorMsg(this.props.JenkinsJob.fetchJob.error);
      this.setState({
        ...this.state,
        page: "search",
      });
    }

    if (
      this.props.JenkinsJob.fetchJob.success &&
      !prevProps.JenkinsJob.fetchJob.success
    ) {
      this.setState({
        ...this.state,
        page: "view",
      });
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);

    let nodeList = [];

    if (nextProps.JenkinsNode.nodes.nodeList) {
      nextProps.JenkinsNode.nodes.nodeList.forEach((nodeName) => {
        nodeList.push({ key: nodeName, value: nodeName, text: nodeName });
      });
    }

    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      };
    }
    if (prevState.jobList !== nextProps.JenkinsJob.jobs.jobList) {
      return {
        ...prevState,
        jobList: nextProps.JenkinsJob.jobs.jobList,
      };
    }
    if (nextProps.JenkinsJob.fetchJob.job) {
      if (
        prevState.jobDetails.name !== nextProps.JenkinsJob.fetchJob.job.name
      ) {
        return {
          ...prevState,
          jobDetails: nextProps.JenkinsJob.fetchJob.job,
        };
      }
    }

    if (nodeList !== prevState.nodeList) {
      return {
        ...prevState,
        nodeList: nodeList,
      };
    }
    return null;
  }

  getJobDetails = () => {
    console.log(this.state.selectedJob);
    this.props.fetchJobFn(this.state.selectedJob);
  };

  setJobsHandler = (jobs) => {
    let options = [];
    for (let job of jobs) {
      options.push({ value: job, label: job });
    }
    console.log(options);

    this.setState({
      ...this.state,
      jobs: options,
    });
  };

  selectedJobHandler = (event, data) => {
    this.setState({
      ...this.state,
      selectedJob: data.value,
    });
  };

  editJobHandler = () => {
    console.log("editJobHandler");
    this.setState({
      ...this.state,
      page: "edit",
    });
  };

  updateJobHandler = (updatedJob) => {
    console.log("updateJobHandler");
    console.log(updatedJob);
    this.props.updateJobFn(updatedJob);
  };

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.group(this.props.history);
    this.props.history.push("/settings/configurations");
  };

  deleteJobHandler = () => {
    console.log("deleteJobHandler");
    this.props.deleteJobFn(this.state.jobDetails.name);
  };

  discardChangesHandler = () => {
    console.log("discardChangesHandler");
    this.setState({
      ...this.state,
      ...initialState,
    });
  };

  render() {
    let page = null;
    let searchBar = null;
    let options = [];
    console.dir(this.state.jobList);
    if (this.state.jobList) {
      for (let job of this.state.jobList) {
        options.push({ key: job, value: job, text: job });
      }
    }

    if (this.state.isConfigured) {
      searchBar = (
        <div>
          <Col md="12">
            <Card>
              <CardHeader>
                <strong>Jenkins</strong>
                <small> Select a Job</small>
              </CardHeader>
              <CardBody>
                <Dropdown
                  fluid
                  placeholder="Select a Job"
                  search
                  selection
                  options={options}
                  onChange={this.selectedJobHandler}
                  value={this.state.selectedJob}
                />
              </CardBody>
              <CardFooter>
                <Button
                  size="tiny"
                  color="blue"
                  loading={this.props.JenkinsJob.fetchJob.loading}
                  onClick={this.getJobDetails}
                  disabled={!this.state.selectedJob}
                >
                  View
                </Button>
              </CardFooter>
            </Card>
          </Col>
        </div>
      );

      switch (this.state.page) {
        case "search":
          page = null;
          break;
        case "view":
          page = (
            <ViewJob
              job={this.state.jobDetails}
              editJobHandler={this.editJobHandler}
              deleteJobHandler={this.deleteJobHandler}
            />
          );
          break;
        case "edit":
          page = (
            <EditJob
              discardChangesHandler={this.discardChangesHandler}
              jobDetails={this.state.jobDetails}
              nodeList={this.state.nodeList}
              updateJob={(updatedJob) => this.updateJobHandler(updatedJob)}
            />
          );
          break;
      }
    } else {
      searchBar = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Edit Job</small>
          </CardHeader>
          <CardBody>
            <CardBody>
              <Message warning>
                <Message.Header>
                  You must update configuration before you can do that!
                </Message.Header>
                <p>
                  Visit &nbsp; <Link to="/configurations">Configuration</Link>
                  &nbsp; page, then try again.
                </p>
              </Message>
            </CardBody>
          </CardBody>
        </Card>
      );
    }
    return (
      <div>
        {searchBar}
        {page}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList,
        loading: state.JenkinsJob.jobs.loading,
        error: state.JenkinsJob.jobs.error,
        success: state.JenkinsJob.jobs.success,
      },
      fetchJob: {
        job: state.JenkinsJob.fetchJob.job,
        loading: state.JenkinsJob.fetchJob.loading,
        error: state.JenkinsJob.fetchJob.error,
        success: state.JenkinsJob.fetchJob.success,
      },
      updateJob: {
        jobName: state.JenkinsJob.updateJob.jobName,
        loading: state.JenkinsJob.updateJob.loading,
        error: state.JenkinsJob.updateJob.error,
        success: state.JenkinsJob.updateJob.success,
      },
      deleteJob: {
        jobName: state.JenkinsJob.deleteJob.jobName,
        loading: state.JenkinsJob.deleteJob.loading,
        error: state.JenkinsJob.deleteJob.error,
        success: state.JenkinsJob.deleteJob.success,
      },
    },
    JenkinsNode: {
      nodes: {
        nodeList: state.JenkinsNode.nodes.nodeList,
        loading: state.JenkinsNode.nodes.loading,
        error: state.JenkinsNode.nodes.error,
      },
    },
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchAllJobs: (jobType) =>
      dispatch(actions.fetchAllRelativeJobsStart(jobType)),
    fetchJobFn: (jobName) => dispatch(actions.fetchJobStart(jobName)),
    updateJobFn: (updatedJob) => dispatch(actions.updateJobStart(updatedJob)),
    deleteJobFn: (jobName) => dispatch(actions.deleteJobStart(jobName)),
    fetchAllNodes: () => dispatch(actions.fetchAllNodesStart()),
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UpdateJob)
);
