import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
} from 'reactstrap';
import { Button, Icon, Message } from 'semantic-ui-react';
import { withRouter, Link } from "react-router-dom";

import 'react-select/dist/react-select.css';

import Select from 'react-select';

import ViewNode from '../../../components/Jenkins/Node/EditNode/ViewNode';

import EditNode from '../../../components/Jenkins/Node/EditNode/EditNode';

import * as actions from '../../../store/actions';

import { errorMsg, successMsg, warningMsg } from '../../../components/UI/Message/Message';
const initialState = {
  node: {
    name: '',
    description: '',
    rootDirectory: '',
  },
  page: "search",
  selectedNode: '',
}

class UpdateNode extends Component {

  state = {
    ...initialState,
    nodeList: null,
    jobList: null,
    nodes: [{ value: '', label: '' }],
    isConfigured: false
  }

  componentDidMount() {
    console.log("[UpdateNode] componentDidMount");
    this.props.fetchAllNodes();
  }

  componentDidUpdate(prevProps, prevState) {
    console.log(prevProps.deleteNode);
    console.log(this.props.deleteNode);
    if (this.props.JenkinsNode.fetchNode.success && !prevProps.JenkinsNode.fetchNode.success) {
      this.setState({
        ...prevState,
        page: "view"
      });
    }

    if (this.props.JenkinsNode.fetchNode.error && !prevProps.JenkinsNode.fetchNode.error) {
      errorMsg(this.props.JenkinsNode.fetchNode.error);
    }

    if (this.props.JenkinsNode.deleteNode.error && !prevProps.JenkinsNode.deleteNode.error) {
      errorMsg(this.props.JenkinsNode.deleteNode.error);
    }

    if (this.props.JenkinsNode.deleteNode.success && !prevProps.JenkinsNode.deleteNode.success) {
      this.setState({
        ...this.state,
        ...initialState
      })
      successMsg("Node " + this.props.JenkinsNode.deleteNode.nodeName + " deleted successfully!")
    }


    if (this.props.JenkinsNode.updateNode.error && !prevProps.JenkinsNode.updateNode.error) {
      errorMsg(this.props.JenkinsNode.updateNode.error);
    }

    if (this.props.JenkinsNode.updateNode.success && !prevProps.JenkinsNode.updateNode.success) {
      this.setState({
        ...this.state,
        ...initialState
      })
      successMsg("Node " + this.props.JenkinsNode.updateNode.nodeName + " updated successfully!")
    }


  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);
    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      }
    }
    if (prevState.nodeList !== nextProps.JenkinsNode.nodes.nodeList) {
      return {
        ...prevState,
        nodeList: nextProps.JenkinsNode.nodes.nodeList
      }
    }
    if (nextProps.JenkinsNode.fetchNode.node) {
      if (prevState.node.name !== nextProps.JenkinsNode.fetchNode.node.name) {
        return {
          ...prevState,
          node: nextProps.JenkinsNode.fetchNode.node
        }
      }
    }
    return null;
  }

  getNodeDetails = () => {
    this.props.fetchNodeFn(this.state.selectedNode.label);
  }

  setNodesHandler = (nodes) => {
    let options = [];
    for (let node of nodes) {
      options.push({ value: node, label: node })
    }
    console.log(options);

    this.setState({
      ...this.state,
      nodes: options
    });

  }

  selectedNodeHandler = (selectedOption) => {
    this.setState({
      ...this.state,
      selectedNode: selectedOption
    });
  }

  editNodeHandler = () => {
    console.log("editNodeHandler");
    this.setState({
      ...this.state,
      page: "edit"
    });
  }

  updateNodeHandler = (updatedNode) => {
    console.log("updateNodeHandler");
    this.props.updateNodeFn(updatedNode);
  }

  deleteNodeHandler = () => {
    console.log("deleteNodeHandler");
    this.props.deleteNodeFn(this.state.node.name)
  }

  discardChangesHandler = () => {
    this.setState({
      ...this.state,
      page: "search",
      selectedNode: '',
    })
  }

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.group(this.props.history);
    this.props.history.push('/settings/configurations');
  }

  render() {
    let page = null;
    let searchBar = null;
    let options = [];
    console.dir(this.state.nodeList);
    if (this.state.nodeList) {
      for (let job of this.state.nodeList) {
        options.push({ value: job, label: job })
      }
    }

    if (this.state.isConfigured) {
      searchBar = (
        <div>
          <Col md="12">
            <Card >
              <CardHeader>
                <strong>Jenkins</strong>
                <small> Select a Node</small>
              </CardHeader>
              <CardBody>
                <Select
                  name="form-field-name"
                  value={this.state.selectedNode}
                  onChange={this.selectedNodeHandler}
                  options={options || [
                    { value: '', label: '' }
                  ]}
                />
              </CardBody>
              <CardFooter>
                <Button size="tiny" color="blue"
                  disabled={!this.state.selectedNode}
                  loading={this.props.JenkinsNode.fetchNode.loading}
                  onClick={this.getNodeDetails}>View</Button>
              </CardFooter>
            </Card>
          </Col>
        </div>
      );

      switch (this.state.page) {
        case ("search"):
          page = null;
          break;
        case ("view"):
          page = <ViewNode
            node={this.state.node}
            editNodeHandler={this.editNodeHandler}
            deleteNodeHandler={this.deleteNodeHandler}
            deleteLoading={this.props.JenkinsNode.deleteNode.loading} />;
          break;
        case ("edit"):
          page = <EditNode
            jobList={this.state.jobList}
            node={this.state.node}
            updateNode={(updatedNode) => this.updateNodeHandler(updatedNode)}
            discardChangesHandler={this.discardChangesHandler}
            updateLoading={this.props.JenkinsNode.updateNode.loading} />;
          break;
      }
    } else {
      searchBar = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Node</small>
          </CardHeader>
          <CardBody>
            <CardBody>
              <Message warning>
                <Message.Header>You must update configuration before you can do that!</Message.Header>
                <p>Visit &nbsp; <Link to='/configurations'>Configuration</Link>&nbsp; page, then try again.</p>
              </Message>
            </CardBody>
          </CardBody>
        </Card>);
    }
    return (
      <div>
        {searchBar}
        {page}
      </div>
    )
  }
}


const mapStateToProps = (state) => {
  console.log(JSON.stringify(state));
  return {
    JenkinsNode: {
      nodes: {
        nodeList: state.JenkinsNode.nodes.nodeList
      },
      fetchNode: {
        node: state.JenkinsNode.fetchNode.node,
        error: state.JenkinsNode.fetchNode.error,
        success: state.JenkinsNode.fetchNode.success,
        loading: state.JenkinsNode.fetchNode.loading
      },
      deleteNode: {
        nodeName: state.JenkinsNode.deleteNode.nodeName,
        error: state.JenkinsNode.deleteNode.error,
        success: state.JenkinsNode.deleteNode.success,
        loading: state.JenkinsNode.deleteNode.loading
      },
      updateNode: {
        nodeName: state.JenkinsNode.updateNode.nodeName,
        error: state.JenkinsNode.updateNode.error,
        success: state.JenkinsNode.updateNode.success,
        loading: state.JenkinsNode.updateNode.loading
      },
    },
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList
      }
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchAllNodes: () => dispatch(actions.fetchAllNodesStart()),
    fetchNodeFn: nodeName => dispatch(actions.fetchNodeStart(nodeName)),
    updateNodeFn: updatedNode => dispatch(actions.updateNodeStart(updatedNode)),
    deleteNodeFn: nodeName => dispatch(actions.deleteNodeStart(nodeName))
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(UpdateNode));