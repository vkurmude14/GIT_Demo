import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter, Link } from "react-router-dom";
import { Card, CardHeader, CardBody } from 'reactstrap';
import { Button, Icon, Message, Grid } from 'semantic-ui-react';
import NodeDetails from '../../../components/Jenkins/Node/CreateNode/NodeDetails';
import NodeSummary from '../../../components/Jenkins/Node/CreateNode/NodeSummary';
import * as actions from '../../../store/actions';
import axios from '../../../axios';
import { errorMsg, successMsg, warningMsg } from '../../../components/UI/Message/Message';

const initialState = {
  node: {
    name: '',
    description: '',
    rootDirectory: ''
  },
  isFormValid: false,
  nodeExists: false
}

class CreateNode extends Component {
  state = {
    isConfigured: true,
    isConfigloading: false,
    isFormValid: false,
    showDwnldAgent: false,
    ...initialState
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.createNode.success && !prevProps.createNode.success) {
      successMsg("Node " + this.props.createNode.nodeName + " created successfully..");
      this.setState({
        ...prevState,
        ...initialState,
        showDwnldAgent: true
      }, () => setTimeout(() => {
        this.setState({
          ...prevState,
          showDwnldAgent: false
        })
      }, 10000))
    }
    if (this.props.createNode.error && !prevProps.createNode.error) {
      errorMsg(this.props.createNode.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {

    if (prevState.isConfigured !== nextProps.isConfigured) {
      console.log(nextProps.isConfigured);
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      }
    }

    if (prevState.isConfigloading !== nextProps.configLoading) {
      return {
        ...prevState,
        isConfigloading: nextProps.configLoading,
      }
    }
    return null;
  }

  componentDidMount() {
    console.log("componentDidMount");
    this.props.fetchAllNodes();
  }

  prevPageHandler = () => {
    this.setState({
      page: this.state.page - 1
    });
  }

  nextPageHandler = () => {
    this.setState({
      page: this.state.page + 1
    });
  }

  isFormValid = () => {
    if (this.state.node.name && this.state.node.description && this.state.node.rootDirectory) {
      this.setState({
        ...this.state,
        isFormValid: true
      }, () => {
      })
    } else {
      this.setState({
        ...this.state,
        isFormValid: false
      }, () => {
        console.log("invalid form!")
      })
    }
  }

  formChangeHandler = (event, data) => {
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        [data.id]: data.value
      },
      nodeExists: data.id == 'name' && this.state.nodeExists ? false : this.state.nodeExists,
    }, () => {
      this.isFormValid();
    });
  }

  dropdownChangeHandler = (target) => {
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        job: target.value
      }
    }, () => {
      this.isFormValid();
    });
  }

  toggleCheckbox = event => {
    const target = event.target;
    this.setState({
      ...this.state,
      node: {
        ...this.state.node,
        [target.id]: target.checked
      }
    });
  }

  discardNodeHandler = () => {
    console.log("discardNodeHandler");
    this.setState({
      ...this.state,
      ...initialState
    });
  }

  addNodeHandler = () => {
    console.log("addNodeHandler");
    if (this.props.nodeList.includes(this.state.node.name)) {
      warningMsg("Node '" + this.state.node.name + "' already exists!");
      this.setState({
        ...this.state,
        nodeExists: true
      })
    } else {
      this.props.createNodeFn(this.state.node);
    }

  }

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.log(this.props);
    this.props.history.push('/settings/configurations');
  }

  downloadSlaveAgent = () => {
    axios.get('downloadSlaveAgent', {
      params: { slaveName: this.props.createNode.nodeName }
    })
      .then(response => {
        console.log(response.data);
        fileDownload(response.data, 'slave-agent-' + this.props.createNode.nodeName + '.jnlp')
      })
      .catch(error => console.log(error.message));
  }

  handleInfoboxDismiss = () => {
    this.setState({
      ...this.state,
      showDwnldAgent: false
    })
  }

  render() {

    const infoboxSlaveAgent = (
      <Message warning onDismiss={this.handleInfoboxDismiss} >
        <Grid>
          <Grid.Row style={{ marginTop: "5px", marginLeft: "5px" }} verticalAlign="bottom">
            <Grid.Column width="1">
              <Button icon='download' color='orange' onClick={this.downloadSlaveAgent} />
            </Grid.Column>
            <Grid.Column width="15">
              <Message.Header>Slave-Agent</Message.Header>
              <p>Download slave-agent and run on slave machine..</p>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </Message>);

    console.log(this.state);
    let pageTable = null;
    let pageEdit = (
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create Node</small>
        </CardHeader>
        <CardBody>
          <Message icon info>
            <Icon name='circle notched' loading />
            <Message.Content>
              <Message.Header>Just one second</Message.Header>
              We are validating configs..
            </Message.Content>
          </Message>
        </CardBody>
      </Card>);

    if (this.state.isConfigured) {
      console.log(this.state);
      pageTable = (<NodeSummary
        node={this.state.node}
        isFormValid={this.state.isFormValid}
        addNodeHandler={this.addNodeHandler}
        discardNodeHandler={this.discardNodeHandler}
        createLoading={this.props.createNode.loading} />);

      pageEdit = (<NodeDetails node={this.state.node}
        formChangeHandler={this.formChangeHandler}
        nextPageHandler={this.nextPageHandler}
        dropdownChangeHandler={(jobName) => this.dropdownChangeHandler(jobName)}
        isFormValid={this.state.isFormValid}
        nodeExists={this.state.nodeExists}
        createLoading={this.props.createNode.loading} />);
    } else if (!this.state.isConfigloading) {
      pageEdit = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Node</small>
          </CardHeader>
          <CardBody>
            <Message warning>
              <Message.Header>You must update configuration before you can do that!</Message.Header>
              <p>Visit &nbsp; <Link to='/configurations'>Configuration</Link>&nbsp; page, then try again.</p>
            </Message>
          </CardBody>
        </Card>);
    }

    return (
      <div >
        {pageEdit}
        {pageTable}
        {this.state.showDwnldAgent ? infoboxSlaveAgent : null}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    jobList: state.JenkinsJob.jobs.jobList,
    nodeList: state.JenkinsNode.nodes.nodeList,
    createNode: {
      nodeName: state.JenkinsNode.createNode.nodeName,
      error: state.JenkinsNode.createNode.error,
      loading: state.JenkinsNode.createNode.loading,
      success: state.JenkinsNode.createNode.success,
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    createNodeFn: node => dispatch(actions.createNodeStart(node)),
    fetchAllNodes: () => dispatch(actions.fetchAllNodesStart())
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CreateNode));