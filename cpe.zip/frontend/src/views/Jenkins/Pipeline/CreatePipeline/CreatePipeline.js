import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter, Link } from "react-router-dom";
import {
  Row,
  Col,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Collapse,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Table,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';
import { Button, Icon, Message } from 'semantic-ui-react';
import Spinner from '../../../../components/Spinner/Spinner';
import axios from 'axios';
import PipelineDetails from '../../../../components/Jenkins/Pipeline/CreatePipeline/PipelineDetails';
import PipelineSummary from '../../../../components/Jenkins/Pipeline/CreatePipeline/PipelineSummary';
import * as actions from '../../../../store/actions';
import { errorMsg, successMsg, warningMsg } from '../../../../components/UI/Message/Message';

const initialState = {
  pipeline: {
    name: '',
    job: '',
    release: ''
  },
  isFormValid: false,
  pipelineExists: false
}

class CreatePipeline extends Component {
  state = {
    jobList: null,
    pipelineList: null,
    isConfigured: true,
    isConfigloading: false,
    isFormValid: false,
    ...initialState
  }

  componentDidUpdate = (prevProps, prevState) => {

    if (!prevProps.JenkinsPipeline.createPipeline.success && this.props.JenkinsPipeline.createPipeline.success) {
      successMsg("Pipeline '" + this.props.JenkinsPipeline.createPipeline.pipelineName + "' created successfully!!");
      this.setState({
        ...this.state,
        ...initialState,
      })
    }

    if (!prevProps.JenkinsPipeline.createPipeline.error && this.props.JenkinsPipeline.createPipeline.error) {
      errorMsg(this.props.JenkinsPipeline.createPipeline.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);
    let jobList = [];

    if (nextProps.JenkinsJob.jobs.jobList) {
      (nextProps.JenkinsJob.jobs.jobList).forEach(jobname => {
        console.log(jobname);
        jobList.push({ key: jobname, value: jobname, text: jobname })
      });
    }

    if (prevState.isConfigured !== nextProps.isConfigured) {
      console.log(nextProps.isConfigured);
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      }
    }

    if (prevState.pipelineList !== nextProps.JenkinsPipeline.pipelines.pipelineList) {
      console.log("............");
      return {
        ...prevState,
        pipelineList: nextProps.JenkinsPipeline.pipelines.pipelineList
      }
    }

    if (jobList !== prevState.jobList) {
      return {
        ...prevState,
        jobList: jobList,
      }
    }

    if (prevState.isConfigloading !== nextProps.configLoading) {
      return {
        ...prevState,
        isConfigloading: nextProps.configLoading,
      }
    }
  }

  componentDidMount() {
    console.log("componentDidMount");
    this.props.fetchAllJobs();
    this.props.fetchAllPipelines();
  }

  prevPageHandler = () => {
    this.setState({
      page: this.state.page - 1
    });
  }

  nextPageHandler = () => {
    this.setState({
      page: this.state.page + 1
    });
  }

  isFormValid = () => {
    if (this.state.pipeline.name && this.state.pipeline.job) {
      this.setState({
        ...this.state,
        isFormValid: true
      }, () => {
      })
    } else {
      this.setState({
        ...this.state,
        isFormValid: false
      }, () => {
        console.log("invalid form!");
      })
    }
  }

  formChangeHandler = (event, data) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [data.id]: data.value
      },
      pipelineExists: data.id == 'name' && this.state.pipelineExists ? false : this.state.pipelineExists,
    }, () => {
      this.isFormValid();
    });
  }

  dropdownChangeHandler = (event, data) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        job: data.value
      }
    }, () => {
      this.isFormValid();
    });
  }

  toggleCheckbox = event => {
    const target = event.target;
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [target.id]: target.checked
      }
    });
  }

  discardPipelineHandler = () => {
    console.log("discardPipelineHandler");
    this.setState({
      ...this.state,
      ...initialState
    });
  }

  addPipelineHandler = () => {
    console.log(this.state.pipelineList)
    this.state.pipelineList.includes(this.state.pipeline.name) ?
      this.setState({
        ...this.state,
        pipelineExists: true
      }, () => warningMsg("Pipeline '" + this.state.pipeline.name + "' already exists!")) :
      this.setState({
        ...this.state,
        pipelineExists: false
      }, () => this.props.createPipelineFn(this.state.pipeline));


  }

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.log(this.props);
    this.props.history.push('/configurations');
  }

  render() {
    console.log(this.state);
    let pageTable = null;
    let pageEdit = (
      <Card>
        <CardHeader>
          <strong>Jenkins</strong>
          <small> Create Pipeline</small>
        </CardHeader>
        <CardBody>
          <Message icon info>
            <Icon name='circle notched' loading />
            <Message.Content>
              <Message.Header>Just one second</Message.Header>
              We are validating configs..
            </Message.Content>
          </Message>
        </CardBody>
      </Card>);

    if (this.state.isConfigured) {
      console.log(this.state);
      pageTable = (<PipelineSummary
        pipeline={this.state.pipeline}
        isFormValid={this.state.isFormValid}
        addPipelineHandler={this.addPipelineHandler}
        discardPipelineHandler={this.discardPipelineHandler}
        submitLoading={this.props.JenkinsPipeline.createPipeline.loading} />);

      pageEdit = (<PipelineDetails pipeline={this.state.pipeline}
        formChangeHandler={this.formChangeHandler}
        nextPageHandler={this.nextPageHandler}
        dropdownChangeHandler={this.dropdownChangeHandler}
        isFormValid={this.state.isFormValid}
        jobList={this.state.jobList}
        pipelineExists={this.state.pipelineExists}
        submitLoading={this.props.JenkinsPipeline.createPipeline.loading} />);
    } else if (!this.state.isConfigloading) {
      pageEdit = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Pipeline</small>
          </CardHeader>
          <CardBody>
            <Message warning>
              <Message.Header>You must update configuration before you can do that!</Message.Header>
              <p>Visit &nbsp; <Link to='/configurations'>Configuration</Link>&nbsp; page, then try again.</p>
            </Message>
          </CardBody>
        </Card>);
    }

    return (
      <div >
        {pageEdit}
        {pageTable}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList
      }
    },
    JenkinsPipeline: {
      pipelines: {
        pipelineList: state.JenkinsPipeline.pipelines.pipelineList
      },
      createPipeline: {
        pipelineName: state.JenkinsPipeline.createPipeline.pipelineName,
        error: state.JenkinsPipeline.createPipeline.error,
        loading: state.JenkinsPipeline.createPipeline.loading,
        success: state.JenkinsPipeline.createPipeline.success,
      }
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchAllPipelines: () => dispatch(actions.fetchAllPipelinesStart()),
    fetchAllJobs: () => dispatch(actions.fetchAllJobsStart()),
    createPipelineFn: pipeline => dispatch(actions.createPipelineStart(pipeline)),
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CreatePipeline));