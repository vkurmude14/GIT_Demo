import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,

} from 'reactstrap';
import { Button, Icon, Message } from 'semantic-ui-react';
import { withRouter, Link } from "react-router-dom";

import 'react-select/dist/react-select.css';

import Select from 'react-select';

import axios from 'axios';

import Spinner from '../../../../components/Spinner/Spinner';

import ViewPipeline from '../../../../components/Jenkins/Pipeline/UpdatePipeline/ViewPipeline';

import EditPipeline from '../../../../components/Jenkins/Pipeline/UpdatePipeline/EditPipeline';

import * as actions from '../../../../store/actions';

import { errorMsg, successMsg, warningMsg } from '../../../../components/UI/Message/Message';

// import { pipeline } from 'stream';
const initialState = {
  pipeline: {
    name: '',
    release: '',
    jobName: ''
  },
  page: "search",
  selectedPipeline: '',
}
class UpdatePipeline extends Component {

  state = {
    ...initialState,
    pipelineList: null,
    jobList: null,
    isConfigured: false
  }

  componentDidMount() {
    console.log("[UpdatePipeline] componentDidMount");
    this.props.fetchAllPipelines();
    this.props.fetchAllJobs();
  }

  componentDidUpdate = (prevProps, prevState) => {

    if (!prevProps.JenkinsPipeline.pipelineStages.success && this.props.JenkinsPipeline.pipelineStages.success) {
      this.props.JenkinsPipeline.pipelineStages.list.indexOf("Performance Test") > -1 ?
        this.props.fetchPipelineFn(this.state.selectedPipeline.label) :
        this.setState({
          prevState,
          page: "view"
        });;
    }

    if (!prevProps.JenkinsPipeline.pipelineStages.error && this.props.JenkinsPipeline.pipelineStages.error) {
      errorMsg(this.props.JenkinsPipeline.pipelineStages.error);
    }

    if (!prevProps.JenkinsPipeline.fetchPipeline.success && this.props.JenkinsPipeline.fetchPipeline.success) {
      this.setState({
        prevState,
        page: "view"
      });
    }

    if (!prevProps.JenkinsPipeline.fetchPipeline.error && this.props.JenkinsPipeline.fetchPipeline.error) {
      this.setState({
        prevState,
        page: "search"
      });
      errorMsg(this.props.JenkinsPipeline.fetchPipeline.error);
    }

    if (!prevProps.JenkinsPipeline.updatePipeline.success && this.props.JenkinsPipeline.updatePipeline.success) {
      successMsg("Pipeline '" + this.props.JenkinsPipeline.updatePipeline.pipelineName + "' updated successfully!!");
      this.setState({
        ...this.state,
        ...initialState,
      })
    }

    if (!prevProps.JenkinsPipeline.updatePipeline.error && this.props.JenkinsPipeline.updatePipeline.error) {
      errorMsg(this.props.JenkinsPipeline.updatePipeline.error);
    }


    if (!prevProps.JenkinsPipeline.deletePipeline.success && this.props.JenkinsPipeline.deletePipeline.success) {
      successMsg("Pipeline '" + this.props.JenkinsPipeline.deletePipeline.pipelineName + "' deleted successfully!!");
      this.setState({
        ...this.state,
        ...initialState,
      })
    }

    if (!prevProps.JenkinsPipeline.deletePipeline.error && this.props.JenkinsPipeline.deletePipeline.error) {
      errorMsg(this.props.JenkinsPipeline.deletePipeline.error);
    }
  }


  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);
    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      }
    }
    if (prevState.pipelineList !== nextProps.JenkinsPipeline.pipelines.pipelineList) {
      return {
        ...prevState,
        pipelineList: nextProps.JenkinsPipeline.pipelines.pipelineList
      }
    }
    if (nextProps.JenkinsPipeline.fetchPipeline.pipeline) {
      if (prevState.pipeline.name !== nextProps.JenkinsPipeline.fetchPipeline.pipeline.name) {
        return {
          ...prevState,
          pipeline: nextProps.JenkinsPipeline.fetchPipeline.pipeline
        }
      }
    }

    if (nextProps.JenkinsJob.jobs.jobList) {
      let jobList = [];
      (nextProps.JenkinsJob.jobs.jobList).forEach(jobname => {
        jobList.push({ key: jobname, value: jobname, text: jobname })
      });
      if (jobList !== prevState.jobList) {
        return {
          ...prevState,
          jobList: jobList,
        }
      }
    }
    return null;
  }

  getPipelineDetails = () => {
    console.log(this.state.selectedPipeline.label);
    this.props.fetchPipelineStages(this.state.selectedPipeline.label);
    // this.props.fetchPipeline(this.state.selectedPipeline.label);
    // this.setState({
    //   ...this.state,
    //   page: "view"
    // });
  }

  setPipelinesHandler = (pipelines) => {
    let options = [];
    for (let pipeline of pipelines) {
      options.push({ value: pipeline, label: pipeline })
    }
    console.log(options);

    this.setState({
      ...this.state,
      pipelines: options
    });

  }

  selectedPipelineHandler = (selectedOption) => {
    this.setState({
      ...this.state,
      selectedPipeline: selectedOption
    });
  }

  editPipelineHandler = () => {
    console.log("editPipelineHandler");
    this.setState({
      ...this.state,
      page: "edit"
    });
  }

  updatePipelineHandler = (updatedPipeline) => {
    console.log("updatePipelineHandler");
    console.log(updatedPipeline);
    this.props.updatePipelineFn(updatedPipeline);
  }

  deletePipelineHandler = () => {
    console.log("deletePipelineHandler");
    this.props.deletePipelineFn(this.state.pipeline.name)
  }

  discardChangesHandler = () => {
    this.setState({
      ...this.state,
      page: "search",
      selectedPipeline: '',
    })
  }

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.group(this.props.history);
    this.props.history.push('/configurations');
  }

  render() {
    let page = null;
    let searchBar = null;
    let options = [];
    console.dir(this.state.pipelineList);
    if (this.state.pipelineList) {
      for (let job of this.state.pipelineList) {
        options.push({ value: job, label: job })
      }
    }

    if (this.state.isConfigured) {
      searchBar = (
        <div>
          <Col md="12">
            <Card >
              <CardHeader>
                <strong>Jenkins</strong>
                <small> Select a Pipeline</small>
              </CardHeader>
              <CardBody>
                <Select
                  name="form-field-name"
                  value={this.state.selectedPipeline}
                  onChange={this.selectedPipelineHandler}
                  options={options || [
                    { value: '', label: '' }
                  ]}
                />
              </CardBody>
              <CardFooter>
                <Button size="tiny" color="blue"
                  onClick={this.getPipelineDetails}
                  disabled={!this.state.selectedPipeline}
                  loading={this.props.JenkinsPipeline.fetchPipeline.loading} >View</Button>
              </CardFooter>
            </Card>
          </Col>
        </div>
      );

      switch (this.state.page) {
        case ("search"):
          page = null;
          break;
        case ("view"):
          page = <ViewPipeline
            pipeline={this.state.pipeline}
            pipelineStages={this.props.JenkinsPipeline.pipelineStages.list}
            editPipelineHandler={this.editPipelineHandler}
            deletePipelineHandler={this.deletePipelineHandler}
            deleteLoading={this.props.JenkinsPipeline.deletePipeline.loading} />;
          break;
        case ("edit"):
          page = <EditPipeline
            jobList={this.state.jobList}
            pipeline={this.state.pipeline}
            updatePipeline={(updatedPipeline) => this.updatePipelineHandler(updatedPipeline)}
            discardChangesHandler={this.discardChangesHandler}
            updateLoading={this.props.JenkinsPipeline.updatePipeline.loading} />;
          break;
      }
    } else {
      searchBar = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Pipeline</small>
          </CardHeader>
          <CardBody>
            <CardBody>
              <Message warning>
                <Message.Header>You must update configuration before you can do that!</Message.Header>
                <p>Visit &nbsp; <Link to='/configurations'>Configuration</Link>&nbsp; page, then try again.</p>
              </Message>
            </CardBody>
          </CardBody>
        </Card>);
    }
    return (
      <div>
        {searchBar}
        {page}
      </div>
    )
  }
}


const mapStateToProps = (state) => {
  console.log(state);
  return {
    JenkinsPipeline: {
      pipelines: {
        pipelineList: state.JenkinsPipeline.pipelines.pipelineList
      },
      fetchPipeline: {
        pipeline: state.JenkinsPipeline.fetchPipeline.pipeline,
        error: state.JenkinsPipeline.fetchPipeline.error,
        loading: state.JenkinsPipeline.fetchPipeline.loading,
        success: state.JenkinsPipeline.fetchPipeline.success,
      },
      pipelineStages: {
        list: state.JenkinsPipeline.pipelineStages.list,
        error: state.JenkinsPipeline.pipelineStages.error,
        loading: state.JenkinsPipeline.pipelineStages.loading,
        success: state.JenkinsPipeline.pipelineStages.success,
      },
      updatePipeline: {
        pipelineName: state.JenkinsPipeline.updatePipeline.pipelineName,
        error: state.JenkinsPipeline.updatePipeline.error,
        loading: state.JenkinsPipeline.updatePipeline.loading,
        success: state.JenkinsPipeline.updatePipeline.success,
      },
      deletePipeline: {
        pipelineName: state.JenkinsPipeline.deletePipeline.pipelineName,
        error: state.JenkinsPipeline.deletePipeline.error,
        loading: state.JenkinsPipeline.deletePipeline.loading,
        success: state.JenkinsPipeline.deletePipeline.success,
      }
    },
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList
      }
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchAllPipelines: () => dispatch(actions.fetchAllPipelinesStart()),
    fetchAllJobs: () => dispatch(actions.fetchAllJobsStart()),
    fetchPipelineFn: pipelineName => dispatch(actions.fetchPipelineStart(pipelineName)),
    updatePipelineFn: updatedPipeline => dispatch(actions.updatePipelineStart(updatedPipeline)),
    deletePipelineFn: pipelineName => dispatch(actions.deletePipelineStart(pipelineName)),
    fetchPipelineStages: pipelineName => dispatch(actions.fetchPipelineStagesStart(pipelineName)),
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(UpdatePipeline));