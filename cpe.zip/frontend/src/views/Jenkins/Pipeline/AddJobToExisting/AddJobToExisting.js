import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardFooter,
  CardBody,

} from 'reactstrap';
import { Button, Icon, Message, Dropdown, Transition } from 'semantic-ui-react';
import { withRouter, Link } from "react-router-dom";

import 'react-select/dist/react-select.css';

import AddStage from '../../../../components/Jenkins/Pipeline/AddToExisting/AddStage';

import * as actions from '../../../../store/actions';
import { errorMsg, successMsg, warningMsg } from '../../../../components/UI/Message/Message';

// import { pipeline } from 'stream';
const initialState = {
  pipeline: {
    name: '',
    stageRef: "",
    where: "after",
    jobName: '',
    release: '',
  },
  pipelineStages: null,
  showStages: false,
  selectedPipeline: '',
  isFormValid: false,
}

class AddJobToExisting extends Component {

  state = {
    ...initialState,
    pipelineStages: null,
    pipelineList: null,
    jobList: null,
    isConfigured: false
  }

  componentDidMount() {
    console.log("[AddJobToExisting] componentDidMount");
    this.props.fetchAllPipelines();
  }

  componentDidUpdate = (prevProps, prevState) => {

    if (!prevProps.JenkinsPipeline.pipelineStages.success && this.props.JenkinsPipeline.pipelineStages.success) {
      this.setState({
        ...this.state,
        showStages: true
      });
    }

    if (!prevProps.JenkinsPipeline.pipelineStages.error  && this.props.JenkinsPipeline.pipelineStages.error) {
      errorMsg(this.props.JenkinsPipeline.pipelineStages.error);
    }

    if (!prevProps.JenkinsPipeline.addJobToExisting.success && this.props.JenkinsPipeline.addJobToExisting.success) {
      successMsg("Performance Stage is added to '" + this.props.JenkinsPipeline.addJobToExisting.pipelineName + "' pipeline!");
      this.setState({
        ...this.state,
        ...initialState,
      })
    }

    if (!prevProps.JenkinsPipeline.addJobToExisting.error && this.props.JenkinsPipeline.addJobToExisting.error) {
      errorMsg(this.props.JenkinsPipeline.addJobToExisting.error);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.isConfigured);
    if (prevState.isConfigured !== nextProps.isConfigured) {
      return {
        ...prevState,
        isConfigured: nextProps.isConfigured,
      }
    }
    if (prevState.pipelineList !== nextProps.JenkinsPipeline.pipelines.pipelineList) {
      return {
        ...prevState,
        pipelineList: nextProps.JenkinsPipeline.pipelines.pipelineList
      }
    }
    if (nextProps.JenkinsPipeline.pipelineStages.list) {
      if (prevState.pipelineStages !== nextProps.JenkinsPipeline.pipelineStages.list) {
        return {
          ...prevState,
          pipelineStages: nextProps.JenkinsPipeline.pipelineStages.list
        }
      }
    }

    if (nextProps.JenkinsJob.jobs.jobList) {
      console.log(nextProps.JenkinsJob.jobs.jobList);
      let jobList = [];
      (nextProps.JenkinsJob.jobs.jobList).forEach(jobname => {
        jobList.push({ key: jobname, value: jobname, text: jobname })
      });
      if (jobList !== prevState.jobList) {
        return {
          ...prevState,
          jobList: jobList,
        }
      };
    }
    return null;
  }

  isFormValid = () => {
    if (this.state.pipeline.jobName && this.state.pipeline.release &&
      (this.state.pipelineStages.length !== 0 ? this.state.pipeline.stageRef ? true : false : true)) {
      this.setState({
        ...this.state,
        isFormValid: true
      }, () => {
      })
    } else {
      this.setState({
        ...this.state,
        isFormValid: false
      }, () => {
        console.log("invalid form!")
      })
    }
  }

  getPipelineDetails = () => {
    console.log(this.state.selectedPipeline);
    this.props.fetchPipelineStages(this.state.selectedPipeline);
    this.props.fetchAllJobs();
  }

  selectedPipelineHandler = (event, data) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        name: data.value
      },
      selectedPipeline: data.value
    });
  }

  submitHandler = () => {
    console.log("updatePipelineHandler");
    console.log();
    let pipeline;
    this.state.pipeline.stageRef ?
      pipeline = {
        ...this.state.pipeline,
      } : pipeline = {
        ...this.state.pipeline,
        where: "starting"
      }
    this.props.AddJobToExisting(pipeline);
  }


  discardChangesHandler = () => {
    this.setState({
      ...this.state,
      ...initialState,
    })
  }

  gotoConfiguration = (e) => {
    e.preventDefault();
    console.group(this.props.history);
    this.props.history.push('/configurations');
  }

  formChangeHandler = (event, data) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [data.id]: data.value
      }
    }, () => {
      this.isFormValid();
    });
  }

  dropdownChangeHandler = (event, data) => {
    this.setState({
      ...this.state,
      pipeline: {
        ...this.state.pipeline,
        [data.id]: data.value
      }
    }, () => {
      this.isFormValid();
    });
  }

  render() {
    let page = null;
    let searchBar = null;
    let options = [];
    console.log(this.state.pipelineList);
    if (this.state.pipelineList) {
      for (let job of this.state.pipelineList) {
        // options.push({ value: job, label: job })
        options.push({ key: job, value: job, text: job })
      }
    }

    if (this.state.isConfigured) {
      searchBar = (
        <div>
          <Col md="12">
            <Card >
              <CardHeader>
                <strong>Jenkins</strong>
                <small> Select a Pipeline</small>
              </CardHeader>
              <CardBody>
                <Dropdown fluid placeholder='Select a Pipeline'
                  search selection options={options}
                  onChange={this.selectedPipelineHandler}
                  value={this.state.selectedPipeline} />
              </CardBody>
              <CardFooter>
                <Button size="tiny" color="blue"
                  onClick={this.getPipelineDetails}
                  disabled={!this.state.selectedPipeline}
                  loading={this.props.JenkinsPipeline.pipelineStages.loading} >View</Button>
              </CardFooter>
            </Card>
          </Col>
        </div>
      );
      page = (this.state.showStages &&
        <AddStage
          pipelineStages={this.state.pipelineStages}
          stagesloading={this.props.JenkinsPipeline.pipelineStages.loading}
          jobList={this.state.jobList}
          discardChangesHandler={this.discardChangesHandler}
          submitHandler={(updatedPipeline) => this.submitHandler(updatedPipeline)}
          dropdownChangeHandler={this.dropdownChangeHandler}
          formChangeHandler={this.formChangeHandler}
          pipeline={this.state.pipeline}
          isFormValid={this.state.isFormValid}
          submitLoading={this.props.JenkinsPipeline.addJobToExisting.loading}
        />);

    } else {
      searchBar = (
        <Card>
          <CardHeader>
            <strong>Jenkins</strong>
            <small> Create Pipeline</small>
          </CardHeader>
          <CardBody>
            <CardBody>
              <Message warning>
                <Message.Header>You must update configuration before you can do that!</Message.Header>
                <p>Visit &nbsp; <Link to='/configurations'>Configuration</Link>&nbsp; page, then try again.</p>
              </Message>
            </CardBody>
          </CardBody>
        </Card>);
    }
    return (
      <div>
        {searchBar}
        {page}
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    JenkinsPipeline: {
      pipelines: {
        pipelineList: state.JenkinsPipeline.pipelines.pipelineList
      },
      pipelineStages: {
        list: state.JenkinsPipeline.pipelineStages.list,
        error: state.JenkinsPipeline.pipelineStages.error,
        loading: state.JenkinsPipeline.pipelineStages.loading,
        success: state.JenkinsPipeline.pipelineStages.success,
      },
      addJobToExisting: {
        pipelineName: state.JenkinsPipeline.addJobToExisting.pipelineName,
        error: state.JenkinsPipeline.addJobToExisting.error,
        loading: state.JenkinsPipeline.addJobToExisting.loading,
        success: state.JenkinsPipeline.addJobToExisting.success,
      }
    },
    JenkinsJob: {
      jobs: {
        jobList: state.JenkinsJob.jobs.jobList
      }
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    fetchAllPipelines: () => dispatch(actions.fetchAllPipelinesStart()),
    fetchPipelineStages: pipelineName => dispatch(actions.fetchPipelineStagesStart(pipelineName)),
    fetchAllJobs: () => dispatch(actions.fetchAllJobsStart()),
    AddJobToExisting: (pipeline) => dispatch(actions.addJobToExistingStart(pipeline)),
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AddJobToExisting));