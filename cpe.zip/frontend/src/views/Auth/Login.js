import React, { Component } from 'react';
import { Input, Card, CardFooter, CardBody, CardGroup, Col, Container, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';
import { Button, Segment, Divider, Message } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import * as actions from '../../store/actions';

class Login extends Component {
  state = {
    controls: {
      username: {
        value: '',
        validation: {
          required: true,
        },
        valid: false,
        touched: false
      },
      password: {
        value: '',
        validation: {
          required: true,
          minLength: 6
        },
        valid: false,
        touched: false
      }
    },
    isSignup: false
  }
  // static getDerivedStateFromProps(nextProps, prevState) {
  //   if (!nextProps.loading) {
  //     if (prevState.isSignup) {
  //       console.log("working");
  //     }

  //   }
  // }

  componentDidMount() {
    if (this.props.authRedirectPath !== '/') {
      this.props.onSetAuthRedirectPath();
    }
    if (this.props.isSignup) {
      console.log("isAuthenticated....");
      this.props.createUser({ userId: localStorage.userId, email: this.props.email, role: "user" });
    }
  }

  checkValidity(value, rules) {
    let isValid = true;
    if (!rules) {
      return true;
    }

    if (rules.required) {
      isValid = value.trim() !== '' && isValid;
    }

    if (rules.minLength) {
      isValid = value.length >= rules.minLength && isValid
    }

    if (rules.maxLength) {
      isValid = value.length <= rules.maxLength && isValid
    }

    if (rules.isEmail) {
      const pattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
      isValid = pattern.test(value) && isValid
    }

    if (rules.isNumeric) {
      const pattern = /^\d+$/;
      isValid = pattern.test(value) && isValid
    }

    return isValid;
  }

  inputChangedHandler = (event, controlName) => {
    const updatedControls = {
      ...this.state.controls,
      [controlName]: {
        ...this.state.controls[controlName],
        value: event.target.value,
        valid: this.checkValidity(event.target.value, this.state.controls[controlName].validation),
        touched: true
      }
    };
    this.setState({ controls: updatedControls });
  }

  submitHandler = (event) => {
    event.preventDefault();
    this.props.onAuth(this.state.controls.username.value, this.state.controls.password.value, this.state.isSignup);
  }

  switchAuthModeHandler = () => {
    this.setState(prevState => {
      return { isSignup: !prevState.isSignup };
    });
  }

  render() {
    let errorMessage = null;
    if (this.props.error) {
      errorMessage = (
        <Message negative>
          <Message.Header>Failed..!</Message.Header>
          <p>{this.props.error.message}</p>
        </Message>
      );
    }

    let authRedirect = null;
    if (this.props.isAuthenticated) {
      authRedirect = <Redirect to={this.props.authRedirectPath} />
    }

    return (

      <div className="app flex-row align-items-center">
        <Container>
          {authRedirect}

          <Row className="justify-content-center">
            <Col md="5">
              <Card className="mx-4">
                <CardBody className="p-4">
                  <h1>Login</h1>
                  <p className="text-muted"> Sign In to CPE</p>
                  <br />
                  <InputGroup className="mb-4">
                    <InputGroupAddon addonType="prepend">
                      <InputGroupText><i className="icon-user"></i></InputGroupText>
                    </InputGroupAddon>
                    <Input type="text" placeholder="Username"
                      value={this.state.controls.username.value}
                      onChange={(event) => this.inputChangedHandler(event, 'username')} />
                  </InputGroup>
                  <InputGroup className="mb-4">
                    <InputGroupAddon addonType="prepend">
                      <InputGroupText>
                        <i className="icon-lock"></i>
                      </InputGroupText>
                    </InputGroupAddon>
                    <Input type="password" placeholder="Password"
                      value={this.state.controls.password.value}
                      onChange={(event) => this.inputChangedHandler(event, 'password')} />
                  </InputGroup>
                  <br />
                  <Button fluid primary onClick={this.submitHandler}
                    loading={this.props.loading}>
                    <span>{this.state.isSignup ? 'SignUp' : 'Login'}</span>
                  </Button>

                  <br />
                  {/* <Divider horizontal>Or</Divider>
                  <Button secondary fluid onClick={this.switchAuthModeHandler}>
                    <span>Switch to {this.state.isSignup ? 'Login' : 'SignUp'}</span></Button> */}

                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

const mapStateToProps = state => {
  console.log(state);
  return {
    loading: state.auth.loading,
    error: state.auth.error,
    isAuthenticated: state.auth.token !== null,
    authRedirectPath: state.auth.authRedirectPath,
    email: state.auth.email
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onAuth: (username, password) => dispatch(actions.auth(username, password)),
    onSetAuthRedirectPath: () => dispatch(actions.setAuthRedirectPath('/')),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);