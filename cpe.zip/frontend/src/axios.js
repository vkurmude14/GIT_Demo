import axios from "axios";

const instance = axios.create({
  baseURL: "http://" + location.hostname + ":" + location.port + "/cpe",

  //baseURL: "http://localhost:8089/cpe",
});

export default instance;
