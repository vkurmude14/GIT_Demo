import React, { Component } from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { Container } from "reactstrap";

import Header from "../../components/UI/Header/";
import Sidebar from "../../components/UI/Sidebar/";
import Breadcrumb from "../../components/UI/Breadcrumb/";
import Aside from "../../components/UI/Aside/";
import Footer from "../../components/UI/Footer/";
import Dashboard from "../../views/Dashboard/";
import CreateJob from "../../views/Jenkins/Job/CreateJob/";
import UpdateJob from "../../views/Jenkins/Job/UpdateJob/";
import CreatePCJob from "../../views/Jenkins/Job/PerformanceCenter/CreatePCJob";
import UpdatePCJob from "../../views/Jenkins/Job/PerformanceCenter/UpdatePCJob";
import CreateLRJob from "../../views/Jenkins/Job/LoadRunner/CreateLRJob";
import UpdateLRJob from "../../views/Jenkins/Job/LoadRunner/UpdateLRJob";
import CreatePipeline from "../../views/Jenkins/Pipeline/CreatePipeline/";
import UpdatePipeline from "../../views/Jenkins/Pipeline/UpdatePipeline/";
import AddJobToExisting from "../../views/Jenkins/Pipeline/AddJobToExisting/";
import CreateNode from "../../views/Jenkins/Node/CreateNode";
import EditNode from "../../views/Jenkins/Node/EditNode";
import Configurations from "../../views/Configurations/";
import * as actions from "../../store/actions";

class Full extends Component {
  state = {
    JenkinsConfig: {
      user: null,
      url: null,
      config: null,
      loading: true,
    },
    isConfigured: true,
  };

  componentDidMount = () => {
    this.props.getConfigs();
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps);
    const isConfigured =
      nextProps.user.username &&
      nextProps.user.password &&
      nextProps.url.hostname &&
      nextProps.url.port &&
      nextProps.url.hosttype &&
      nextProps.config.jmf &&
      nextProps.config.grafana &&
      nextProps.config.jenkinsPath &&
      nextProps.config.jmeterHome
        ? true
        : false;

    if (prevState.isConfigured !== isConfigured) {
      console.log("inside 1");
      return {
        ...prevState,
        isConfigured: isConfigured,
      };
    }

    if (prevState.JenkinsConfig.loading !== nextProps.loading) {
      console.log("inside 2");
      return {
        ...prevState,
        JenkinsConfig: {
          ...prevState.JenkinsConfig,
          loading: nextProps.loading,
        },
      };
    }

    if (
      prevState.JenkinsConfig.user !== nextProps.user ||
      prevState.JenkinsConfig.url !== nextProps.url ||
      prevState.JenkinsConfig.config !== nextProps.config
    ) {
      console.log("inside 3");
      return {
        ...prevState,
        JenkinsConfig: {
          ...prevState.JenkinsConfig,
          user: {
            ...nextProps.user,
          },
          url: {
            ...nextProps.url,
          },
          config: {
            ...nextProps.config,
          },
        },
        isConfigured: isConfigured,
      };
    }
    return null;
  }

  render() {
    console.log(this.state);
    console.log(this.props);
    return (
      <div className="app">
        <Header />
        <div className="app-body">
          <Sidebar {...this.props} />
          <main className="main">
            <Breadcrumb />
            <Container fluid style={{ overflow: "hidden" }}>
              <Switch>
                <Route
                  exact
                  path="/dashboard"
                  name="Dashboard"
                  render={() => (
                    <Dashboard
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/createJob"
                  name="CreateJob"
                  render={() => (
                    <CreateJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/editJob"
                  name="EditJob"
                  render={() => (
                    <UpdateJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/jmeterResults"
                  name="JmeterResults"
                  render={() => (
                    <JmeterResults
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/createPCJob"
                  name="CreatePCJob"
                  render={() => (
                    <CreatePCJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/editPCJob"
                  name="UpdatePCJob"
                  render={() => (
                    <UpdatePCJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/createLRJob"
                  name="CreateLRJob"
                  render={() => (
                    <CreateLRJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/job/editLRJob"
                  name="UpdateLRJob"
                  render={() => (
                    <UpdateLRJob
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/pipeline/addJobToExisting"
                  name="AddJobToExisting"
                  render={() => (
                    <AddJobToExisting
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/pipeline/createPipeline"
                  name="CreatePipeline"
                  render={() => (
                    <CreatePipeline
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/pipeline/editPipeline"
                  name="EditPipeline"
                  render={() => (
                    <UpdatePipeline
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/node/createNode"
                  name="CreateNode"
                  render={() => (
                    <CreateNode
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/node/editNode"
                  name="EditNode"
                  render={() => (
                    <EditNode
                      isConfigured={this.state.isConfigured}
                      configLoading={this.state.JenkinsConfig.loading}
                    />
                  )}
                />

                <Route
                  path="/configurations"
                  name="Configurations"
                  component={Configurations}
                  isConfigured={this.state.isConfigured}
                  configLoading={this.state.JenkinsConfig.loading}
                />

                <Redirect exact from="/index.html" to="/dashboard" />

                <Redirect from="*" to="/dashboard" />
              </Switch>
            </Container>
          </main>
          <Aside />
        </div>
        <Footer />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    user: {
      username: state.JenkinsConfig.fetch.user.username,
      password: state.JenkinsConfig.fetch.user.password,
    },
    url: {
      hostname: state.JenkinsConfig.fetch.url.hostname,
      port: state.JenkinsConfig.fetch.url.port,
      hosttype: state.JenkinsConfig.fetch.url.hosttype,
    },
    config: {
      jmf: state.JenkinsConfig.fetch.config.jmf,
      grafana: state.JenkinsConfig.fetch.config.grafana,
      jenkinsPath: state.JenkinsConfig.fetch.config.jenkinsPath,
      jmeterHome: state.JenkinsConfig.fetch.config.jmeterHome,
    },
    loading: state.JenkinsConfig.loading,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getConfigs: () => dispatch(actions.getConfigsStart()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Full);
