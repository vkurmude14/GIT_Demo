package com.mindtree.cpe.util;

import org.ektorp.CouchDbConnector;
import org.ektorp.CouchDbInstance;
import org.ektorp.http.HttpClient;
import org.ektorp.http.StdHttpClient;
import org.ektorp.impl.StdCouchDbInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import com.mindtree.cpe.exception.ConfigException;

@Configuration
public class CouchConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(CouchConfig.class.getName());
	
	public static  CouchDbConnector couchConnector() throws ConfigException {
		CouchDbConnector dbConnector = null;
		HttpClient httpClient=null;
		try {
			if (Boolean.TRUE.equals(DatabaseUtil.dbAuthEnabled))
			{
				 httpClient = new StdHttpClient.Builder().host(DatabaseUtil.dbHost)
		        		.port(DatabaseUtil.dbPort)
		        		.username(DatabaseUtil.dbUser)
		        		.password(DatabaseUtil.dbPassword)
		        		.build();  
			}
			else
			{
				 httpClient = new StdHttpClient.Builder().host(DatabaseUtil.dbHost)
		        		.port(DatabaseUtil.dbPort)
		        		.build();  
			}
		
				

        CouchDbInstance dbInstance = new StdCouchDbInstance(httpClient);
        dbConnector = dbInstance.createConnector(DatabaseUtil.dbName, true);
         
		}
		catch(Exception e)
		{
			LOGGER.error("Error in obtaining CouchDB Connector");
			throw new ConfigException(e.getMessage());
		}
        
        return dbConnector;
	}

}
