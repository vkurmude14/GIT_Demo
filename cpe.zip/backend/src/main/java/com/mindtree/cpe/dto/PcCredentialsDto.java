package com.mindtree.cpe.dto;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@JsonIgnoreProperties({"id", "revision"})
public class PcCredentialsDto {
	
	@JsonProperty("_id")
	private String id;
	@JsonProperty("_rev")
    private String revision;
	
	private String credentialsId;
	private String pcUsername;
	private String pcPassword;
	public PcCredentialsDto(String credentialsId, String username, String password) {
		super();
		this.credentialsId = credentialsId;
		this.pcUsername = username;
		this.pcPassword = password;
	}
	public PcCredentialsDto() {
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	@Override
	public String toString() {
		return "PcCredentialsDto [credentialsId=" + credentialsId + ", username=" + pcUsername + ", password=" + pcPassword
				+ "]";
	}
	public String getCredentialsId() {
		return credentialsId;
	}
	public void setCredentialsId(String credentialsId) {
		this.credentialsId = credentialsId;
	}
	public String getPcUsername() {
		return pcUsername;
	}
	public void setPcUsername(String pcUsername) {
		this.pcUsername = pcUsername;
	}
	public String getPcPassword() {
		return pcPassword;
	}
	public void setPcPassword(String pcPassword) {
		this.pcPassword = pcPassword;
	}

	
	
}
