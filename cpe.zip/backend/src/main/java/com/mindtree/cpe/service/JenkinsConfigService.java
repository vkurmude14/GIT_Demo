package com.mindtree.cpe.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.ini4j.Wini;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.cpe.dao.JenkinsConfigDao;
import com.mindtree.cpe.entity.JenkinsConfig;
import com.mindtree.cpe.entity.JenkinsUrl;
import com.mindtree.cpe.entity.JenkinsUser;
import com.mindtree.cpe.exception.ConfigException;

/**
 * @author Abhilash Hegde
 *
 */
@Service
public class JenkinsConfigService {
	String grafanaPort = "";
	private static final Logger LOGGER = LoggerFactory.getLogger(JenkinsConfigService.class);
	@Autowired
	JenkinsConfigDao dao;

	public void readJenkinsConfig() throws ConfigException {
		boolean loaded = false;

		if (!dao.isDataAlreadyPresent()) {
			String jenkinsconfig = "properties/jenkins_config.properties";
			Properties properties = null;
			properties = new Properties();
			JenkinsUrl jenkinsUrl = new JenkinsUrl();
			JenkinsUser jenkinsUser = new JenkinsUser();
			JenkinsConfig jenkinsConfig = new JenkinsConfig();
			

			try (InputStream is = this.getClass().getClassLoader().getResourceAsStream(jenkinsconfig);) {

				properties.load(is);

				jenkinsUser.setUser("user");
				jenkinsUser.setId(jenkinsUser.getUser());
				jenkinsUser.setUsername(properties.getProperty("username"));
				jenkinsUser.setPassword(properties.getProperty("password"));
				dao.saveJenkinsUser(jenkinsUser);

				jenkinsUrl.setUser("url");
				jenkinsUrl.setId(jenkinsUrl.getUser());
				jenkinsUrl.setHostname(properties.getProperty("hostname"));
				jenkinsUrl.setPort(properties.getProperty("port"));
				jenkinsUrl.setHosttype(properties.getProperty("hosttype"));
				dao.saveJenkinsUrl(jenkinsUrl);

				jenkinsConfig.setUser("config");
				jenkinsConfig.setId(jenkinsConfig.getUser());
				jenkinsConfig.setJmf(properties.getProperty("jmf"));

				File jmeterHome = new File(System.getenv("JMETER_HOME"));
				String jmeterHomeValue = jmeterHome.getCanonicalPath();
				if (jmeterHomeValue != null)
					jenkinsConfig.setJmeterHome(jmeterHomeValue);
				else
					jenkinsConfig.setJmeterHome("");

				File jenkinsHome = new File(System.getenv("JENKINS_HOME"));
				String jenkinsHomeValue = jenkinsHome.getCanonicalPath();
				if (jenkinsHomeValue != null)
					jenkinsConfig.setJenkinsPath(jenkinsHomeValue);
				else
					jenkinsConfig.setJenkinsPath("");

				File grafanaHome = new File(System.getenv("GRAFANA_HOME"));
				grafanaPort = grafanaHome.getCanonicalPath();
				grafanaPort = replaceSelected(grafanaPort);
				if (grafanaPort != null)
					jenkinsConfig.setGrafana("http://localhost:" + grafanaPort);
				else
					jenkinsConfig.setGrafana("http://localhost:3000");
				dao.saveJenkinsConfig(jenkinsConfig);
				loaded = true;
			} catch (IOException | NullPointerException e) {
				throw new ConfigException(e);
			}
		}

	}

	public  String replaceSelected(String type) {
		type = type.replace("\\", "\\\\");
		try {
			String fileName = type + "\\defaults.ini";
			Wini ini = new Wini(new File(fileName));
			grafanaPort = ini.get("server", "http_port");
		} catch (Exception e) {
			LOGGER.error("Error  while getting grafana port : {} ", e.getMessage());
			
		}
		return grafanaPort;
	}

}
