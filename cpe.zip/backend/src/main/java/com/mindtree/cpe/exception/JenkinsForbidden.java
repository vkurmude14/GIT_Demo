package com.mindtree.cpe.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class JenkinsForbidden extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JenkinsForbidden() {
		super();
	}

	public JenkinsForbidden(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public JenkinsForbidden(String message, Throwable cause) {
		super(message, cause);

	}

	public JenkinsForbidden(String message) {
		super(message);
	}

	public JenkinsForbidden(Throwable cause) {
		super(cause);
	}
}
