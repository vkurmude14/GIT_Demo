package com.mindtree.cpe.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.mindtree.cpe.dto.JenkinsJobDto;
import com.mindtree.cpe.service.BuildService;

@Controller
public class BuildController {

	@Autowired
	BuildService buildService;
	
	@CrossOrigin 
	@RequestMapping(value = "/buildStart", method = RequestMethod.POST, consumes = "text/html", produces = "text/html")
	public @ResponseBody String buildStart(@RequestParam String jobName) {

		buildService.buildStart(jobName);
		return "success";
	}
	@CrossOrigin 
	@RequestMapping(value = "/buildCompleted", method = RequestMethod.GET,  produces = "text/plain")
	public @ResponseBody String buildCompleted(@RequestParam String jobName) {
		return  buildService.buildCompleted(jobName);
	}

	@CrossOrigin 
	@RequestMapping(value = "/getRunningJobs", method = RequestMethod.GET,  produces = "application/json")
	public @ResponseBody String getRunningJobs(HttpServletRequest request) {
		Gson gson =new Gson();
		List<JenkinsJobDto> job= buildService.getRunningJobs();

		return gson.toJson(job);
	}
}
