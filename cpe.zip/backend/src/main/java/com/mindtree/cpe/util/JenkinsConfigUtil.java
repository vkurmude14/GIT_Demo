package com.mindtree.cpe.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mindtree.cpe.exception.ConfigException;

public class JenkinsConfigUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(JenkinsConfigUtil.class);
	
	private  boolean loaded = false;
	
	public void loadproperties() throws ConfigException {
		
		String userName;
		String password;
	    String hostName;
	    String hostType;
	    String port;
	    String jmf;
		
		if (!loaded) {
			String configLocation = "properties/db_properties.properties";
			
			LOGGER.info("2. db properties loaded");
			Properties prop = null;
			prop = new Properties();
			
			try(InputStream is = this.getClass().getClassLoader().getResourceAsStream(configLocation);) {
				prop.load(is);

				if (prop.containsKey("username"))
					userName = prop.getProperty("username");
				if (prop.containsKey("password"))
					password = prop.getProperty("password");
				if (prop.containsKey("hostname"))
					hostName = prop.getProperty("hostname");
				if(prop.contains("hosttype"))
					hostType = prop.getProperty("hosttype");
				if (prop.containsKey("port"))
					port = prop.getProperty("port");
				if (prop.containsKey("jmf"))
					jmf = prop.getProperty("jmf");
				loaded = true;
			} catch (IOException e) {
				throw new ConfigException(e);
			}
		}
		
	}

}
