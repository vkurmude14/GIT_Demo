package com.mindtree.cpe.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mindtree.cpe.exception.ConfigException;

public class DatabaseUtil {
	
	    private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseUtil.class);
		protected static String dbHost;
		protected static Integer dbPort;
		protected static String dbName;
		protected static Boolean dbAuthEnabled;
		protected static String dbUser;
		protected static String dbPassword;
		protected static boolean loaded = false;
		
		private DatabaseUtil() {
			// private constructor
		}

		public static void loadDBProperties() throws ConfigException {
			if (!loaded) {
				String configLocation = "properties/db_properties.properties";
				
				LOGGER.info("db properties loaded");
				Properties prop = null;
				prop = new Properties();
				
				try(InputStream is = DatabaseUtil.class.getClassLoader().getResourceAsStream(configLocation);) {
					
					prop.load(is);

					if (prop.containsKey("DB_HOST"))
						dbHost = prop.getProperty("DB_HOST");
					if (prop.containsKey("DB_PORT"))
						dbPort = Integer.parseInt(prop.getProperty("DB_PORT"));
					if (prop.containsKey("DB_NAME"))
						dbName = prop.getProperty("DB_NAME");
					if (prop.containsKey("DB_AUTH_ENABLED"))
						dbAuthEnabled = Boolean.parseBoolean(prop.getProperty("DB_AUTH_ENABLED"));
					if (prop.containsKey("DB_USER"))
						dbUser = prop.getProperty("DB_USER");
					if (prop.containsKey("DB_PASSWORD"))
						dbPassword = prop.getProperty("DB_PASSWORD");
					loaded = true;
				} catch (IOException e) {
					throw new ConfigException(e);
				} 
			}
		}

	}
