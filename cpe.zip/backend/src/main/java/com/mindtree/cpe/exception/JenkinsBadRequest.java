package com.mindtree.cpe.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class JenkinsBadRequest extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JenkinsBadRequest() {
		super();
	}

	public JenkinsBadRequest(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public JenkinsBadRequest(String message, Throwable cause) {
		super(message, cause);
	}

	public JenkinsBadRequest(String message) {
		super(message);
	}

	public JenkinsBadRequest(Throwable cause) {
		super(cause);
	}
}
