package com.mindtree.cpe.dao;

import org.apache.log4j.Logger;
import org.ektorp.CouchDbConnector;
import org.springframework.stereotype.Repository;

import com.mindtree.cpe.dto.JenkinsJobDto;
import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.util.CouchConfig;


/**
 * @author Abhilash Hegde
 *
 */
@Repository
public class BuildDao {
	private static final Logger LOGGER = Logger.getLogger(BuildDao.class.getName());
	private CouchDbConnector dbConnector;

	public BuildDao() {
		try {
			dbConnector = CouchConfig.couchConnector();
			
		} catch (ConfigException e) {
			LOGGER.error("Error in getting CouchDB Connector");
		}
	}


	public void buildStart(String jobName, long startTime) {				
		JenkinsJobDto job = dbConnector.find(JenkinsJobDto.class,jobName);
		if( job!= null)
		{
			job.setRunning(true);
			job.setStartTime(startTime);
			dbConnector.update(job);
		}
	}

	public JenkinsJobDto buildCompleted(String jobName) {
		JenkinsJobDto job = dbConnector.find(JenkinsJobDto.class,jobName);
		if( job!= null)
		{
			job.setRunning(false);
			dbConnector.update(job);
		}
		return job;
	}
}
