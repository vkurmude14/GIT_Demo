package com.mindtree.cpe.dto;

public class ServerDetailsDto {
	
	
	private String name;
	private String os;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	
	@Override
	public String toString() {
		return "ServerDetailsDto [name=" + name + ", os=" + os + "]";
	}
	
	
}
