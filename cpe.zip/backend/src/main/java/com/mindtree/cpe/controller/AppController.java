package com.mindtree.cpe.controller;

import javax.annotation.PostConstruct;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.service.JenkinsConfigService;
import com.mindtree.cpe.util.DatabaseUtil;

/**
 * @author Abhilash Hegde
 *
 */
@Controller
public class AppController {
	
	private static final Logger logger = LoggerFactory.getLogger(AppController.class);
	
	@Autowired
	JenkinsConfigService jenkinsConfigService;
	
	public AppController() {
		try {
			PropertyConfigurator.configure(AppController.class.getClassLoader().getResourceAsStream("Log4j.properties"));
			DatabaseUtil.loadDBProperties();
		} catch (ConfigException e) {
			logger.error("Error while loading database properties file : {} ", e.getMessage());
		}			
	}
	
	@PostConstruct
	public void readConfigFiles() throws ConfigException {
		jenkinsConfigService.readJenkinsConfig();		
	}

}
