package com.mindtree.cpe.dao;

import org.apache.log4j.Logger;
import org.ektorp.CouchDbConnector;
import org.springframework.stereotype.Repository;

import com.mindtree.cpe.entity.JenkinsConfig;
import com.mindtree.cpe.entity.JenkinsUrl;
import com.mindtree.cpe.entity.JenkinsUser;
import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.util.CouchConfig;

/**
 * @author Abhilash Hegde
 *
 */
@Repository
public class JenkinsConfigDao {
	private static final Logger LOGGER = Logger.getLogger(JenkinsConfigDao.class.getName());
    private CouchDbConnector dbConnector;
	public JenkinsConfigDao() {
		try {
			dbConnector = CouchConfig.couchConnector();
			
		} catch (ConfigException e) {
			LOGGER.error("Error in getting CouchDB Connector");
		}
	}

	public JenkinsUser saveJenkinsUser(JenkinsUser user) {
		
		JenkinsUser userOld =dbConnector.find(JenkinsUser.class,user.getId());
		if( userOld!= null)
		{	
			user.setRevision(userOld.getRevision());
			dbConnector.update(user);
		}
		else
		{
			dbConnector.create(user);
		}
		return user;
	}

	public JenkinsConfig saveJenkinsConfig(JenkinsConfig config) {
		JenkinsConfig configOld = dbConnector.find(JenkinsConfig.class,config.getId());
		if( configOld!= null)
		{
			config.setRevision(configOld.getRevision());
			dbConnector.update(config);
		}
		else
		{
			dbConnector.create(config);
		}
		return config;
	}

	public JenkinsUrl saveJenkinsUrl(JenkinsUrl url) {

		JenkinsUrl urlOld = dbConnector.find(JenkinsUrl.class,url.getId());
		if( urlOld!= null)
		{
			url.setRevision(urlOld.getRevision());
			dbConnector.update(url);
		}
		else
		{
			dbConnector.create(url);
		}
		return url;
	}

	public JenkinsUrl getJenkinsUrl() {
		return dbConnector.find(JenkinsUrl.class,"url");
	}

	public JenkinsUser getJenkinsUser() {
		return dbConnector.find(JenkinsUser.class,"user");
	}

	public JenkinsConfig getJenkinsConfig() {
		return dbConnector.find(JenkinsConfig.class,"config");
		
	}

	public boolean isDataAlreadyPresent() {
		
		JenkinsConfig config = dbConnector.find(JenkinsConfig.class,"config");
	   return !(config == null || config.getJenkinsPath() == null || config.getJmeterHome() == null);	
	}
}
