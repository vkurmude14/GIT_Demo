package com.mindtree.cpe.entity;

import java.util.List;

import javax.persistence.Entity;

import com.mindtree.cpe.dto.ServerDetailsDto;

@Entity
public class JenkinsPCJob {
	private String name;
	private String release;
	private boolean baseline;
	private String description;
	private String email;
	private boolean successTrigger;
	private boolean failureTrigger;
	private boolean beforebuildTrigger;
	private boolean enableSlave;
	private String slave;
    private List<ServerDetailsDto> servers;

    private int durationHours;
    private int durationMinutes;
    private boolean statusBySLA;
    private String serverAndPort;
    private String pcServerName;
    private String credentialsID;
    private String pcUsername;
    private String pcPassword;
	private String almDomain;
    private String almProject;
    private int testID;
    private boolean autoTestInstance;
    private int testInstanceID;
	private String postRunAction;
    private boolean vudsMode;
    private String addRunToTrendReport;
    private int trendReportId;
    private boolean httpsProtocol;
    private String proxyOutURL;
    private String credentialsProxyId;    
	private boolean retry;
    private String retryDelay;
    private int retryOccurrences;
    private String proxyUsername;
    private String proxyPassword;
    private String jobType;
    public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getProxyUsername() {
		return proxyUsername;
	}
	public void setProxyUsername(String proxyUsername) {
		this.proxyUsername = proxyUsername;
	}
	public String getProxyPassword() {
		return proxyPassword;
	}
	public void setProxyPassword(String proxyPassword) {
		this.proxyPassword = proxyPassword;
	}
	public String getPcUsername() {
		return pcUsername;
	}
	public void setPcUsername(String pcUsername) {
		this.pcUsername = pcUsername;
	}
	public String getPcPassword() {
		return pcPassword;
	}
	public void setPcPassword(String pcPassword) {
		this.pcPassword = pcPassword;
	}

    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRelease() {
		return release;
	}
	public void setRelease(String release) {
		this.release = release;
	}
	public boolean getBaseline() {
		return baseline;
	}
	public void setBaseline(boolean baseline) {
		this.baseline = baseline;
	}
	public String getPcServerName() {
		return pcServerName;
	}
	public void setPcServerName(String pcServerName) {
		this.pcServerName = pcServerName;
	}
	public boolean isHttpsProtocol() {
		return httpsProtocol;
	}
	public void setHttpsProtocol(boolean httpsProtocol) {
		this.httpsProtocol = httpsProtocol;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isSuccessTrigger() {
		return successTrigger;
	}
	public void setSuccessTrigger(boolean successTrigger) {
		this.successTrigger = successTrigger;
	}
	public boolean isFailureTrigger() {
		return failureTrigger;
	}
	public void setFailureTrigger(boolean failureTrigger) {
		this.failureTrigger = failureTrigger;
	}
	public boolean isBeforebuildTrigger() {
		return beforebuildTrigger;
	}
	public void setBeforebuildTrigger(boolean beforebuildTrigger) {
		this.beforebuildTrigger = beforebuildTrigger;
	}
	public boolean isEnableSlave() {
		return enableSlave;
	}
	public void setEnableSlave(boolean enableSlave) {
		this.enableSlave = enableSlave;
	}
	public String getSlave() {
		return slave;
	}
	public void setSlave(String slave) {
		this.slave = slave;
	}
	public List<ServerDetailsDto> getServers() {
		return servers;
	}
	public void setServers(List<ServerDetailsDto> servers) {
		this.servers = servers;
	}
	public int getDurationHours() {
		return durationHours;
	}
	public void setDurationHours(int durationHours) {
		this.durationHours = durationHours;
	}
	public int getDurationMinutes() {
		return durationMinutes;
	}
	public void setDurationMinutes(int durationMinutes) {
		this.durationMinutes = durationMinutes;
	}
	public boolean isStatusBySLA() {
		return statusBySLA;
	}
	public void setStatusBySLA(boolean statusBySLA) {
		this.statusBySLA = statusBySLA;
	}
	public String getServerAndPort() {
		return serverAndPort;
	}
	public void setServerAndPort(String serverAndPort) {
		this.serverAndPort = serverAndPort;
	}
	public String getCredentialsID() {
		return credentialsID;
	}
	public void setCredentialsID(String credentialsID) {
		this.credentialsID = credentialsID;
	}
	public String getAlmDomain() {
		return almDomain;
	}
	public void setAlmDomain(String almDomain) {
		this.almDomain = almDomain;
	}
	public String getAlmProject() {
		return almProject;
	}
	public void setAlmProject(String almProject) {
		this.almProject = almProject;
	}
	public int getTestID() {
		return testID;
	}
	public void setTestID(int testID) {
		this.testID = testID;
	}
	
	public int getTestInstanceID() {
		return testInstanceID;
	}
	public void setTestInstanceID(int testInstanceID) {
		this.testInstanceID = testInstanceID;
	}
	public String getPostRunAction() {
		return postRunAction;
	}
	public void setPostRunAction(String postRunAction) {
		this.postRunAction = postRunAction;
	}
	public boolean isVudsMode() {
		return vudsMode;
	}
	public void setVudsMode(boolean vudsMode) {
		this.vudsMode = vudsMode;
	}
	public String getAddRunToTrendReport() {
		return addRunToTrendReport;
	}
	public void setAddRunToTrendReport(String addRunToTrendReport) {
		this.addRunToTrendReport = addRunToTrendReport;
	}
	public int getTrendReportId() {
		return trendReportId;
	}
	public void setTrendReportId(int trendReportId) {
		this.trendReportId = trendReportId;
	}
	public String getProxyOutURL() {
		return proxyOutURL;
	}
	public void setProxyOutURL(String proxyOutURL) {
		this.proxyOutURL = proxyOutURL;
	}
	public String getCredentialsProxyId() {
		return credentialsProxyId;
	}
	public void setCredentialsProxyId(String credentialsProxyId) {
		this.credentialsProxyId = credentialsProxyId;
	}
	
	public boolean isAutoTestInstance() {
		return autoTestInstance;
	}
	public void setAutoTestInstance(boolean autoTestInstance) {
		this.autoTestInstance = autoTestInstance;
	}
	public boolean isRetry() {
		return retry;
	}
	public void setRetry(boolean retry) {
		this.retry = retry;
	}
	public String getRetryDelay() {
		return retryDelay;
	}
	public void setRetryDelay(String retryDelay) {
		this.retryDelay = retryDelay;
	}
	public int getRetryOccurrences() {
		return retryOccurrences;
	}
	public void setRetryOccurrences(int retryOccurrences) {
		this.retryOccurrences = retryOccurrences;
	}
	@Override
	public String toString() {
		return "JenkinsPCJob [name=" + name + ", release=" + release + ", baseline=" + baseline + ", description="
				+ description + ", email=" + email + ", successTrigger=" + successTrigger + ", failureTrigger="
				+ failureTrigger + ", beforebuildTrigger=" + beforebuildTrigger + ", enableSlave=" + enableSlave
				+ ", slave=" + slave + ", servers=" + servers + ", durationHours=" + durationHours
				+ ", durationMinutes=" + durationMinutes + ", statusBySLA=" + statusBySLA + ", serverAndPort="
				+ serverAndPort + ", pcServerName=" + pcServerName + ", credentialsID=" + credentialsID
				+ ", pcUsername=" + pcUsername + ", pcPassword=" + pcPassword + ", almDomain=" + almDomain
				+ ", almProject=" + almProject + ", testID=" + testID + ", autoTestInstance=" + autoTestInstance
				+ ", testInstanceID=" + testInstanceID + ", postRunAction=" + postRunAction + ", vudsMode=" + vudsMode
				+ ", addRunToTrendReport=" + addRunToTrendReport + ", trendReportId=" + trendReportId
				+ ", httpsProtocol=" + httpsProtocol + ", proxyOutURL=" + proxyOutURL + ", credentialsProxyId="
				+ credentialsProxyId + ", retry=" + retry + ", retryDelay=" + retryDelay + ", retryOccurrences="
				+ retryOccurrences + ", proxyUsername=" + proxyUsername + ", proxyPassword=" + proxyPassword + "]";
	}
	

	
}
