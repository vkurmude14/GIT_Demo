package com.mindtree.cpe.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties({"id", "revision"})
public class JenkinsUrl {
	
	@JsonProperty("_id")
	private String id;
	@JsonProperty("_rev")
    private String revision;
	private String user;
	private String hostname;
	private String port;
	private String hosttype;
	public String getHostname() {
		return hostname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getHosttype() {
		return hosttype;
	}
	public void setHosttype(String hosttype) {
		this.hosttype = hosttype;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	 public String getRevision() {
         return revision;
     }
	@Override
	public String toString() {
		return "Url [hostname=" + hostname + ", port=" + port + " , hosttype =" +hosttype+"]";
	}
	
	
}
