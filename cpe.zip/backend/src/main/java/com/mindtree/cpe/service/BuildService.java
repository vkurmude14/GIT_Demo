package com.mindtree.cpe.service;

import java.util.Date;
import java.util.List;

import org.ektorp.CouchDbConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cpe.dao.BuildDao;
import com.mindtree.cpe.dao.CPERepo;
import com.mindtree.cpe.dao.JenkinsConfigDao;
import com.mindtree.cpe.dao.JenkinsJobDao;
import com.mindtree.cpe.dto.JenkinsJobDto;
import com.mindtree.cpe.dto.ServerDetailsDto;
import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.util.CouchConfig;

@Service
public class BuildService {

	@Autowired
	BuildDao buildDao;

	@Autowired
	JenkinsConfigDao jenkinsConfigDao;
	
	@Autowired
	JenkinsService jenkinsService;
	
	@Autowired
	JenkinsJobDao jenkinsJobDao;
	private CouchDbConnector dbConnector;
	CPERepo cpeRepo;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BuildService.class);
	public BuildService() {
		try {
			dbConnector = CouchConfig.couchConnector();
			cpeRepo= new CPERepo(dbConnector);

			
		} catch (ConfigException e) {
			LOGGER.error("Error in getting CouchDB Connector");
		}
	}
	
	

	public void buildStart(String jobName) {
		Date date = new Date();
		long startTime = date.getTime();
		buildDao.buildStart(jobName, startTime);
		
		 if(jenkinsJobDao.getJob(jobName).getJobType().equalsIgnoreCase("LR"))
		 {
			 jenkinsService.parseLRMetrics(jobName);
		 }
		
		
	}

	@SuppressWarnings("unused")
	public String buildCompleted(String jobName) {
		JenkinsJobDto job = buildDao.buildCompleted(jobName);
		StringBuilder response = new StringBuilder("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n" + 
				"\r\n" + 
				"<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n" + 
				"\r\n" + 
				"<title></title>\r\n" + 
				"<meta name=\"GENERATOR\" content=\"OpenOffice 4.1.1  (FreeBSD/amd64)\">\r\n" + 
				"<meta name=\"CREATED\" content=\"20180718;2094400\">\r\n" + 
				"<meta name=\"CHANGED\" content=\"0;0\">\r\n" + 
				"<style type=\"text/css\">\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"<body lang=\"en-US\" dir=\"LTR\">\r\n" + 
				"<pre class=\"western\"> Dashboard Links: \n");
		Date date = new Date();
		long startTime = job.getStartTime();
		long endTime = date.getTime();
		String  grafanaUrl = jenkinsConfigDao.getJenkinsConfig().getGrafana();
		 List<ServerDetailsDto> servers= job.getServers();
		
		 if(jenkinsJobDao.getJob(jobName).getJobType().equalsIgnoreCase("LR"))
		 {
			 String lrDashboard = "/d/pGPE2dpGk/lr-dashboard?orgId=1&from=" +startTime +
					 				"&to="+ endTime + "&refresh=5s&kiosk=true";
			 response.append("LR Dashboard- " + grafanaUrl + lrDashboard + "\n\n");
			 for(ServerDetailsDto server : servers){
					String hostname= server.getName();

					String serverWin = "/d/-ZGmrzZiz/windows-host-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-hostname=" + hostname+
							"&var-disk=All&var-process=All&var-network=All&&refresh=5s&kiosk=true";
					String serverLinux = "/d/MfS2FDOmz/linux-host-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-datasource=default&var-server=" + hostname +
							"&var-inter=10s&var-netif=All&refresh=5s&kiosk=true";

					if(server.getOs().equalsIgnoreCase("windows")) {
						response.append("Server: " + hostname + "\n");
						response.append("ServerWindows- "+   grafanaUrl + serverWin + "\n\n");
					}else {
						response.append("Server: " + hostname + "\n");
						response.append("ServerLinux- "+   grafanaUrl + serverLinux + "\n\n");
					}
			 
			 }
		 }
		 else
		 {
			
			 String applicationName= job.getApplicationName();
				
				String jmeterDashboard = "/d/fr--ToImk/jmeter-dashboard?orgId=1&from=" + startTime +
						"&to="+ endTime +"&var-Application=" + applicationName +
						"&var-request=all&var-aggregation=10s&refresh=5s&kiosk=true";
				//HashMap<String, String> urls = new HashMap<>();
				//urls.put("Jmeter Dashboard", grafanaUrl + jmeterDashboard);

				response.append("Jmeter Dashboard- " + grafanaUrl + jmeterDashboard + "\n\n");
				for(ServerDetailsDto server : servers){
					String hostname= server.getName();

					String correlatedWin = "/d/cvj5jvOmz/windows-correlated-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-hostname=" + hostname + "&var-Application=" + applicationName +
							"&var-request=all&var-aggregation=10s&var-process=All&refresh=5s&kiosk=true";

					String serverWin = "/d/-ZGmrzZiz/windows-host-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-hostname=" + hostname+
							"&var-disk=All&var-process=All&var-network=All&&refresh=5s&kiosk=true";
					String serverLinux = "/d/MfS2FDOmz/linux-host-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-datasource=default&var-server=" + hostname +
							"&var-inter=10s&var-netif=All&refresh=5s&kiosk=true";
					String correlatedLinux = "/d/h39jXzWmz/linux-correlated-dashboard?orgId=1&from=" + startTime +
							"&to="+ endTime +"&var-hostname=" + hostname +
							"&var-Application=" + applicationName +
							"&var-request=checkout&var-aggregation=10s&var-process=All&refresh=5s&kiosk=true";

					if(server.getOs().equalsIgnoreCase("windows")) {
						response.append("Server: " + hostname + "\n");
						response.append("Correlated- " +  grafanaUrl + correlatedWin + "\n");
						response.append("ServerWindows- "+   grafanaUrl + serverWin + "\n\n");
					}else {
						response.append("Server: " + hostname + "\n");
						response.append("Correlated- " +  grafanaUrl + correlatedLinux + "\n");
						response.append("ServerLinux- "+   grafanaUrl + serverLinux + "\n\n");
					}
				}
		 }
		
		
		


	
		response.append("</pre>\r\n" + 
				"\r\n" + 
				"</body></html>");
		return response.toString();

	}

	public List<JenkinsJobDto> getRunningJobs() {
		return  cpeRepo.getRunningJobs();

	}

}
