package com.mindtree.cpe.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class JenkinsBadGateaway extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JenkinsBadGateaway() {
		super();
	}

	public JenkinsBadGateaway(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public JenkinsBadGateaway(String message, Throwable cause) {
		super(message, cause);
	}

	public JenkinsBadGateaway(String message) {
		super(message);
	}

	public JenkinsBadGateaway(Throwable cause) {
		super(cause);
	}
}
