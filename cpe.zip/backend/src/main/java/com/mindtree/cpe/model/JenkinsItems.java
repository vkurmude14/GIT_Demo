package com.mindtree.cpe.model;

import java.util.List;

public class JenkinsItems {
	List<String> jobs;
	List<String> pipelines;
	
	
	public List<String> getJobs() {
		return jobs;
	}
	public void setJobs(List<String> jobs) {
		this.jobs = jobs;
	}
	public List<String> getPipelines() {
		return pipelines;
	}
	public void setPipelines(List<String> pipelines) {
		this.pipelines = pipelines;
	}
	@Override
	public String toString() {
		return "JenkinsItems [jobs=" + jobs + ", pipelines=" + pipelines + "]";
	}
	
}
