package com.mindtree.cpe.util;

import org.springframework.stereotype.Service;

import com.mindtree.cpe.exception.JenkinsBadGateaway;
import com.mindtree.cpe.exception.JenkinsBadRequest;
import com.mindtree.cpe.exception.JenkinsForbidden;
import com.mindtree.cpe.exception.JenkinsNotFound;

@Service
public class ErrorHandler {

	private String message = "message: ";
	public void throwError(int responseCode) {

		if(responseCode == 404) {
			throw new JenkinsNotFound(message+" "+ responseCode);
		} else if(responseCode == 400) {
			throw new JenkinsBadRequest(message+" "+responseCode);
		} else if(responseCode == 502) {
			throw new JenkinsBadGateaway(message+" "+ responseCode);
		} else if(responseCode == 403) {
			throw new JenkinsForbidden(message+" "+ responseCode);
		}
	}
}