package com.mindtree.cpe.entity;
import java.util.List;
import javax.persistence.Entity;
import com.mindtree.cpe.dto.ServerDetailsDto;

@Entity
public class JenkinsLRJob {

		private String name;
		private String release;
		private boolean baseline;
		private String description;
		private String email;
		private boolean successTrigger;
		private boolean failureTrigger;
		private boolean beforebuildTrigger;
		private boolean enableSlave;
		private String slave;
	    private List<ServerDetailsDto> servers;
	   private List<String> testScriptsPath;
	   private int pollInterval;
	   private List<String> errorstoIgnore;
	   private String analysisTemplate;
	   private int scenarioTimeout;
	   private String resDir;
	   private String jobType;
	   
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getResDir() {
		return resDir;
	}
	public void setResDir(String resDir) {
		this.resDir = resDir;
	}
	public int getScenarioTimeout() {
		return scenarioTimeout;
	}
	public void setScenarioTimeout(int scenarioTimeout) {
		this.scenarioTimeout = scenarioTimeout;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRelease() {
		return release;
	}
	public void setRelease(String release) {
		this.release = release;
	}
	public boolean isBaseline() {
		return baseline;
	}
	public void setBaseline(boolean baseline) {
		this.baseline = baseline;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isSuccessTrigger() {
		return successTrigger;
	}
	public void setSuccessTrigger(boolean successTrigger) {
		this.successTrigger = successTrigger;
	}
	public boolean isFailureTrigger() {
		return failureTrigger;
	}
	public void setFailureTrigger(boolean failureTrigger) {
		this.failureTrigger = failureTrigger;
	}
	public boolean isBeforebuildTrigger() {
		return beforebuildTrigger;
	}
	public void setBeforebuildTrigger(boolean beforebuildTrigger) {
		this.beforebuildTrigger = beforebuildTrigger;
	}
	public boolean isEnableSlave() {
		return enableSlave;
	}
	public void setEnableSlave(boolean enableSlave) {
		this.enableSlave = enableSlave;
	}
	public String getSlave() {
		return slave;
	}
	public void setSlave(String slave) {
		this.slave = slave;
	}
	public List<ServerDetailsDto> getServers() {
		return servers;
	}
	public void setServers(List<ServerDetailsDto> servers) {
		this.servers = servers;
	}
	public List<String> getTestScriptsPath() {
		return testScriptsPath;
	}
	public void setTestScriptsPath(List<String> testScriptsPath) {
		this.testScriptsPath = testScriptsPath;
	}
	public int getPollInterval() {
		return pollInterval;
	}
	public void setPollInterval(int pollInterval) {
		this.pollInterval = pollInterval;
	}
	public List<String> getErrorstoIgnore() {
		return errorstoIgnore;
	}
	public void setErrorstoIgnore(List<String> errorstoIgnore) {
		this.errorstoIgnore = errorstoIgnore;
	}
	public String getAnalysisTemplate() {
		return analysisTemplate;
	}
	public void setAnalysisTemplate(String analysisTemplate) {
		this.analysisTemplate = analysisTemplate;
	}
	@Override
	public String toString() {
		return "JenkinsLRJob [name=" + name + ", release=" + release + ", baseline=" + baseline + ", description="
				+ description + ", email=" + email + ", successTrigger=" + successTrigger + ", failureTrigger="
				+ failureTrigger + ", beforebuildTrigger=" + beforebuildTrigger + ", enableSlave=" + enableSlave
				+ ", slave=" + slave + ", servers=" + servers + ", testScriptsPath=" + testScriptsPath
				+ ", pollInterval=" + pollInterval + ", errorstoIgnore=" + errorstoIgnore + ", analysisTemplate="
				+ analysisTemplate + ", scenarioTimeout=" + scenarioTimeout + ", resDir=" + resDir + "]";
	}

	

}
