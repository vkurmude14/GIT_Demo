package com.mindtree.cpe.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.ektorp.CouchDbConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.cpe.dto.JenkinsJobDto;
import com.mindtree.cpe.dto.PcCredentialsDto;
import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.util.CouchConfig;

@Repository
public class JenkinsJobDao {

	private static final Logger LOGGER = Logger.getLogger(JenkinsJobDao.class.getName());
	private CouchDbConnector dbConnector;
	@Autowired
	JenkinsConfigDao jenkinsConfigDao;
	PCCredRepo pcCredRepo;


	public JenkinsJobDao() {
		try {
			dbConnector = CouchConfig.couchConnector();
			pcCredRepo= new PCCredRepo(dbConnector);
			
		} catch (ConfigException e) {
			LOGGER.error("Error in getting CouchDB Connector");
		}
	}

	public String saveJob (JenkinsJobDto job) {
		job.setRunning(false);
		job.setStartTime(0);
		JenkinsJobDto jobOld = dbConnector.find(JenkinsJobDto.class,job.getId());
		if( jobOld!= null)
		{
			job.setRevision(jobOld.getRevision());
			dbConnector.update(job);
		}
		else
		{
			dbConnector.create(job);
		}
		return  null;		
	}

	public JenkinsJobDto getJob(String jobName) {
		return dbConnector.find(JenkinsJobDto.class,jobName);
	}
	
	public int getPCCredentialCount() {
		
		List<PcCredentialsDto> cred = pcCredRepo.getAll();
		if(cred!=null)
		{
			return cred.size();
		}
		else
		{
			return 0;
		}
		
	}
	public String savePCCred(PcCredentialsDto cred) {
		LOGGER.info("cred---");
		LOGGER.info(cred.getCredentialsId());
		PcCredentialsDto credOld = dbConnector.find(PcCredentialsDto.class,cred.getId());
		if( credOld!= null)
		{
			cred.setRevision(credOld.getRevision());
			dbConnector.update(cred);
		}
		else
		{
			dbConnector.create(cred);
		}
		return  null;	
		
	}
	public String isPcCredExists(String username,String password) {
		 List<PcCredentialsDto> credList = pcCredRepo.getAll();
		 List<PcCredentialsDto> finalList = new ArrayList<>();
	    	for (PcCredentialsDto cred : credList) {
	    		if(cred.getPcPassword().equals(password) && cred.getPcUsername().equals(username))
	    			finalList.add(cred);	    			
	    	}
		if(!finalList.isEmpty())
		{
			LOGGER.info("credId--"+finalList.get(0).getCredentialsId());
			return finalList.get(0).getCredentialsId();
		}
		else
			return null;
	}
	
	public PcCredentialsDto getPCCred(String credId) {
		return dbConnector.find(PcCredentialsDto.class,credId);
	}
	
	public void deleteJob (String job) {
		dbConnector.delete(dbConnector.find(JenkinsJobDto.class,job));			
	}
	
}


