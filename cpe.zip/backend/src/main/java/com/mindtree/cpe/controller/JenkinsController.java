package com.mindtree.cpe.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.mindtree.cpe.dto.JenkinsConfigDto;
import com.mindtree.cpe.entity.JenkinsConfig;
import com.mindtree.cpe.entity.JenkinsJob;
import com.mindtree.cpe.entity.JenkinsLRJob;
import com.mindtree.cpe.entity.JenkinsNode;
import com.mindtree.cpe.entity.JenkinsPCJob;
import com.mindtree.cpe.entity.JenkinsPipeline;
import com.mindtree.cpe.entity.JenkinsUrl;
import com.mindtree.cpe.entity.JenkinsUser;
import com.mindtree.cpe.model.JenkinsItems;
import com.mindtree.cpe.service.JenkinsService;

@Controller
public class JenkinsController {

  private static final Logger LOGGER = LoggerFactory.getLogger(JenkinsController.class);
  @Autowired JenkinsService jenkinsService;
  String formatter = "%s://%s:%d/cpe";
  String requestUrl = "API CALL - CPE API - :{} ";

  public JenkinsController() {
    LOGGER.info("JenkinsController constructor");
  }

  @CrossOrigin
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String indexPage() {
    return "redirect:/index.html";
  }


  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(value = "/jobTrigger", method = RequestMethod.POST, produces = "application/json")
  public @ResponseBody ResponseEntity<String> jobTrigger(String jobName)
       {
	  
	  LOGGER.info(requestUrl , "/jobTrigger");
      try {
      String responseMsg = jenkinsService.jobTrigger(jobName);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (Exception e) {
    	LOGGER.error("Error while triggering job in jenkins : {} ", e.getMessage());
    	e.printStackTrace();
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }
  
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(value = "/getLRMetric", method = RequestMethod.GET, produces = "application/json")
  public @ResponseBody ResponseEntity<String> getLRMetrics()
       {
	  
	  LOGGER.info(requestUrl , "/getLRMetric");
      try {
    	  String jobName = "testJobLR";
      String responseMsg = jenkinsService.parseLRMetrics(jobName);
      responseMsg = "true";
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (Exception e) {
    	LOGGER.error("Error while getting LR metrics  in jenkins : {} ", e.getMessage());
    	e.printStackTrace();
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/createJob",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> createJob(
      @RequestBody JenkinsJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/createJob");
	  
    String baseUrl =
        String.format(
            formatter, request.getScheme(), request.getServerName(), request.getServerPort());

    Boolean isUpdating = false;
    try {
      String responseMsg = jenkinsService.createJob(job, isUpdating, baseUrl);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (IOException e) {
    	LOGGER.error("Error while creating jmeter job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/checkJobName",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody String checkJobName(
      @RequestBody String jobName, HttpServletResponse response) throws IOException {
	  LOGGER.info(requestUrl , "/checkJobName");
    return jenkinsService.checkJobName(jobName);
  }

  @CrossOrigin
  @RequestMapping(value = "/getAllJobs", method = RequestMethod.GET, produces = "application/json")
  public @ResponseBody String getAllJobs() throws IOException {	  
	  LOGGER.info(requestUrl , "/getAllJobs");
    Gson gson = new Gson();
    JenkinsItems jobs = new JenkinsItems();
    
    try {
     jobs= jenkinsService.getAllJobs();
    }
    catch(IOException e)
    {
    	LOGGER.error("Error while getting all jobs : {} ", e.getMessage());
    }
    return gson.toJson(jobs, JenkinsItems.class);
  }
  
  @CrossOrigin
  @RequestMapping(value = "/getAllRelativeJobs", method = RequestMethod.GET, produces = "application/json")
  public @ResponseBody String getAllRelativeJobs(String jobType) {
	  LOGGER.info(requestUrl , "/getAllRelativeJobs");
    Gson gson = new Gson();
    JenkinsItems jobs = new JenkinsItems();
    try {
    		jobs=jenkinsService.getAllRelativeJobs(jobType);
    }
    catch(Exception e)
    {
    	LOGGER.error("Error while getting relative jobs : {} ", e.getMessage());
    	e.printStackTrace();
    }
    return gson.toJson(jobs, JenkinsItems.class);
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getJobDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getJobDetails(@RequestParam String jobName)
      throws IOException, SAXException, ParserConfigurationException {
	  LOGGER.info(requestUrl , "/getJobDetails");
    Gson gson = new Gson();

    try {
      JenkinsJob jobDetails = jenkinsService.getJobDetails(jobName);
      return ResponseEntity.ok(gson.toJson(jobDetails));
    } catch (IOException | SAXException | ParserConfigurationException e) {
    	LOGGER.error("Error while getting jmeter Job details : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(value = "/updateJob", method = RequestMethod.POST, produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateJob(
      @RequestBody JenkinsJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/updateJob");
    Boolean isUpdating = true;
    String baseUrl =
        String.format(
            formatter, request.getScheme(), request.getServerName(), request.getServerPort());
    try {
      String responseMsg = jenkinsService.createJob(job, isUpdating, baseUrl);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (IOException e) {
    	LOGGER.error("Error while updating jmeter Job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  // Create Performance Center Job
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/createPCJob",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> createPCJob(
      @RequestBody JenkinsPCJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/createPCJob");
    Boolean isUpdating = false;

    try {
      String responseMsg = jenkinsService.createPCJob(job, isUpdating);

      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (IOException e) {
    	LOGGER.error("Error while creating PC Job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getPCJobDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getPCJobDetails(@RequestParam String jobName)
      throws IOException, SAXException, ParserConfigurationException {
	  LOGGER.info(requestUrl , "/getPCJobDetails");
    Gson gson = new Gson();

    try {
      JenkinsPCJob jobDetails = jenkinsService.getPCJobDetails(jobName);

      return ResponseEntity.ok(gson.toJson(jobDetails));
    } catch (IOException e) {
    	LOGGER.error("Error  while getting PC Job details : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/updatePCJob",
      method = RequestMethod.POST,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updatePCJob(
      @RequestBody JenkinsPCJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/updatePCJob");
    Boolean isUpdating = true;
    try {
      String responseMsg = jenkinsService.createPCJob(job, isUpdating);

      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();
    } catch (IOException e) {
    	LOGGER.error("Error while updating PC Job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }
  
  //create LR job
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/createLRJob",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> createLRJob(
      @RequestBody JenkinsLRJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/createLRJob");
	  String baseUrl =
		        String.format(
		            formatter, request.getScheme(), request.getServerName(), request.getServerPort());

    Boolean isUpdating = false;

    try {
      String responseMsg = jenkinsService.createLRJob(job, isUpdating,baseUrl);

      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();

    } catch (IOException e) {
    	LOGGER.error("Error while creating LR Job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getLRJobDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getLRJobDetails(@RequestParam String jobName)
      throws IOException, SAXException, ParserConfigurationException {
	  LOGGER.info(requestUrl , "/getLRJobDetails");
    Gson gson = new Gson();

    try {
      JenkinsLRJob jobDetails = jenkinsService.getLRJobDetails(jobName);

      return ResponseEntity.ok(gson.toJson(jobDetails));
    } catch (IOException e) {
    	LOGGER.error("Error while getting LR Job details : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }
  
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/updateLRJob",
      method = RequestMethod.POST,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateLRJob(
      @RequestBody JenkinsLRJob job, HttpServletResponse response, HttpServletRequest request)
      throws IOException {
	  LOGGER.info(requestUrl , "/updateLRJob");
	  String baseUrl =
		        String.format(
		            formatter, request.getScheme(), request.getServerName(), request.getServerPort());
    Boolean isUpdating = true;
    try {
      String responseMsg = jenkinsService.createLRJob(job, isUpdating,baseUrl);

      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();
    } catch (IOException e) {
    	LOGGER.error("Error while updating LR Job : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }
  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/createPipeline",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> createPipeline(
      @RequestBody JenkinsPipeline pipeline, HttpServletResponse response)
      throws IOException, TransformerException {
	  LOGGER.info(requestUrl , "/createPipeline");
    Boolean isUpdating = false;
    try {
      String responseMsg = jenkinsService.createPipeline(pipeline, isUpdating);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();
    } catch (IOException | TransformerException e) {
    	LOGGER.error("Error while creating pipeline : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/checkPipelineName",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody String checkPipelineName(
      @RequestBody String jobName, HttpServletResponse response) throws IOException {
	  LOGGER.info(requestUrl , "/checkPipelineName");
    return jenkinsService.checkJobName(jobName);
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getPipelineDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getPipelineDetails(@RequestParam String pipelineName)
      throws IOException, SAXException, ParserConfigurationException {
	  LOGGER.info(requestUrl , "/getPipelineDetails");
    Gson gson = new Gson();
    try {
      JenkinsPipeline pipeline = jenkinsService.getPipelineDetails(pipelineName);
      return ResponseEntity.ok(gson.toJson(pipeline));
    } catch (IOException | SAXException | ParserConfigurationException e) {
    	LOGGER.error("Error while getting pipeline details: {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getAllPipelineStages",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody @ResponseStatus ResponseEntity<String> getAllPipelineStages(
      @RequestParam String pipelineName)
      throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
	  LOGGER.info(requestUrl , "/getAllPipelineStages");
    Gson gson = new Gson();
    try {
      List<String> pipeline = jenkinsService.getAllPipelineStages(pipelineName);
      return ResponseEntity.ok(gson.toJson(pipeline));
    } catch (IOException
        | SAXException
        | ParserConfigurationException
        | FactoryConfigurationError e) {
    	LOGGER.error("Error while getting pipeline stages : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/updatePipeline",
      method = RequestMethod.POST,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updatePipeline(
      @RequestBody JenkinsPipeline pipeline, HttpServletResponse response)
      throws IOException, TransformerException {
	  LOGGER.info(requestUrl , "/updatePipeline");
    Boolean isUpdating = true;
    try {
      String responseMsg = jenkinsService.createPipeline(pipeline, isUpdating);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();
    } catch (IOException | TransformerException e) {
    	LOGGER.error("Error while updating pipleine : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @SuppressWarnings("unchecked")
  @CrossOrigin
  @RequestMapping(
      value = "/addJobToExistingPipeline",
      method = RequestMethod.POST,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> addJobToExistingPipeline(
      @RequestBody JenkinsPipeline pipeline, HttpServletResponse response)
      throws IOException, TransformerException {
	  LOGGER.info(requestUrl , "/addJobToExistingPipeline");
    try {
      Boolean isUpdating = true;
      String responseMsg = jenkinsService.createPipeline(pipeline, isUpdating);
      if (responseMsg.equals("true")) return ResponseEntity.ok("OK");
      else return (ResponseEntity<String>) ResponseEntity.badRequest();
    } catch (IOException | TransformerException e) {
    	LOGGER.error("Error while adding job to existing pipeline: {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(value = "/deleteItem", method = RequestMethod.POST, produces = "application/json")
  public @ResponseBody ResponseEntity<String> deleteItem(@RequestBody String itemName)
      throws IOException {
	  LOGGER.info(requestUrl , "/deleteItem");
    try {
      jenkinsService.deleteItem(itemName);
      return ResponseEntity.ok("OK");
    } catch (IOException e) {
    	LOGGER.error("Error while deleting item : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/updateUrl",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateUrl(
      @RequestBody JenkinsUrl url, HttpServletResponse response) {
	  LOGGER.info(requestUrl , "/updateUrl");
	  LOGGER.info(url.getUser());
	  url.setId(url.getUser());
    try {
      jenkinsService.updateUrl(url);
      return ResponseEntity.ok("OK");
    } catch (Exception e) {
    	LOGGER.error("Error while updating url : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/updateUser",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateUser(
      @RequestBody JenkinsUser user, HttpServletResponse response) {
	  LOGGER.info(requestUrl , "/updateUser");
    try {
    	user.setId(user.getUser());
      jenkinsService.updateUser(user);
      return ResponseEntity.ok("OK");
    } catch (Exception e) {
    	LOGGER.error("Error while updating user : {} ", e.getMessage());
    	e.printStackTrace();
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/updateConfig",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateConfig(
      @RequestBody JenkinsConfig config, HttpServletResponse response) {
	  LOGGER.info(requestUrl , "/updateConfig");
	  LOGGER.info(config.getUser());
	  config.setId(config.getUser());
    try {
      jenkinsService.updateConfig(config);
      return ResponseEntity.ok("OK");
    } catch (Exception e) {
    	LOGGER.error("Error while updating config : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getConfigDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getConfigDetails() {
	  LOGGER.info(requestUrl , "/getConfigDetails");
    Gson gson = new Gson();
    try {
      JenkinsConfigDto conf = jenkinsService.getConfigDetails();
      return ResponseEntity.ok(gson.toJson(conf, JenkinsConfigDto.class));
    } catch (Exception e) {
    	LOGGER.error("Error while getting config details : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/createNode",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> createNode(
      @RequestBody JenkinsNode node, HttpServletResponse response) throws IOException {
	  LOGGER.info(requestUrl , "/createNode");
    Boolean isUpdating = false;
    try {
      jenkinsService.createNode(node, isUpdating);
      return ResponseEntity.ok("OK");
    } catch (IOException e) {
    	LOGGER.error("Error while creating node : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(value = "/getAllNodes", method = RequestMethod.GET, produces = "application/json")
  public @ResponseBody @ResponseStatus ResponseEntity<String> getAllNodes() throws IOException {
	  LOGGER.info(requestUrl , "/getAllNodes");
    Gson gson = new Gson();
    try {
      List<String> nodeList = jenkinsService.getAllNodes();
      return ResponseEntity.ok(gson.toJson(nodeList));
    } catch (IOException e) {
    	
    	LOGGER.error("Error while getting all nodes : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/getNodeDetails",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> getNodeDetails(@RequestParam String nodeName)
      throws IOException {
	  LOGGER.info(requestUrl , "/getNodeDetails");
    Gson gson = new Gson();
    try {
      JenkinsNode node = jenkinsService.getNodeDetails(nodeName);
      return ResponseEntity.ok(gson.toJson(node));
    } catch (IOException e) {
    	LOGGER.error("Error while getting node details : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/updateNode",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> updateNode(
      @RequestBody JenkinsNode node, HttpServletResponse response) throws IOException {
	  LOGGER.info(requestUrl , "/updateNode");
    Boolean isUpdating = true;
    try {
      jenkinsService.createNode(node, isUpdating);
      return ResponseEntity.ok("OK");
    } catch (IOException e) {
    	LOGGER.error("Error while updating node : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(value = "/deleteNode", method = RequestMethod.POST, produces = "application/json")
  public @ResponseBody ResponseEntity<String> deleteNode(@RequestParam String nodeName)
      throws IOException {
	  LOGGER.info(requestUrl , "/deleteNode");
    try {
      jenkinsService.deleteNode(nodeName);
      return ResponseEntity.ok("OK");
    } catch (IOException e) {
    	LOGGER.error("Error while deleting node : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }

  @CrossOrigin
  @RequestMapping(
      value = "/downloadSlaveAgent",
      method = RequestMethod.GET,
      produces = "application/json")
  public @ResponseBody ResponseEntity<String> downloadSlaveAgent(@RequestParam String slaveName)
      throws IOException {
	  LOGGER.info(requestUrl , "/downloadSlaveAgent");
    try {
      String slaveAgent = jenkinsService.downloadSlaveAgent(slaveName);
      return ResponseEntity.ok(slaveAgent);
    } catch (IOException e) {
    	LOGGER.error("Error while downloading slave agent : {} ", e.getMessage());
      return ResponseEntity.status(500).body(e.getMessage());
    }
  }
}
