package com.mindtree.cpe.dao;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.GenerateView;
import org.ektorp.support.View;

import com.mindtree.cpe.dto.JenkinsJobDto;

public class CPERepo  extends CouchDbRepositorySupport<JenkinsJobDto>  {

	
	public CPERepo(CouchDbConnector db) {
		super(JenkinsJobDto.class, db);
		 initStandardDesignDocument();
	}


	 @GenerateView
     public List<JenkinsJobDto> findByJobType(String jobType) {
		 return  queryView("by_jobType", jobType);  
     }
	 
	 @View( name="by_running", map =  "function(doc) { if(doc.running) {emit(doc.running, doc._id)} }")
	    public List<JenkinsJobDto> getRunningJobs() {	      
	        return  queryView("by_running");
	    }
}
