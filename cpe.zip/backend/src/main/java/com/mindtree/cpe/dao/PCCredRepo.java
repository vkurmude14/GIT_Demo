package com.mindtree.cpe.dao;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.View;

import com.mindtree.cpe.dto.PcCredentialsDto;

public class PCCredRepo extends CouchDbRepositorySupport<PcCredentialsDto> {

	public PCCredRepo(CouchDbConnector db) {
		super(PcCredentialsDto.class, db);
		 initStandardDesignDocument();
	}
	
	 @Override
	    @View( name="all", map =  "function(doc){if(doc.credentialsId)emit(doc._id);}")
	    public List<PcCredentialsDto> getAll() {	      
	        return  queryView("all");
	    }
	
}
