package com.mindtree.cpe.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.ektorp.CouchDbConnector;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.mindtree.cpe.dao.CPERepo;
import com.mindtree.cpe.dao.JenkinsConfigDao;
import com.mindtree.cpe.dao.JenkinsJobDao;
import com.mindtree.cpe.dao.PCCredRepo;
import com.mindtree.cpe.dto.JenkinsConfigDto;
import com.mindtree.cpe.dto.JenkinsJobDto;
import com.mindtree.cpe.dto.PcCredentialsDto;
import com.mindtree.cpe.entity.JenkinsConfig;
import com.mindtree.cpe.entity.JenkinsJob;
import com.mindtree.cpe.entity.JenkinsLRJob;
import com.mindtree.cpe.entity.JenkinsNode;
import com.mindtree.cpe.entity.JenkinsPCJob;
import com.mindtree.cpe.entity.JenkinsPipeline;
import com.mindtree.cpe.entity.JenkinsUrl;
import com.mindtree.cpe.entity.JenkinsUser;
import com.mindtree.cpe.exception.ConfigException;
import com.mindtree.cpe.exception.JenkinsForbidden;
import com.mindtree.cpe.model.JenkinsItems;
import com.mindtree.cpe.util.CouchConfig;
import com.mindtree.cpe.util.ErrorHandler;
import com.mindtree.cpe.util.XmlHandler;


/**
 * @author Abhilash Hegde
 *
 */
@Service
public class JenkinsService{

	JenkinsUrl jenkinsUrl;
	JenkinsUser jenkinsUser;
	JenkinsConfig  jenkinsConfig;

	@Autowired
	JenkinsConfigDao jenkinsConfigDao;

	@Autowired
	JenkinsJobDao jenkinsJobDao;

	@Autowired
	XmlHandler xmlHandler;
	
	

	@Autowired
	ErrorHandler errorHandler;
	CPERepo cpeRepo;
	PCCredRepo pcCredRepo;
	String http = "http";
	String job = "job";
	String config = "config.xml";
	String basic = "Basic";
	String utf = "UTF-8";
	String authorization = "Authorization";
	String contentType = "Content-Type";
	String application = "application/xml";
	String computer = "computer";
	String responseCodeStr ="API RESPONSE - Jenkins Response Code -{} "; 
	String countStr ="Count is {}";
	String emptyStr ="&#x200B;";
	int responseCode;		
	String jobCreated;
	String jenkinsCrumb = "Jenkins-Crumb";
	String requestJenkinsUrl = "API CALL - Jenkins API - {}";
	final String serverURL = "http://127.0.0.1:8086", username = "root", password = "root";
	InfluxDB influxDB = InfluxDBFactory.connect(serverURL);
	private CouchDbConnector dbConnector;
	static int count=0;
	static int errorCount =0;
	static int passedCount =0;
	static int failedCount=0;
	static float hitsCount=0;
	static StringBuilder response = new StringBuilder();
	static int presentScriptNum=0;
	static Long elapsedTime=0L;
	static  List<String> initialTimes=new ArrayList<>();
	static List<String> time= new ArrayList<>();
	

	private static final Logger LOGGER = LoggerFactory.getLogger(JenkinsService.class);
	
	public JenkinsService() {
		try {
			dbConnector = CouchConfig.couchConnector();
			cpeRepo= new CPERepo(dbConnector);

			
		} catch (ConfigException e) {
			LOGGER.error("Error in getting CouchDB Connector");
		}
	}
	
	public String createJob(JenkinsJob jenkinsJob, Boolean isUpdating, String baseUrl) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();

		try {
		URL url;
		if(Boolean.FALSE.equals(isUpdating)) {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/createItem?name="+jenkinsJob.getName());
		} else {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+jenkinsJob.getName()+"/"+config);
		}
		String xml = xmlHandler.createJobXml(jenkinsJob, jenkinsConfig, baseUrl,jenkinsUrl);
	
		responseCode=postContentstoUrl(url, xml);
		}
		catch(Exception e)
		{
			LOGGER.error("Error while creating jmeter job {} ", e.getMessage());
		}
		if(responseCode == 200) {
			JenkinsJobDto jenkinsJobDto = new JenkinsJobDto();
			jenkinsJobDto.setName(jenkinsJob.getName());
			jenkinsJobDto.setApplicationName(jenkinsJob.getApplicationName());
			jenkinsJobDto.setBandwidth(jenkinsJob.getBandwidth());
			jenkinsJobDto.setJobType(jenkinsJob.getJobType());
			jenkinsJobDto.setServers(jenkinsJob.getServers());
			jenkinsJobDto.setId(jenkinsJob.getName());
			jenkinsJobDao.saveJob(jenkinsJobDto);
			jobCreated = checkJobName(jenkinsJob.getName());
			return jobCreated;

		} else {
			errorHandler.throwError(responseCode);
			return null;
		}
	}

	public String createPipeline(JenkinsPipeline jenkinsPipeline, Boolean isUpdating) throws IOException, TransformerException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();

		URL url;
		String xml = "";
		if(Boolean.FALSE.equals(isUpdating)) {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/createItem?name="+jenkinsPipeline.getName());
			xml = xmlHandler.createPipelineXml(jenkinsPipeline);
		}else {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+jenkinsPipeline.getName()+"/"+config);
			String xmlResponse = getPipelineAPI(jenkinsPipeline.getName());
			xml = xmlHandler.updatePipelineXml(jenkinsPipeline, xmlResponse);
			
		}
		LOGGER.info(requestJenkinsUrl , url);
		responseCode=postContentstoUrl(url, xml);
		if(responseCode == 200) {
			jobCreated = checkJobName(jenkinsPipeline.getName());
			return jobCreated;

		} else {
			errorHandler.throwError(responseCode);
			return null;
		}
	}


	public String checkJobName(String jobName) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];

		boolean jobExists = false;
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/checkJobName?value="+jobName);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);
		OutputStream os = conn.getOutputStream();
		LOGGER.info(requestJenkinsUrl , url);
		os.flush();
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

		while ((output = br.readLine()) != null) {
			if(output.contains("A job already exists with the name")) {
				jobExists= true;
			}
		}
		conn.disconnect();

		if(responseCode==200) {
			if(jobExists) {
				return "true";
			}
			else
				return "false";
		} else {
			errorHandler.throwError(responseCode);
		}
		return null;

	}

	public static String encode(String url)  
	{  
		try {  
			return URLEncoder.encode( url, "UTF-8" );  
		} catch (UnsupportedEncodingException e) {  
			return "Issue while encoding" +e.getMessage();  
		}  
	}

	public JenkinsItems getAllJobs( ) throws IOException  {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		ArrayList<String> jobs = new ArrayList<>();
		ArrayList<String> pipelines = new ArrayList<>();
		String jsonStr =null;
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
	    sessionID = sessionID.split(";")[0];		
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/api/json?tree=jobs[name]");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");		
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);

		OutputStream os = conn.getOutputStream();
		os.flush();
		LOGGER.info(requestJenkinsUrl , url);
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));
		while (( output = br.readLine()) != null) {
			if(!output.equals(""))
				output= output.substring(40, output.length()-2);
			jsonStr=output;
		}
		conn.disconnect();

		if(responseCode == 200) {
			JSONArray jsonarr = new JSONArray("["+jsonStr+"]");
			for(int i = 0; i < jsonarr.length(); i++){
				JSONObject jsonobj = jsonarr.getJSONObject(i);
				if(jsonobj.getString("_class").equalsIgnoreCase("hudson.model.FreeStyleProject"))
					jobs.add(jsonobj.getString("name"));
				else if(jsonobj.getString("_class").equalsIgnoreCase("org.jenkinsci.plugins.workflow.job.WorkflowJob"))
					pipelines.add(jsonobj.getString("name"));
			}
			JenkinsItems jenkinsItems= new JenkinsItems();
			jenkinsItems.setJobs(jobs);
			jenkinsItems.setPipelines(pipelines);

			return jenkinsItems;
		} else {
			errorHandler.throwError(responseCode);
			return null;
		}
	}

	public JenkinsJob getJobDetails(String jobName) throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();

		JenkinsJob jenkinsJob=null;
		try {
			String output;
			//crumb
			URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
			HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
					
			String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
			String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
			connCrumb.setDoOutput(true);
			connCrumb.setRequestMethod("GET");
			connCrumb.setRequestProperty (authorization, basicAuth);		
			
			responseCode= connCrumb.getResponseCode();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(connCrumb.getInputStream())));
			String output1="";
			while (( output = br.readLine()) != null) {
				output1=output;
			}
			JSONObject jsonObject = new JSONObject(output1);
			connCrumb.disconnect();
			String crumb=jsonObject.getString("crumb");
			
			List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
			String sessionID = "";
		    if (cookieList != null) {
		        for (String cookieTemp : cookieList) {
		        	sessionID = cookieTemp;
		        }
		    }
		    sessionID = sessionID.split(";")[0];

			
			URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+jobName+"/"+config);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty (authorization, basicAuth);
			conn.setRequestProperty(jenkinsCrumb, crumb);
			conn.setRequestProperty("Cookie", sessionID);
			responseCode= conn.getResponseCode();
			LOGGER.info(responseCodeStr , responseCode);
			BufferedReader in = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String inputLine;
			LOGGER.info(requestJenkinsUrl , url);
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			conn.disconnect();

			jenkinsJob = xmlHandler.parseXml(response, jobName);
			jenkinsJob.setServers(jenkinsJobDao.getJob(jobName).getServers());
			jenkinsJob.setApplicationName(jenkinsJobDao.getJob(jobName).getApplicationName());
			jenkinsJob.setJobType(jenkinsJobDao.getJob(jobName).getJobType());

		}catch (IOException e) {        
			LOGGER.error("Error while getting jmeter job details : {} ", e.getMessage());
		} 
		return jenkinsJob;
	}

	public void updateUrl(JenkinsUrl url) {
		jenkinsConfigDao.saveJenkinsUrl(url);
	}

	public void updateUser(JenkinsUser user) {
		jenkinsConfigDao.saveJenkinsUser(user);

	}

	public void updateConfig(JenkinsConfig config) {
		jenkinsConfigDao.saveJenkinsConfig(config);

	}

	public JenkinsConfigDto getConfigDetails() {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		return new JenkinsConfigDto(jenkinsUrl, jenkinsUser, jenkinsConfig);
	}

	public void createNode(JenkinsNode node, Boolean isUpdating) throws IOException  {
		try {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		LOGGER.info(node.getRootDirectory());
		String url;
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		connCrumb.disconnect();
		if(Boolean.FALSE.equals(isUpdating)) {
			url = http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/computer/doCreateItem?name="+node.getName()+"&type=hudson.slaves.DumbSlave";
		}else {
			url = http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/computer/"+node.getName()+"/"+config;
		}

		URL obj = new URL(url);
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");

		if(Boolean.TRUE.equals(isUpdating)) {
			conn.setRequestProperty(contentType, application);
		}else {
			conn.setRequestProperty(contentType, "application/x-www-form-urlencoded");
		}
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);
		conn.setRequestProperty (authorization, basicAuth);

		if(Boolean.TRUE.equals(isUpdating)) {
			
			String xml = xmlHandler.createNodeXml(node);
			LOGGER.info(xml);
			OutputStream os = conn.getOutputStream();
			os.write(xml.getBytes());
			os.flush();
		}else {
		node.setRootDirectory(node.getRootDirectory().replace("\\", "\\\\"));
		String json = xmlHandler.createNodeJson(node);
		OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
		out.write(json);
		out.close();
		}
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
	    br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));
		while ((output = br.readLine()) != null) {
	 		LOGGER.info(output);
		}

		conn.disconnect();

		if(responseCode != 200) {
			errorHandler.throwError(responseCode);
		}
	}
		catch(Exception e)
		{
			LOGGER.error("Error in creating/updating node : {} ", e.getMessage());
			
		}
	}

	public void deleteNode(String nodeName) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		String url = http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+computer+"/"+nodeName+"/doDelete";
		LOGGER.info(requestJenkinsUrl , url);
		URL obj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		conn.setDoOutput(true);

		conn.setRequestMethod("POST");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);
		try(BufferedReader br1 = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));) {
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		LOGGER.info("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			LOGGER.info(output);
		}		
		}
		catch(Exception e)
		{
			LOGGER.error("Error in deleting Node : {} ", e.getMessage());
		}
		finally
		{
			conn.disconnect();
		}
		List<String> nodes = getAllNodes();
			if(nodes.contains(nodeName))
			{
				errorHandler.throwError(responseCode);
			}
	}

	public List<String> getAllNodes() throws IOException, JenkinsForbidden {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		String jsonStr = null;
		List<String> nodeList = new ArrayList<>();
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
	    sessionID = sessionID.split(";")[0];

		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/computer/api/json?tree=computer[displayName]");
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);

		OutputStream os = conn.getOutputStream();
		os.flush();
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));
	
		while (( output = br.readLine()) != null) {
			if(!output.equals(""))
				output= output.substring(48, output.length()-1);
			jsonStr=output;

		}
		conn.disconnect();
		if(responseCode == 200) {
			JSONArray jsonarr = new JSONArray(jsonStr);
			for(int i = 0; i < jsonarr.length(); i++){
				JSONObject jsonobj = jsonarr.getJSONObject(i);
				if(!jsonobj.getString("displayName").equals("master"))
					nodeList.add(jsonobj.getString("displayName"));
			}
			return nodeList;
		} else {
			errorHandler.throwError(responseCode);
		}
		return new ArrayList<>();
	}


	public JenkinsPipeline getPipelineDetails(String pipelineName) 
			throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
		String response = getPipelineAPI(pipelineName);
		if(response != null) {
			return xmlHandler.parsePipelineXml(response, pipelineName);
		}
		return null;
	}


	public List<String> getAllPipelineStages(String pipelineName) throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
		List<String> pipelineStages;
		String response = getPipelineAPI(pipelineName);
		if(response != null) {
			pipelineStages = xmlHandler.parsePipelineStagesXml(response);
			return pipelineStages;
		}
		return new ArrayList<>();
	}

	private String getPipelineAPI(String pipelineName) throws IOException {	
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+pipelineName+"/"+config);
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);

		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);


		BufferedReader in = new BufferedReader(
				new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuilder response = new StringBuilder();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		conn.disconnect();
		if(responseCode == 200) {
			return response.toString();
		}else {
			errorHandler.throwError(responseCode);
			return null;
		}

	}


	public void deleteItem(String itemName) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		List<String> jobs = getAllJobs().getJobs();
		List<String> pipelines = getAllJobs().getPipelines();
		String type ="";
		if (jobs.contains(itemName)) 
			{
			type ="job";			
			}
		else if(pipelines.contains(itemName))
		{
			type = "pipeline";
		}
		
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+itemName+"/doDelete");
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty(contentType, application);		
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);		
		
		try (BufferedReader br1 = new BufferedReader(new InputStreamReader(
				(conn.getInputStream()))); )
		{
			responseCode= conn.getResponseCode();
			LOGGER.info(responseCodeStr , responseCode );
		LOGGER.info("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			LOGGER.info(output);
		}		
		}
		catch(Exception e)
		{
			LOGGER.error("Error in deleting Item : {} ", e.getMessage());
		}
		finally
		{
			conn.disconnect();
		}
		jobs = getAllJobs().getJobs();
	    pipelines = getAllJobs().getPipelines();
		
			if(jobs.contains(itemName) || pipelines.contains(itemName))
			{
				errorHandler.throwError(responseCode);
			}
			else
			{
				if(type.equalsIgnoreCase("job"))
					jenkinsJobDao.deleteJob(itemName);
			}
		
	}


	public JenkinsNode getNodeDetails(String nodeName) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();

		JenkinsNode node = null;
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+computer+"/"+nodeName+"/"+config);
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);

		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		BufferedReader in = new BufferedReader(
				new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuilder response = new StringBuilder();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		conn.disconnect();

		node = xmlHandler.parseNodeXml(response, nodeName);

		return node;
	}


	public String downloadSlaveAgent(String slaveName) throws IOException {
		String slaveAgent =null;
		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
    sessionID = sessionID.split(";")[0];
		URL url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+computer+"/"+slaveName+"/slave-agent.jnlp");
		LOGGER.info(requestJenkinsUrl , url);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);


		OutputStream os = conn.getOutputStream();
		os.flush();
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr ,responseCode);
		br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));
		while (( output = br.readLine()) != null) {
			if(!output.equals("")) {
				slaveAgent = output;
			}
			LOGGER.info(output);
		}
		conn.disconnect();

		if(responseCode == 200) {
			return slaveAgent;
		} else {
			errorHandler.throwError(responseCode);
			return null;
		}
	}
	

	public String createPCJob(JenkinsPCJob jenkinsPCJob, Boolean isUpdating) throws IOException {
		
		
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		String	cred="";
		PcCredentialsDto pcCred = new PcCredentialsDto();
		PcCredentialsDto proxyCred=new PcCredentialsDto();
		
		URL url;
		URL url1;
		int count =jenkinsJobDao.getPCCredentialCount();
		LOGGER.info(countStr, count);
		pcCred.setPcUsername(jenkinsPCJob.getPcUsername());
		pcCred.setPcPassword(jenkinsPCJob.getPcPassword());
		proxyCred.setPcUsername(jenkinsPCJob.getProxyUsername());
		proxyCred.setPcPassword(jenkinsPCJob.getProxyPassword());
		
		if(Boolean.FALSE.equals(isUpdating))  {
			url = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/createItem?name="+jenkinsPCJob.getName());
			LOGGER.info(requestJenkinsUrl , url);
			
			LOGGER.info("inside create credentials");
			//pcCred
			cred=jenkinsJobDao.isPcCredExists(jenkinsPCJob.getPcUsername(),jenkinsPCJob.getPcPassword());
				if( cred== null)
				{
					cred="cred"+count;
					LOGGER.info(countStr, count);
					pcCred.setCredentialsId(cred);
					pcCred.setId(cred);
					
					url1 = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/credentials/store/system/domain/_/createCredentials");
					LOGGER.info(requestJenkinsUrl , url1);
					String xml1 = xmlHandler.createPCCred(pcCred);
					postContentstoUrl(url1, xml1);				
					jenkinsJobDao.savePCCred(pcCred);
					jenkinsPCJob.setCredentialsID(cred);
				}
				else {
					pcCred.setCredentialsId(cred);
					pcCred.setId(cred);
					jenkinsPCJob.setCredentialsID(cred);
				}
			
			LOGGER.info("cred-:{} ",pcCred.getCredentialsId());
			
			//proxyCred
			
			if(jenkinsPCJob.getProxyOutURL().equalsIgnoreCase("") || (jenkinsPCJob.getProxyUsername().equalsIgnoreCase("") && jenkinsPCJob.getProxyPassword().equalsIgnoreCase("")))
			{
				
				if(jenkinsPCJob.getProxyOutURL().equalsIgnoreCase(""))
					jenkinsPCJob.setProxyOutURL(emptyStr);
				if( (jenkinsPCJob.getProxyUsername().equalsIgnoreCase("") && jenkinsPCJob.getProxyPassword().equalsIgnoreCase("")))
						jenkinsPCJob.setCredentialsProxyId(emptyStr);
			
			}
			else
			{
				count =jenkinsJobDao.getPCCredentialCount();
				LOGGER.info(countStr, count);
				cred=jenkinsJobDao.isPcCredExists(jenkinsPCJob.getProxyUsername(),jenkinsPCJob.getProxyPassword());
					if( cred== null)
					{
						cred="cred"+count;
						LOGGER.info(countStr, count);
						proxyCred.setCredentialsId(cred);
						proxyCred.setId(cred);
						
						url1 = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/credentials/store/system/domain/_/createCredentials");
						LOGGER.info(requestJenkinsUrl , url1);
						String xml1 = xmlHandler.createPCCred(proxyCred);
						postContentstoUrl(url1, xml1);
						jenkinsJobDao.savePCCred(proxyCred);
						jenkinsPCJob.setCredentialsProxyId(cred);
					}
					else {
						proxyCred.setCredentialsId(cred);
						jenkinsPCJob.setCredentialsProxyId(cred);
					}				
			}
			
			LOGGER.info("credProxy -:{} ",proxyCred.getCredentialsId());
		
		} else {
			url = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/job/"+jenkinsPCJob.getName()+"/config.xml");
			LOGGER.info(requestJenkinsUrl , url);
			LOGGER.info("inside update credentials");
			pcCred.setCredentialsId(jenkinsPCJob.getCredentialsID());
			pcCred.setPcUsername(jenkinsPCJob.getPcUsername());
			pcCred.setPcPassword(jenkinsPCJob.getPcPassword());		
			pcCred.setId(jenkinsPCJob.getCredentialsID());
			
			url1 = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/credentials/store/system/domain/_/credential/"+jenkinsPCJob.getCredentialsID()+"/config.xml");
			LOGGER.info(requestJenkinsUrl , url1);
			String xml1 = xmlHandler.createPCCred(pcCred);
			postContentstoUrl(url1, xml1);		
			jenkinsJobDao.savePCCred(pcCred);
			
			//proxyCred
			try {
				
			
	
				proxyCred.setPcUsername(jenkinsPCJob.getProxyUsername());
				proxyCred.setPcPassword(jenkinsPCJob.getProxyPassword());	

			if(jenkinsPCJob.getProxyOutURL().equalsIgnoreCase("") || (jenkinsPCJob.getProxyUsername().equalsIgnoreCase("") && jenkinsPCJob.getProxyPassword().equalsIgnoreCase("")))
			{
				
				if(jenkinsPCJob.getProxyOutURL().equalsIgnoreCase(""))
					jenkinsPCJob.setProxyOutURL(emptyStr);
				if( (jenkinsPCJob.getProxyUsername().equalsIgnoreCase("") && jenkinsPCJob.getProxyPassword().equalsIgnoreCase("")))
						jenkinsPCJob.setCredentialsProxyId(emptyStr);
			
			}
			else
			{
				if(jenkinsPCJob.getCredentialsProxyId().equalsIgnoreCase(""))
				{
					count =jenkinsJobDao.getPCCredentialCount();
					LOGGER.info(countStr, count);
					cred=jenkinsJobDao.isPcCredExists(jenkinsPCJob.getProxyUsername(),jenkinsPCJob.getProxyPassword());
						if( cred== null)
						{
							cred="cred"+count;
							LOGGER.info(countStr, count);
							proxyCred.setCredentialsId(cred);
							proxyCred.setId(cred);
							
							url1 = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/credentials/store/system/domain/_/createCredentials");
							LOGGER.info(requestJenkinsUrl , url1);
							xml1 = xmlHandler.createPCCred(proxyCred);
							postContentstoUrl(url1, xml1);
							jenkinsJobDao.savePCCred(proxyCred);
							jenkinsPCJob.setCredentialsProxyId(cred);
						}
						else {
							proxyCred.setCredentialsId(cred);
							proxyCred.setId(cred);
							jenkinsPCJob.setCredentialsProxyId(cred);
						}				
				}
				else
				{
					proxyCred.setCredentialsId(jenkinsPCJob.getCredentialsProxyId());
					proxyCred.setId(jenkinsPCJob.getCredentialsProxyId());
				}

				
					
				URL url2 = new URL("http://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/credentials/store/system/domain/_/credential/"+jenkinsPCJob.getCredentialsProxyId()+"/config.xml");
				LOGGER.info(requestJenkinsUrl , url2);
				String xml2 = xmlHandler.createPCCred(proxyCred);
				postContentstoUrl(url2, xml2);	
				jenkinsJobDao.savePCCred(proxyCred);
			}
	
			}
			catch(Exception e)
			{
				LOGGER.error("Error while updating proxy credentials : {} ", e.getMessage());
			}
			
		}
		
		String xml = xmlHandler.createPCJobXml(jenkinsPCJob, jenkinsConfig,jenkinsUrl);
		responseCode=postContentstoUrl(url, xml);
		if(responseCode == 200 || responseCode ==400) {
			JenkinsJobDto jenkinsPCJobDto = new JenkinsJobDto();
			jenkinsPCJobDto.setName(jenkinsPCJob.getName());
			jenkinsPCJobDto.setJobType(jenkinsPCJob.getJobType());
			jenkinsPCJobDto.setServers(jenkinsPCJob.getServers());
			jenkinsPCJobDto.setId(jenkinsPCJob.getName());
			jenkinsJobDao.saveJob(jenkinsPCJobDto);
			jobCreated = checkJobName(jenkinsPCJob.getName());
			return jobCreated;

		} else {
			errorHandler.throwError(responseCode);
			
			return null;
		}

	}

	public JenkinsPCJob getPCJobDetails(String jobName) throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
		
		
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();


		JenkinsPCJob jenkinsPCJob = null;
		try {
			
			String output;
			//crumb
			URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
			HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
					
			String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
			String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
			connCrumb.setDoOutput(true);
			connCrumb.setRequestMethod("GET");
			connCrumb.setRequestProperty (authorization, basicAuth);		
			
			responseCode= connCrumb.getResponseCode();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(connCrumb.getInputStream())));
			String output1="";
			while (( output = br.readLine()) != null) {
				output1=output;
			}
			JSONObject jsonObject = new JSONObject(output1);
			connCrumb.disconnect();
			String crumb=jsonObject.getString("crumb");
			
			List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
			String sessionID = "";
		    if (cookieList != null) {
		        for (String cookieTemp : cookieList) {
		        	sessionID = cookieTemp;
		        }
		    }
	    sessionID = sessionID.split(";")[0];
			URL url = new URL("http://" + jenkinsUrl.getHostname() + ":" + jenkinsUrl.getPort() + "/job/" + jobName
					+ "/config.xml");
			LOGGER.info(requestJenkinsUrl , url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty(authorization, basicAuth);
			conn.setRequestProperty(jenkinsCrumb, crumb);
			conn.setRequestProperty("Cookie", sessionID);
			responseCode= conn.getResponseCode();
			LOGGER.info(responseCodeStr , responseCode );
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			conn.disconnect();
			


			jenkinsPCJob = xmlHandler.parsePCJobXml(response, jobName);
			LOGGER.info("proxyouturl - :{} ",jenkinsPCJob.getProxyOutURL());
			if(jenkinsPCJob.getProxyOutURL().equalsIgnoreCase("​"))
			{
				LOGGER.info("inside proxy loop");
				jenkinsPCJob.setProxyOutURL("");
			}
			PcCredentialsDto pcCred2 = jenkinsJobDao.getPCCred(jenkinsPCJob.getCredentialsID());
			PcCredentialsDto proxyCred2 = jenkinsJobDao.getPCCred(jenkinsPCJob.getCredentialsProxyId());
			jenkinsPCJob.setPcUsername(pcCred2.getPcUsername());
			jenkinsPCJob.setPcPassword(pcCred2.getPcPassword());
			if(proxyCred2 == null) {
				jenkinsPCJob.setProxyUsername("");
				jenkinsPCJob.setProxyPassword("");
				jenkinsPCJob.setCredentialsProxyId("");
				
				
			}
			else {
			jenkinsPCJob.setProxyUsername(proxyCred2.getPcUsername());
			jenkinsPCJob.setProxyPassword(proxyCred2.getPcPassword());
			}
			jenkinsPCJob.setServers(jenkinsJobDao.getJob(jobName).getServers());
			
			jenkinsPCJob.setJobType(jenkinsJobDao.getJob(jobName).getJobType());

		} catch (MalformedURLException e) {
			LOGGER.error("Error while getting PC Job details: {} ", e.getMessage());
		} catch (IOException e) {
			LOGGER.error("Error while opening file in getting PC Job details : {} ", e.getMessage());
		}
		return jenkinsPCJob;
	}
	
	int postContentstoUrl(URL url,String xml) throws IOException
	{

		String output;
		//crumb
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
      sessionID = sessionID.split(";")[0];
		
		
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty(contentType, application);		
		conn.setRequestProperty (authorization, basicAuth);
		conn.setRequestProperty(jenkinsCrumb, crumb);
		conn.setRequestProperty("Cookie", sessionID);
		
		
		OutputStream os = conn.getOutputStream();
		os.write(xml.getBytes());
		os.flush();
		responseCode= conn.getResponseCode();
		LOGGER.info(responseCodeStr , responseCode);
		conn.disconnect();
		return responseCode;
	}
	
	
	public String createLRJob(JenkinsLRJob jenkinsLRJob, Boolean isUpdating,String baseUrl) throws IOException {
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();

		
		URL url;
		if(Boolean.FALSE.equals(isUpdating)) {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/createItem?name="+jenkinsLRJob.getName());
		} else {
			url = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/"+job+"/"+jenkinsLRJob.getName()+"/"+config);
		}
		LOGGER.info(requestJenkinsUrl , url);
	
		String xml = xmlHandler.createLRJobXml(jenkinsLRJob, jenkinsConfig,jenkinsUrl,baseUrl);
		
		
		responseCode=postContentstoUrl(url, xml);

		
		if(responseCode == 200) {
			JenkinsJobDto jenkinsJobDto = new JenkinsJobDto();
			jenkinsJobDto.setName(jenkinsLRJob.getName());
			jenkinsJobDto.setJobType(jenkinsLRJob.getJobType());
			jenkinsJobDto.setServers(jenkinsLRJob.getServers());
			jenkinsJobDto.setId(jenkinsLRJob.getName());
			jenkinsJobDao.saveJob(jenkinsJobDto);
			jobCreated = checkJobName(jenkinsLRJob.getName());
			return jobCreated;

		} else {
			errorHandler.throwError(responseCode);
			return null;
		}
		
	}
	
	public JenkinsLRJob getLRJobDetails(String jobName) throws IOException, SAXException, ParserConfigurationException, FactoryConfigurationError {
		
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();


		JenkinsLRJob jenkinsLRJob = null;
		try {
			String output;
			//crumb
			URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
			HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
					
			String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
			String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
			connCrumb.setDoOutput(true);
			connCrumb.setRequestMethod("GET");
			connCrumb.setRequestProperty (authorization, basicAuth);		
			
			responseCode= connCrumb.getResponseCode();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(connCrumb.getInputStream())));
			String output1="";
			while (( output = br.readLine()) != null) {
				output1=output;
			}
			JSONObject jsonObject = new JSONObject(output1);
			connCrumb.disconnect();
			String crumb=jsonObject.getString("crumb");
			
			List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
			String sessionID = "";
		    if (cookieList != null) {
		        for (String cookieTemp : cookieList) {
		        	sessionID = cookieTemp;
		        }
		    }
	    sessionID = sessionID.split(";")[0];
			URL url = new URL("http://" + jenkinsUrl.getHostname() + ":" + jenkinsUrl.getPort() + "/job/" + jobName
					+ "/config.xml");
		
			LOGGER.info(requestJenkinsUrl , url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty(authorization, basicAuth);
			conn.setRequestProperty(jenkinsCrumb, crumb);
			conn.setRequestProperty("Cookie", sessionID);

			responseCode= conn.getResponseCode();
			LOGGER.info(responseCodeStr , responseCode);
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine+"\n");
			}
			in.close();
			conn.disconnect();
		


			jenkinsLRJob = xmlHandler.parseLRJobXml(response, jobName);
			jenkinsLRJob.setResDir(jenkinsConfig.getJenkinsPath());			
			jenkinsLRJob.setServers(jenkinsJobDao.getJob(jobName).getServers());
			jenkinsLRJob.setJobType(jenkinsJobDao.getJob(jobName).getJobType());

		} catch (MalformedURLException e) {
			LOGGER.error("Error while getting LR Job details: {} ", e.getMessage());
		} catch (IOException e) {
			LOGGER.error("Error while opening file in getting LR Job details : {} ", e.getMessage());
		}
		return jenkinsLRJob;
	}

	public JenkinsItems getAllRelativeJobs(String jobType) {
		
		jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
		jenkinsUser = jenkinsConfigDao.getJenkinsUser();
		jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		ArrayList<String> jobs = new ArrayList<>();
		ArrayList<String> pipelines = new ArrayList<>();	
		JenkinsItems jenkinsItems= new JenkinsItems(); 
		List<JenkinsJobDto> relativeJobs = cpeRepo.findByJobType(jobType);
		for(int i=0;i<relativeJobs.size();i++)
		{
			jobs.add(relativeJobs.get(i).getName());
		}
		jenkinsItems.setJobs(jobs);
		jenkinsItems.setPipelines(pipelines);
		
		return jenkinsItems;
	}

	public String jobTrigger(String jobName) {
		String output;
		//crumb
		
		try {	
			jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
			jenkinsUser = jenkinsConfigDao.getJenkinsUser();
			jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
		URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
		HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();
				
		String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
		connCrumb.setDoOutput(true);
		connCrumb.setRequestMethod("GET");
		connCrumb.setRequestProperty (authorization, basicAuth);		
		
		responseCode= connCrumb.getResponseCode();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(connCrumb.getInputStream())));
		String output1="";
		while (( output = br.readLine()) != null) {
			output1=output;
		}
		JSONObject jsonObject = new JSONObject(output1);
		connCrumb.disconnect();
		String crumb=jsonObject.getString("crumb");
		
		List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
		String sessionID = "";
	    if (cookieList != null) {
	        for (String cookieTemp : cookieList) {
	        	sessionID = cookieTemp;
	        }
	    }
	    
		    sessionID = sessionID.split(";")[0];
		   
		   String releaseVersionParam="";
		   if(jenkinsJobDao.getJob(jobName).getJobType().equalsIgnoreCase("LR"))
			   releaseVersionParam=getLRJobDetails(jobName).getRelease();
		   else if(jenkinsJobDao.getJob(jobName).getJobType().equalsIgnoreCase("PC"))
			   releaseVersionParam=getPCJobDetails(jobName).getRelease();
		   else {
			   releaseVersionParam=getJobDetails(jobName).getRelease();
		   }
		   
		    URL url = new URL("http://" + jenkinsUrl.getHostname() + ":" + jenkinsUrl.getPort() + "/job/" + jobName
					+ "/buildWithParameters?releaseVersion="+releaseVersionParam);
		
			LOGGER.info(requestJenkinsUrl , url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty(authorization, basicAuth);
			conn.setRequestProperty(jenkinsCrumb, crumb);
			conn.setRequestProperty("Cookie", sessionID);
		
			responseCode= conn.getResponseCode();
			LOGGER.info(responseCodeStr , responseCode);
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine+"\n");
			}
			in.close();
			conn.disconnect();
			if(responseCode==200 || responseCode ==201)
			{
				return "true";
			}
			else
				return null;
			
	
	
	} catch (Exception e) {
		LOGGER.error("Error while triggering the job: {} ", e.getMessage());
	}

    
		return null;
	}

	public String parseLRMetrics(final String jobName) {
			
		count=0;
		errorCount =0;
		passedCount =0;
		failedCount=0;
		hitsCount=0;
		response = new StringBuilder();
		presentScriptNum=0;
		elapsedTime=0L;
		initialTimes=new ArrayList<>();
		time= new ArrayList<>();
		
		try {	
			
		    
		    
		    final Timer timer = new Timer();
	
		    final JenkinsLRJob jenkinsLRJob = getLRJobDetails(jobName);
		    timer.schedule(new TimerTask()
		    {
		      public void run()
		      {
		    	  try {	    jenkinsUrl = jenkinsConfigDao.getJenkinsUrl();
					jenkinsUser = jenkinsConfigDao.getJenkinsUser();
					jenkinsConfig = jenkinsConfigDao.getJenkinsConfig();
			
					
					List<String> preScripts= jenkinsLRJob.getTestScriptsPath();
					String userpass = jenkinsUser.getUsername() + ":" + jenkinsUser.getPassword();
					String  basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes(utf));
					URL urlCrumb = new URL(http+"://"+jenkinsUrl.getHostname()+":"+jenkinsUrl.getPort()+"/crumbIssuer/api/json");
					HttpURLConnection connCrumb = (HttpURLConnection) urlCrumb.openConnection();				
					connCrumb.setDoOutput(true);
					connCrumb.setRequestMethod("GET");
					connCrumb.setRequestProperty (authorization, basicAuth);		
				
				responseCode= connCrumb.getResponseCode();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(connCrumb.getInputStream())));
				String output1="";
				String output="";
				while (( output = br.readLine()) != null) {
					output1=output;
				}
				JSONObject jsonObject = new JSONObject(output1);
				connCrumb.disconnect();
				String crumb=jsonObject.getString("crumb");		
				List<String> cookieList = connCrumb.getHeaderFields().get("Set-Cookie");
				String sessionID = "";
			    if (cookieList != null) {
			        for (String cookieTemp : cookieList) {
			        	sessionID = cookieTemp;
			        }
			    }
			    
				    sessionID = sessionID.split(";")[0];
				    URL url = new URL("http://" + jenkinsUrl.getHostname() + ":" + jenkinsUrl.getPort() + "/job/" + jobName
							+ "/lastBuild/consoleText");
				
					LOGGER.info(requestJenkinsUrl , url);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setDoOutput(true);
					conn.setRequestMethod("GET");
					conn.setRequestProperty(authorization, basicAuth);
					conn.setRequestProperty(jenkinsCrumb, crumb);
					conn.setRequestProperty("Cookie", sessionID);
				
					responseCode= conn.getResponseCode();
					LOGGER.info(responseCodeStr , responseCode);
					BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String inputLine;
					
					 List<String> scripts = new ArrayList<>();
					 
					 StringBuilder response1= new StringBuilder();
						while ((inputLine = in.readLine()) != null) {
							 response1.append(inputLine+"\n");
						}
					if (( StringUtils.difference(response.toString(), response1.toString())) != null) 
					{
						
						String diff =StringUtils.difference(response.toString(), response1.toString());
						response.append(diff);	
						String line;
						
						BufferedReader bufReader = new BufferedReader(new StringReader(diff));
						

						
						while( (line=bufReader.readLine()) != null )
						{

							
							inputLine=line;
							
							count++;
						
							//status of the job 
							Pattern patternFinish = Pattern.compile("Finished: (.*)",Pattern.DOTALL);
							Matcher matcherFinish = patternFinish.matcher(inputLine);
							 if (matcherFinish.find()) {
								LOGGER.info("Timer stopped");
								 timer.cancel();
								 timer.purge();		
								
								 }
							 //No:of scenarios completed
							Pattern patternTestComplete = Pattern.compile("Test complete:(.*)",Pattern.DOTALL);
							Matcher matcherTestComplete = patternTestComplete.matcher(inputLine);
								 if (matcherTestComplete.find() && presentScriptNum<preScripts.size()) {
									
								
									presentScriptNum = presentScriptNum+1;
															
									 }
				

							Pattern patternInitialTime = Pattern.compile("(.*) Running: ",Pattern.DOTALL);
							Matcher matcherInitialTime = patternInitialTime.matcher(inputLine);
							 if (matcherInitialTime.find()) {
								
								 initialTimes.add(matcherInitialTime.group(1));
							
								 }
							
						
							 Pattern patternScriptName = Pattern.compile("Preparing scenario (.*?) for execution.");
							 Matcher matcherScriptName = patternScriptName.matcher(inputLine);
						//	 String presentScenario;
							 if (matcherScriptName.find()) {
								
								 scripts.add(matcherScriptName.group(1));	
								
								 }
							//Elapsed Time
								Pattern patternTime = Pattern.compile("Elapsed Time \\(D:H:M:S\\): (.*)",Pattern.DOTALL);
								Matcher matcherTime = patternTime.matcher(inputLine);
							
								if(matcherTime.find())
								{
									count=1;
									time=Arrays.asList(matcherTime.group(1).split(":"));
									
							
									String myDate = initialTimes.get(presentScriptNum);
									SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
									Date date = sdf.parse(myDate);
									long millis = date.getTime();
								
									elapsedTime=((long) ((Integer.parseInt(time.get(0)))*86400)+
											(long) ((Integer.parseInt(time.get(1)))*3600)+
											(long) ((Integer.parseInt(time.get(2)))*60)+
											(long) ((Integer.parseInt(time.get(3)))));
									elapsedTime=elapsedTime*1000+millis;
							
								}
							 
							//Error
							Pattern patternError = Pattern.compile("Error count: (.*)",Pattern.DOTALL);
							Matcher matcherError = patternError.matcher(inputLine);
						
							if(matcherError.find())
							{
								count=2;
								errorCount = Integer.parseInt(matcherError.group(1));
								
							}
							//Passed Transactions
							Pattern patternPassed = Pattern.compile("Passed transactions: (.*)",Pattern.DOTALL);
							Matcher matcherPassed = patternPassed.matcher(inputLine);
						
							if(matcherPassed.find())
							{
								count=3;
								passedCount=  Integer.parseInt(matcherPassed.group(1));
								
							}
							//Failed Transactions
							Pattern patternFailed = Pattern.compile("Failed transactions: (.*)",Pattern.DOTALL);
							Matcher matcherFailed = patternFailed.matcher(inputLine);
						
							if(matcherFailed.find())
							{
								count=4;
								failedCount=  Integer.parseInt(matcherFailed.group(1));
								
							}
							//Hits Per Second
							Pattern patternHits = Pattern.compile("Hits per second: (.*)",Pattern.DOTALL);
							Matcher matcherHits = patternHits.matcher(inputLine);
						
							if(matcherHits.find())
							{
								count=5;
								hitsCount =  Float.parseFloat(matcherHits.group(1));
								
							}
							
							if(count ==5)
							{
								influxDB.setDatabase("telegraf");

								
								BatchPoints batchPoints = BatchPoints.database("telegraf").build();
							    Point point1 = Point
							            .measurement("LR")
							            .time(elapsedTime, TimeUnit.MILLISECONDS)
							            .addField("errors", errorCount)
							            .addField("Passed transactions", passedCount)
							            .addField("Failed transactions", failedCount)
							            .addField("Hits per sec", hitsCount)
							            .tag("ScenarioName", preScripts.get(presentScriptNum))
							            .build();
							    batchPoints.point(point1);
							    influxDB.write(batchPoints);
							  
								
							}
						}					
														
					}
					
						
					in.close();
					conn.disconnect();}
		      catch(Exception e)
		      {
		    	  e.printStackTrace();
		      }
		    }}, 0,jenkinsLRJob.getPollInterval()*1000 ); 
		        }
		        catch( Exception e )
		        {
		            e.printStackTrace();
		        }
			if(responseCode==200 || responseCode ==201)
			{
				return "true";
			}
			else
				return null;
			/*	} catch (Exception e) {
		LOGGER.error("Error while triggering the job: {} ", e.getMessage());
	}*/

    
		//return null;
	
		
	}

}