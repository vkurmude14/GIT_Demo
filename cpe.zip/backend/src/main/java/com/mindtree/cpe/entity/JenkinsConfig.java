package com.mindtree.cpe.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"id", "revision"})
public class JenkinsConfig {
	
	@JsonProperty("_id")
	private String id;
	@JsonProperty("_rev")
    private String revision;
	private String user;
	private String jmf;
	private String grafana;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	private String jenkinsPath;
	private String jmeterHome;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getJmf() {
		return jmf;
	}
	public void setJmf(String jmf) {
		this.jmf = jmf;
	}
	public String getGrafana() {
		return grafana;
	}
	public void setGrafana(String grafana) {
		this.grafana = grafana;
	}
	public String getJenkinsPath() {
		return jenkinsPath;
	}
	public void setJenkinsPath(String jenkinsPath) {
		this.jenkinsPath = jenkinsPath;
	}
	public String getJmeterHome() {
		return jmeterHome;
	}
	public void setJmeterHome(String jmeterHome) {
		this.jmeterHome = jmeterHome;
	}
	 public String getRevision() {
         return revision;
     }
	@Override
	public String toString() {
		return "JenkinsConfig [user=" + user + ", jmf=" + jmf + ", grafana=" + grafana + ", jenkinsPath=" + jenkinsPath
				+ ", jmeterHome=" + jmeterHome + "]";
	}
}
