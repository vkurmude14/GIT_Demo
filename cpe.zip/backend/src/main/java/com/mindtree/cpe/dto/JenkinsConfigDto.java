package com.mindtree.cpe.dto;

import com.mindtree.cpe.entity.JenkinsConfig;
import com.mindtree.cpe.entity.JenkinsUrl;
import com.mindtree.cpe.entity.JenkinsUser;

public class JenkinsConfigDto {
	private JenkinsUrl url;
	private JenkinsUser user;
	private JenkinsConfig config;
	public JenkinsUrl getUrl() {
		return url;
	}
	public void setUrl(JenkinsUrl url) {
		this.url = url;
	}
	public JenkinsUser getUser() {
		return user;
	}
	public void setUser(JenkinsUser user) {
		this.user = user;
	}
	public JenkinsConfig getConfig() {
		return config;
	}
	public void setConfig(JenkinsConfig config) {
		this.config = config;
	}
	public JenkinsConfigDto(JenkinsUrl url, JenkinsUser user, JenkinsConfig config) {
		super();
		this.url = url;
		this.user = user;
		this.config = config;
	}
	


	
}
