package com.mindtree.emp.entity;

import javax.persistence.*;

@Entity

public class Employee {
	@Id
	@GeneratedValue
	private Long eid;
	private String ename;

	@Column(unique = true)
	private String eemail;

	@Column(unique = true)
	private String phoneno;
	
	@OneToOne(cascade=CascadeType.ALL)
    private Address address;
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Long getEid() {
		return eid;
	}

	public void setEid(Long eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEemail() {
		return eemail;
	}

	public void setEemail(String eemail) {
		this.eemail = eemail;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eemail=" + eemail + ", phoneno=" + phoneno + "]";
	}
	
	

}
