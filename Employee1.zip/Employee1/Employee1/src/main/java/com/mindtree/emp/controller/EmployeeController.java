package com.mindtree.emp.controller;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.emp.entity.Employee;
import com.mindtree.emp.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/")
	@ResponseBody
	public ResponseEntity<Collection<Employee>> getAllEmployees() {
		Collection<Employee> employees = employeeService.findAll();
		return new ResponseEntity<>(employees, HttpStatus.OK);
	}

	// Finding employee by ID:
	@RequestMapping("/{eid}")
	@ResponseBody
	public ResponseEntity<Optional<Employee>> getEmployeeById(@PathVariable("eid") Long id) {
		Optional<Employee> employee = employeeService.findById(id);
		return new ResponseEntity<>(employee, HttpStatus.OK);
	}

	// Creating New Employee
	@PostMapping(path = "/", consumes = { "application/json" })
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {
		Employee newEmployee = employeeService.create(employee);
		return new ResponseEntity<>(newEmployee, HttpStatus.CREATED);
	}

	// Deleting an Employee:
	@DeleteMapping("/{eid}")
	public ResponseEntity<?> deleteEmployee(@PathVariable("eid") Long eid) {
		employeeService.delete(eid);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	// Updating an Employee:
	@PutMapping(path = "/", consumes = { "application/json" })
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) {
		Employee updateEmployee = employeeService.update(employee);
		return new ResponseEntity<>(updateEmployee, HttpStatus.OK);
	}

}
