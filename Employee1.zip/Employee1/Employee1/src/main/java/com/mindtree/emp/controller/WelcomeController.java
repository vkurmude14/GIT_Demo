package com.mindtree.emp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
	@GetMapping("/home")
	public String welCome() {
		return "Welcome to Mindtree";
	}
}
