package com.mindtree.emp.service;

import java.util.List;

import com.mindtree.emp.entity.Address;

public interface AddressService {
	List<Address> findAll();
}
