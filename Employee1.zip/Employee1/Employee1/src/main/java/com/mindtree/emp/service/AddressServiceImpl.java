package com.mindtree.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.emp.dao.AddressRepo;
import com.mindtree.emp.entity.Address;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepo addressData;
	
	
	public List<Address> findAll() {
		List<Address> addressess=addressData.findAll();
		return addressess;
	
		
	}

}
