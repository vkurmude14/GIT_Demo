package com.mindtree.emp.service;

import java.util.Collection;
import java.util.Optional;

import com.mindtree.emp.entity.Employee;

public interface EmployeeService {
	Collection<Employee> findAll();
	
	Optional<Employee> findById(Long eid);

	Employee create(Employee employee);

	Employee update(Employee employee);

    void delete(Long id);
}
