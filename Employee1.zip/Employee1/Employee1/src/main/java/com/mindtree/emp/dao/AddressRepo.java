package com.mindtree.emp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mindtree.emp.entity.Address;

@Repository
@Component
public interface AddressRepo extends JpaRepository<Address,Long> {

}
