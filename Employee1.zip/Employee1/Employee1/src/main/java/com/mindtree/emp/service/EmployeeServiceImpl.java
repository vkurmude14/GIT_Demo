package com.mindtree.emp.service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mindtree.emp.dao.EmployeeRepo;
import com.mindtree.emp.entity.Employee;

@Service
@Component
public class EmployeeServiceImpl implements EmployeeService {
	
	
	@Autowired
	private EmployeeRepo empRepo;

	public Collection<Employee> findAll() {

		Collection<Employee> employees = empRepo.findAll();

		return employees;
	}

	public Optional<Employee> findById(Long eid) {
		// TODO Auto-generated method stub
		Optional<Employee> emp = empRepo.findById(eid);

		return emp;
	}

	public Employee create(Employee employee) {

		Employee savedEmployee = empRepo.save(employee);

		return savedEmployee;
	}

	@Override
	public Employee update(Employee employee) {
		// TODO Auto-generated method stub
		Employee updatedEmployee = empRepo.save(employee);

		return updatedEmployee;
	}

	@Override
	public void delete(Long id) {
		empRepo.deleteById(id);
		
	}
}
